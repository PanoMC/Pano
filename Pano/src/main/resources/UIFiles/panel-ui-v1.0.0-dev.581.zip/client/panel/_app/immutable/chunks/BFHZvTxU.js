var e=`--_masonry-layout-col-count`,t=`--_masonry-layout-gap`,n=new Map;function r(e,t,n){let r=parseFloat(e.getAttribute(t)||``);return isNaN(r)?n:r}function i(e,t,n){return isNaN(t)?Math.max(1,Math.ceil(e/n)):t}function a(e,t,r){let i=n.get(r);i!=null&&window.clearTimeout(i),n.set(r,window.setTimeout(e,t))}function o(e){let t=0,n=1/0;return e.forEach((e,r)=>{e<n&&(n=e,t=r)}),t}var s=document.createElement(`template`);s.innerHTML=`
  <style>
    :host {
      display: flex;
      align-items: flex-start;
      justify-content: stretch;
    }

    .column {
	  max-width: calc((100% / var(${e}, 1) - ((var(${t}, 24px) * (var(${e}, 1) - 1) / var(${e}, 1)))));
	  width: 100%;
      flex: 1;
      display: flex;
      flex-direction: column;
    }

    .column:not(:last-child) {
      margin-inline-end: var(${t}, 24px);
    }

    .column ::slotted(*) {
      margin-block-end: var(${t}, 24px);
      box-sizing: border-box;
      width: 100%;
    }

    /* Hide the items that has not yet found the correct slot */
    #unset-items {
      opacity: 0;
      position: absolute;
      pointer-events: none;
    }
  </style>
  <div id="unset-items">
    <slot></slot>
  </div>
`;var c=class extends HTMLElement{static get observedAttributes(){return[`maxcolwidth`,`gap`,`cols`]}set maxColWidth(e){this.setAttribute(`maxcolwidth`,e.toString())}get maxColWidth(){return r(this,`maxcolwidth`,500)}set cols(e){this.setAttribute(`cols`,e.toString())}get cols(){return r(this,`cols`,`auto`)}set gap(e){this.setAttribute(`gap`,e.toString())}get gap(){return r(this,`gap`,24)}set debounce(e){this.setAttribute(`debounce`,e.toString())}get debounce(){return r(this,`debounce`,300)}get $columns(){return Array.from(this.shadowRoot.querySelectorAll(`.column`))}constructor(){super(),this.debounceId=`layout_${Math.random()}`,this.ro=void 0,this.currentRequestAnimationFrameCallback=void 0,this.attachShadow({mode:`open`}).appendChild(s.content.cloneNode(!0)),this.onSlotChange=this.onSlotChange.bind(this),this.onResize=this.onResize.bind(this),this.layout=this.layout.bind(this),this.$unsetElementsSlot=this.shadowRoot.querySelector(`#unset-items > slot`)}connectedCallback(){this.$unsetElementsSlot.addEventListener(`slotchange`,this.onSlotChange),`ResizeObserver`in window?(this.ro=new ResizeObserver(this.onResize),this.ro.observe(this)):window.addEventListener(`resize`,this.onResize)}disconnectedCallback(){this.$unsetElementsSlot.removeEventListener(`slotchange`,this.onSlotChange),window.removeEventListener(`resize`,this.onResize),this.ro!=null&&this.ro.unobserve(this)}attributeChangedCallback(e){e===`gap`&&this.style.setProperty(t,`${this.gap}px`),this.scheduleLayout()}onSlotChange(){(this.$unsetElementsSlot.assignedNodes()||[]).filter(e=>e.nodeType===1).length>0&&this.layout()}onResize(e){let{width:t}=e!=null&&Array.isArray(e)&&e.length>0?e[0].contentRect:{width:this.offsetWidth};i(t,this.cols,this.maxColWidth)!==this.$columns.length&&this.scheduleLayout()}renderCols(t){let n=this.$columns;if(n.length!==t){for(let e of n)e.parentNode&&e.parentNode.removeChild(e);for(let e=0;e<t;e++){let t=document.createElement(`div`);t.classList.add(`column`),t.setAttribute(`part`,`column column-${e}`);let n=document.createElement(`slot`);n.setAttribute(`name`,e.toString()),t.appendChild(n),this.shadowRoot.appendChild(t)}this.style.setProperty(e,t.toString())}}scheduleLayout(e=this.debounce){a(this.layout,e,this.debounceId)}layout(){this.currentRequestAnimationFrameCallback!=null&&window.cancelAnimationFrame(this.currentRequestAnimationFrameCallback),this.currentRequestAnimationFrameCallback=requestAnimationFrame(()=>{let e=this.gap,t=Array.from(this.children).filter(e=>e.nodeType===1),n=i(this.offsetWidth,this.cols,this.maxColWidth),r=Array(n).fill(0),a=[];for(let n of t){let t=n.getBoundingClientRect().height,i=o(r);r[i]+=t+e;let s=i.toString();n.slot!==s&&a.push(()=>n.slot=s)}for(let e of a)e();this.renderCols(n)})}};customElements.define(`masonry-layout`,c);