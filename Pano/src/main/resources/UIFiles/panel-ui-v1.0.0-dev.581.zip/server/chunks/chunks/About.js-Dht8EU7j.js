import { J as getContext, Z as escape_html, Q as store_get, T as attr, U as stringify, P as ensure_array_like, S as unsubscribe_stores, O as bind_props } from './index-server.js-DdhL7Abu.js';
import { e as buildQueryParams, b as ApiUtil, P as PANO_WEBSITE_URL } from './Store.js-DT3aZHRb.js';
import { $ as $format } from './runtime.js-BzHEw_ze.js';
import './server.js-BlClO2ED.js';
import './internal2.js-CNe5OZUJ.js';
import './routing.js-N-OPb2ye.js';

//#region src/lib/pages/settings/About.svelte
async function load(event) {
	const { parent } = event;
	await parent();
	const queryParams = buildQueryParams({ type: "ABOUT" });
	const apiData = await ApiUtil.get({
		path: "/api/panel/settings" + queryParams,
		request: event
	});
	let licenses = [];
	try {
		licenses = (await ApiUtil.get({
			path: "/api/panel/licenses/oss",
			request: event
		})).data;
		if (!Array.isArray(licenses)) licenses = [];
	} catch (e) {
		console.log(e);
		console.warn("Lisans dosyası bulunamadı. Lütfen 'npm run generate-licenses' komutunu çalıştırın.");
	}
	return {
		...apiData,
		licenses
	};
}
function About($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let data = $$props["data"];
		getContext("pageTitle").set("pages.settings.about.title");
		const licenses = data.licenses || [];
		$$renderer.push(`<div class="row g-3"><div class="col-lg-6 order-2 order-lg-1"><div class="card"><div class="card-header">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.about.info"))}</div> <div class="card-body"><form><div class="row"><label class="col-md-6 col-form-label" for="panoVersion">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.about.version"))}</label> <div class="col-md-6 col-form-label"><span class="user-select-all font-monospace" aria-describedby="panoVersion" id="panoVersion">${escape_html(data.platformVersion)}</span> <button type="button" class="btn btn-sm btn-link px-0 text-decoration-none ms-2"><i class="fa-solid fa-magic-wand-sparkles me-1"></i> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.whats-new.title"))}</button></div></div> <div class="row"><label class="col-md-6 col-form-label" for="siteKeywords">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.about.release"))}</label> <div class="col-md-6 col-form-label"><span aria-describedby="panoRelease" id="panoRelease">${escape_html(data.platformStage)}</span></div></div> <div class="row mb-0"><label class="col-md-6 col-form-label" for="siteKeywords">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.about.website"))}</label> <div class="col-md-6 col-form-label"><a class="btn btn-sm btn-link px-0 text-decoration-none" aria-describedby="panoWebsite"${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("pages.settings.about.website"))}${attr("href", PANO_WEBSITE_URL)} id="panoWebsite"${attr("title", store_get($$store_subs ??= {}, "$_", $format)("pages.settings.about.website"))} target="_blank"><i class="fa-solid fa-up-right-from-square"></i></a></div></div> <div class="row mb-0"><label class="col-md-6 col-form-label" for="siteKeywords">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.about.discord"))}</label> <div class="col-md-6 col-form-label"><a class="btn btn-sm btn-link px-0 text-decoration-none" aria-describedby="panoWebsite" aria-label="Discord"${attr("href", `${stringify(PANO_WEBSITE_URL)}/discord`)} id="panoWebsite" title="Discord" target="_blank"><i class="fab fa-discord fa-lg"></i></a></div></div></form></div></div></div> <div class="col-lg-6 order-1 order-lg-2"><div class="alert alert-primary h-100 mb-0 d-flex flex-column blocks border"><h5 class="alert-heading">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.about.support-pano"))}</h5> <p class="mb-3">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.about.support-pano-text"))}</p> <div class="mt-auto d-flex gap-3"><a${attr("href", `${stringify(PANO_WEBSITE_URL)}/source-code`)} target="_blank" class="btn btn-link p-0 text-decoration-none d-flex align-items-center"><i class="fa-brands fa-github fa-lg me-2"></i> <span class="fw-bold">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.about.support-pano-button"))}</span></a> <a${attr("href", `${stringify(PANO_WEBSITE_URL)}/donate`)} target="_blank" class="btn btn-link p-0 text-decoration-none d-flex align-items-center"><i class="fa-solid fa-donate fa-lg me-2"></i> <span class="fw-bold">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.about.support-pano-donate"))}</span></a></div></div></div></div> <div class="card"><div class="card-header">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.about.open-source-licenses"))}</div> <div class="card-body">`);
		if (licenses && licenses.length > 0) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<div class="list-group"><!--[-->`);
			const each_array = ensure_array_like(licenses);
			for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
				let license = each_array[$$index];
				$$renderer.push(`<details class="list-group-item"><summary class="d-flex justify-content-between align-items-center list-unstyled mb-0"><div class="d-flex align-items-center flex-wrap gap-2 text-break"><i class="fa-solid fa-chevron-right me-2"></i> <strong class="me-2">${escape_html(license.name)}</strong> <span class="small">v${escape_html(license.version)}</span></div> `);
				if (license.homepage) {
					$$renderer.push("<!--[0-->");
					$$renderer.push(`<a${attr("href", license.homepage)} target="_blank" rel="noopener noreferrer" class="text-decoration-none ms-2"${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("pages.settings.about.open-homepage", { values: { name: license.name } }))}><i class="fa-solid fa-external-link"></i></a>`);
				} else $$renderer.push("<!--[-1-->");
				$$renderer.push(`<!--]--></summary> <div class="pt-3">`);
				if (license.author) {
					$$renderer.push("<!--[0-->");
					$$renderer.push(`<p class="mb-2"><strong>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.about.author"))}:</strong> ${escape_html(license.author)}</p>`);
				} else $$renderer.push("<!--[-1-->");
				$$renderer.push(`<!--]--> `);
				if (license.repository) {
					$$renderer.push("<!--[0-->");
					$$renderer.push(`<p class="mb-2"><strong>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.about.repository"))}:</strong> <a${attr("href", license.repository)} target="_blank" rel="noopener noreferrer" class="ms-1 text-break">${escape_html(license.repository)} <i class="fa-solid fa-up-right-from-square ms-1"></i></a></p>`);
				} else $$renderer.push("<!--[-1-->");
				$$renderer.push(`<!--]--> `);
				if (license.licenseText) {
					$$renderer.push("<!--[0-->");
					$$renderer.push(`<pre class="bg-body-secondary p-3 rounded small border" style="max-height: 300px; overflow: auto;"><code class="text-body">${escape_html(license.licenseText)}</code></pre>`);
				} else {
					$$renderer.push("<!--[-1-->");
					$$renderer.push(`<p><strong>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.about.license"))}:</strong> ${escape_html(license.license)}</p>`);
				}
				$$renderer.push(`<!--]--></div></details>`);
			}
			$$renderer.push(`<!--]--></div>`);
		} else {
			$$renderer.push("<!--[-1-->");
			$$renderer.push(`<p>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.about.no-licenses"))}</p>`);
		}
		$$renderer.push(`<!--]--></div></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
		bind_props($$props, { data });
	});
}

export { About as A, load as l };
//# sourceMappingURL=About.js-Dht8EU7j.js.map
