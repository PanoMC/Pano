import { e as error } from './exports2.js-VkmSkXbz.js';
import { J as getContext, Z as escape_html, Q as store_get, P as ensure_array_like, S as unsubscribe_stores, O as bind_props } from './index-server.js-DdhL7Abu.js';
import './stores.js-D5xmrOAP.js';
import { e as buildQueryParams, b as ApiUtil } from './Store.js-DT3aZHRb.js';
import { $ as $format } from './runtime.js-BzHEw_ze.js';
import 'node:module';
import './server.js-BlClO2ED.js';
import './internal2.js-CNe5OZUJ.js';
import './routing.js-N-OPb2ye.js';
import { N as NoContent } from './NoContent.js-Coj2fA9d.js';
import { S as SearchInput } from './SearchInput.js-DPW0WADK.js';
import { P as Pagination } from './Pagination.js-sd1xTcbW.js';
import { A as ActivityLogRow, V as ViewActivityLogModal } from './ViewActivityLogModal.js-BQcvB1fM.js';

//#region src/lib/pages/ActivityLogs.svelte
async function load(event) {
	const { parent, url: { searchParams } } = event;
	await parent();
	const page = parseInt(searchParams.get("page")) || 1;
	const search = searchParams.get("search")?.trim() || "";
	const locale = searchParams.get("locale")?.trim() || "";
	const queryParams = buildQueryParams({
		page,
		search: search || void 0,
		locale: locale || void 0
	});
	const body = await ApiUtil.get({
		path: `/api/panel/logs/activity` + queryParams,
		request: event
	});
	if (body.error) {
		if (body.error === "PAGE_NOT_FOUND") throw error(404, body.error);
		throw error(500, body.error);
	}
	return {
		logs: body.data,
		meta: {
			...body.meta,
			page
		},
		search
	};
}
function ActivityLogs($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let data = $$props["data"];
		let search = data.search || "";
		let isSearching = false;
		let visibleLogCount = data.meta.filteredCount || data.meta.totalCount;
		getContext("pageTitle").set("pages.activity-logs.title");
		visibleLogCount = data.meta.filteredCount || data.meta.totalCount;
		$$renderer.push(`<div class="container vstack gap-3"><div class="card"><div class="card-header d-flex flex-wrap align-items-center justify-content-between gap-2"><span>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.activity-logs.card-title", { values: { count: visibleLogCount } }))}</span> <div style="width: min(100%, 280px);">`);
		SearchInput($$renderer, {
			initialValue: search,
			searching: isSearching,
			debounceMs: 300,
			ariaLabelKey: "buttons.find",
			placeholderKey: "buttons.find"
		});
		$$renderer.push(`<!----></div></div> `);
		if (data.logs.length === 0) {
			$$renderer.push("<!--[0-->");
			NoContent($$renderer, {});
		} else {
			$$renderer.push("<!--[-1-->");
			$$renderer.push(`<div class="list-group list-group-flush"><!--[-->`);
			const each_array = ensure_array_like(data.logs);
			for (let index = 0, $$length = each_array.length; index < $$length; index++) {
				let log = each_array[index];
				ActivityLogRow($$renderer, { log });
			}
			$$renderer.push(`<!--]--></div>`);
		}
		$$renderer.push(`<!--]--> <div class="card-footer">`);
		Pagination($$renderer, {
			page: data.meta.page,
			totalPage: data.meta.totalPage
		});
		$$renderer.push(`<!----></div></div></div> `);
		ViewActivityLogModal($$renderer);
		$$renderer.push(`<!---->`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
		bind_props($$props, { data });
	});
}

export { ActivityLogs as A, load as l };
//# sourceMappingURL=ActivityLogs.js-CgEdvaRe.js.map
