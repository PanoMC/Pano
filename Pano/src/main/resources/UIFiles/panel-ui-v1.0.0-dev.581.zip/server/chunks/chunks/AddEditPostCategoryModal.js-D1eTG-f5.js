import { Q as store_get, Z as escape_html, T as attr, V as attr_class, S as unsubscribe_stores, F as writable } from './index-server.js-DdhL7Abu.js';
import 'node:module';
import './stores.js-D5xmrOAP.js';
import './server.js-BlClO2ED.js';
import './internal2.js-CNe5OZUJ.js';
import './routing.js-N-OPb2ye.js';
import './ToastContainer.js-Bv1jJ2dr.js';
import { $ as $format } from './runtime.js-BzHEw_ze.js';
import './tooltip.util.js-BeLZL-Tj.js';

var mode = writable("create");
var category = writable({});
var errors = writable([]);
function AddEditPostCategoryModal($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let buttonDisabled;
		buttonDisabled = !store_get($$store_subs ??= {}, "$category", category).title;
		$$renderer.push(`<div class="modal fade" role="dialog" tabindex="-1"><div class="modal-dialog modal-dialog-centered" role="dialog"><div class="modal-content"><div class="modal-header"><h5 class="modal-title">${escape_html(store_get($$store_subs ??= {}, "$mode", mode) === "create" ? store_get($$store_subs ??= {}, "$_", $format)("components.modals.add-edit-post-category.create-category") : store_get($$store_subs ??= {}, "$_", $format)("components.modals.add-edit-post-category.edit-category"))}</h5> <button${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("buttons.close"))} type="button" class="btn-close" data-bs-dismiss="modal"></button></div> <form><div class="modal-body"><input${attr_class("form-control form-control-lg mb-3", void 0, { "border-danger": store_get($$store_subs ??= {}, "$errors", errors).title })}${attr("placeholder", store_get($$store_subs ??= {}, "$_", $format)("components.modals.add-edit-post-category.inputs.title.placeholder"))} id="category" type="text"${attr("value", store_get($$store_subs ??= {}, "$category", category).title)}/> <textarea${attr_class("form-control mb-3", void 0, { "border-danger": store_get($$store_subs ??= {}, "$errors", errors).description })}${attr("placeholder", store_get($$store_subs ??= {}, "$_", $format)("components.modals.add-edit-post-category.inputs.description.placeholder"))} id="categoryDescription" type="text" rows="5">`);
		const $$body = escape_html(store_get($$store_subs ??= {}, "$category", category).description);
		if ($$body) $$renderer.push(`${$$body}`);
		$$renderer.push(`</textarea> <div class="mb-3 input-group"><span class="input-group-text">/category/</span> <input${attr_class("form-control", void 0, { "is-invalid": store_get($$store_subs ??= {}, "$errors", errors).url })}${attr("placeholder", store_get($$store_subs ??= {}, "$_", $format)("components.modals.add-edit-post-category.inputs.url.placeholder"))} id="categoryURL" type="text"${attr("value", store_get($$store_subs ??= {}, "$category", category).url)}/></div> <small${attr_class("", void 0, { "text-danger": store_get($$store_subs ??= {}, "$errors", errors).url })}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.add-edit-post-category.inputs.url.helper"))}</small></div> <div class="modal-footer"><button${attr_class("btn w-100", void 0, {
			"btn-secondary": store_get($$store_subs ??= {}, "$mode", mode) === "create",
			"btn-primary": store_get($$store_subs ??= {}, "$mode", mode) === "edit",
			"disabled": buttonDisabled
		})} type="submit"><span>`);
		if (store_get($$store_subs ??= {}, "$mode", mode) === "edit") {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.save"))}`);
		} else {
			$$renderer.push("<!--[-1-->");
			$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.create"))}`);
		}
		$$renderer.push(`<!--]--></span></button></div></form></div></div></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
	});
}

export { AddEditPostCategoryModal as A };
//# sourceMappingURL=AddEditPostCategoryModal.js-D1eTG-f5.js.map
