import { _ as __exportAll } from './rolldown-runtime.js-BMnQIuNT.js';
import { e as error } from './exports2.js-VkmSkXbz.js';
import { b as base } from './internal.js-BRN1McAa.js';
import { J as getContext, T as attr, U as stringify, V as attr_class, Z as escape_html, Q as store_get, S as unsubscribe_stores, x as setContext, P as ensure_array_like, F as writable } from './index-server.js-DdhL7Abu.js';
import './stores.js-D5xmrOAP.js';
import './server.js-BlClO2ED.js';
import './internal2.js-CNe5OZUJ.js';
import './routing.js-N-OPb2ye.js';
import { b as ApiUtil, P as PANO_WEBSITE_URL } from './Store.js-DT3aZHRb.js';
import { $ as $format } from './runtime.js-BzHEw_ze.js';
import './ToastContainer.js-Bv1jJ2dr.js';
import './tooltip.util.js-BeLZL-Tj.js';
import { e as executeHookLoad, b as executeLifecycle } from './SiteNavigationMenu.js-DeoPp7eK.js';
import { V as VerifiedStatus } from './VerifiedStatus.js-BWWM3WML.js';
import { L as LicenseStatusBadge } from './LicenseStatusBadge.js-C5qJr3_k.js';
import { P as PageActions } from './PageActions.js-co-RIHDp.js';
import { P as PageNav, a as PageNavItem } from './PageNav.js-Bzzuwwjz.js';
import { F as FreemiumBadge } from './FreemiumBadge.js-DKfLAS4Z.js';
import { A as AddonStartupErrorModal, i as isAddonLicenseStartupBlocked, a as isPremiumAddonEnableBlockedByLicense } from './addon-license-issue.util.js-C_l-lxBM.js';

var pluginId = writable();
function ConfirmRemoveAddonModal($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let loading = false;
		$$renderer.push(`<div aria-hidden="true" class="modal fade" role="dialog" tabindex="-1"><div class="modal-dialog modal-dialog-centered" role="dialog"><div class="modal-content"><div class="modal-body text-center"><div class="pb-3"><i class="fas fa-question-circle fa-3x d-block m-auto text-gray"></i></div> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.confirm-remove-addon.title", { values: { pluginId: store_get($$store_subs ??= {}, "$pluginId", pluginId) } }))}</div> <div class="modal-footer flex-nowrap"><button${attr_class("btn btn-link col-6 m-0", void 0, { "disabled": loading })} type="button">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.cancel"))}</button> <button${attr_class("btn btn-danger col-6 m-0", void 0, { "disabled": loading })} type="button">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.yes"))}</button></div></div></div></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
	});
}
var plugin = writable({ dependents: [] });
function ConfirmRemoveAddonWillCauseMoreUnloadModal($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let loading = false;
		$$renderer.push(`<div aria-hidden="true" class="modal fade" role="dialog" tabindex="-1"><div class="modal-dialog modal-dialog-centered" role="dialog"><div class="modal-content"><div class="modal-body text-center"><div class="pb-3"><i class="fas fa-question-circle fa-3x d-block m-auto text-gray"></i></div> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.confirm-remove-addon.title", { values: { pluginId: store_get($$store_subs ??= {}, "$plugin", plugin).id } }))} <div class="mt-3 alert alert-warning text-left">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.confirm-remove-addon-will-cause-more-unload.description", { values: { pluginId: store_get($$store_subs ??= {}, "$plugin", plugin).id } }))} <br/> <br/> <!--[-->`);
		const each_array = ensure_array_like(store_get($$store_subs ??= {}, "$plugin", plugin).removeDependents);
		for (let index = 0, $$length = each_array.length; index < $$length; index++) {
			let addon = each_array[index];
			$$renderer.push(`<a class="badge bg-warning rounded-pill"${attr("href", `${stringify(base)}/addons/detail/${stringify(addon)}`)} target="_blank">${escape_html(addon)}</a>`);
		}
		$$renderer.push(`<!--]--></div></div> <div class="modal-footer flex-nowrap"><button${attr_class("btn btn-link col-6 m-0", void 0, { "disabled": loading })} type="button">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.cancel"))}</button> <button${attr_class("btn btn-danger col-6 m-0", void 0, { "disabled": loading })} type="button">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.yes"))}</button></div></div></div></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
	});
}
//#endregion
//#region src/lib/layouts/AddonDetailLayout.svelte
var AddonDetailLayout_exports = /* @__PURE__ */ __exportAll({
	default: () => AddonDetailLayout,
	initSlots: () => initSlots,
	load: () => load
});
var key = "layout-slots";
function initSlots() {
	const slots = {
		right: null,
		left: null
	};
	setContext(key, slots);
	return slots;
}
/**
* @type {import('@sveltejs/kit').LayoutLoad}
*/
async function load(event) {
	const { parent } = event;
	await parent();
	const addonId = event.params.addonId;
	const body = await ApiUtil.get({
		path: `/api/panel/plugins/${addonId}`,
		request: event
	});
	if (body.error === "NOT_FOUND") throw error(404, body.error);
	const [globalHookProps, specificHookProps] = await Promise.all([executeHookLoad("panel:plugin-detail:content", event), executeHookLoad(`panel:plugin-detail:content:${addonId}`, event)]);
	await executeLifecycle("panel:addon-detail:load", { addon: body.data }, event);
	return {
		addon: body.data,
		hookProps: {
			"panel:plugin-detail:content": globalHookProps,
			[`panel:plugin-detail:content:${addonId}`]: specificHookProps
		}
	};
}
function AddonDetailLayout($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let { data, children } = $$props;
		const slots = initSlots();
		let removing = false;
		getContext("pageTitle");
		ConfirmRemoveAddonModal($$renderer);
		$$renderer.push(`<!----> `);
		ConfirmRemoveAddonWillCauseMoreUnloadModal($$renderer);
		$$renderer.push(`<!----> `);
		AddonStartupErrorModal($$renderer);
		$$renderer.push(`<!----> <div class="container vstack gap-3">`);
		PageActions($$renderer, { $$slots: {
			left: ($$renderer) => {
				$$renderer.push(`<div slot="left" class="hstack gap-3"><a${attr("href", `${stringify(base)}/addons`)} class="btn btn-link" role="button"${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("buttons.addons"))}><i class="fas fa-arrow-left"></i></a> `);
				if (slots.left) {
					$$renderer.push("<!--[0-->");
					slots.left($$renderer);
					$$renderer.push(`<!---->`);
				} else {
					$$renderer.push("<!--[-1-->");
					PageNav($$renderer, {
						children: ($$renderer) => {
							PageNavItem($$renderer, {
								href: `/addons/detail/${stringify(data.addon.id)}`,
								children: ($$renderer) => {
									$$renderer.push(`<!---->${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.addon-detail.overview"))}`);
								}});
							$$renderer.push(`<!----> `);
							PageNavItem($$renderer, {
								href: `/addons/detail/${stringify(data.addon.id)}/settings`,
								children: ($$renderer) => {
									$$renderer.push(`<!---->${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.settings"))}`);
								}});
							$$renderer.push(`<!---->`);
						},
						$$slots: { default: true }
					});
				}
				$$renderer.push(`<!--]--></div>`);
			},
			right: ($$renderer) => {
				$$renderer.push(`<div slot="right" class="hstack gap-2">`);
				if (slots.right) {
					$$renderer.push("<!--[0-->");
					slots.right($$renderer);
					$$renderer.push(`<!---->`);
				} else {
					$$renderer.push("<!--[-1-->");
					$$renderer.push(`<div class="hstack gap-2 align-items-center">`);
					$$renderer.push("<!--[-1-->");
					if (data.addon.verifyStatus !== "UNKNOWN") {
						$$renderer.push("<!--[0-->");
						$$renderer.push(`<a${attr("title", store_get($$store_subs ??= {}, "$_", $format)("buttons.show-in-store"))}${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("buttons.show-in-store"))}${attr("href", `${PANO_WEBSITE_URL}/addons/${data.addon.id}`)} target="_blank" class="btn btn-link"><i class="fas fa-store"></i></a>`);
					} else $$renderer.push("<!--[-1-->");
					$$renderer.push(`<!--]--> `);
					if (data.addon.updateVersion) {
						$$renderer.push("<!--[0-->");
						$$renderer.push(`<button type="button" class="btn btn-link position-relative"${attr("title", store_get($$store_subs ??= {}, "$_", $format)("pages.addons.update-available") + " (v" + data.addon.updateVersion + ")")}${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("pages.addons.update-available"))}><i class="fas fa-sync"></i> <span class="position-absolute top-0 start-100 translate-middle mt-2 badge rounded-pill bg-secondary p-1"><span class="visually-hidden">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.addons.update-available"))}</span></span></button>`);
					} else $$renderer.push("<!--[-1-->");
					$$renderer.push(`<!--]--> <button${attr_class("btn btn-link", void 0, { "disabled": removing })} type="button"${attr("title", store_get($$store_subs ??= {}, "$_", $format)("buttons.remove"))}${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("buttons.remove"))}><i class="fas fa-trash"></i></button> <div class="form-check form-switch"><input class="form-check-input" type="checkbox" role="switch"${attr("checked", data.addon.status === "STARTED", true)}${attr("disabled", data.addon.status !== "STARTED" && isPremiumAddonEnableBlockedByLicense(data.addon), true)}/></div>`);
					$$renderer.push(`<!--]--></div>`);
				}
				$$renderer.push(`<!--]--></div>`);
			}
		} });
		$$renderer.push(`<!----> <div class="card"><div class="card-body"><div class="row g-3"><div class="col-auto d-flex justify-content-center align-items-start rounded-start rounded-top"><img${attr("src", `/api/panel/plugins/${stringify(data.addon.id)}/logo`)} class="img-fluid rounded"${attr("alt", data.addon.name)} height="86" width="86"/></div> <div class="col"><h5${attr_class("card-title d-inline-flex align-items-center gap-2 mb-2 flex-wrap", void 0, { "text-danger": data.addon.status === "FAILED" && !isAddonLicenseStartupBlocked(data.addon) })}>${escape_html(data.addon.name)} `);
		VerifiedStatus($$renderer, { status: data.addon.verifyStatus });
		$$renderer.push(`<!----> `);
		if (data.addon.premium && data.addon.licenseStatus !== "LICENSED") {
			$$renderer.push("<!--[0-->");
			LicenseStatusBadge($$renderer, { status: data.addon.licenseStatus });
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--> `);
		if (data.addon.freemium) {
			$$renderer.push("<!--[0-->");
			FreemiumBadge($$renderer);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--> `);
		if (data.addon.status === "FAILED" && !isAddonLicenseStartupBlocked(data.addon)) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<button type="button"${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("buttons.error-log"))} class="btn btn-link link-danger ps-2"><i class="fa-solid fa-circle-exclamation"></i></button>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--></h5> <div class="small mb-2 hstack gap-2"><span class="user-select-all font-monospace">${escape_html(data.addon.id)}</span> <span class="vr"></span> <span class="user-select-all font-monospace">${escape_html(data.addon.version)}</span> <span class="vr"></span> <span class="user-select-all font-monospace">${escape_html(data.addon.panoVersion)}</span> <span class="vr"></span> <span${attr_class(`badge ${data.addon.status === "STARTED" ? "text-bg-success" : "text-bg-secondary"}`)}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.addon-status-badge." + data.addon.status, { default: data.addon.status }))}</span></div> `);
		if (data.addon.description) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`${escape_html(data.addon.description)}`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--></div></div></div></div> `);
		children($$renderer);
		$$renderer.push(`<!----></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
	});
}

export { AddonDetailLayout_exports as A, AddonDetailLayout as a, load as l };
//# sourceMappingURL=AddonDetailLayout.js-Dsuoa7y-.js.map
