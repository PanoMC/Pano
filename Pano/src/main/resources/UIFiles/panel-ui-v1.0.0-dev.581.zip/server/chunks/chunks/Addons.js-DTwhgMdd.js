import { e as error } from './exports2.js-VkmSkXbz.js';
import { b as base } from './internal.js-BRN1McAa.js';
import { J as getContext, Q as store_get, P as ensure_array_like, V as attr_class, U as stringify, T as attr, Z as escape_html, X as html, S as unsubscribe_stores, O as bind_props } from './index-server.js-DdhL7Abu.js';
import './stores.js-D5xmrOAP.js';
import './server.js-BlClO2ED.js';
import './internal2.js-CNe5OZUJ.js';
import './routing.js-N-OPb2ye.js';
import { e as buildQueryParams, b as ApiUtil } from './Store.js-DT3aZHRb.js';
import { $ as $format } from './runtime.js-BzHEw_ze.js';
import './ToastContainer.js-Bv1jJ2dr.js';
import { w as websiteDisplayHost } from './website-display.util.js-DvL-i3X3.js';
import { I as InstallResourceModal } from './InstallingResourceModal.js-CaKAxtGU.js';
import { h as panoApiClient } from './SiteNavigationMenu.js-DeoPp7eK.js';
import { N as NoContent } from './NoContent.js-Coj2fA9d.js';
import { S as SearchInput } from './SearchInput.js-DPW0WADK.js';
import { V as VerifiedStatus } from './VerifiedStatus.js-BWWM3WML.js';
import { L as LicenseStatusBadge } from './LicenseStatusBadge.js-C5qJr3_k.js';
import { C as CardHeader } from './CardHeader.js-XBureLRg.js';
import { F as FailedLoginPanoStoreAlert } from './Themes.js-B8ffV7iF.js';
import { C as CardFilters, a as CardFiltersItem } from './CardFiltersItem.js-n0hSsrtm.js';
import { P as PageActions } from './PageActions.js-co-RIHDp.js';
import { F as FreemiumBadge } from './FreemiumBadge.js-DKfLAS4Z.js';
import { b as ADDON_LICENSE_ISSUE_STATUSES, A as AddonStartupErrorModal, i as isAddonLicenseStartupBlocked, a as isPremiumAddonEnableBlockedByLicense } from './addon-license-issue.util.js-C_l-lxBM.js';

//#region src/lib/pages/addons/AddonSettingsButton.svelte
function AddonSettingsButton($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let hooks;
		let plugin = $$props["plugin"];
		hooks = panoApiClient.ui.hook.get(`panel:plugin-detail:content:${plugin.id}`);
		if (store_get($$store_subs ??= {}, "$hooks", hooks).length > 0 && plugin.status === "STARTED") {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<a${attr("href", `${stringify(base)}/addons/detail/${stringify(plugin.id)}/settings`)} class="btn btn-link p-0"${attr("title", store_get($$store_subs ??= {}, "$_", $format)("buttons.preferences"))}${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("buttons.preferences"))}><i class="fa-solid fa-sliders-h"></i></a>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]-->`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
		bind_props($$props, { plugin });
	});
}
//#endregion
//#region src/lib/pages/Addons.svelte
var PageTypes = Object.freeze({
	ALL: "ALL",
	ACTIVE: "ACTIVE",
	DISABLED: "DISABLED",
	LICENSE_ISSUES: "LICENSE_ISSUES"
});
var DefaultPageType = PageTypes.ALL;
async function load(event) {
	const { parent, url: { searchParams } } = event;
	await parent();
	const status = searchParams.get("status") || DefaultPageType;
	const search = searchParams.get("search");
	const failedLogin = searchParams.has("failedLogin");
	if (!Object.values(PageTypes).includes(status)) throw error(404, "PAGE_NOT_FOUND");
	const serverStatus = status === PageTypes.LICENSE_ISSUES ? PageTypes.ALL : status;
	const queryParams = buildQueryParams({
		status: serverStatus,
		search
	});
	const body = await ApiUtil.get({
		path: `/api/panel/plugins` + queryParams,
		request: event
	});
	if (body.error) throw error(500, body);
	let plugins = body.data;
	if (status === PageTypes.LICENSE_ISSUES) plugins = plugins.filter((p) => p.premium && ADDON_LICENSE_ISSUE_STATUSES.has(p.licenseStatus));
	return {
		plugins,
		pageType: status,
		failedLogin
	};
}
function Addons($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let buyAddonOnMarketLabel, sortedPlugins;
		let data = $$props["data"];
		let search = "";
		let isSearching = false;
		function cardBorderClass(plugin, justInstalledId) {
			const failedNonLicense = plugin.status === "FAILED" && !isAddonLicenseStartupBlocked(plugin);
			if (!plugin.premium) return failedNonLicense ? "border-danger border-2" : "";
			switch (plugin.licenseStatus) {
				case "VERSION_MISMATCH":
				case "AUDIENCE_MISMATCH":
				case "PLATFORM_MISMATCH": return "border-danger border-2";
				case "NO_PURCHASE":
				case "MISSING":
				case "JAR_TAMPERED":
				case "SIGNATURE_INVALID":
				case "EXPIRED":
				case "NOT_CONNECTED":
				case "NEEDS_REFRESH":
				case "NETWORK_ERROR": return failedNonLicense ? "border-danger border-2" : "";
				default: return failedNonLicense ? "border-danger border-2" : "";
			}
		}
		getContext("pageTitle").set("pages.addons.title");
		buyAddonOnMarketLabel = store_get($$store_subs ??= {}, "$_", $format)("buttons.buy-addon-on-market", { values: { website: websiteDisplayHost() } });
		sortedPlugins = data.plugins;
		InstallResourceModal($$renderer);
		$$renderer.push(`<!----> `);
		AddonStartupErrorModal($$renderer);
		$$renderer.push(`<!----> <div class="container vstack gap-3">`);
		if (data.failedLogin) {
			$$renderer.push("<!--[0-->");
			FailedLoginPanoStoreAlert($$renderer);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--> `);
		PageActions($$renderer, {
			middleClasses: "d-lg-flex d-none",
			leftClasses: "d-lg-flex d-none",
			$$slots: { right: ($$renderer) => {
				$$renderer.push(`<div slot="right" class="hstack gap-2"><div class="btn-group"><button type="button" class="btn btn-link"${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("buttons.enable-all-addons"))}${attr("title", store_get($$store_subs ??= {}, "$_", $format)("buttons.enable-all-addons"))}${attr("disabled", data.plugins.every((p) => p.status === "STARTED"), true)}><i class="fa-solid fa-play"></i></button> <button type="button" class="btn btn-link link-danger"${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("buttons.disable-all-addons"))}${attr("title", store_get($$store_subs ??= {}, "$_", $format)("buttons.disable-all-addons"))}${attr("disabled", data.plugins.every((p) => p.status !== "STARTED"), true)}><i class="fa-solid fa-stop"></i></button></div> <button type="button" class="btn btn-secondary"><i class="fas fa-plus"></i> <span class="d-lg-inline d-none ms-2">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.install-addon"))}</span></button></div>`);
			} }
		});
		$$renderer.push(`<!----> <div class="card">`);
		CardHeader($$renderer, { $$slots: {
			left: ($$renderer) => {
				$$renderer.push(`<div slot="left">${escape_html(data.pageType === PageTypes.LICENSE_ISSUES ? store_get($$store_subs ??= {}, "$_", $format)("pages.addons.card-title.license-issues", { values: { amount: data.plugins.length } }) : data.pageType === PageTypes.ACTIVE ? store_get($$store_subs ??= {}, "$_", $format)("pages.addons.card-title.active", { values: { amount: data.plugins.length } }) : data.pageType === PageTypes.DISABLED ? store_get($$store_subs ??= {}, "$_", $format)("pages.addons.card-title.inactive", { values: { amount: data.plugins.length } }) : store_get($$store_subs ??= {}, "$_", $format)("pages.addons.card-title.installed", { values: { amount: data.plugins.length } }))}</div>`);
			},
			middle: ($$renderer) => {
				$$renderer.push(`<div slot="middle" style="width: 250px;">`);
				SearchInput($$renderer, {
					initialValue: search,
					searching: isSearching,
					debounceMs: 500
				});
				$$renderer.push(`<!----></div>`);
			},
			right: ($$renderer) => {
				CardFilters($$renderer, {
					slot: "right",
					children: ($$renderer) => {
						CardFiltersItem($$renderer, {
							href: "/addons",
							active: data.pageType === PageTypes.ALL,
							children: ($$renderer) => {
								$$renderer.push(`<!---->${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.all"))}`);
							}});
						$$renderer.push(`<!----> `);
						CardFiltersItem($$renderer, {
							href: "/addons?status=ACTIVE",
							active: data.pageType === PageTypes.ACTIVE,
							children: ($$renderer) => {
								$$renderer.push(`<!---->${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.active"))}`);
							}});
						$$renderer.push(`<!----> `);
						CardFiltersItem($$renderer, {
							href: "/addons?status=DISABLED",
							active: data.pageType === PageTypes.DISABLED,
							children: ($$renderer) => {
								$$renderer.push(`<!---->${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.disabled"))}`);
							}});
						$$renderer.push(`<!----> `);
						CardFiltersItem($$renderer, {
							href: "/addons?status=LICENSE_ISSUES",
							active: data.pageType === PageTypes.LICENSE_ISSUES,
							children: ($$renderer) => {
								$$renderer.push(`<!---->${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.license-issues"))}`);
							}});
						$$renderer.push(`<!---->`);
					},
					$$slots: { default: true }
				});
			}
		} });
		$$renderer.push(`<!----> <div class="card-body">`);
		if (data.plugins.length === 0) {
			$$renderer.push("<!--[0-->");
			NoContent($$renderer, {});
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--> <div class="row row-cols-xl-2 row-cols-1 g-3"><!--[-->`);
		const each_array = ensure_array_like(sortedPlugins);
		for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
			let plugin = each_array[$$index];
			$$renderer.push(`<div class="col"><div${attr_class(`card h-100 position-relative ${stringify(cardBorderClass(plugin))}`)}><div class="position-absolute top-0 end-0 m-2 d-flex align-items-center gap-2">`);
			if (plugin.status === "FAILED" && !isAddonLicenseStartupBlocked(plugin)) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<button type="button"${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("buttons.error-log"))} class="btn btn-link link-danger"><i class="fa-solid fa-circle-exclamation"></i></button>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--> `);
			if (isAddonLicenseStartupBlocked(plugin) && plugin.purchaseUrl) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<a${attr("href", plugin.purchaseUrl)} target="_blank" rel="noopener" class="btn btn-sm btn-warning"${attr("title", buyAddonOnMarketLabel)}${attr("aria-label", buyAddonOnMarketLabel)}><i class="fa-solid fa-store"></i></a>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--> `);
			if (plugin.loading) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<i class="fa-solid fa-spinner fa-spin me-2"></i>`);
			} else {
				$$renderer.push("<!--[-1-->");
				if (plugin.updateVersion) {
					$$renderer.push("<!--[0-->");
					$$renderer.push(`<button type="button" class="btn btn-link"${attr("title", store_get($$store_subs ??= {}, "$_", $format)("pages.addons.update-available") + " (v" + plugin.updateVersion + ")")}${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("pages.addons.update-available"))}><i class="fas fa-sync"></i></button>`);
				} else $$renderer.push("<!--[-1-->");
				$$renderer.push(`<!--]--> `);
				AddonSettingsButton($$renderer, { plugin });
				$$renderer.push(`<!----> <div class="form-check form-switch"><input class="form-check-input" type="checkbox" role="switch"${attr("checked", plugin.status === "STARTED", true)}${attr("disabled", plugin.loading || plugin.status !== "STARTED" && isPremiumAddonEnableBlockedByLicense(plugin), true)}/></div>`);
			}
			$$renderer.push(`<!--]--></div> <div class="card-body"><a${attr("href", `${stringify(base)}/addons/detail/${stringify(plugin.id)}`)} class="text-decoration-none rounded focus-ring mb-2"><img${attr("src", `/api/panel/plugins/${stringify(plugin.id)}/logo`)} class="rounded mb-2" width="64" height="64"${attr("alt", plugin.name)}/></a> <a${attr("href", `${stringify(base)}/addons/detail/${stringify(plugin.id)}`)} class="text-decoration-none focus-ring rounded d-flex align-items-center gap-2 mb-2 flex-wrap"><h5 class="text-truncate mb-0">${escape_html(plugin.name)}</h5> `);
			VerifiedStatus($$renderer, { status: plugin.verifyStatus });
			$$renderer.push(`<!----> `);
			if (plugin.premium) {
				$$renderer.push("<!--[0-->");
				LicenseStatusBadge($$renderer, { status: plugin.licenseStatus });
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--> `);
			if (plugin.freemium) {
				$$renderer.push("<!--[0-->");
				FreemiumBadge($$renderer);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--></a> <small class="d-block mb-2">${html(plugin.description)}</small> <small class="font-monospace user-select-all">${escape_html(plugin.version)}</small></div></div></div>`);
		}
		$$renderer.push(`<!--]--></div></div></div></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
		bind_props($$props, { data });
	});
}

export { Addons as A, load as l };
//# sourceMappingURL=Addons.js-DTwhgMdd.js.map
