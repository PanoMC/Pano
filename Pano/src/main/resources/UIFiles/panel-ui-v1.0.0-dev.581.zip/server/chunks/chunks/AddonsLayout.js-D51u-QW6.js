import { _ as __exportAll } from './rolldown-runtime.js-BMnQIuNT.js';
import { r as redirect } from './exports2.js-VkmSkXbz.js';
import { b as base } from './internal.js-BRN1McAa.js';
import { W as slot } from './index-server.js-DdhL7Abu.js';
import './server.js-BlClO2ED.js';
import './internal2.js-CNe5OZUJ.js';
import './routing.js-N-OPb2ye.js';
import { h as hasPermission, P as Permissions } from './auth.util.js-C77uoaNq.js';
import { C as ConfirmDisableAddonWillCauseMoreDisableModal, a as ConfirmEnablingAddonWillCauseMoreEnableModal } from './ConfirmEnablingAddonWillCauseMoreEnableModal.js-CyBJmbmY.js';

//#region src/lib/layouts/AddonsLayout.svelte
var AddonsLayout_exports = /* @__PURE__ */ __exportAll({
	default: () => AddonsLayout,
	load: () => load
});
async function load({ parent }) {
	const parentData = await parent();
	const { user } = parentData;
	if (!hasPermission(Permissions.MANAGE_ADDONS, user)) throw redirect(302, base);
	return parentData;
}
function AddonsLayout($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		$$renderer.push(`<!--[-->`);
		slot($$renderer, $$props, "default", {}, null);
		$$renderer.push(`<!--]--> `);
		ConfirmDisableAddonWillCauseMoreDisableModal($$renderer);
		$$renderer.push(`<!----> `);
		ConfirmEnablingAddonWillCauseMoreEnableModal($$renderer);
		$$renderer.push(`<!---->`);
	});
}

export { AddonsLayout_exports as A, AddonsLayout as a, load as l };
//# sourceMappingURL=AddonsLayout.js-D51u-QW6.js.map
