import { _ as __exportAll, b as __toESM } from './rolldown-runtime.js-BMnQIuNT.js';
import { e as error } from './exports2.js-VkmSkXbz.js';
import { b as base } from './internal.js-BRN1McAa.js';
import './internal2.js-CNe5OZUJ.js';
import { F as writable, x as setContext, Y as get, a0 as onDestroy, Q as store_get, a4 as store_set, a6 as head, S as unsubscribe_stores, O as bind_props, W as slot, $ as attr_style, J as getContext, Z as escape_html, T as attr, V as attr_class, U as stringify, P as ensure_array_like, X as html, G as noop } from './index-server.js-DdhL7Abu.js';
import { n as navigating, p as page, i as invalidateAll, a as invalidate, g as goto } from './stores.js-D5xmrOAP.js';
import './server.js-BlClO2ED.js';
import './routing.js-N-OPb2ye.js';
import { b as ApiUtil, f as avatarVersion, u as updateApiUrl, g as api_util_exports, h as networkErrorCallbacks, l as logoutLoading, o as options, c as updatePanoWebsiteUrl, d as updatePanoWebsiteApiUrl, i as checkDomainRedirection, j as PRERELEASE, P as PANO_WEBSITE_URL, k as PANO_WEBSITE_API_URL, m as PANEL_URL, J as JWT_COOKIE_NAME, a as CSRF_TOKEN_COOKIE_NAME, p as CSRF_HEADER, C as COOKIE_PREFIX, A as API_URL, q as quickNotifications, r as retryingNetworkErrors } from './Store.js-DT3aZHRb.js';
import { $ as $format } from './runtime.js-BzHEw_ze.js';
import { T as ToastContainer_exports, b as Toast, c as ToastContainer } from './ToastContainer.js-Bv1jJ2dr.js';
import { h as hasPermission, P as Permissions } from './auth.util.js-C77uoaNq.js';
import { s as show, W as WhatsNewModal } from './WhatsNewModal.js-DYlgNmt1.js';
import { l as locale_exports } from './locale.js-DgLiJnqO.js';
import { s as sanitize } from './server2.js-z2LG8ejq.js';
import { s as sanitizeImageSrc } from './security.util.js-D4eJjJV6.js';
import { i as isPanelNotificationUnread, f as formatDistanceToNow } from './panelNotification.util.js-BhOOsCbR.js';
import { D as Date_1 } from './Date.js-DCZp_jrB.js';
import { l as language_util_exports, i as init, c as currentLanguage } from './language.util.js-ByanOnuS.js';
import { t as tooltip } from './tooltip.util.js-BeLZL-Tj.js';
import { D as DragAndDropZone } from './DragAndDropZone.js-DkRk4oSS.js';
import { a as InstallingResourceModal } from './InstallingResourceModal.js-CaKAxtGU.js';
import { p as preparePlugins, s as setPanoContext, i as initializePlugins, S as SiteNavigationMenu, a as ServerNavigationMenu } from './SiteNavigationMenu.js-DeoPp7eK.js';
import { N as NoContent } from './NoContent.js-Coj2fA9d.js';
import { S as SearchInput } from './SearchInput.js-DPW0WADK.js';
import { C as CardHeader } from './CardHeader.js-XBureLRg.js';
import { P as Pagination } from './Pagination.js-sd1xTcbW.js';
import { a as CardFiltersItem, C as CardFilters } from './CardFiltersItem.js-n0hSsrtm.js';
import { r as require_copy_to_clipboard } from './copy-to-clipboard.js-Doa_mbw4.js';
import { S as ServersModal, C as ConnectServerModal } from './ServersModal.js-BMcMWCMK.js';
import { C as ConfirmActionModal } from './ConfirmActionModal.js-C9rhvdA5.js';
import { P as PageActions } from './PageActions.js-co-RIHDp.js';
import { P as PageNav, a as PageNavItem } from './PageNav.js-Bzzuwwjz.js';
import { P as PageLoading } from './PageLoading.js-BAdCAKhL.js';
import { E as Editor_1 } from './Editor.js-Cs5tQi--.js';

//#region src/lib/storage.util.js
var SIDEBAR_STORAGE_STATUS = "sidebar_storage_status";
var SIDEBAR_TABS_STORAGE_STATE = "sidebar_tabs_storage_state";
var PanelSidebarStorageUtil = {
	getSidebarOpenStatus() {
		return true;
	},
	savePanelSidebarStorageUtil(status) {
		localStorage.setItem(SIDEBAR_STORAGE_STATUS, status);
	},
	isThereSideBarOpenStatus() {
		return true;
	},
	getSidebarTabsState() {
		return "website";
	},
	setSidebarTabsState(state) {
		localStorage.setItem(SIDEBAR_TABS_STORAGE_STATE, state);
	},
	isThereSideBarTabsState() {
		return false;
	}
};
//#endregion
//#region src/lib/variables.js
var variables_exports = /* @__PURE__ */ __exportAll({
	API_URL: () => API_URL,
	COOKIE_PREFIX: () => COOKIE_PREFIX,
	CSRF_HEADER: () => CSRF_HEADER,
	CSRF_TOKEN_COOKIE_NAME: () => CSRF_TOKEN_COOKIE_NAME,
	JWT_COOKIE_NAME: () => JWT_COOKIE_NAME,
	PANEL_URL: () => PANEL_URL,
	PANO_WEBSITE_API_URL: () => PANO_WEBSITE_API_URL,
	PANO_WEBSITE_URL: () => PANO_WEBSITE_URL,
	PRERELEASE: () => PRERELEASE,
	SETUP_URL: () => "/",
	UI_URL: () => "/",
	checkDomainRedirection: () => checkDomainRedirection,
	updateApiUrl: () => updateApiUrl,
	updatePanoWebsiteApiUrl: () => updatePanoWebsiteApiUrl,
	updatePanoWebsiteUrl: () => updatePanoWebsiteUrl
});
//#endregion
//#region src/lib/components/Splash.svelte
function Splash($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let basicData, notLoggedIn, noPermission;
		let networkErrors = false;
		let jsLoaded = false;
		const session = getContext("session");
		onDestroy(() => {
			if (unsubscribe) unsubscribe();
		});
		const unsubscribe = networkErrorCallbacks.subscribe((value) => {
			networkErrors = value.length !== 0;
		});
		basicData = store_get($$store_subs ??= {}, "$session", session).basicData;
		notLoggedIn = basicData.error === "NOT_LOGGED_IN";
		noPermission = basicData.error === "NO_PERMISSION";
		head("v8bbdp", $$renderer, ($$renderer) => {
			if (networkErrors) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<style class="svelte-v8bbdp">
      .show {
        display: none !important;
      }
    </style>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]-->`);
		});
		$$renderer.push(`<div class="d-flex align-items-center justify-content-center vh-100 w-100 flex-column svelte-v8bbdp" role="status"><div class="loader-content position-relative svelte-v8bbdp" style="height: 100px; width: 100px;"><div class="logo-wrapper bg-primary p-2 shadow-sm pano-anim center-content d-flex align-items-center justify-content-center svelte-v8bbdp"><img alt="Pano"${attr("src", `${stringify(base)}/assets/img/logo.svg`)} class="w-100 h-100 object-fit-contain svelte-v8bbdp"/></div> <div class="mc-img-wrapper mc-anim center-content d-flex align-items-center justify-content-center svelte-v8bbdp"><img alt="Minecraft"${attr("src", `${stringify(base)}/assets/img/minecraft-icon.png`)} class="w-100 h-100 object-fit-contain svelte-v8bbdp"/></div> <div class="hytale-img-wrapper hytale-anim center-content d-flex align-items-center justify-content-center svelte-v8bbdp"><img alt="Hytale"${attr("src", `${stringify(base)}/assets/img/hytale-icon.png`)} class="w-100 h-100 object-fit-contain svelte-v8bbdp"/></div></div> `);
		if (networkErrors) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<div class="mt-4 text-center svelte-v8bbdp">`);
			if (notLoggedIn) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<small class="svelte-v8bbdp">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.splash.errors.session"))}</small>`);
			} else if (noPermission) {
				$$renderer.push("<!--[1-->");
				$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.splash.errors.permission"))}`);
			} else {
				$$renderer.push("<!--[-1-->");
				$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.splash.errors.connection"))}`);
			}
			$$renderer.push(`<!--]--> <br class="svelte-v8bbdp"/> <div class="d-flex flex-wrap align-items-center justify-content-center gap-2 mt-3 svelte-v8bbdp"><button class="btn btn-sm btn-outline-secondary svelte-v8bbdp" type="button">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.splash.manual-refresh"))}</button> `);
			if (!notLoggedIn && !noPermission) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<button${attr_class("btn btn-sm btn-primary svelte-v8bbdp", void 0, { "disabled": store_get($$store_subs ??= {}, "$retryingNetworkErrors", retryingNetworkErrors) })} type="button">${escape_html(store_get($$store_subs ??= {}, "$retryingNetworkErrors", retryingNetworkErrors) ? store_get($$store_subs ??= {}, "$_", $format)("components.splash.refreshing") : store_get($$store_subs ??= {}, "$_", $format)("components.splash.retry"))}</button>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--></div></div>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--> <div${attr_class("mt-4 text-center stuck-ui svelte-v8bbdp", void 0, { "stuck-hidden": networkErrors || jsLoaded })}><small class="d-block mb-3 svelte-v8bbdp">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.splash.stuck-text"))}</small> <a href="." class="btn btn-outline-secondary btn-sm svelte-v8bbdp"><i class="fas fa-sync-alt me-2 svelte-v8bbdp"></i> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.splash.manual-refresh"))}</a></div></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
	});
}
//#endregion
//#region node_modules/svelte/src/internal/client/timing.js
/** @import { Raf } from '#client' */
var now = () => Date.now();
/** @type {Raf} */
var raf = {
	tick: /** @param {any} _ */ (_) => noop(),
	now: () => now(),
	tasks: /* @__PURE__ */ new Set()
};
/**
* Creates a new task that runs on each raf frame
* until it returns a falsy value or is aborted
* @param {TaskCallback} callback
* @returns {Task}
*/
function loop(callback) {
	/** @type {TaskEntry} */
	let task;
	if (raf.tasks.size === 0) ;
	return {
		promise: new Promise((fulfill) => {
			raf.tasks.add(task = {
				c: callback,
				f: fulfill
			});
		}),
		abort() {
			raf.tasks.delete(task);
		}
	};
}
//#endregion
//#region node_modules/svelte/src/motion/utils.js
/**
* @param {any} obj
* @returns {obj is Date}
*/
function is_date(obj) {
	return Object.prototype.toString.call(obj) === "[object Date]";
}
//#endregion
//#region node_modules/svelte/src/easing/index.js
/**
* @param {number} t
* @returns {number}
*/
function linear(t) {
	return t;
}
/**
* @param {number} t
* @returns {number}
*/
function cubicOut(t) {
	const f = t - 1;
	return f * f * f + 1;
}
//#endregion
//#region node_modules/svelte/src/motion/tweened.js
/** @import { Task } from '../internal/client/types' */
/** @import { Tweened, TweenOptions } from './public' */
/**
* @template T
* @param {T} a
* @param {T} b
* @returns {(t: number) => T}
*/
function get_interpolator(a, b) {
	if (a === b || a !== a) return () => a;
	const type = typeof a;
	if (type !== typeof b || Array.isArray(a) !== Array.isArray(b)) throw new Error("Cannot interpolate values of different type");
	if (Array.isArray(a)) {
		const arr = b.map((bi, i) => {
			return get_interpolator(
				/** @type {Array<any>} */
				a[i],
				bi
			);
		});
		return (t) => arr.map((fn) => fn(t));
	}
	if (type === "object") {
		if (!a || !b) throw new Error("Object cannot be null");
		if (is_date(a) && is_date(b)) {
			const an = a.getTime();
			const delta = b.getTime() - an;
			return (t) => new Date(an + t * delta);
		}
		const keys = Object.keys(b);
		/** @type {Record<string, (t: number) => T>} */
		const interpolators = {};
		keys.forEach((key) => {
			interpolators[key] = get_interpolator(a[key], b[key]);
		});
		return (t) => {
			/** @type {Record<string, any>} */
			const result = {};
			keys.forEach((key) => {
				result[key] = interpolators[key](t);
			});
			return result;
		};
	}
	if (type === "number") {
		const delta = b - a;
		return (t) => a + t * delta;
	}
	return () => b;
}
/**
* A tweened store in Svelte is a special type of store that provides smooth transitions between state values over time.
*
* @deprecated Use [`Tween`](https://svelte.dev/docs/svelte/svelte-motion#Tween) instead
* @template T
* @param {T} [value]
* @param {TweenOptions<T>} [defaults]
* @returns {Tweened<T>}
*/
function tweened(value, defaults = {}) {
	const store = writable(value);
	/** @type {Task} */
	let task;
	let target_value = value;
	/**
	* @param {T} new_value
	* @param {TweenOptions<T>} [opts]
	*/
	function set(new_value, opts) {
		target_value = new_value;
		if (value == null) {
			store.set(value = new_value);
			return Promise.resolve();
		}
		/** @type {Task | null} */
		let previous_task = task;
		let started = false;
		let { delay = 0, duration = 400, easing = linear, interpolate = get_interpolator } = {
			...defaults,
			...opts
		};
		if (duration === 0) {
			if (previous_task) {
				previous_task.abort();
				previous_task = null;
			}
			store.set(value = target_value);
			return Promise.resolve();
		}
		const start = raf.now() + delay;
		/** @type {(t: number) => T} */
		let fn;
		task = loop((now) => {
			if (now < start) return true;
			if (!started) {
				fn = interpolate(value, new_value);
				if (typeof duration === "function") duration = duration(value, new_value);
				started = true;
			}
			if (previous_task) {
				previous_task.abort();
				previous_task = null;
			}
			const elapsed = now - start;
			if (elapsed > duration) {
				store.set(value = new_value);
				return false;
			}
			store.set(value = fn(easing(elapsed / duration)));
			return true;
		});
		return task.promise;
	}
	return {
		set,
		update: (fn, opts) => set(fn(target_value, value), opts),
		subscribe: store.subscribe
	};
}
//#endregion
//#region src/lib/components/PageLoader.svelte
function PageLoader($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		const progress = tweened(0, { easing: cubicOut });
		const opacity = tweened(1, { easing: cubicOut });
		if (store_get($$store_subs ??= {}, "$navigating", navigating)) {
			opacity.set(1, { duration: 0 });
			progress.set(.7, { duration: 3500 });
		} else {
			const duration = 1e3;
			progress.set(1, { duration });
			opacity.set(0, {
				duration: duration / 2,
				delay: duration / 2
			});
			setTimeout(() => {
				progress.set(0, { duration: 0 });
			}, duration);
		}
		$$renderer.push(`<div class="progress-bar svelte-jx6mac"${attr_style(`opacity: ${store_get($$store_subs ??= {}, "$opacity", opacity)}`)}><div class="progress-sliver svelte-jx6mac"${attr_style(`--width: ${store_get($$store_subs ??= {}, "$progress", progress) * 100}%`)}></div></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
	});
}
//#endregion
//#region src/lib/components/App.svelte
function App($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		onDestroy(page.subscribe(() => {}));
		head("xo6w1v", $$renderer, ($$renderer) => {
			$$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]-->`);
		});
		PageLoader($$renderer);
		$$renderer.push(`<!----> <!--[-->`);
		slot($$renderer, $$props, "default", {}, null);
		$$renderer.push(`<!--]-->`);
	});
}
//#endregion
//#region src/lib/components/NotificationContainer.svelte
var notifications = writable([]);
Array.prototype.insert = function(index, item) {
	this.splice(index, 0, item);
	return this;
};
Array.prototype.remove = function(index) {
	this.splice(index, 1);
	return this;
};
function NotificationContainer($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let checkTime = 0;
		let interval;
		getContext("notificationCount");
		function getTime(check, time, locale) {
			return formatDistanceToNow(time, {
				addSuffix: true,
				locale
			});
		}
		onDestroy(() => {
			clearInterval(interval);
		});
		function sanitizeObject(obj) {
			return Object.keys(obj).reduce((sanitizedObj, key) => {
				sanitizedObj[key] = sanitize(obj[key]);
				return sanitizedObj;
			}, {});
		}
		$$renderer.push(`<div class="toast-container position-fixed bottom-0 end-0 p-3 d-none d-md-block"><!--[-->`);
		const each_array = ensure_array_like(store_get($$store_subs ??= {}, "$notifications", notifications));
		for (let index = 0, $$length = each_array.length; index < $$length; index++) {
			let notification = each_array[index];
			$$renderer.push(`<article${attr("id", `notificationToast${stringify(notification.id)}`)} class="toast position-relative" aria-live="assertive" aria-atomic="true"><div class="toast-header text-bg-primary"><strong class="me-auto">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.notification-container.notification"))}</strong> <small>${escape_html(getTime(checkTime, parseInt(notification.createdAt), locale_exports[store_get($$store_subs ??= {}, "$currentLanguage", currentLanguage).dateFnsCode]))}</small> <button type="button" class="btn-close btn-close-white position-relative z-3"${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("buttons.close"))} data-bs-dismiss="toast"></button></div> <div class="toast-body"><div class="fw-normal list-group-item list-group-item-action d-flex align-items-center gap-3 text-wrap"><button type="button"${attr("title", store_get($$store_subs ??= {}, "$_", $format)("buttons.view"))} class="text-start border-0 bg-transparent p-0 d-flex align-items-center gap-3"><span class="d-flex align-items-center">`);
			if (notification.details.faIcon) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<i${attr_class(`${stringify(notification.details.faIcon)} fa-fw`)}></i>`);
			} else if (notification.details.image || notification.details.username) {
				$$renderer.push("<!--[1-->");
				$$renderer.push(`<img${attr("src", sanitizeImageSrc(notification.details.image || `/api/profile/picture/${notification.details.username}?${store_get($$store_subs ??= {}, "$avatarVersion", avatarVersion)}`, "/api/server/icon/default"))}${attr("alt", store_get($$store_subs ??= {}, "$_", $format)("buttons.view"))} width="48" height="48" class="rounded"/>`);
			} else {
				$$renderer.push("<!--[-1-->");
				$$renderer.push(`<i class="fa fa-fw fa-bolt"></i>`);
			}
			$$renderer.push(`<!--]--></span> <span class="text-start"><span class="text-wrap markdown-renderer text-break">${html(store_get($$store_subs ??= {}, "$_", $format)("notifications." + notification.type, { values: { ...sanitizeObject(notification.details || {}) } }))}</span></span></button></div></div> <button type="button" class="stretched-link p-0 border-0 bg-transparent position-absolute top-0 start-0 w-100 h-100"${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("buttons.view"))}></button></article>`);
		}
		$$renderer.push(`<!--]--></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
	});
}
var acceptDisplayName = writable("");
var server = writable({
	id: -1,
	name: "",
	customName: null,
	playerCount: 0,
	maxPlayerCount: 0,
	type: "",
	version: "",
	favicon: "",
	host: "",
	port: 0,
	remoteAddress: null,
	permissionGranted: false,
	status: "OFFLINE"
});
var loading = writable(true);
var submitLoading = writable(false);
function ServerRequestModal($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		getContext("selectedServer");
		function getPrimaryAddress(server) {
			return String(server?.remoteAddress || "").trim() || server?.host || "";
		}
		$$renderer.push(`<div id="serverRequestModal" aria-hidden="true" class="modal fade" role="dialog" tabindex="-1"><div class="modal-dialog modal-dialog-centered" role="dialog"><div class="modal-content">`);
		if (store_get($$store_subs ??= {}, "$loading", loading)) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<div class="modal-body"><div class="text-center"><div class="spinner-border text-primary" role="status"></div></div></div>`);
		} else {
			$$renderer.push("<!--[-1-->");
			$$renderer.push(`<div class="modal-header border-bottom-0"><button class="btn-close"${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("buttons.close"))} data-bs-dismiss="modal" type="button"></button></div> <div class="modal-body text-center"><div class="pb-3"><i class="fas fa-plug fa-3x d-block m-auto text-gray"></i></div> <p>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.server-request.title", { values: { serverName: store_get($$store_subs ??= {}, "$server", server).name } }))}</p> <div class="card"><div class="card-body"><div class="row"><div class="col-auto"><img${attr("src", sanitizeImageSrc(store_get($$store_subs ??= {}, "$server", server).favicon ? store_get($$store_subs ??= {}, "$server", server).favicon : "/api/server/icon/default", "/api/server/icon/default"))} class="rounded border" width="48" height="48"${attr("alt", store_get($$store_subs ??= {}, "$server", server).name)}/></div> <div class="col text-start"><span class="badge text-bg-primary rounded-pill mb-2">${escape_html(store_get($$store_subs ??= {}, "$server", server).type)}</span> <div class="d-flex flex-row justify-content-between gap-2 mb-1"><span class="small text-body-secondary">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.remote"))}:</span> <span class="flex-shrink-0">${escape_html(store_get($$store_subs ??= {}, "$server", server).playerCount)}/${escape_html(store_get($$store_subs ??= {}, "$server", server).maxPlayerCount)}</span></div> <div class="font-monospace user-select-all text-break mb-1">${escape_html(getPrimaryAddress(store_get($$store_subs ??= {}, "$server", server)))}</div></div></div></div></div> <div class="text-start px-2 mt-3 w-100"><label class="form-label small mb-1" for="acceptServerDisplayName">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.server-request.display-name-label"))}</label> <input id="acceptServerDisplayName" type="text" class="form-control form-control-sm" maxlength="255"${attr("value", store_get($$store_subs ??= {}, "$acceptDisplayName", acceptDisplayName))}${attr("disabled", store_get($$store_subs ??= {}, "$submitLoading", submitLoading), true)} autocomplete="off" aria-describedby="acceptServerDisplayNameHint"/> <small id="acceptServerDisplayNameHint" class="text-muted d-block mt-1">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.server-request.display-name-hint"))}</small></div></div> <div class="modal-footer flex-nowrap"><button${attr_class("btn btn-link link-danger col-6 m-0", void 0, { "disabled": store_get($$store_subs ??= {}, "$submitLoading", submitLoading) })} type="button">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.server-request.reject"))}</button> <button${attr_class("btn btn-secondary col-6 m-0", void 0, { "disabled": store_get($$store_subs ??= {}, "$submitLoading", submitLoading) })} type="button">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.server-request.connect"))}</button></div>`);
		}
		$$renderer.push(`<!--]--></div></div></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
	});
}
//#endregion
//#region src/lib/components/sidebar/Bottom.svelte
function Bottom($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		getContext("session");
		getContext("panelTheme");
		getContext("siteInfo");
		$$renderer.push(`<nav class="nav justify-content-around w-100 py-1 align-items-center"><a class="nav-link text-light p-2"${attr("href", `${stringify(PANO_WEBSITE_URL)}/docs`)} target="_blank"${attr("title", store_get($$store_subs ??= {}, "$_", $format)("components.bottom.documentation"))}${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("components.bottom.documentation"))}><i class="fas fa-question-circle"></i></a> <a class="nav-link text-light p-2"${attr("href", PANO_WEBSITE_URL)} target="_blank"${attr("title", store_get($$store_subs ??= {}, "$_", $format)("components.bottom.website"))}${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("components.bottom.website"))}><i class="fas fa-globe"></i></a> <a class="nav-link text-light p-2"${attr("href", `${stringify(PANO_WEBSITE_URL)}/discord`)} target="_blank"${attr("title", store_get($$store_subs ??= {}, "$_", $format)("components.bottom.discord"))}${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("components.bottom.discord"))}><i class="fab fa-discord"></i></a> <a class="nav-link text-light p-2" href="https://github.com/PanoMC/Pano/issues/new" target="_blank" rel="noopener noreferrer"${attr("title", store_get($$store_subs ??= {}, "$_", $format)("components.navbar.report-a-bug"))}${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("components.navbar.report-a-bug"))}><i class="fa-solid fa-bug"></i></a></nav>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
	});
}
//#endregion
//#region src/lib/components/Sidebar.svelte
function Sidebar($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let panoVersion, isAlpha, isBeta;
		let menuComponent = SiteNavigationMenu;
		const sidebarTabsState = getContext("sidebarTabsState");
		const isSidebarOpen = getContext("isSidebarOpen");
		const siteInfo = getContext("siteInfo");
		let closeButton;
		let isFocused = false;
		let isScrolledTop = false;
		const unsubscribeSidebarTabsState = sidebarTabsState.subscribe((value) => {
			if (value === "website" || !hasPermission(Permissions.MANAGE_SERVERS)) menuComponent = SiteNavigationMenu;
			else menuComponent = ServerNavigationMenu;
		});
		onDestroy(unsubscribeSidebarTabsState);
		if (store_get($$store_subs ??= {}, "$isSidebarOpen", isSidebarOpen) && closeButton);
		panoVersion = store_get($$store_subs ??= {}, "$siteInfo", siteInfo)?.panoVersion || "";
		isAlpha = panoVersion.toLowerCase().includes("alpha") || panoVersion === "local-build";
		isBeta = panoVersion.toLowerCase().includes("beta");
		if (hasPermission(Permissions.MANAGE_SERVERS)) {
			$$renderer.push("<!--[0-->");
			ServersModal($$renderer);
			$$renderer.push(`<!----> `);
			ConnectServerModal($$renderer);
			$$renderer.push(`<!---->`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--> <div${attr_class("offcanvas offcanvas-start offcanvas-lg bg-primary h-100 overflow-hidden border svelte-129hoe0", void 0, { "sidebar-desktop-collapsed": !store_get($$store_subs ??= {}, "$isSidebarOpen", isSidebarOpen) })} tabindex="-1" id="sidebar" aria-labelledby="sidebarLabel" data-bs-scroll="true" data-bs-backdrop="true"><div class="offcanvas-body d-flex flex-column p-0 overflow-hidden h-100"><div class="sidebar-header-container p-2 flex-shrink-0 svelte-129hoe0"><div${attr_class("sidebar-top-fade-overlay svelte-129hoe0", void 0, { "show": isScrolledTop })}></div> <div class="navbar navbar-expand navbar-dark navbar-nav flex-row w-100 justify-content-center align-items-center position-relative"><button type="button"${attr_class("navbar-toggler d-block position-absolute start-0 ms-2 svelte-129hoe0", void 0, { "active": isFocused })}${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("components.sidebar.hide-menu"))}${attr("title", null)}${attr("data-bs-dismiss", void 0)}><i class="fa-solid fa-bars svelte-129hoe0"></i></button> <a class="navbar-brand m-auto position-relative focus-ring focus-ring-white rounded d-flex align-items-center justify-content-center svelte-129hoe0"${attr("href", `${stringify(base)}/`)} style="width: 48px; height: 48px;"><img alt="Pano" title="Pano"${attr("src", base + "/assets/img/logo.svg")} width="20"/> `);
		if (isAlpha) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<span class="badge text-bg-info position-absolute top-100 start-50 translate-middle small d-none">Alpha</span>`);
		} else if (isBeta) {
			$$renderer.push("<!--[1-->");
			$$renderer.push(`<span class="badge text-bg-primary position-absolute top-100 start-50 translate-middle small d-none">Beta</span>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--></a></div>  <ul class="nav nav-pills nav-fill gap-1 svelte-129hoe0" data-bs-theme="dark"><li class="nav-item"><button${attr_class("nav-link p-1 text-center svelte-129hoe0", void 0, { "active": store_get($$store_subs ??= {}, "$sidebarTabsState", sidebarTabsState) === "website" })}${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("components.sidebar.website"))}${attr("title", store_get($$store_subs ??= {}, "$_", $format)("components.sidebar.website"))}><i class="fas fa-globe"></i></button></li> `);
		if (hasPermission(Permissions.MANAGE_SERVERS)) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<li class="nav-item"><button${attr_class("nav-link p-1 text-center svelte-129hoe0", void 0, { "active": store_get($$store_subs ??= {}, "$sidebarTabsState", sidebarTabsState) === "game" })}${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("components.sidebar.server"))}${attr("title", store_get($$store_subs ??= {}, "$_", $format)("components.sidebar.server"))}><i class="fas fa-cube"></i></button></li>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--></ul></div> <div class="sidebar-scroll-area px-2 svelte-129hoe0">`);
		if (menuComponent) {
			$$renderer.push("<!--[-->");
			menuComponent($$renderer, {});
			$$renderer.push("<!--]-->");
		} else {
			$$renderer.push("<!--[!-->");
			$$renderer.push("<!--]-->");
		}
		$$renderer.push(`</div> <div class="sidebar-bottom-container p-2 svelte-129hoe0"><div class="sidebar-bottom-fade-overlay svelte-129hoe0"></div> `);
		Bottom($$renderer);
		$$renderer.push(`<!----></div></div></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
	});
}
//#endregion
//#region src/lib/components/Navbar.svelte
function Navbar($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		const selectedServer = getContext("selectedServer");
		const pageTitle = getContext("pageTitle");
		const user = getContext("user");
		const notificationCount = getContext("notificationCount");
		const isSidebarOpen = getContext("isSidebarOpen");
		const session = getContext("session");
		getContext("panelTheme");
		const sidebarTabsState = getContext("sidebarTabsState");
		getContext("siteInfo");
		let checkTime = 0;
		let sidebarToggler;
		let isFocused = false;
		const panelThemes = ["light", "dark"];
		function getTime(check, time, locale) {
			return formatDistanceToNow(time, {
				addSuffix: true,
				locale
			});
		}
		function scheduleReadForLast5(notifications) {}
		onDestroy(quickNotifications.subscribe(scheduleReadForLast5));
		onDestroy(() => {});
		function sanitizeObject(obj) {
			return Object.keys(obj).reduce((sanitizedObj, key) => {
				sanitizedObj[key] = sanitize(obj[key]);
				return sanitizedObj;
			}, {});
		}
		if (!store_get($$store_subs ??= {}, "$isSidebarOpen", isSidebarOpen) && sidebarToggler);
		store_get($$store_subs ??= {}, "$page", page).url.pathname.startsWith((base || "") + "/server");
		$$renderer.push(`<nav class="navbar navbar-expand navbar-light py-3"><div class="container"><div class="col-4 d-flex justify-content-start"><div class="navbar-nav"><button${attr_class("navbar-toggler d-inline-block me-2 svelte-rfuq4y", void 0, {
			"d-lg-none": store_get($$store_subs ??= {}, "$isSidebarOpen", isSidebarOpen),
			"active": isFocused
		})} type="button"${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("components.navbar.show-menu"))}${attr("title", null)}${attr("data-bs-toggle", void 0)}${attr("data-bs-target", void 0)} aria-controls="sidebar"><i class="fa-solid fa-bars svelte-rfuq4y"></i></button> `);
		if (store_get($$store_subs ??= {}, "$sidebarTabsState", sidebarTabsState) === "website") {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<div class="nav-item"><a${attr("href", "/")} target="_blank" class="nav-link d-flex align-items-center px-2"${attr("title", void 0)}><i class="fas fa-globe d-lg-none"></i> <span class="d-none d-lg-inline">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.sidebar.show-website"))}</span> <i class="fa-solid fa-arrow-up-right-from-square ms-2 d-none d-lg-inline-block"></i></a></div>`);
		} else if (store_get($$store_subs ??= {}, "$sidebarTabsState", sidebarTabsState) === "game") {
			$$renderer.push("<!--[1-->");
			$$renderer.push(`<div class="nav-item d-flex align-items-center"><div class="btn-group"><button type="button" class="btn btn-sm btn-link nav-link d-flex align-items-center border-0 px-2"${attr("title", store_get($$store_subs ??= {}, "$selectedServer", selectedServer) ? store_get($$store_subs ??= {}, "$_", $format)("components.navbar.selected-server") : store_get($$store_subs ??= {}, "$_", $format)("components.server-navigation-menu.select-server"))}>`);
			if (store_get($$store_subs ??= {}, "$selectedServer", selectedServer)) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<i${attr_class("fas fa-check-circle me-2 d-none", void 0, {
					"text-success": store_get($$store_subs ??= {}, "$selectedServer", selectedServer).status === "ONLINE",
					"text-danger": store_get($$store_subs ??= {}, "$selectedServer", selectedServer).status !== "ONLINE"
				})}></i> <span${attr_class("text-truncate d-none d-lg-inline", void 0, {
					"text-success": store_get($$store_subs ??= {}, "$selectedServer", selectedServer).status === "ONLINE",
					"text-danger": store_get($$store_subs ??= {}, "$selectedServer", selectedServer).status !== "ONLINE"
				})} style="max-width: 150px;">${escape_html(store_get($$store_subs ??= {}, "$selectedServer", selectedServer).customName || store_get($$store_subs ??= {}, "$selectedServer", selectedServer).name)}</span> <i${attr_class("fas fa-server d-lg-none", void 0, {
					"text-success": store_get($$store_subs ??= {}, "$selectedServer", selectedServer).status === "ONLINE",
					"text-danger": store_get($$store_subs ??= {}, "$selectedServer", selectedServer).status !== "ONLINE"
				})}></i>`);
			} else {
				$$renderer.push("<!--[-1-->");
				$$renderer.push(`<i class="fa-solid fa-ghost me-lg-2" aria-hidden="true"></i> <span class="d-none d-lg-inline">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.server-navigation-menu.no-selected-server"))}</span> <span class="visually-hidden d-lg-none">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.server-navigation-menu.no-selected-server"))}</span>`);
			}
			$$renderer.push(`<!--]--></button> <button class="btn btn-sm btn-link nav-link border-0 px-2" data-bs-target="#connectServer" data-bs-toggle="modal"${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("components.server-navigation-menu.connect-server"))} type="button"${attr("title", store_get($$store_subs ??= {}, "$_", $format)("components.server-navigation-menu.connect-server"))}><i class="fa-solid fa-plus"></i></button></div></div>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--></div></div> <div class="col-4 d-flex justify-content-center"><h5 class="text-truncate mb-0">${escape_html(store_get($$store_subs ??= {}, "$pageTitle", pageTitle) ? store_get($$store_subs ??= {}, "$_", $format)(store_get($$store_subs ??= {}, "$pageTitle", pageTitle)) : options.DEFAULT_PAGE_TITLE)}</h5></div> <div class="col-4 d-flex justify-content-end"><div class="navbar-nav"><div class="nav-item dropdown" id="quickNotificationsDropdown"><button class="nav-link position-relative" data-bs-toggle="dropdown" type="button"${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("components.navbar.notifications"))}${attr("title", store_get($$store_subs ??= {}, "$_", $format)("components.navbar.notifications"))}><i class="fa-regular fa-bolt"></i> `);
		if (store_get($$store_subs ??= {}, "$notificationCount", notificationCount) !== 0) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">${escape_html(store_get($$store_subs ??= {}, "$notificationCount", notificationCount))}</span>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--></button> <div style="width: 300px;" class="dropdown-menu dropdown-menu-end"><h6 class="dropdown-header">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.navbar.notifications"))}
              ${escape_html(store_get($$store_subs ??= {}, "$notificationCount", notificationCount) === 0 ? "" : "(" + store_get($$store_subs ??= {}, "$notificationCount", notificationCount) + ")")}</h6> `);
		if (store_get($$store_subs ??= {}, "$quickNotifications", quickNotifications).length === 0) {
			$$renderer.push("<!--[0-->");
			NoContent($$renderer, {});
		} else {
			$$renderer.push("<!--[-1-->");
			$$renderer.push(`<div class="list-group list-group-flush"><!--[-->`);
			const each_array = ensure_array_like(store_get($$store_subs ??= {}, "$quickNotifications", quickNotifications));
			for (let index = 0, $$length = each_array.length; index < $$length; index++) {
				let notification = each_array[index];
				$$renderer.push(`<div${attr_class("panel-notification-row fw-normal list-group-item list-group-item-action d-flex align-items-center gap-3 text-wrap", void 0, { "notification-unread": isPanelNotificationUnread(notification) })}><button type="button"${attr("title", store_get($$store_subs ??= {}, "$_", $format)("buttons.view"))} class="text-start border-0 bg-transparent p-0 d-flex align-items-center gap-3"><div class="d-flex align-items-center">`);
				if (notification.details.faIcon) {
					$$renderer.push("<!--[0-->");
					$$renderer.push(`<i${attr_class(`${stringify(notification.details.faIcon)} fa-lg fa-fw text-primary`)}></i>`);
				} else if (notification.details.image || notification.details.username) {
					$$renderer.push("<!--[1-->");
					$$renderer.push(`<img${attr("src", sanitizeImageSrc(notification.details.image || `/api/profile/picture/${notification.details.username}?${store_get($$store_subs ??= {}, "$avatarVersion", avatarVersion)}`, "/api/server/icon/default"))}${attr("alt", store_get($$store_subs ??= {}, "$_", $format)("buttons.view"))} width="18" height="18" class="rounded-circle"/>`);
				} else {
					$$renderer.push("<!--[-1-->");
					$$renderer.push(`<i class="fa fa-bolt fa-lg fa-fw text-primary"></i>`);
				}
				$$renderer.push(`<!--]--></div> <div class="fw-normal"><span class="text-wrap markdown-renderer text-break">${html(store_get($$store_subs ??= {}, "$_", $format)("notifications." + notification.type, { values: { ...sanitizeObject(notification.details || {}) } }))}</span> <br/> <small>${escape_html(getTime(checkTime, parseInt(notification.createdAt), locale_exports[store_get($$store_subs ??= {}, "$currentLanguage", currentLanguage).dateFnsCode]))}</small></div></button></div>`);
			}
			$$renderer.push(`<!--]--></div>`);
		}
		$$renderer.push(`<!--]--> <a class="dropdown-item bg-transparent"${attr("href", `${stringify(base)}/notifications`)}><button class="btn btn-sm btn-primary w-100">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.navbar.show-all"))}</button></a></div></div> <div class="nav-item dropdown">`);
		{
			$$renderer.push("<!--[-1-->");
			$$renderer.push(`<button class="nav-link" data-bs-toggle="dropdown" type="button"${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("components.navbar.panel-theme"))}${attr("title", store_get($$store_subs ??= {}, "$_", $format)("components.navbar.panel-theme"))}><i class="fa-solid fa-palette"></i></button> <ul class="dropdown-menu dropdown-menu-end"><h6 class="dropdown-header">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.navbar.panel-theme"))}</h6> <!--[-->`);
			const each_array_1 = ensure_array_like(panelThemes);
			for (let $$index_1 = 0, $$length = each_array_1.length; $$index_1 < $$length; $$index_1++) {
				let theme = each_array_1[$$index_1];
				$$renderer.push(`<li><button type="button"${attr_class("dropdown-item", void 0, { "active": (store_get($$store_subs ??= {}, "$session", session).basicData.panelTheme || "dark") === theme })}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("panel-themes." + theme))}</button></li>`);
			}
			$$renderer.push(`<!--]--></ul>`);
		}
		$$renderer.push(`<!--]--></div> <div class="nav-item dropdown"><button type="button" class="nav-link h-100 d-flex align-items-center" data-bs-toggle="dropdown"${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("components.navbar.account-dropdown.session"))}${attr("title", store_get($$store_subs ??= {}, "$_", $format)("components.navbar.account-dropdown.session"))}><img${attr("src", `/api/profile/picture/${stringify(store_get($$store_subs ??= {}, "$user", user).username)}?${stringify(store_get($$store_subs ??= {}, "$avatarVersion", avatarVersion))}`)} width="20" height="20" class="rounded-circle"${attr("alt", store_get($$store_subs ??= {}, "$user", user).username)}/></button> <ul class="dropdown-menu dropdown-menu-end"><h6 class="dropdown-header">${escape_html(store_get($$store_subs ??= {}, "$user", user).username)}</h6> `);
		if (hasPermission(Permissions.MANAGE_PLAYERS, store_get($$store_subs ??= {}, "$user", user))) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<li><a class="dropdown-item focus-ring"${attr("href", `${stringify(base)}/players/detail/${stringify(store_get($$store_subs ??= {}, "$user", user).username)}`)}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.navbar.account-dropdown.profile"))}</a></li>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--> <li class="dropdown-item bg-transparent"><button class="btn btn-sm btn-danger w-100">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.navbar.account-dropdown.logout"))}</button></li></ul></div></div></div></div></nav>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
	});
}
//#endregion
//#region src/lib/layouts/MainLayout.svelte
var MainLayout_exports = /* @__PURE__ */ __exportAll({ default: () => MainLayout });
function MainLayout($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		const showDevModeAlert = getContext("showDevModeAlert");
		const siteInfo = getContext("siteInfo");
		Sidebar($$renderer);
		$$renderer.push(`<!----> <main class="main-container d-flex h-100 flex-grow-1 flex-column overflow-auto svelte-1vud52s">`);
		if (store_get($$store_subs ??= {}, "$siteInfo", siteInfo)?.isDemo) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<div class="alert alert-info fade show mb-0" role="alert"><div class="container-fluid d-flex align-items-center"><i class="fa-solid fa-circle-info me-3"></i> <div><strong class="me-2">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.alerts.demo-mode-title"))}</strong> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.alerts.demo-mode-description"))}</div></div></div>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--> `);
		if (store_get($$store_subs ??= {}, "$showDevModeAlert", showDevModeAlert)) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<div class="alert alert-warning alert-dismissible fade show mb-0" role="alert"><div class="container-fluid d-flex align-items-center"><i class="fa-solid fa-triangle-exclamation me-3"></i> <div><strong class="me-2">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.alerts.dev-mode-title"))}</strong> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.alerts.dev-mode-description"))}</div> <button type="button" class="btn-close"${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("buttons.close"))}></button></div></div>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--> `);
		Navbar($$renderer);
		$$renderer.push(`<!----> <!--[-->`);
		slot($$renderer, $$props, "default", {}, null);
		$$renderer.push(`<!--]--></main>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
	});
}
//#endregion
//#region src/lib/components/modals/RestartingModal.svelte
function RestartingModal($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		const platformRestarting = getContext("platformRestarting");
		if (store_get($$store_subs ??= {}, "$platformRestarting", platformRestarting)) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<div class="modal show svelte-1dgkdxx" style="display: block; pointer-events: none; z-index: 1070;" tabindex="-1" role="dialog" aria-hidden="false"><div class="modal-dialog modal-dialog-centered svelte-1dgkdxx" role="document"><div class="modal-content text-center shadow-lg border-0 svelte-1dgkdxx" style="pointer-events: auto; border-radius: 1.5rem;"><div class="modal-body p-5 svelte-1dgkdxx"><div class="mb-4 svelte-1dgkdxx"><i class="fas fa-arrows-rotate fa-3x text-primary spin svelte-1dgkdxx"></i></div> <h4 class="mb-3 fw-bold svelte-1dgkdxx">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.restarting-pano.title"))}</h4> <p class="mb-0 svelte-1dgkdxx">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.restarting-pano.description"))}</p></div></div></div></div> <div class="modal-backdrop fade show svelte-1dgkdxx" style="z-index: 1060;"></div>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]-->`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
	});
}
//#endregion
//#region src/lib/layouts/AppLayout.svelte
var AppLayout_exports = /* @__PURE__ */ __exportAll({
	default: () => AppLayout,
	load: () => load,
	loadServer: () => loadServer
});
var import_copy_to_clipboard = /* @__PURE__ */ __toESM(require_copy_to_clipboard());
var initLanguage = init;
/**
* @type {import('@sveltejs/kit').LayoutServerLoad}
*/
async function loadServer(event) {
	const { locals: { basicData, csrfToken, apiUrlEnv, panoWebsiteUrlEnv, panoWebsiteApiUrlEnv } } = event;
	let siteInfo = await ApiUtil.get({
		path: "/api/siteInfo",
		request: event,
		csrfToken
	});
	await preparePlugins(siteInfo);
	return {
		basicData,
		csrfToken,
		siteInfo,
		apiUrlEnv,
		panoWebsiteUrlEnv,
		panoWebsiteApiUrlEnv,
		avatarVersionDate: `&v=${Date.now()}`
	};
}
/**
* @type {import('@sveltejs/kit').LayoutLoad}
*/
async function load(event) {
	const { data: { basicData, csrfToken, siteInfo, apiUrlEnv, panoWebsiteUrlEnv, panoWebsiteApiUrlEnv, avatarVersionDate }, parent } = event;
	await parent();
	avatarVersion.set(avatarVersionDate);
	if (apiUrlEnv) updateApiUrl(apiUrlEnv);
	if (panoWebsiteUrlEnv) updatePanoWebsiteUrl(panoWebsiteUrlEnv);
	if (panoWebsiteApiUrlEnv) updatePanoWebsiteApiUrl(panoWebsiteApiUrlEnv);
	setPanoContext({
		page,
		base,
		navigating,
		browser: false,
		goto,
		invalidate,
		invalidateAll,
		error,
		components: {
			PageActions,
			PageLoader,
			PageNavItem,
			PageNav,
			Pagination,
			PageLoading,
			Toast,
			CardFilters,
			CardFiltersItem,
			CardHeader,
			Date: Date_1,
			NoContent,
			Editor: Editor_1,
			DragAndDropZone,
			SearchInput
		},
		utils: {
			api: {
				ApiUtil,
				...api_util_exports
			},
			language: {
				...language_util_exports,
				_: $format
			},
			tooltip: { tooltip },
			toast: { ...ToastContainer_exports },
			text: { copy: import_copy_to_clipboard.default }
		},
		variables: { ...variables_exports }
	});
	await initializePlugins(siteInfo);
	await initLanguage(siteInfo.locale, event);
	const output = {
		session: {
			basicData,
			csrfToken
		},
		user: basicData.user || {},
		website: basicData.website || {},
		platformServerMatchKey: basicData.platformServerMatchKey || "",
		platformKeyRefreshedTime: basicData.platformServerMatchKeyTimeStarted || Date.now(),
		platformHostAddress: basicData.platformHostAddress || "",
		notificationCount: basicData.notificationCount || 0,
		mainServer: basicData.mainServer || {},
		selectedServer: basicData.selectedServer,
		connectedServerCount: basicData.connectedServerCount,
		siteInfo,
		resetLayout: writable(false),
		pageTitle: writable(null)
	};
	if (basicData.result !== "ok") output.NETWORK_ERROR = true;
	return output;
}
function AppLayout($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let title;
		let data = $$props["data"];
		const session = writable(data.session);
		const user = writable(data.user);
		const website = writable(data.website);
		const platformServerMatchKey = writable(data.platformServerMatchKey);
		const platformKeyRefreshedTime = writable(data.platformKeyRefreshedTime);
		const platformHostAddress = writable(data.platformHostAddress);
		const notificationCount = writable(data.notificationCount);
		const mainServer = writable(data.mainServer);
		const selectedServer = writable(data.selectedServer);
		const connectedServerCount = writable(data.connectedServerCount);
		const siteInfo = writable(data.siteInfo);
		const showSplash = writable(true);
		const platformUpdating = writable(false);
		const platformRestarting = writable(false);
		const panelTheme = writable(data.session.basicData.panelTheme || "dark");
		const showDevModeAlert = writable(data.session.basicData.showDevModeAlert);
		const maintenanceMode = writable(!!data.session.basicData.maintenanceMode);
		let tmp = data, resetLayout = tmp.resetLayout, pageTitle = tmp.pageTitle;
		const sidebarTabsState = writable(getCurrentSidebarState());
		const isSidebarOpen = writable(PanelSidebarStorageUtil.getSidebarOpenStatus() );
		const navigatingUnsubscribe = navigating.subscribe((nav) => {});
		const pageUnsubscribe = page.subscribe((p) => {
			session.set(data.session);
			user.set(data.user);
			website.set(data.website);
			platformServerMatchKey.set(data.platformServerMatchKey);
			platformKeyRefreshedTime.set(data.platformKeyRefreshedTime);
			platformHostAddress.set(data.platformHostAddress);
			notificationCount.set(data.notificationCount);
			mainServer.set(data.mainServer);
			connectedServerCount.set(data.connectedServerCount);
			siteInfo.set(data.siteInfo);
			panelTheme.set(data.session.basicData.panelTheme || "dark");
			sidebarTabsState.set(getCurrentSidebarState());
		});
		setContext("pageTitle", pageTitle);
		setContext("session", session);
		setContext("user", user);
		setContext("website", website);
		setContext("platformServerMatchKey", platformServerMatchKey);
		setContext("platformKeyRefreshedTime", platformKeyRefreshedTime);
		setContext("platformHostAddress", platformHostAddress);
		setContext("notificationCount", notificationCount);
		setContext("mainServer", mainServer);
		setContext("selectedServer", selectedServer);
		setContext("connectedServerCount", connectedServerCount);
		setContext("sidebarTabsState", sidebarTabsState);
		setContext("isSidebarOpen", isSidebarOpen);
		setContext("siteInfo", siteInfo);
		setContext("platformUpdating", platformUpdating);
		setContext("platformRestarting", platformRestarting);
		setContext("panelTheme", panelTheme);
		setContext("showDevModeAlert", showDevModeAlert);
		setContext("maintenanceMode", maintenanceMode);
		let waitAnimation = false;
		let mounted = false;
		let whatsNewShown = false;
		function getCurrentSidebarState() {
			if (!hasPermission(Permissions.MANAGE_SERVERS)) return "website";
			return "website";
		}
		setTimeout(function() {
			waitAnimation = false;
			if (get(networkErrorCallbacks).length === 0 && !get(logoutLoading) && mounted);
		}, 1500);
		onDestroy(networkErrorCallbacks.subscribe((value) => {
			if (!store_get($$store_subs ??= {}, "$showSplash", showSplash) && value.length !== 0) {
				if (store_get($$store_subs ??= {}, "$platformUpdating", platformUpdating) || store_get($$store_subs ??= {}, "$platformRestarting", platformRestarting)) return;
				store_set(showSplash, true);
			} else if (store_get($$store_subs ??= {}, "$showSplash", showSplash) && value.length === 0 && !waitAnimation && !get(logoutLoading) && mounted);
		}));
		onDestroy(pageUnsubscribe);
		onDestroy(navigatingUnsubscribe);
		onDestroy(() => {});
		({resetLayout, pageTitle} = data);
		setContext("resetLayout", resetLayout);
		setContext("pageTitle", pageTitle);
		if (data && data.selectedServer !== void 0) {
			const next = data.selectedServer;
			if (next == null) selectedServer.set(null);
			else {
				const cur = get(selectedServer);
				if (cur && Number(cur.id) === Number(next.id)) selectedServer.set({
					...next,
					...cur
				});
				else selectedServer.set(next);
			}
		}
		if (data?.session?.basicData) {
			showDevModeAlert.set(data.session.basicData.showDevModeAlert);
			if (data.session.basicData.maintenanceMode !== void 0) maintenanceMode.set(!!data.session.basicData.maintenanceMode);
		}
		title = store_get($$store_subs ??= {}, "$pageTitle", pageTitle) ? `${store_get($$store_subs ??= {}, "$_", $format)(store_get($$store_subs ??= {}, "$pageTitle", pageTitle))} \u2014 ${options.DEFAULT_PAGE_TITLE}` : options.DEFAULT_PAGE_TITLE;
		if (!store_get($$store_subs ??= {}, "$showSplash", showSplash) && !whatsNewShown) {
			if (data.session.basicData.dismissedWhatsNewVersion === "1") whatsNewShown = true;
			else {
				show();
				whatsNewShown = true;
			}
		}
		head("1m3kzz8", $$renderer, ($$renderer) => {
			$$renderer.title(($$renderer) => {
				$$renderer.push(`<title>${escape_html(title)}</title>`);
			});
			$$renderer.push(`<link${attr("href", `/api/favicon?hash=${stringify(data.siteInfo.faviconHash)}`)} rel="icon"/> <meta${attr("content", store_get($$store_subs ??= {}, "$session", session).basicData.panelTheme || "dark")} name="x-theme"/>`);
		});
		App($$renderer, {
			children: ($$renderer) => {
				if (store_get($$store_subs ??= {}, "$showSplash", showSplash)) {
					$$renderer.push("<!--[0-->");
					Splash($$renderer);
				} else $$renderer.push("<!--[-1-->");
				$$renderer.push(`<!--]--> <div${attr_class("vh-100 overflow-hidden flex-column", void 0, { "d-flex": !store_get($$store_subs ??= {}, "$showSplash", showSplash) })}${attr("hidden", store_get($$store_subs ??= {}, "$showSplash", showSplash))}>`);
				if (store_get($$store_subs ??= {}, "$maintenanceMode", maintenanceMode)) {
					$$renderer.push("<!--[0-->");
					$$renderer.push(`<div class="alert alert-danger fade show mb-0 rounded-0 flex-shrink-0" role="alert"><div class="container-fluid d-flex align-items-center"><i class="fa-solid fa-screwdriver-wrench me-3"></i> <div>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.maintenance-banner.text"))} `);
					if (hasPermission(Permissions.MANAGE_PLATFORM_SETTINGS)) {
						$$renderer.push("<!--[0-->");
						$$renderer.push(`<a class="alert-link ms-2"${attr("href", `${stringify(base)}/settings/platform`)}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.maintenance-banner.go-to-settings"))} <i class="fa-solid fa-arrow-right ms-1"></i></a>`);
					} else $$renderer.push("<!--[-1-->");
					$$renderer.push(`<!--]--></div></div></div>`);
				} else $$renderer.push("<!--[-1-->");
				$$renderer.push(`<!--]--> <div class="d-flex flex-grow-1 overflow-hidden" style="min-height: 0;">`);
				if (store_get($$store_subs ??= {}, "$resetLayout", resetLayout)) {
					$$renderer.push("<!--[0-->");
					$$renderer.push(`<!--[-->`);
					slot($$renderer, $$props, "default", {}, null);
					$$renderer.push(`<!--]-->`);
				} else {
					$$renderer.push("<!--[-1-->");
					MainLayout($$renderer, {
						children: ($$renderer) => {
							$$renderer.push(`<!--[-->`);
							slot($$renderer, $$props, "default", {}, null);
							$$renderer.push(`<!--]-->`);
						},
						$$slots: { default: true }
					});
				}
				$$renderer.push(`<!--]--></div></div> `);
				NotificationContainer($$renderer);
				$$renderer.push(`<!----> `);
				ToastContainer($$renderer);
				$$renderer.push(`<!----> `);
				if (hasPermission(Permissions.MANAGE_SERVERS)) {
					$$renderer.push("<!--[0-->");
					ServerRequestModal($$renderer);
				} else $$renderer.push("<!--[-1-->");
				$$renderer.push(`<!--]--> `);
				if (hasPermission(Permissions.MANAGE_VIEW) || hasPermission(Permissions.MANAGE_ADDONS)) {
					$$renderer.push("<!--[0-->");
					InstallingResourceModal($$renderer);
				} else $$renderer.push("<!--[-1-->");
				$$renderer.push(`<!--]--> `);
				RestartingModal($$renderer);
				$$renderer.push(`<!----> `);
				ConfirmActionModal($$renderer);
				$$renderer.push(`<!----> `);
				WhatsNewModal($$renderer);
				$$renderer.push(`<!---->`);
			},
			$$slots: { default: true }
		});
		if ($$store_subs) unsubscribe_stores($$store_subs);
		bind_props($$props, { data });
	});
}

export { AppLayout_exports as A, MainLayout_exports as M, loadServer as a, AppLayout as b, load as l };
//# sourceMappingURL=AppLayout.js-DQpVQODo.js.map
