import { b as base } from './internal.js-BRN1McAa.js';
import { N as fallback, T as attr, U as stringify, Q as store_get, Z as escape_html, S as unsubscribe_stores, O as bind_props, V as attr_class, a1 as clsx } from './index-server.js-DdhL7Abu.js';
import './server.js-BlClO2ED.js';
import './internal2.js-CNe5OZUJ.js';
import './routing.js-N-OPb2ye.js';
import { f as avatarVersion } from './Store.js-DT3aZHRb.js';
import { $ as $format } from './runtime.js-BzHEw_ze.js';
import { l as locale_exports } from './locale.js-DgLiJnqO.js';
import { e as enUS, h as getDefaultOptions } from './en-US.js-Qz-txlMm.js';
import { i as intervalToDuration } from './intervalToDuration.js-Bqoo9ab3.js';
import { D as Date_1 } from './Date.js-DCZp_jrB.js';
import { c as currentLanguage } from './language.util.js-ByanOnuS.js';
import './tooltip.util.js-BeLZL-Tj.js';

//#region node_modules/date-fns/formatDuration.js
/**
* The {@link formatDuration} function options.
*/
var defaultFormat = [
	"years",
	"months",
	"weeks",
	"days",
	"hours",
	"minutes",
	"seconds"
];
/**
* @name formatDuration
* @category Common Helpers
* @summary Formats a duration in human-readable format
*
* @description
* Return human-readable duration string i.e. "9 months 2 days"
*
* @param duration - The duration to format
* @param options - An object with options.
*
* @returns The formatted date string
*
* @example
* // Format full duration
* formatDuration({
*   years: 2,
*   months: 9,
*   weeks: 1,
*   days: 7,
*   hours: 5,
*   minutes: 9,
*   seconds: 30
* })
* //=> '2 years 9 months 1 week 7 days 5 hours 9 minutes 30 seconds'
*
* @example
* // Format partial duration
* formatDuration({ months: 9, days: 2 })
* //=> '9 months 2 days'
*
* @example
* // Customize the format
* formatDuration(
*   {
*     years: 2,
*     months: 9,
*     weeks: 1,
*     days: 7,
*     hours: 5,
*     minutes: 9,
*     seconds: 30
*   },
*   { format: ['months', 'weeks'] }
* ) === '9 months 1 week'
*
* @example
* // Customize the zeros presence
* formatDuration({ years: 0, months: 9 })
* //=> '9 months'
* formatDuration({ years: 0, months: 9 }, { zero: true })
* //=> '0 years 9 months'
*
* @example
* // Customize the delimiter
* formatDuration({ years: 2, months: 9, weeks: 3 }, { delimiter: ', ' })
* //=> '2 years, 9 months, 3 weeks'
*/
function formatDuration(duration, options) {
	const defaultOptions = getDefaultOptions();
	const locale = options?.locale ?? defaultOptions.locale ?? enUS;
	const format = options?.format ?? defaultFormat;
	const zero = options?.zero ?? false;
	const delimiter = options?.delimiter ?? " ";
	if (!locale.formatDistance) return "";
	return format.reduce((acc, unit) => {
		const token = `x${unit.replace(/(^.)/, (m) => m.toUpperCase())}`;
		const value = duration[unit];
		if (value !== void 0 && (zero || duration[unit])) return acc.concat(locale.formatDistance(token, value));
		return acc;
	}, []).join(delimiter);
}
//#endregion
//#region src/lib/components/badges/BanSourceBadge.svelte
function BanSourceBadge($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let variant, label, icon;
		let source = $$props["source"];
		function deriveVariant(src) {
			if (!src) return "other";
			const upper = src.toUpperCase();
			if (upper === "PANEL") return "panel";
			if (upper.startsWith("MIGRATION")) return "migration";
			if (upper === "SERVER") return "server";
			return "other";
		}
		function deriveLabel(src) {
			if (!src) return "";
			const upper = src.toUpperCase();
			if (upper === "PANEL") return store_get($$store_subs ??= {}, "$_", $format)("pages.player-detail.source-panel");
			if (upper.startsWith("MIGRATION")) return store_get($$store_subs ??= {}, "$_", $format)("pages.player-detail.source-migration");
			if (upper === "SERVER") return store_get($$store_subs ??= {}, "$_", $format)("pages.player-detail.source-server");
			return src;
		}
		function deriveIcon(v) {
			switch (v) {
				case "panel": return "fas fa-desktop";
				case "migration": return "fas fa-file-import";
				case "server": return "fas fa-server";
				default: return "fas fa-circle";
			}
		}
		variant = deriveVariant(source);
		label = deriveLabel(source);
		icon = deriveIcon(variant);
		$$renderer.push(`<span${attr_class("badge", void 0, {
			"text-bg-primary": variant === "panel",
			"text-bg-secondary": variant === "migration",
			"text-bg-info": variant === "server",
			"text-bg-light": variant === "other"
		})}><i${attr_class(clsx(icon), void 0, { "me-1": !!label })}></i>${escape_html(label)}</span>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
		bind_props($$props, { source });
	});
}
//#endregion
//#region src/lib/components/rows/BanHistoryRow.svelte
function BanHistoryRow($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let banHistory = $$props["banHistory"];
		let showBannedPlayer = fallback($$props["showBannedPlayer"], false);
		function getBanDurationText(createdAt, bannedUntil) {
			const createdAtDate = new Date(createdAt);
			const bannedUntilDate = new Date(bannedUntil);
			const duration = intervalToDuration({
				start: createdAtDate,
				end: bannedUntilDate
			});
			let years = duration.years || 0;
			let months = duration.months || 0;
			let weeks = 0;
			let days = duration.days || 0;
			let hours = duration.hours || 0;
			let minutes = duration.minutes || 0;
			if ((duration.seconds || 0) > 0) minutes += 1;
			if (minutes >= 60) {
				const extraHours = Math.floor(minutes / 60);
				hours += extraHours;
				minutes = minutes % 60;
			}
			if (hours >= 24) {
				const extraDays = Math.floor(hours / 24);
				days += extraDays;
				hours = hours % 24;
			}
			if (days >= 7) {
				const extraWeeks = Math.floor(days / 7);
				weeks += extraWeeks;
				days = days % 7;
			}
			if (weeks >= 4) {
				const extraMonths = Math.floor(weeks / 4);
				months += extraMonths;
				weeks = weeks % 4;
			}
			if (months >= 12) {
				const extraYears = Math.floor(months / 12);
				years += extraYears;
				months = months % 12;
			}
			const durationObj = {};
			if (years > 0) {
				durationObj.years = years;
				if (months > 0) durationObj.months = months;
				if (weeks > 0 && years === 0) durationObj.weeks = weeks;
				if (days > 0 && years === 0 && months === 0) durationObj.days = days;
				if (hours > 0) durationObj.hours = hours;
				if (minutes > 0) durationObj.minutes = minutes;
			} else if (months > 0) {
				durationObj.months = months;
				if (weeks > 0) durationObj.weeks = weeks;
				if (hours > 0) durationObj.hours = hours;
				if (minutes > 0) durationObj.minutes = minutes;
			} else if (weeks > 0) {
				durationObj.weeks = weeks;
				if (days > 0) durationObj.days = days;
				if (hours > 0) durationObj.hours = hours;
				if (minutes > 0) durationObj.minutes = minutes;
			} else if (days > 0) {
				durationObj.days = days;
				if (hours > 0) durationObj.hours = hours;
				if (minutes > 0) durationObj.minutes = minutes;
			} else if (hours > 0) {
				durationObj.hours = hours;
				if (minutes > 0) durationObj.minutes = minutes;
			} else if (minutes > 0) durationObj.minutes = minutes;
			else durationObj.minutes = 1;
			return formatDuration(durationObj, { locale: locale_exports[store_get($$store_subs ??= {}, "$currentLanguage", currentLanguage).dateFnsCode] });
		}
		$$renderer.push(`<tr>`);
		if (showBannedPlayer) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<td class="align-middle" style="max-width: 200px;"><div class="text-truncate d-flex align-items-center"><a class="rounded focus-ring text-decoration-none text-truncate d-flex align-items-center"${attr("title", banHistory.username)}${attr("href", `${stringify(base)}/players/detail/${stringify(banHistory.username)}`)}><img${attr("src", `/api/profile/picture/${stringify(banHistory.username)}?${stringify(store_get($$store_subs ??= {}, "$avatarVersion", avatarVersion))}`)}${attr("alt", banHistory.username)} width="32" height="32" class="rounded-circle me-2 flex-shrink-0"/> <span class="text-truncate">${escape_html(banHistory.username)}</span></a></div></td>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--><td class="align-middle text-nowrap">`);
		if (banHistory.bannedUntil) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<span>${escape_html(getBanDurationText(banHistory.bannedAt ?? banHistory.createdAt, banHistory.bannedUntil))}</span>`);
		} else {
			$$renderer.push("<!--[-1-->");
			$$renderer.push(`<span>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.player-detail.permanent-ban"))}</span>`);
		}
		$$renderer.push(`<!--]--></td><td class="align-middle" style="max-width: 250px;"><div class="text-truncate">`);
		if (banHistory.reason) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<span>${escape_html(banHistory.reason)}</span>`);
		} else if (banHistory.banReason) {
			$$renderer.push("<!--[1-->");
			$$renderer.push(`<span>${escape_html(banHistory.banReason)}</span>`);
		} else {
			$$renderer.push("<!--[-1-->");
			$$renderer.push(`<span>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.player-detail.no-reason"))}</span>`);
		}
		$$renderer.push(`<!--]--></div></td><td class="align-middle text-center">`);
		if (banHistory.emailNotified) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<span class="badge text-bg-success">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.player-detail.email-notified"))}</span>`);
		} else {
			$$renderer.push("<!--[-1-->");
			$$renderer.push(`<span class="badge text-bg-danger">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.player-detail.email-not-notified"))}</span>`);
		}
		$$renderer.push(`<!--]--></td><td class="align-middle" style="max-width: 180px;"><div class="text-truncate d-flex align-items-center">`);
		if (banHistory.bannedBy) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<a${attr("href", `${stringify(base)}/players/detail/${stringify(banHistory.bannedBy)}`)}${attr("title", store_get($$store_subs ??= {}, "$_", $format)("buttons.view"))} class="rounded focus-ring text-decoration-none text-truncate d-flex align-items-center"><img${attr("src", `/api/profile/picture/${stringify(banHistory.bannedBy)}?${stringify(store_get($$store_subs ??= {}, "$avatarVersion", avatarVersion))}`)}${attr("alt", banHistory.bannedBy)} class="rounded-circle me-2 flex-shrink-0" height="24" width="24"/> <span class="text-truncate">${escape_html(banHistory.bannedBy)}</span></a>`);
		} else {
			$$renderer.push("<!--[-1-->");
			$$renderer.push(`<span class="badge text-bg-primary">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.player-detail.system-ban"))}</span>`);
		}
		$$renderer.push(`<!--]--></div></td><td class="align-middle">`);
		if (banHistory.source) {
			$$renderer.push("<!--[0-->");
			BanSourceBadge($$renderer, { source: banHistory.source });
		} else {
			$$renderer.push("<!--[-1-->");
			$$renderer.push(`<span class="opacity-50">-</span>`);
		}
		$$renderer.push(`<!--]--></td><td class="align-middle text-nowrap">`);
		Date_1($$renderer, { time: banHistory.bannedAt ?? banHistory.createdAt });
		$$renderer.push(`<!----></td></tr>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
		bind_props($$props, {
			banHistory,
			showBannedPlayer
		});
	});
}

export { BanHistoryRow as B, BanSourceBadge as a, formatDuration as f };
//# sourceMappingURL=BanHistoryRow.js-5e9qraff.js.map
