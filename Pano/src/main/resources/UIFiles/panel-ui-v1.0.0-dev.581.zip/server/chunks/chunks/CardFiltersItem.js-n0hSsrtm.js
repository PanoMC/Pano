import { b as base } from './internal.js-BRN1McAa.js';
import { N as fallback, V as attr_class, U as stringify, W as slot, O as bind_props, T as attr } from './index-server.js-DdhL7Abu.js';
import './server.js-BlClO2ED.js';
import './internal2.js-CNe5OZUJ.js';
import './routing.js-N-OPb2ye.js';

//#region src/lib/components/CardFilters.svelte
function CardFilters($$renderer, $$props) {
	let clazz = fallback($$props["clazz"], "btn-group col-sm-auto col");
	$$renderer.push(`<div${attr_class(`overflow-x-auto ${stringify(clazz)}`)}><!--[-->`);
	slot($$renderer, $$props, "default", {}, null);
	$$renderer.push(`<!--]--></div>`);
	bind_props($$props, { clazz });
}
//#endregion
//#region src/lib/components/CardFiltersItem.svelte
function CardFiltersItem($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		let { href = "", active = false, button = false, onclick, children } = $$props;
		if (button) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<button type="button"${attr_class("btn btn-sm btn-outline-primary text-truncate", void 0, { "active": active })}>`);
			children?.($$renderer);
			$$renderer.push(`<!----></button>`);
		} else {
			$$renderer.push("<!--[-1-->");
			$$renderer.push(`<a${attr_class("btn btn-sm btn-outline-primary text-truncate", void 0, { "active": active })} role="button"${attr("href", href ? href.startsWith("http") ? href : base + href : "javascript:void(0)")}>`);
			children?.($$renderer);
			$$renderer.push(`<!----></a>`);
		}
		$$renderer.push(`<!--]-->`);
	});
}

export { CardFilters as C, CardFiltersItem as a };
//# sourceMappingURL=CardFiltersItem.js-n0hSsrtm.js.map
