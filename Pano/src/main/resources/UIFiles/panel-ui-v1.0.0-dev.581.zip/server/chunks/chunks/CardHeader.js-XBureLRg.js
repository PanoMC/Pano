import { a2 as sanitize_slots, N as fallback, V as attr_class, U as stringify, W as slot, O as bind_props } from './index-server.js-DdhL7Abu.js';

//#region src/lib/components/CardHeader.svelte
function CardHeader($$renderer, $$props) {
	const $$slots = sanitize_slots($$props);
	/** When false, the left slot can wrap (e.g. narrow cards / long titles). */
	let truncateLeftSlot = fallback($$props["truncateLeftSlot"], true);
	let leftClasses = fallback($$props["leftClasses"], "");
	let rightClasses = fallback($$props["rightClasses"], "");
	let middleClasses = fallback($$props["middleClasses"], "");
	let showRight = fallback($$props["showRight"], true);
	$$renderer.push(`<div class="card-header py-3"><div class="row d-flex align-items-center gx-0 gy-2"><div${attr_class(`${$$slots.middle ? $$slots.right && showRight ? "col-lg-3" : "col-lg-6" : $$slots.right && showRight ? "col-lg-6" : "col-12"} d-flex ${$$slots.right && showRight && !$$slots.middle ? "justify-content-lg-between" : "justify-content-lg-start"} justify-content-center text-center text-lg-start min-w-0 ${truncateLeftSlot ? "text-truncate text-nowrap" : "text-wrap"} ${stringify(leftClasses)}`)}><!--[-->`);
	slot($$renderer, $$props, "left", {}, null);
	$$renderer.push(`<!--]--></div> `);
	if ($$slots.middle) {
		$$renderer.push("<!--[0-->");
		$$renderer.push(`<div${attr_class(`col-lg-6 d-flex justify-content-center ${stringify(middleClasses)}`)}><!--[-->`);
		slot($$renderer, $$props, "middle", {}, null);
		$$renderer.push(`<!--]--></div>`);
	} else $$renderer.push("<!--[-1-->");
	$$renderer.push(`<!--]--> `);
	if ($$slots.right && showRight) {
		$$renderer.push("<!--[0-->");
		$$renderer.push(`<div${attr_class(`${$$slots.middle ? "col-lg-3" : "col-lg-6"} d-flex justify-content-lg-end justify-content-center ${stringify(rightClasses)}`)}><!--[-->`);
		slot($$renderer, $$props, "right", {}, null);
		$$renderer.push(`<!--]--></div>`);
	} else $$renderer.push("<!--[-1-->");
	$$renderer.push(`<!--]--></div></div>`);
	bind_props($$props, {
		truncateLeftSlot,
		leftClasses,
		rightClasses,
		middleClasses,
		showRight
	});
}

export { CardHeader as C };
//# sourceMappingURL=CardHeader.js-XBureLRg.js.map
