import { b as base } from './internal.js-BRN1McAa.js';
import { V as attr_class, T as attr, U as stringify, Z as escape_html, O as bind_props } from './index-server.js-DdhL7Abu.js';
import './server.js-BlClO2ED.js';
import './internal2.js-CNe5OZUJ.js';
import './routing.js-N-OPb2ye.js';
import './runtime.js-BzHEw_ze.js';

//#region src/lib/components/badges/CategoryBadge.svelte
function CategoryBadge($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		let category = $$props["category"];
		let pageType = $$props["pageType"];
		let filterTitle = $$props["filterTitle"];
		let noCategoryText = $$props["noCategoryText"];
		$$renderer.push(`<a${attr_class(`badge focus-ring text-decoration-none ${category.title === "-" ? "text-bg-primary" : "text-bg-secondary"}`)}${attr("title", filterTitle)}${attr("href", `${stringify(base)}/${stringify(pageType)}?categoryUrl=${stringify(category.url)}`)}>${escape_html(category.title === "-" ? noCategoryText : category.title)}</a>`);
		bind_props($$props, {
			category,
			pageType,
			filterTitle,
			noCategoryText
		});
	});
}

export { CategoryBadge as C };
//# sourceMappingURL=CategoryBadge.js-DjLui7ZD.js.map
