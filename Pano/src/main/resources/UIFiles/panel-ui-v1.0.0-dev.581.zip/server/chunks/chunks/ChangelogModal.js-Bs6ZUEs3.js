import { Z as escape_html, Q as store_get, T as attr, S as unsubscribe_stores, F as writable } from './index-server.js-DdhL7Abu.js';
import { $ as $format } from './runtime.js-BzHEw_ze.js';
import { M as MarkdownRenderer } from './MarkdownRenderer.js-CF3Vvdqz.js';

var changelogContent = writable("");
function ChangelogModal($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		$$renderer.push(`<div aria-hidden="true" class="modal fade" role="dialog"><div class="modal-dialog modal-dialog-centered modal-lg" role="dialog"><div class="modal-content"><div class="modal-header"><h5 class="modal-title">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.updates.changelog"))}</h5> <button type="button" class="btn-close"${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("buttons.close"))}></button></div> <div class="modal-body"><div class="markdown-renderer">`);
		MarkdownRenderer($$renderer, { content: store_get($$store_subs ??= {}, "$changelogContent", changelogContent) });
		$$renderer.push(`<!----></div></div></div></div></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
	});
}

export { ChangelogModal as C };
//# sourceMappingURL=ChangelogModal.js-Bs6ZUEs3.js.map
