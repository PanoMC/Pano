import { Z as escape_html, Q as store_get, S as unsubscribe_stores, F as writable } from './index-server.js-DdhL7Abu.js';
import { $ as $format } from './runtime.js-BzHEw_ze.js';

var titleValue = writable("");
var titleValues = writable({});
function ConfirmActionModal($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		$$renderer.push(`<div aria-hidden="true" class="modal fade" role="dialog" tabindex="-1"><div class="modal-dialog modal-dialog-centered" role="dialog"><div class="modal-content"><div class="modal-body text-center"><div class="pb-3"><i class="fas fa-question-circle fa-3x d-block m-auto text-gray"></i></div> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)(store_get($$store_subs ??= {}, "$titleValue", titleValue), { values: store_get($$store_subs ??= {}, "$titleValues", titleValues) }))}</div> <div class="modal-footer flex-nowrap"><button class="btn btn-link col-6 m-0" type="button">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.cancel"))}</button> <button class="btn btn-danger col-6 m-0" type="button">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.yes"))}</button></div></div></div></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
	});
}

export { ConfirmActionModal as C };
//# sourceMappingURL=ConfirmActionModal.js-C9rhvdA5.js.map
