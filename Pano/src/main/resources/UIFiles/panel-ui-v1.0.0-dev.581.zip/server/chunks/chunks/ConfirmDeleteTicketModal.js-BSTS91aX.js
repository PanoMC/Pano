import { Z as escape_html, Q as store_get, V as attr_class, T as attr, S as unsubscribe_stores, F as writable } from './index-server.js-DdhL7Abu.js';
import './server.js-BlClO2ED.js';
import './internal2.js-CNe5OZUJ.js';
import './routing.js-N-OPb2ye.js';
import 'node:module';
import './stores.js-D5xmrOAP.js';
import './ToastContainer.js-Bv1jJ2dr.js';
import { $ as $format } from './runtime.js-BzHEw_ze.js';

var selectedTickets$1 = writable([]);
function ConfirmCloseTicketModal($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let loading;
		$$renderer.push(`<div aria-hidden="true" class="modal fade" role="dialog" tabindex="-1"><div class="modal-dialog modal-dialog-centered" role="dialog"><div class="modal-content"><div class="modal-body text-center"><div class="pb-3"><i class="fas fa-question-circle fa-3x d-block m-auto text-gray"></i></div> ${escape_html(store_get($$store_subs ??= {}, "$selectedTickets", selectedTickets$1).length === 1 ? store_get($$store_subs ??= {}, "$_", $format)("components.modals.confirm-close-ticket.title-single") : store_get($$store_subs ??= {}, "$_", $format)("components.modals.confirm-close-ticket.title-multi"))}</div> <div class="modal-footer flex-nowrap"><button${attr_class("btn btn-link col-6 m-0", void 0, { "disabled": loading })} data-bs-dismiss="modal" type="button"${attr("aria-disabled", loading)}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.cancel"))}</button> <button${attr_class("btn btn-secondary col-6 m-0", void 0, { "disabled": loading })} type="button"${attr("aria-disabled", loading)}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.yes"))}</button></div></div></div></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
	});
}
var selectedTickets = writable([]);
function ConfirmDeleteTicketModal($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let loading;
		$$renderer.push(`<div aria-hidden="true" class="modal fade" role="dialog" tabindex="-1"><div class="modal-dialog modal-dialog-centered" role="dialog"><div class="modal-content"><div class="modal-body text-center"><div class="pb-3"><i class="fas fa-question-circle fa-3x d-block m-auto text-gray"></i></div> ${escape_html(store_get($$store_subs ??= {}, "$selectedTickets", selectedTickets).length === 1 ? store_get($$store_subs ??= {}, "$_", $format)("components.modals.confirm-delete-ticket.title-single") : store_get($$store_subs ??= {}, "$_", $format)("components.modals.confirm-delete-ticket.title-multi"))}</div> <div class="modal-footer flex-nowrap"><button${attr_class("btn btn-link col-6 m-0", void 0, { "disabled": loading })} type="button"${attr("aria-disabled", loading)}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.cancel"))}</button> <button${attr_class("btn btn-danger col-6 m-0", void 0, { "disabled": loading })} type="button"${attr("aria-disabled", loading)}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.yes"))}</button></div></div></div></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
	});
}

export { ConfirmCloseTicketModal as C, ConfirmDeleteTicketModal as a };
//# sourceMappingURL=ConfirmDeleteTicketModal.js-BSTS91aX.js.map
