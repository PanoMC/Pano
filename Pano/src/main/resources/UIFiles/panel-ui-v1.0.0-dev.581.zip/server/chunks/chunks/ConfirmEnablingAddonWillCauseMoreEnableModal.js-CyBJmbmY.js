import { b as base } from './internal.js-BRN1McAa.js';
import { Z as escape_html, Q as store_get, P as ensure_array_like, T as attr, U as stringify, V as attr_class, S as unsubscribe_stores, F as writable } from './index-server.js-DdhL7Abu.js';
import './server.js-BlClO2ED.js';
import './internal2.js-CNe5OZUJ.js';
import './routing.js-N-OPb2ye.js';
import { $ as $format } from './runtime.js-BzHEw_ze.js';

var plugin$1 = writable({ dependents: [] });
function ConfirmDisableAddonWillCauseMoreDisableModal($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let loading = false;
		$$renderer.push(`<div aria-hidden="true" class="modal fade" role="dialog" tabindex="-1"><div class="modal-dialog modal-dialog-centered" role="dialog"><div class="modal-content"><div class="modal-body text-center"><div class="pb-3"><i class="fas fa-question-circle fa-3x d-block m-auto text-gray"></i></div> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.confirm-disable-addon-will-cause-more-disable.title", { values: { pluginId: store_get($$store_subs ??= {}, "$plugin", plugin$1).id } }))} <div class="mt-3 alert alert-warning text-left">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.confirm-disable-addon-will-cause-more-disable.description", { values: { pluginId: store_get($$store_subs ??= {}, "$plugin", plugin$1).id } }))} <br/> <br/> <!--[-->`);
		const each_array = ensure_array_like(store_get($$store_subs ??= {}, "$plugin", plugin$1).dependents);
		for (let index = 0, $$length = each_array.length; index < $$length; index++) {
			let addon = each_array[index];
			$$renderer.push(`<a class="badge bg-warning rounded-pill"${attr("href", `${stringify(base)}/addons/detail/${stringify(addon)}`)} target="_blank">${escape_html(addon)}</a>`);
		}
		$$renderer.push(`<!--]--></div></div> <div class="modal-footer flex-nowrap"><button${attr_class("btn btn-link col-6 m-0", void 0, { "disabled": loading })} type="button">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.cancel"))}</button> <button${attr_class("btn btn-danger col-6 m-0", void 0, { "disabled": loading })} type="button">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.yes"))}</button></div></div></div></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
	});
}
var plugin = writable({ notStartedDependencies: [] });
function ConfirmEnablingAddonWillCauseMoreEnableModal($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let loading = false;
		$$renderer.push(`<div aria-hidden="true" class="modal fade" role="dialog" tabindex="-1"><div class="modal-dialog modal-dialog-centered" role="dialog"><div class="modal-content"><div class="modal-body text-center"><div class="pb-3"><i class="fas fa-question-circle fa-3x d-block m-auto text-gray"></i></div> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.confirm-enabling-addon-will-cause-more-enable.title", { values: { pluginId: store_get($$store_subs ??= {}, "$plugin", plugin).id } }))} <div class="mt-3 alert alert-warning text-left">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.confirm-enabling-addon-will-cause-more-enable.description", { values: { pluginId: store_get($$store_subs ??= {}, "$plugin", plugin).id } }))} <br/> <br/> <!--[-->`);
		const each_array = ensure_array_like(store_get($$store_subs ??= {}, "$plugin", plugin).notStartedDependencies);
		for (let index = 0, $$length = each_array.length; index < $$length; index++) {
			let addon = each_array[index];
			$$renderer.push(`<a class="badge bg-warning rounded-pill"${attr("href", `${stringify(base)}/addons/detail/${stringify(addon)}`)} target="_blank">${escape_html(addon)}</a>`);
		}
		$$renderer.push(`<!--]--></div></div> <div class="modal-footer flex-nowrap"><button${attr_class("btn btn-link col-6 m-0", void 0, { "disabled": loading })} type="button">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.cancel"))}</button> <button${attr_class("btn btn-danger col-6 m-0", void 0, { "disabled": loading })} type="button">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.yes"))}</button></div></div></div></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
	});
}

export { ConfirmDisableAddonWillCauseMoreDisableModal as C, ConfirmEnablingAddonWillCauseMoreEnableModal as a };
//# sourceMappingURL=ConfirmEnablingAddonWillCauseMoreEnableModal.js-CyBJmbmY.js.map
