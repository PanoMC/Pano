import { N as fallback, J as getContext, a4 as store_set, Q as store_get, Z as escape_html, T as attr, V as attr_class, S as unsubscribe_stores, O as bind_props, F as writable } from './index-server.js-DdhL7Abu.js';
import 'node:module';
import './stores.js-D5xmrOAP.js';
import './server.js-BlClO2ED.js';
import './internal2.js-CNe5OZUJ.js';
import './routing.js-N-OPb2ye.js';
import './ToastContainer.js-Bv1jJ2dr.js';
import { $ as $format } from './runtime.js-BzHEw_ze.js';

var loading$1 = writable(false);
var passwordError$1 = writable(false);
var password$1 = writable("");
var background = writable(false);
function ConfirmRestartPanoModal($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let showBackgroundOption, confirmButtonDisabled;
		let runMode = fallback($$props["runMode"], void 0);
		getContext("platformRestarting");
		showBackgroundOption = runMode != null && !runMode.background;
		if (showBackgroundOption) store_set(background, true);
		else store_set(background, false);
		confirmButtonDisabled = store_get($$store_subs ??= {}, "$password", password$1).length === 0 || showBackgroundOption && !store_get($$store_subs ??= {}, "$background", background);
		$$renderer.push(`<div aria-hidden="true" class="modal fade" role="dialog" tabindex="-1"><div class="modal-dialog modal-dialog-centered" role="dialog"><div class="modal-content"><form><div class="modal-body text-center"><div class="pb-3"><i class="fas fa-refresh fa-3x d-block m-auto text-warning"></i></div> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.confirm-restart-pano.title"))} `);
		if (showBackgroundOption) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<div class="alert alert-warning small text-start mt-3 mb-0"><i class="fas fa-triangle-exclamation me-2"></i> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.confirm-restart-pano.terminal-mode-warning"))}</div> <div class="form-check form-switch text-start mt-2"><input id="restartInBackgroundSwitch" class="form-check-input" type="checkbox"${attr("checked", store_get($$store_subs ??= {}, "$background", background), true)}${attr("disabled", store_get($$store_subs ??= {}, "$loading", loading$1), true)}/> <label class="form-check-label" for="restartInBackgroundSwitch">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.confirm-restart-pano.restart-in-background"))}</label></div>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--> <input${attr_class("form-control mt-3", void 0, { "border-danger": store_get($$store_subs ??= {}, "$passwordError", passwordError$1) })}${attr("placeholder", store_get($$store_subs ??= {}, "$_", $format)("components.modals.confirm-restart-pano.account-password"))} type="password"${attr("value", store_get($$store_subs ??= {}, "$password", password$1))}/></div> <div class="modal-footer flex-nowrap"><button class="btn btn-link col-6 m-0" type="button"${attr("disabled", store_get($$store_subs ??= {}, "$loading", loading$1), true)}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.cancel"))}</button> <button class="btn btn-warning col-6 m-0" type="button"${attr("disabled", confirmButtonDisabled || store_get($$store_subs ??= {}, "$loading", loading$1), true)}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.yes"))} `);
		if (store_get($$store_subs ??= {}, "$loading", loading$1)) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<i class="fas fa-sync fa-spin ms-2"></i>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--></button></div></form></div></div></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
		bind_props($$props, { runMode });
	});
}
var loading = writable(false);
var passwordError = writable(false);
var password = writable("");
function ConfirmSaveCriticalSettingsModal($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let confirmButtonDisabled;
		confirmButtonDisabled = store_get($$store_subs ??= {}, "$password", password).length === 0;
		$$renderer.push(`<div aria-hidden="true" class="modal fade" role="dialog" tabindex="-1"><div class="modal-dialog modal-dialog-centered" role="dialog"><div class="modal-content"><form><div class="modal-body text-center"><div class="pb-3"><i class="fas fa-triangle-exclamation fa-3x d-block m-auto text-warning"></i></div> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.confirm-save-critical-settings.title"))} <input${attr_class("form-control mt-3", void 0, { "border-danger": store_get($$store_subs ??= {}, "$passwordError", passwordError) })}${attr("placeholder", store_get($$store_subs ??= {}, "$_", $format)("components.modals.confirm-save-critical-settings.account-password"))} type="password"${attr("value", store_get($$store_subs ??= {}, "$password", password))}/></div> <div class="modal-footer flex-nowrap"><button class="btn btn-link col-6 m-0" type="button"${attr("disabled", store_get($$store_subs ??= {}, "$loading", loading), true)}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.cancel"))}</button> <button class="btn btn-warning col-6 m-0" type="submit"${attr("disabled", confirmButtonDisabled || store_get($$store_subs ??= {}, "$loading", loading), true)}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.save"))} `);
		if (store_get($$store_subs ??= {}, "$loading", loading)) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<i class="fas fa-sync fa-spin ms-2"></i>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--></button></div></form></div></div></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
	});
}

export { ConfirmRestartPanoModal as C, ConfirmSaveCriticalSettingsModal as a };
//# sourceMappingURL=ConfirmSaveCriticalSettingsModal.js-Coj5M9TO.js.map
