import { Q as store_get, Z as escape_html, V as attr_class, T as attr, S as unsubscribe_stores, F as writable } from './index-server.js-DdhL7Abu.js';
import './server.js-BlClO2ED.js';
import './internal2.js-CNe5OZUJ.js';
import './routing.js-N-OPb2ye.js';
import './stores.js-D5xmrOAP.js';
import 'node:module';
import './ToastContainer.js-Bv1jJ2dr.js';
import { $ as $format } from './runtime.js-BzHEw_ze.js';

var loading = writable(false);
var passwordError = writable(false);
var currentPassword = writable("");
function ConfirmDeletePlayerModal($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let yesButtonDisabled;
		yesButtonDisabled = store_get($$store_subs ??= {}, "$loading", loading) || !store_get($$store_subs ??= {}, "$currentPassword", currentPassword);
		$$renderer.push(`<div aria-hidden="true" class="modal fade" role="dialog" tabindex="-1"><div class="modal-dialog modal-dialog-centered" role="dialog"><div class="modal-content"><form><div class="modal-body text-center"><div class="pb-3"><i class="fas fa-question-circle fa-3x d-block m-auto text-gray"></i></div> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.confirm-delete-player.title"))} <input${attr_class("form-control d-inline-block text-center mt-3", void 0, { "border-danger": store_get($$store_subs ??= {}, "$passwordError", passwordError) })}${attr("placeholder", store_get($$store_subs ??= {}, "$_", $format)("components.modals.confirm-delete-player.inputs.password.placeholder"))} type="password" id="currentPasswordInput"${attr("value", store_get($$store_subs ??= {}, "$currentPassword", currentPassword))}/></div> <div class="modal-footer flex-nowrap"><button${attr_class("btn btn-link col-6 m-0", void 0, { "disabled": store_get($$store_subs ??= {}, "$loading", loading) })} type="button">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.cancel"))}</button> <button${attr_class("btn btn-danger col-6 m-0", void 0, { "disabled": yesButtonDisabled })} type="button">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.yes"))}</button></div></form></div></div></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
	});
}
function ConfirmSendVerificationEmailModal($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let loading = false;
		$$renderer.push(`<div aria-hidden="true" class="modal fade" role="dialog" tabindex="-1"><div class="modal-dialog modal-dialog-centered" role="dialog"><div class="modal-content"><div class="modal-body text-center"><div class="pb-3"><i class="fas fa-question-circle fa-3x d-block m-auto text-gray"></i></div> <div class="pb-3">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.confirm-send-verification-email.description"))}</div></div> <div class="modal-footer flex-nowrap"><button${attr_class("btn btn-link col-6 m-0", void 0, { "disabled": loading })} type="button">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.cancel"))}</button> <button${attr_class("btn btn-primary col-6 m-0", void 0, { "disabled": loading })} type="button">`);
		$$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.yes"))}</button></div></div></div></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
	});
}

export { ConfirmDeletePlayerModal as C, ConfirmSendVerificationEmailModal as a };
//# sourceMappingURL=ConfirmSendVerificationEmailModal.js-CMMYyDqx.js.map
