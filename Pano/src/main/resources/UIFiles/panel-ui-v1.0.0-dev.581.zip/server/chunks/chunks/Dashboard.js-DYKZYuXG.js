import { b as base } from './internal.js-BRN1McAa.js';
import { J as getContext, Z as escape_html, Q as store_get, T as attr, U as stringify, X as html, P as ensure_array_like, S as unsubscribe_stores, O as bind_props, F as writable } from './index-server.js-DdhL7Abu.js';
import './server.js-BlClO2ED.js';
import './internal2.js-CNe5OZUJ.js';
import './routing.js-N-OPb2ye.js';
import { b as ApiUtil, P as PANO_WEBSITE_URL, f as avatarVersion } from './Store.js-DT3aZHRb.js';
import { $ as $format } from './runtime.js-BzHEw_ze.js';
import { h as hasPermission, P as Permissions } from './auth.util.js-C77uoaNq.js';
import './locale.js-DgLiJnqO.js';
import 'node:module';
import './tooltip.util.js-BeLZL-Tj.js';
import { N as NoContent } from './NoContent.js-Coj2fA9d.js';
import { C as CardHeader } from './CardHeader.js-XBureLRg.js';
import { P as PlayerStatusBadge } from './PlayerPermissionBadge.js-CZpeO_Jh.js';
import { T as TicketStatusBadge } from './TicketStatusBadge.js-DtBYgr-f.js';
import { A as ActivityLogRow, V as ViewActivityLogModal } from './ViewActivityLogModal.js-BQcvB1fM.js';
import { V as ViewAllLink } from './ViewAllLink.js-Cn_c9MC0.js';

//#region src/lib/pages/Dashboard.svelte
async function load(event) {
	const { parent } = event;
	const layoutData = await parent();
	const canFetchAbout = layoutData?.user && hasPermission(Permissions.MANAGE_PLATFORM_SETTINGS, layoutData.user);
	const [dashboardResult, activityLogsResult, aboutResult] = await Promise.all([
		ApiUtil.get({
			path: `/api/panel/dashboard`,
			request: event
		}).catch(() => null),
		ApiUtil.get({
			path: `/api/panel/logs/activity`,
			request: event
		}).catch(() => null),
		canFetchAbout ? ApiUtil.get({
			path: `/api/panel/settings?type=ABOUT`,
			request: event
		}).catch(() => null) : Promise.resolve(null)
	]);
	const dashboard = dashboardResult?.result === "ok" ? dashboardResult : {};
	const activityLogs = activityLogsResult?.result === "ok" ? activityLogsResult : { data: [] };
	const about = aboutResult?.data || aboutResult || {};
	return {
		...dashboard,
		activityLogs,
		about
	};
}
function Dashboard($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let data = $$props["data"];
		getContext("pageTitle").set("pages.dashboard.title");
		const mansoryLayoutCols = writable(2);
		$$renderer.push(`<div class="container vstack gap-3">`);
		if (data.licenseFailedPluginCount && data.licenseFailedPluginCount > 0) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<div class="alert alert-warning d-flex align-items-center gap-3 mb-0 border-warning"><i class="fa-solid fa-key fa-lg"></i> <div class="flex-grow-1"><strong>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.dashboard.license-banner.title", { values: { count: data.licenseFailedPluginCount } }))}</strong> <div class="small text-body-secondary">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.dashboard.license-banner.description"))}</div></div> <a class="btn btn-sm btn-warning"${attr("href", `${stringify(base)}/addons?status=LICENSE_ISSUES`)}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.view"))}</a></div>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--> `);
		if (data.gettingStartedBlocks.welcomeBoard) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<div class="alert alert-secondary welcome-board alert-dismissible mb-0 border svelte-hm6sky"><div class="row"><div class="mb-3 lead">${html(store_get($$store_subs ??= {}, "$_", $format)("pages.dashboard.welcome-card.description"))}</div> <div class="col-lg-4"><ul class="list-unstyled svelte-hm6sky"><li class="svelte-hm6sky"><button type="button" class="alert-link focus-ring rounded border-0 bg-transparent p-0 svelte-hm6sky" data-bs-target="#connectServer" data-bs-toggle="modal"><i class="fa-solid fa-gamepad me-2"></i> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.dashboard.welcome-card.connect-server"))}</button></li> <li class="svelte-hm6sky"><a class="alert-link focus-ring rounded svelte-hm6sky"${attr("href", `${stringify(base)}/migration`)}><i class="fa-solid fa-file-import me-2"></i> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.dashboard.welcome-card.import-data"))}</a></li></ul></div> <div class="col-lg-4"><ul class="list-unstyled svelte-hm6sky"><li class="svelte-hm6sky"><a class="alert-link focus-ring rounded svelte-hm6sky"${attr("href", `${stringify(base)}/posts/create-post`)}><i class="fa-solid fa-pen me-2"></i> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.dashboard.welcome-card.publish-your-first-post"))}</a></li> <li class="svelte-hm6sky"><a class="alert-link focus-ring rounded svelte-hm6sky"${attr("href", `${stringify(base)}/view`)}><i class="fa-solid fa-brush me-2"></i> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.dashboard.welcome-card.change-theme"))}</a></li> <li class="svelte-hm6sky"><a class="alert-link focus-ring rounded svelte-hm6sky"${attr("href", `${stringify(base)}/addons`)}><i class="fa-solid fa-puzzle-piece me-2"></i> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.dashboard.welcome-card.manage-addons"))}</a></li> <li class="svelte-hm6sky"><a class="alert-link focus-ring rounded svelte-hm6sky"${attr("href", `${stringify(base)}/players`)}><i class="fa-solid fa-user-cog me-2"></i>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.dashboard.welcome-card.manage-players"))}</a></li></ul></div> <div class="col-lg-4"><ul class="list-unstyled mb-0 svelte-hm6sky"><li class="svelte-hm6sky"><a class="alert-link focus-ring rounded svelte-hm6sky"${attr("href", `${stringify(PANO_WEBSITE_URL)}/addons`)} target="_blank"><i class="fa-solid fa-bag-shopping me-2"></i> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.dashboard.welcome-card.get-themes-and-extensions"))}</a></li> <li class="svelte-hm6sky"><a class="alert-link focus-ring rounded svelte-hm6sky"${attr("href", `${stringify(PANO_WEBSITE_URL)}/docs`)} target="_blank"><i class="fa-solid fa-arrow-up-right-from-square me-2"></i> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.dashboard.welcome-card.documentations"))}</a></li> <li class="svelte-hm6sky"><a class="alert-link focus-ring rounded svelte-hm6sky"${attr("href", PANO_WEBSITE_URL)} target="_blank"><i class="fa-solid fa-globe me-2"></i> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.dashboard.welcome-card.website"))}</a></li> <li class="svelte-hm6sky"><a class="alert-link focus-ring rounded svelte-hm6sky"${attr("href", `${stringify(PANO_WEBSITE_URL)}/discord`)} target="_blank"><i class="fab fa-discord me-2"></i> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.dashboard.welcome-card.discord"))}</a></li></ul></div></div> <button type="button"${attr("title", store_get($$store_subs ??= {}, "$_", $format)("buttons.close"))} class="btn-close" data-bs-dismiss="alert"></button></div>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--> <masonry-layout${attr("cols", store_get($$store_subs ??= {}, "$mansoryLayoutCols", mansoryLayoutCols))} gap="16">`);
		if (hasPermission(Permissions.MANAGE_PLAYERS)) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<div class="ratio ratio-1x1"><div class="card mb-3">`);
			CardHeader($$renderer, { $$slots: {
				left: ($$renderer) => {
					$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.dashboard.last-registers.title"))}`);
				},
				right: ($$renderer) => {
					ViewAllLink($$renderer, { href: `${stringify(base)}/players` });
				}
			} });
			$$renderer.push(`<!----> <div class="card-body p-0 overflow-auto">`);
			if (data.lastRegisters.length === 0) {
				$$renderer.push("<!--[0-->");
				NoContent($$renderer, {});
			} else {
				$$renderer.push("<!--[-1-->");
				$$renderer.push(`<div class="table-responsive"><table class="table table-hover mb-0"><!--[-->`);
				const each_array = ensure_array_like(data.lastRegisters);
				for (let index = 0, $$length = each_array.length; index < $$length; index++) {
					let player = each_array[index];
					$$renderer.push(`<tbody><tr><td class="align-middle text-nowrap d-flex align-items-center"><a class="focus-ring rounded-circle d-inline-block me-2"${attr("title", player.username)}${attr("href", `${stringify(base)}/players/detail/${stringify(player.username)}`)}><img${attr("alt", player.username)} class="rounded-circle" height="32" width="32"${attr("src", `/api/profile/picture/${stringify(player.username)}?${stringify(store_get($$store_subs ??= {}, "$avatarVersion", avatarVersion))}`)}/></a> <a class="text-decoration-none w-100 rounded focus-ring d-block text-truncate p-1"${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("buttons.view"))}${attr("title", player.username)}${attr("href", `${stringify(base)}/players/detail/${stringify(player.username)}`)}>${escape_html(player.username)}</a></td><td class="align-middle">`);
					PlayerStatusBadge($$renderer, {
						banned: player.banned,
						lastActivityTime: player.lastActivityTime,
						inGame: player.inGame,
						checkTime: 0
					});
					$$renderer.push(`<!----></td></tr></tbody>`);
				}
				$$renderer.push(`<!--]--></table></div>`);
			}
			$$renderer.push(`<!--]--></div></div></div>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--> `);
		if (hasPermission(Permissions.MANAGE_TICKETS)) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<div class="ratio ratio-1x1"><div class="card mb-3">`);
			CardHeader($$renderer, { $$slots: {
				left: ($$renderer) => {
					$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.dashboard.last-tickets.title"))}`);
				},
				right: ($$renderer) => {
					ViewAllLink($$renderer, { href: `${stringify(base)}/tickets` });
				}
			} });
			$$renderer.push(`<!----> <div class="card-body p-0 overflow-auto">`);
			if (data.tickets.length === 0) {
				$$renderer.push("<!--[0-->");
				NoContent($$renderer, {});
			} else {
				$$renderer.push("<!--[-1-->");
				$$renderer.push(`<div class="table-responsive"><table class="table table-hover mb-0"><!--[-->`);
				const each_array_1 = ensure_array_like(data.tickets);
				for (let index = 0, $$length = each_array_1.length; index < $$length; index++) {
					let ticket = each_array_1[index];
					$$renderer.push(`<tbody><tr><td class="align-middle text-nowrap d-flex align-items-center"><a class="focus-ring rounded-circle d-inline-block me-2"${attr("title", ticket.writer.username)}${attr("href", `${stringify(base)}/players/detail/${stringify(ticket.writer.username)}`)}><img${attr("src", `/api/profile/picture/${stringify(ticket.writer.username)}?${stringify(store_get($$store_subs ??= {}, "$avatarVersion", avatarVersion))}`)}${attr("alt", store_get($$store_subs ??= {}, "$_", $format)("pages.dashboard.last-tickets.player-name"))} class="rounded-circle" height="32" width="32"/></a> <a class="text-decoration-none w-100 rounded focus-ring d-block text-truncate p-1"${attr("href", `${stringify(base)}/tickets/detail/${stringify(ticket.id)}`)}${attr("title", ticket.title)}${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("buttons.view"))}>${escape_html(ticket.title)}</a></td><td class="align-middle text-nowrap">`);
					TicketStatusBadge($$renderer, { status: ticket.status });
					$$renderer.push(`<!----></td></tr></tbody>`);
				}
				$$renderer.push(`<!--]--></table></div>`);
			}
			$$renderer.push(`<!--]--></div></div></div>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--> <div class="ratio ratio-1x1"><div class="card mb-3">`);
		CardHeader($$renderer, { $$slots: {
			left: ($$renderer) => {
				$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.dashboard.logs.title"))}`);
			},
			right: ($$renderer) => {
				ViewAllLink($$renderer, { href: `${stringify(base)}/logs` });
			}
		} });
		$$renderer.push(`<!----> <div class="card-body p-0 overflow-auto"><ul class="list-group list-group-flush">`);
		const each_array_2 = ensure_array_like(data.activityLogs.data);
		if (each_array_2.length !== 0) {
			$$renderer.push("<!--[-->");
			for (let index = 0, $$length = each_array_2.length; index < $$length; index++) {
				let log = each_array_2[index];
				ActivityLogRow($$renderer, { log });
			}
		} else {
			$$renderer.push("<!--[!-->");
			NoContent($$renderer, {});
		}
		$$renderer.push(`<!--]--></ul></div></div></div> `);
		if (hasPermission(Permissions.MANAGE_PLATFORM_SETTINGS)) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<div class="ratio ratio-1x1"><div class="card mb-3">`);
			CardHeader($$renderer, { $$slots: {
				left: ($$renderer) => {
					$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.about.info"))}`);
				},
				right: ($$renderer) => {
					ViewAllLink($$renderer, { href: `${stringify(base)}/settings/about` });
				}
			} });
			$$renderer.push(`<!----> <div class="card-body overflow-auto"><form><div class="row"><label class="col-6 col-form-label" for="panoVersion">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.about.version"))}</label> <div class="col-6 col-form-label"><span class="user-select-all font-monospace" aria-describedby="panoVersion" id="panoVersion">${escape_html(data.about?.platformVersion || "-")}</span></div></div> <div class="row"><label class="col-6 col-form-label" for="panoRelease">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.about.release"))}</label> <div class="col-6 col-form-label"><span aria-describedby="panoRelease" id="panoRelease">${escape_html(data.about?.platformStage || "-")}</span></div></div> <div class="row mb-0"><label class="col-6 col-form-label" for="panoWebsite">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.about.website"))}</label> <div class="col-6 col-form-label"><a class="btn btn-sm btn-link px-0" aria-describedby="panoWebsite"${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("pages.settings.about.website"))}${attr("href", PANO_WEBSITE_URL)} id="panoWebsite"${attr("title", store_get($$store_subs ??= {}, "$_", $format)("pages.settings.about.website"))} target="_blank"><i class="fa-solid fa-up-right-from-square"></i></a></div></div> <div class="row mb-0"><label class="col-6 col-form-label" for="panoDiscord">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.about.discord"))}</label> <div class="col-6 col-form-label"><a class="btn btn-sm btn-link px-0 text-decoration-none" aria-describedby="panoWebsite" aria-label="Discord"${attr("href", `${stringify(PANO_WEBSITE_URL)}/discord`)} id="panoWebsite" title="Discord" target="_blank"><i class="fab fa-discord fa-lg"></i></a></div></div></form></div></div></div>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--></masonry-layout></div> `);
		ViewActivityLogModal($$renderer);
		$$renderer.push(`<!---->`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
		bind_props($$props, { data });
	});
}

export { Dashboard as D, load as l };
//# sourceMappingURL=Dashboard.js-DYKZYuXG.js.map
