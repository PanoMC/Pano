import { _ as sanitize_props, N as fallback, V as attr_class, U as stringify, $ as attr_style, X as html, Z as escape_html, W as slot, T as attr, O as bind_props } from './index-server.js-DdhL7Abu.js';

//#region src/lib/components/DragAndDropZone.svelte
function DragAndDropZone($$renderer, $$props) {
	const $$sanitized_props = sanitize_props($$props);
	$$renderer.component(($$renderer) => {
		let accept = fallback($$props["accept"], () => [], true);
		let disabled = fallback($$props["disabled"], false);
		let style = fallback($$props["style"], "");
		let multiple = fallback($$props["multiple"], false);
		let maxFileSize = fallback($$props["maxFileSize"], null);
		let icon = fallback($$props["icon"], "");
		let title = fallback($$props["title"], "");
		let subtitle = fallback($$props["subtitle"], "");
		let id = fallback($$props["id"], null);
		let isDragOver = false;
		function click() {}
		$$renderer.push(`<div${attr_class(`p-3 w-100 h-100 d-flex flex-column align-items-center justify-content-center border rounded overflow-hidden text-center ${stringify($$sanitized_props.class || "")} drop-zone`, "svelte-yiixj0", {
			"drag-over": isDragOver,
			"disabled": disabled
		})}${attr_style(style)} role="button" tabindex="0">`);
		if (icon || title || subtitle) {
			$$renderer.push("<!--[0-->");
			if (icon) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<i${attr_class(`${stringify(icon)} mb-2`, "svelte-yiixj0")}></i>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--> `);
			if (title) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<p class="mb-0">${html(title)}</p>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--> `);
			if (subtitle) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<small class="opacity-75">${escape_html(subtitle)}</small>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]-->`);
		} else {
			$$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--[-->`);
			slot($$renderer, $$props, "default", { isDragOver }, null);
			$$renderer.push(`<!--]-->`);
		}
		$$renderer.push(`<!--]--> <input${attr("id", id)} type="file" class="d-none"${attr("accept", accept.join(","))}${attr("multiple", multiple, true)}/></div>`);
		bind_props($$props, {
			accept,
			disabled,
			style,
			multiple,
			maxFileSize,
			icon,
			title,
			subtitle,
			id,
			click
		});
	});
}

export { DragAndDropZone as D };
//# sourceMappingURL=DragAndDropZone.js-DkRk4oSS.js.map
