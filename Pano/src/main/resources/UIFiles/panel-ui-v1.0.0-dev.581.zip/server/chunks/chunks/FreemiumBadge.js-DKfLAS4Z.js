import { Z as escape_html, Q as store_get, S as unsubscribe_stores } from './index-server.js-DdhL7Abu.js';
import { $ as $format } from './runtime.js-BzHEw_ze.js';
import './tooltip.util.js-BeLZL-Tj.js';

//#region src/lib/components/FreemiumBadge.svelte
function FreemiumBadge($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		$$renderer.push(`<span class="badge border border-success text-success bg-body rounded-pill">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.freemium.label"))}</span>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
	});
}

export { FreemiumBadge as F };
//# sourceMappingURL=FreemiumBadge.js-DKfLAS4Z.js.map
