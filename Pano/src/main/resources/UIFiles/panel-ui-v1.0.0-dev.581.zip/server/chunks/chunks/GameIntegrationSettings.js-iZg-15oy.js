import { r as redirect } from './exports2.js-VkmSkXbz.js';
import { b as base } from './internal.js-BRN1McAa.js';
import { J as getContext, Z as escape_html, Q as store_get, T as attr, U as stringify, V as attr_class, S as unsubscribe_stores, O as bind_props } from './index-server.js-DdhL7Abu.js';
import './server.js-BlClO2ED.js';
import './internal2.js-CNe5OZUJ.js';
import './routing.js-N-OPb2ye.js';
import { b as ApiUtil, P as PANO_WEBSITE_URL } from './Store.js-DT3aZHRb.js';
import { $ as $format } from './runtime.js-BzHEw_ze.js';

//#region src/lib/pages/server/GameIntegrationSettings.svelte
async function load(event) {
	const { parent } = event;
	const { selectedServer } = await parent();
	if (!selectedServer) throw redirect(302, base);
	const response = await ApiUtil.get({
		path: `/api/panel/servers/${selectedServer.id}`,
		request: event
	});
	const serverSettings = response.server.settings;
	const requireEmailVerification = response.requireEmailVerification;
	return {
		serverSettings,
		serverSettingsOriginal: structuredClone(serverSettings),
		requireEmailVerification
	};
}
function GameIntegrationSettings($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let saveDisabled;
		getContext("pageTitle").set("pages.server.game-integration.title");
		let data = $$props["data"];
		let serverSettings;
		let serverSettingsOriginal;
		let requireEmailVerification;
		if (data?.serverSettings) {
			serverSettings = data.serverSettings;
			serverSettingsOriginal = structuredClone(data.serverSettingsOriginal);
			requireEmailVerification = data.requireEmailVerification;
		}
		saveDisabled = JSON.stringify(serverSettings) === JSON.stringify(serverSettingsOriginal);
		$$renderer.push(`<div class="card"><div class="card-header">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.server.game-integration.minecraft"))}</div> <div class="card-body"><div class="row mb-3"><label class="col-md-6 col-form-label" for="authIntegration">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.server.game-integration.auth-integration"))} <small class="d-block">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.server.game-integration.auth-integration-description"))}<br/> <a${attr("href", `${stringify(PANO_WEBSITE_URL)}/docs/platform/integrations/authme`)} target="_blank">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.see-docs"))} <i class="fas fa-external-link"></i></a></small></label> <div class="col col-form-label"><div class="form-check form-switch"><input class="form-check-input" type="checkbox" id="authIntegration"${attr("checked", serverSettings.authIntegration, true)} autocomplete="off"/></div></div></div> `);
		if (!requireEmailVerification) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<div class="alert alert-warning py-2 mb-3" role="alert"><i class="fas fa-exclamation-triangle me-2"></i> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.server.game-integration.auth-require-verified-disabled-warning"))}</div>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--> <div class="row mb-3"><label class="col-md-6 col-form-label position-relative" for="authRequireVerified"><span${attr_class("position-absolute start-0 top-0 bottom-0 border-start border-2", void 0, {
			"border-secondary": serverSettings.authIntegration,
			"border-gray": !serverSettings.authIntegration
		})} style="width: 2px;"></span> <span class="ps-3 d-block">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.server.game-integration.auth-require-verified"))} <small class="d-block">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.server.game-integration.auth-require-verified-description"))}<br/> <a${attr("href", `${stringify(PANO_WEBSITE_URL)}/docs/platform/integrations/authme/#step-3-verify-auth-integration-is-enabled-in-panel`)} target="_blank">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.see-docs"))} <i class="fas fa-external-link"></i></a></small></span></label> <div class="col col-form-label"><div class="form-check form-switch"><input class="form-check-input" type="checkbox" id="authRequireVerified"${attr("checked", serverSettings.authRequireVerified, true)}${attr("disabled", !serverSettings.authIntegration || !requireEmailVerification, true)} autocomplete="off"/></div></div></div> <div class="row mb-3"><label class="col-md-6 col-form-label position-relative" for="authKickAfterRegister"><span${attr_class("position-absolute start-0 top-0 bottom-0 border-start border-2", void 0, {
			"border-secondary": serverSettings.authIntegration,
			"border-gray": !serverSettings.authIntegration
		})} style="width: 2px;"></span> <span class="ps-3 d-block">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.server.game-integration.auth-kick-after-register"))} <small class="d-block">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.server.game-integration.auth-kick-after-register-description"))}<br/> <a${attr("href", `${stringify(PANO_WEBSITE_URL)}/docs/platform/integrations/authme/#step-3-verify-auth-integration-is-enabled-in-panel`)} target="_blank">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.see-docs"))} <i class="fas fa-external-link"></i></a></small></span></label> <div class="col col-form-label"><div class="form-check form-switch"><input class="form-check-input" type="checkbox" id="authKickAfterRegister"${attr("checked", serverSettings.authKickAfterRegister, true)}${attr("disabled", !serverSettings.authIntegration, true)} autocomplete="off"/></div></div></div> <div class="row mb-3"><label class="col-md-6 col-form-label" for="permissionIntegration">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.server.game-integration.permission-integration"))} <small class="d-block">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.server.game-integration.permission-integration-description"))}<br/> <a${attr("href", `${stringify(PANO_WEBSITE_URL)}/docs/platform/integrations/luckperms/`)} target="_blank">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.see-docs"))} <i class="fas fa-external-link"></i></a></small></label> <div class="col col-form-label"><div class="form-check form-switch"><input class="form-check-input" type="checkbox" id="permissionIntegration"${attr("checked", serverSettings.permissionIntegration, true)} autocomplete="off"/></div></div></div> <div class="row mb-3"><label class="col-md-6 col-form-label" for="banIntegration">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.server.game-integration.ban-integration"))} <small class="d-block">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.server.game-integration.ban-integration-description"))}<br/> <a${attr("href", `${stringify(PANO_WEBSITE_URL)}/docs/platform/integrations/ban-management/`)} target="_blank">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.see-docs"))} <i class="fas fa-external-link"></i></a></small></label> <div class="col col-form-label"><div class="form-check form-switch"><input class="form-check-input" type="checkbox" id="banIntegration"${attr("checked", serverSettings.banIntegration, true)} autocomplete="off"/></div></div></div> <button${attr_class("btn btn-secondary", void 0, { "disabled": saveDisabled })}${attr("aria-disabled", saveDisabled)}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.save"))}</button></div></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
		bind_props($$props, { data });
	});
}

export { GameIntegrationSettings as G, load as l };
//# sourceMappingURL=GameIntegrationSettings.js-iZg-15oy.js.map
