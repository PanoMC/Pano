import { b as base } from './internal.js-BRN1McAa.js';
import { Z as escape_html, Q as store_get, T as attr, U as stringify, S as unsubscribe_stores, F as writable, a0 as onDestroy, V as attr_class, $ as attr_style } from './index-server.js-DdhL7Abu.js';
import { b as beforeNavigate } from './stores.js-D5xmrOAP.js';
import './server.js-BlClO2ED.js';
import './internal2.js-CNe5OZUJ.js';
import './routing.js-N-OPb2ye.js';
import 'node:module';
import './ToastContainer.js-Bv1jJ2dr.js';
import { $ as $format } from './runtime.js-BzHEw_ze.js';
import { w as websiteDisplayHost } from './website-display.util.js-DvL-i3X3.js';
import './tooltip.util.js-BeLZL-Tj.js';
import { D as DragAndDropZone } from './DragAndDropZone.js-DkRk4oSS.js';

var type$1 = writable("PLUGIN");
function InstallResourceModal($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		$$renderer.push(`<div role="dialog" class="modal modal-lg fade" aria-hidden="true"><div class="modal-dialog modal-dialog-centered"><div class="modal-content"><div class="modal-header"><h5 class="modal-title">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.install-resource.title", { values: { type: store_get($$store_subs ??= {}, "$_", $format)("components.modals.install-resource." + (store_get($$store_subs ??= {}, "$type", type$1) === "PLUGIN" ? "addon" : "theme")) } }))}</h5> <button type="button" class="btn-close" data-bs-dismiss="modal"${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("buttons.close"))}></button></div> <div class="modal-body"><div class="list-group list-group-horizontal w-100" style="height: 250px;">`);
		DragAndDropZone($$renderer, {
			class: "list-group-item rounded-end-0 h-100",
			style: "cursor: pointer; flex: 1;",
			icon: "fas fa-upload fa-2x",
			title: store_get($$store_subs ??= {}, "$_", $format)("components.modals.install-resource.drag-here"),
			accept: store_get($$store_subs ??= {}, "$type", type$1) === "THEME" ? [".zip", "application/zip"] : [".jar", "application/java-archive"]
		});
		$$renderer.push(`<!----> <a${attr("href", `${stringify(base)}/${store_get($$store_subs ??= {}, "$type", type$1) === "PLUGIN" ? "addons" : "view"}/store`)} class="list-group-item d-flex flex-column align-items-center justify-content-center text-center h-100 text-decoration-none" style="flex: 1;"><i class="fas fa-store fa-2x mb-2"></i> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.install-resource.install-from-pano-store"))}</a></div></div></div></div></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
	});
}
var type = writable("PLUGIN");
var processes = writable([]);
var installingStep = writable(1);
var currentProgress = writable(0);
var installError = writable();
var installLicenseDeniedReason = writable(null);
var versionId = writable(null);
function InstallingResourceModal($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		function isFinished(installingStep) {
			return installingStep === store_get($$store_subs ??= {}, "$processes", processes).length + 1;
		}
		onDestroy(() => {});
		beforeNavigate((nav) => {});
		$$renderer.push(`<div role="dialog" class="modal fade" aria-hidden="true"><div class="modal-dialog modal-dialog-centered"><div class="modal-content"><div class="modal-header"><h5 class="modal-title">`);
		if (store_get($$store_subs ??= {}, "$installError", installError)) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.installing-resource.error"))}`);
		} else if (!isFinished(store_get($$store_subs ??= {}, "$installingStep", installingStep))) {
			$$renderer.push("<!--[1-->");
			$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.installing-resource.installing"))}`);
		} else {
			$$renderer.push("<!--[-1-->");
			$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.installing-resource.completed"))}`);
		}
		$$renderer.push(`<!--]--></h5> <button type="button"${attr_class("btn-close", void 0, { "opacity-25": !store_get($$store_subs ??= {}, "$installError", installError) && !isFinished(store_get($$store_subs ??= {}, "$installingStep", installingStep)) })}${attr("disabled", !store_get($$store_subs ??= {}, "$installError", installError) && !isFinished(store_get($$store_subs ??= {}, "$installingStep", installingStep)), true)}${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("buttons.close"))}${attr("aria-disabled", !store_get($$store_subs ??= {}, "$installError", installError) && !isFinished(store_get($$store_subs ??= {}, "$installingStep", installingStep)))}></button></div> <div class="modal-body"><div class="progress mb-3" role="progressbar"${attr("aria-valuenow", store_get($$store_subs ??= {}, "$installingStep", installingStep))} aria-valuemin="0"${attr("aria-valuemax", store_get($$store_subs ??= {}, "$processes", processes).length)} style="height: 16px;"><div${attr_class(`progress-bar progress-bar-striped ${store_get($$store_subs ??= {}, "$installError", installError) ? "bg-danger" : !isFinished(store_get($$store_subs ??= {}, "$installingStep", installingStep)) ? "progress-bar-animated bg-primary" : "bg-success"}`)}${attr_style(`width: ${stringify(Math.min(store_get($$store_subs ??= {}, "$versionId", versionId) ? store_get($$store_subs ??= {}, "$installingStep", installingStep) >= 2 ? store_get($$store_subs ??= {}, "$installingStep", installingStep) - 2 + store_get($$store_subs ??= {}, "$currentProgress", currentProgress) : 0 : store_get($$store_subs ??= {}, "$installingStep", installingStep) - 1 + store_get($$store_subs ??= {}, "$currentProgress", currentProgress), store_get($$store_subs ??= {}, "$processes", processes).length - (store_get($$store_subs ??= {}, "$versionId", versionId) ? 1 : 0)) / (store_get($$store_subs ??= {}, "$processes", processes).length - (store_get($$store_subs ??= {}, "$versionId", versionId) ? 1 : 0)) * 100)}%`)}></div></div> <p class="small mb-0">`);
		if (store_get($$store_subs ??= {}, "$installError", installError)) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<span class="text-danger">`);
			if (store_get($$store_subs ??= {}, "$installLicenseDeniedReason", installLicenseDeniedReason)) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.installing-resource.license-denied." + store_get($$store_subs ??= {}, "$installLicenseDeniedReason", installLicenseDeniedReason), {
					values: { website: websiteDisplayHost() },
					default: store_get($$store_subs ??= {}, "$_", $format)("components.modals.installing-resource.license-denied.generic", { values: { website: websiteDisplayHost() } })
				}))}`);
			} else {
				$$renderer.push("<!--[-1-->");
				$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.installing-resource.error-text", { values: { error: store_get($$store_subs ??= {}, "$_", $format)("errors." + store_get($$store_subs ??= {}, "$installError", installError)) } }))}`);
			}
			$$renderer.push(`<!--]--></span>`);
		} else if (!isFinished(store_get($$store_subs ??= {}, "$installingStep", installingStep))) {
			$$renderer.push("<!--[1-->");
			$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)(store_get($$store_subs ??= {}, "$processes", processes)[store_get($$store_subs ??= {}, "$installingStep", installingStep) - 1]))}`);
		} else {
			$$renderer.push("<!--[-1-->");
			$$renderer.push(`🎉 ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.installing-resource.install-complete"))}`);
		}
		$$renderer.push(`<!--]--></p></div> `);
		if (isFinished(store_get($$store_subs ??= {}, "$installingStep", installingStep)) || store_get($$store_subs ??= {}, "$installError", installError)) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<div class="modal-footer flex-nowrap"><button class="btn btn-link col-6 m-0" data-bs-dismiss="modal" type="button">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.go-to-store"))}</button> <button class="btn btn-primary col-6 m-0" data-bs-dismiss="modal" type="button"><i class="fas fa-arrow-left me-2"></i> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons." + (store_get($$store_subs ??= {}, "$type", type) === "PLUGIN" ? "addons" : "themes")))}</button></div>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--></div></div></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
	});
}

export { InstallResourceModal as I, InstallingResourceModal as a };
//# sourceMappingURL=InstallingResourceModal.js-CaKAxtGU.js.map
