import { e as error$1 } from './exports2.js-VkmSkXbz.js';
import { J as getContext, Z as escape_html, Q as store_get, P as ensure_array_like, S as unsubscribe_stores, O as bind_props, V as attr_class, T as attr, F as writable } from './index-server.js-DdhL7Abu.js';
import './stores.js-D5xmrOAP.js';
import { e as buildQueryParams, b as ApiUtil } from './Store.js-DT3aZHRb.js';
import { $ as $format } from './runtime.js-BzHEw_ze.js';
import './ToastContainer.js-Bv1jJ2dr.js';
import { l as locale_exports } from './locale.js-DgLiJnqO.js';
import { N as NoContent } from './NoContent.js-Coj2fA9d.js';
import { P as Pagination } from './Pagination.js-sd1xTcbW.js';
import { P as PageActions } from './PageActions.js-co-RIHDp.js';
import { P as PageNav, a as PageNavItem } from './PageNav.js-Bzzuwwjz.js';

var mode = writable("create");
var locale$1 = writable({ derivatives: [] });
var error = writable();
var derivative = writable();
function AddEditLanguageModal($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let buttonDisabled;
		buttonDisabled = !store_get($$store_subs ??= {}, "$locale", locale$1).name || !store_get($$store_subs ??= {}, "$locale", locale$1).code || !store_get($$store_subs ??= {}, "$locale", locale$1).dateFnsCode;
		$$renderer.push(`<div class="modal fade" role="dialog" tabindex="-1"><div class="modal-dialog modal-dialog-centered" role="dialog"><div class="modal-content"><div class="modal-header"><h5 class="modal-title">${escape_html(store_get($$store_subs ??= {}, "$mode", mode) === "edit" ? store_get($$store_subs ??= {}, "$_", $format)("components.modals.add-edit-language.edit-language") : store_get($$store_subs ??= {}, "$_", $format)("components.modals.add-edit-language.create-language"))}</h5> <button${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("buttons.close"))} type="button" class="btn-close" data-bs-dismiss="modal"></button></div> <form><div class="modal-body"><div class="row"><div class="col-12 mb-3"><label for="name">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.add-edit-language.inputs.name"))}</label> <input${attr_class("form-control form-control-lg", void 0, { "is-invalid": store_get($$store_subs ??= {}, "$error", error) === "INVALID_LOCALE_NAME" })} id="name" type="text"${attr("value", store_get($$store_subs ??= {}, "$locale", locale$1).name)}/></div> <div class="col-6 mb-3"><label for="code">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.add-edit-language.inputs.code"))}</label> <input${attr_class("form-control", void 0, { "is-invalid": store_get($$store_subs ??= {}, "$error", error) === "INVALID_LOCALE_CODE" })} id="code" type="text"${attr("value", store_get($$store_subs ??= {}, "$locale", locale$1).code)}/> <div class="form-text">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.add-edit-language.inputs.code-helper"))} <a${attr("href", store_get($$store_subs ??= {}, "$_", $format)("components.modals.add-edit-language.inputs.code-lookup-url"))} target="_blank" rel="noopener noreferrer" class="text-decoration-none"><i class="fa-solid fa-external-link small ms-1"></i> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.add-edit-language.inputs.code-lookup-text"))}</a></div></div> <div class="col-6 mb-3"><label for="dateFnsCode">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.add-edit-language.inputs.date-fns-code"))}</label> `);
		$$renderer.select({
			class: "form-control",
			id: "dateFnsCode",
			value: store_get($$store_subs ??= {}, "$locale", locale$1).dateFnsCode
		}, ($$renderer) => {
			$$renderer.option({ value: "" }, ($$renderer) => {
				$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.select-option"))}`);
			});
			$$renderer.push(`<!--[-->`);
			const each_array = ensure_array_like(Object.keys(locale_exports).sort());
			for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
				let dateLocaleKey = each_array[$$index];
				$$renderer.option({ value: locale_exports[dateLocaleKey].code || dateLocaleKey }, ($$renderer) => {
					$$renderer.push(`${escape_html(locale_exports[dateLocaleKey].code || dateLocaleKey)}`);
				});
			}
			$$renderer.push(`<!--]-->`);
		}, void 0, { "is-invalid": store_get($$store_subs ??= {}, "$error", error) === "INVALID_DATE_FNS_CODE" });
		$$renderer.push(` <div class="form-text">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.add-edit-language.inputs.date-fns-code-helper"))}</div></div> <div class="col-12 mb-3"><label for="derivatives">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.languages.derivatives"))}</label> <input id="derivatives"${attr_class("form-control", void 0, { "is-invalid": store_get($$store_subs ??= {}, "$error", error) === "derivatives" || store_get($$store_subs ??= {}, "$error", error) === "INVALID_LOCALE_DERIVATIVE" })}${attr("placeholder", store_get($$store_subs ??= {}, "$_", $format)("components.modals.add-edit-language.inputs.derivatives"))} type="text" name="derivative"${attr("value", store_get($$store_subs ??= {}, "$derivative", derivative))}/> <div class="form-text">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.add-edit-language.inputs.derivatives-helper"))}</div> `);
		if (store_get($$store_subs ??= {}, "$locale", locale$1).derivatives.length > 0) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<div class="hstack gap-2 flex-wrap"><!--[-->`);
			const each_array_1 = ensure_array_like(store_get($$store_subs ??= {}, "$locale", locale$1).derivatives);
			for (let index = 0, $$length = each_array_1.length; index < $$length; index++) {
				let derivative = each_array_1[index];
				$$renderer.push(`<button type="button" class="btn btn-link p-0 d-inline-block mt-2 text-decoration-none"${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("buttons.remove"))}${attr("title", store_get($$store_subs ??= {}, "$_", $format)("buttons.remove"))}><span class="badge text-bg-primary">${escape_html(derivative)}</span></button>`);
			}
			$$renderer.push(`<!--]--></div>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--></div></div></div> <div class="modal-footer"><button${attr_class("btn w-100", void 0, {
			"btn-secondary": store_get($$store_subs ??= {}, "$mode", mode) === "create",
			"btn-primary": store_get($$store_subs ??= {}, "$mode", mode) === "edit",
			"disabled": buttonDisabled
		})} type="submit">${escape_html(store_get($$store_subs ??= {}, "$mode", mode) === "edit" ? store_get($$store_subs ??= {}, "$_", $format)("buttons.save") : store_get($$store_subs ??= {}, "$_", $format)("buttons.create"))}</button></div></form></div></div></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
	});
}
function ConfirmDeleteLanguageModal($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let loading = false;
		$$renderer.push(`<div aria-hidden="true" class="modal fade" role="dialog" tabindex="-1"><div class="modal-dialog modal-dialog-centered" role="dialog"><div class="modal-content"><div class="modal-body text-center"><div class="pb-3"><i class="fas fa-question-circle fa-3x d-block m-auto text-gray"></i></div> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.confirm-delete-language.title"))}</div> <div class="modal-footer flex-nowrap"><button${attr_class("btn btn-link col-6 m-0", void 0, { "disabled": loading })} type="button">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.cancel"))}</button> <button${attr_class("btn btn-danger col-6 m-0", void 0, { "disabled": loading })} type="button">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.yes"))}</button></div></div></div></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
	});
}
//#endregion
//#region src/lib/components/rows/LocaleRow.svelte
function LocaleRow($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let locale = $$props["locale"];
		let index = $$props["index"];
		$$renderer.push(`<tr${attr_class("", void 0, { "table-active": locale.selected })}><th scope="row" class="align-middle">`);
		if (locale.definedBy !== "SYSTEM") {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<button type="button"${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("buttons.delete"))}${attr("title", store_get($$store_subs ??= {}, "$_", $format)("buttons.delete"))} class="btn btn-link"><i class="fas fa-trash"></i></button>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--></th><td class="align-middle" style="max-width: 250px;"><div class="text-truncate">`);
		if (locale.definedBy !== "SYSTEM") {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<button class="btn btn-link p-0 text-start text-decoration-none w-100 text-truncate" type="button"${attr("title", locale.name)}>${escape_html(locale.name)}</button>`);
		} else {
			$$renderer.push("<!--[-1-->");
			$$renderer.push(`<span${attr("title", locale.name)}>${escape_html(locale.name)}</span>`);
		}
		$$renderer.push(`<!--]--></div></td><td class="align-middle text-nowrap" style="max-width: 150px;"><div class="text-truncate"${attr("title", locale.code)}>${escape_html(locale.code)}</div></td><td class="align-middle text-nowrap" style="max-width: 150px;"><div class="text-truncate"${attr("title", locale.dateFnsCode)}>${escape_html(locale.dateFnsCode)}</div></td><td class="align-middle text-nowrap" style="max-width: 150px;"><div class="text-truncate"${attr("title", locale.derivatives)}>${escape_html(locale.derivatives)}</div></td><td class="align-middle" style="max-width: 200px;"><div class="text-truncate"${attr("title", store_get($$store_subs ??= {}, "$_", $format)("pages.languages.defined-by-options." + locale.definedBy))}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.languages.defined-by-options." + locale.definedBy))}</div></td></tr>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
		bind_props($$props, {
			locale,
			index
		});
	});
}
//#endregion
//#region src/lib/pages/translations/Languages.svelte
async function load(event) {
	const { parent, url: { searchParams } } = event;
	await parent();
	const page = searchParams.get("page") || 1;
	const queryParams = buildQueryParams({ page });
	const body = await ApiUtil.get({
		path: `/api/panel/locales` + queryParams,
		request: event
	});
	if (body.error) {
		if (body.error === "PAGE_NOT_FOUND") throw error$1(404, body.error);
		throw error$1(500, body.error);
	}
	return {
		locales: body.data,
		meta: {
			...body.meta,
			page: parseInt(page)
		}
	};
}
function Languages($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let data = $$props["data"];
		getContext("pageTitle").set("pages.languages.title");
		$$renderer.push(`<article class="container vstack gap-3">`);
		PageActions($$renderer, {
			middleClasses: null,
			$$slots: {
				left: ($$renderer) => {
					PageNav($$renderer, {
						slot: "left",
						children: ($$renderer) => {
							PageNavItem($$renderer, {
								href: "/translations",
								children: ($$renderer) => {
									$$renderer.push(`<!---->${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.translations.title"))}`);
								}});
							$$renderer.push(`<!----> `);
							PageNavItem($$renderer, {
								href: "/translations/languages",
								children: ($$renderer) => {
									$$renderer.push(`<!---->${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.languages"))}`);
								}});
							$$renderer.push(`<!---->`);
						},
						$$slots: { default: true }
					});
				},
				right: ($$renderer) => {
					$$renderer.push(`<button class="btn btn-secondary" type="button" slot="right"><i class="fas fa-plus"></i> <span class="d-lg-inline d-none ms-2">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.create-language"))}</span></button>`);
				}
			}
		});
		$$renderer.push(`<!----> <div class="card"><div class="card-header">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.languages.card-title", { values: { count: data.meta.totalCount } }))}</div> `);
		if (data.meta.totalCount === 0) {
			$$renderer.push("<!--[0-->");
			NoContent($$renderer, {});
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--> `);
		if (data.meta.totalCount > 0) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<div class="table-responsive"><table class="table table-hover"><thead><tr><th scope="col"></th><th class="align-middle text-nowrap" scope="col">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.languages.name"))}</th><th scope="col" class="align-middle text-nowrap">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.languages.code"))}</th><th scope="col" class="align-middle text-nowrap">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.languages.date-fns-code"))}</th><th scope="col" class="align-middle text-nowrap">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.languages.derivatives"))}</th><th scope="col" class="align-middle text-nowrap">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.languages.defined-by"))}</th></tr></thead><tbody><!--[-->`);
			const each_array = ensure_array_like(data.locales);
			for (let index = 0, $$length = each_array.length; index < $$length; index++) {
				let locale = each_array[index];
				LocaleRow($$renderer, {
					locale,
					index
				});
			}
			$$renderer.push(`<!--]--></tbody></table></div>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--> <div class="card-footer">`);
		Pagination($$renderer, {
			page: data.meta.page,
			totalPage: data.meta.totalPage
		});
		$$renderer.push(`<!----></div></div></article> `);
		ConfirmDeleteLanguageModal($$renderer);
		$$renderer.push(`<!----> `);
		AddEditLanguageModal($$renderer);
		$$renderer.push(`<!---->`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
		bind_props($$props, { data });
	});
}

export { Languages as L, load as l };
//# sourceMappingURL=Languages.js-R6xXh1u-.js.map
