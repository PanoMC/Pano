import { V as attr_class, U as stringify, Z as escape_html, Q as store_get, S as unsubscribe_stores, y as derived } from './index-server.js-DdhL7Abu.js';
import { $ as $format } from './runtime.js-BzHEw_ze.js';
import { w as websiteDisplayHost } from './website-display.util.js-DvL-i3X3.js';
import './tooltip.util.js-BeLZL-Tj.js';

//#region src/lib/components/LicenseStatusBadge.svelte
function LicenseStatusBadge($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		const websiteI18n = derived(() => ({ values: { website: websiteDisplayHost() } }));
		/**
		* @typedef {'NOT_PREMIUM' | 'LICENSED' | 'MISSING' | 'NO_PURCHASE' | 'EXPIRED' | 'NETWORK_ERROR' | 'JAR_TAMPERED' | 'SIGNATURE_INVALID' | 'VERSION_MISMATCH' | 'AUDIENCE_MISMATCH' | 'PLATFORM_MISMATCH' | 'NOT_CONNECTED' | 'NEEDS_REFRESH' | 'UNKNOWN'} LicenseStatus
		*/
		let { status, labeled = false } = $$props;
		const entry = derived(() => mapStatus(status));
		function mapStatus(s) {
			switch (s) {
				case "LICENSED": return {
					icon: "fa-key",
					iconClass: "text-success",
					labelKey: "components.license-status.LICENSED",
					tooltipKey: "components.license-status.LICENSED-tooltip"
				};
				case "MISSING":
				case "NO_PURCHASE":
				case "NEEDS_REFRESH": return {
					icon: "fa-key",
					iconClass: "text-danger",
					labelKey: "components.license-status.NO_PURCHASE",
					tooltipKey: "components.license-status.NO_PURCHASE-tooltip"
				};
				case "EXPIRED": return {
					icon: "fa-key",
					iconClass: "text-danger",
					labelKey: "components.license-status.EXPIRED",
					tooltipKey: "components.license-status.EXPIRED-tooltip"
				};
				case "NETWORK_ERROR": return {
					icon: "fa-key",
					iconClass: "text-danger",
					labelKey: "components.license-status.NETWORK_ERROR",
					tooltipKey: "components.license-status.NETWORK_ERROR-tooltip"
				};
				case "NOT_CONNECTED": return {
					icon: "fa-key",
					iconClass: "text-danger",
					labelKey: "components.license-status.NOT_CONNECTED",
					tooltipKey: "components.license-status.NOT_CONNECTED-tooltip"
				};
				case "JAR_TAMPERED":
				case "SIGNATURE_INVALID": return {
					icon: "fa-key",
					iconClass: "text-danger",
					labelKey: "components.license-status.NO_PURCHASE",
					tooltipKey: "components.license-status.NO_PURCHASE-tooltip"
				};
				case "VERSION_MISMATCH":
				case "AUDIENCE_MISMATCH":
				case "PLATFORM_MISMATCH": return {
					icon: "fa-key",
					iconClass: "text-danger",
					labelKey: "components.license-status.VERSION_MISMATCH",
					tooltipKey: "components.license-status.VERSION_MISMATCH-tooltip"
				};
				default: return {
					icon: "fa-key",
					iconClass: "text-danger",
					labelKey: "components.license-status.UNKNOWN",
					tooltipKey: "components.license-status.UNKNOWN-tooltip"
				};
			}
		}
		if (status && status !== "NOT_PREMIUM") {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<span class="d-inline-flex align-items-center gap-1"><i${attr_class(`fa-solid ${stringify(entry().icon)} ${stringify(entry().iconClass)}`)} aria-hidden="true"></i> `);
			if (labeled) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<span class="small text-body-secondary">${escape_html(store_get($$store_subs ??= {}, "$_", $format)(entry().labelKey, {
					...websiteI18n(),
					default: entry().labelKey
				}))}</span>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--></span>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]-->`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
	});
}

export { LicenseStatusBadge as L };
//# sourceMappingURL=LicenseStatusBadge.js-C5qJr3_k.js.map
