import { _ as __exportAll } from './rolldown-runtime.js-BMnQIuNT.js';
import { r as redirect } from './exports2.js-VkmSkXbz.js';
import { b as base } from './internal.js-BRN1McAa.js';
import { W as slot, O as bind_props, Z as escape_html, Q as store_get, S as unsubscribe_stores } from './index-server.js-DdhL7Abu.js';
import './server.js-BlClO2ED.js';
import './internal2.js-CNe5OZUJ.js';
import './routing.js-N-OPb2ye.js';
import { $ as $format } from './runtime.js-BzHEw_ze.js';
import { h as hasPermission, P as Permissions } from './auth.util.js-C77uoaNq.js';
import { P as PageActions } from './PageActions.js-co-RIHDp.js';
import { P as PageNav, a as PageNavItem } from './PageNav.js-Bzzuwwjz.js';

//#region src/lib/layouts/MigrationLayout.svelte
var MigrationLayout_exports = /* @__PURE__ */ __exportAll({
	default: () => MigrationLayout,
	load: () => load
});
async function load({ parent }) {
	const parentData = await parent();
	const { user } = parentData;
	if (!hasPermission(Permissions.MANAGE_PLATFORM_SETTINGS, user)) throw redirect(302, base);
	return parentData;
}
function MigrationLayout($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let data = $$props["data"];
		$$renderer.push(`<div class="container vstack gap-3">`);
		PageActions($$renderer, { $$slots: { left: ($$renderer) => {
			$$renderer.push(`<div slot="left">`);
			PageNav($$renderer, {
				children: ($$renderer) => {
					PageNavItem($$renderer, {
						href: "/migration",
						children: ($$renderer) => {
							$$renderer.push(`<!---->${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.server-title"))}`);
						}});
					$$renderer.push(`<!----> `);
					PageNavItem($$renderer, {
						href: "/migration/plugins",
						startsWith: true,
						children: ($$renderer) => {
							$$renderer.push(`<!---->${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.plugins-title"))}`);
						}});
					$$renderer.push(`<!----> `);
					PageNavItem($$renderer, {
						href: "/migration/other",
						startsWith: true,
						children: ($$renderer) => {
							$$renderer.push(`<!---->${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.platforms-title"))}`);
						}});
					$$renderer.push(`<!---->`);
				},
				$$slots: { default: true }
			});
			$$renderer.push(`<!----></div>`);
		} } });
		$$renderer.push(`<!----> <!--[-->`);
		slot($$renderer, $$props, "default", {}, null);
		$$renderer.push(`<!--]--></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
		bind_props($$props, { data });
	});
}

export { MigrationLayout_exports as M, MigrationLayout as a, load as l };
//# sourceMappingURL=MigrationLayout.js-BQMl41SU.js.map
