import { J as getContext, Q as store_get, S as unsubscribe_stores, Z as escape_html } from './index-server.js-DdhL7Abu.js';
import { $ as $format } from './runtime.js-BzHEw_ze.js';
import { N as NoContent } from './NoContent.js-Coj2fA9d.js';

//#region src/lib/pages/settings/migration/CraftWebTribute.svelte
function CraftWebTribute($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		$$renderer.push(`<div class="craftweb-tribute svelte-17t5920"><div class="tribute-icon svelte-17t5920"><i class="fas fa-heart"></i></div> <p class="tribute-text svelte-17t5920">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.craftweb-tribute"))}</p></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
	});
}
//#endregion
//#region src/lib/pages/settings/MigrationPlatforms.svelte
function MigrationPlatforms($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		const pageTitle = getContext("pageTitle");
		if (pageTitle) pageTitle.set("components.settings-layout.migration");
		$$renderer.push(`<div class="card"><div class="card-header pb-0 vstack gap-2"><ul class="nav nav-tabs border-bottom-0" id="migrateTabs" role="tablist"><li class="nav-item" role="presentation"><button class="nav-link active" id="azuriom-tab" data-bs-toggle="tab" data-bs-target="#azuriom" type="button" role="tab" aria-controls="azuriom" aria-selected="true">Azuriom</button></li> <li class="nav-item" role="presentation"><button class="nav-link" id="namelessmc-tab" data-bs-toggle="tab" data-bs-target="#namelessmc" type="button" role="tab" aria-controls="namelessmc" aria-selected="false">NamelessMC</button></li> <li class="nav-item" role="presentation"><button class="nav-link" id="craftweb-tab" data-bs-toggle="tab" data-bs-target="#craftweb" type="button" role="tab" aria-controls="craftweb" aria-selected="false"><i class="fas fa-award me-1"></i> CraftWeb</button></li></ul></div> <div class="card-body"><div class="tab-content"><div class="tab-pane active" id="azuriom" role="tabpanel" aria-labelledby="azuriom-tab">`);
		NoContent($$renderer, { text: store_get($$store_subs ??= {}, "$_", $format)("pages.migration.not-available") });
		$$renderer.push(`<!----></div> <div class="tab-pane" id="namelessmc" role="tabpanel" aria-labelledby="namelessmc-tab">`);
		NoContent($$renderer, { text: store_get($$store_subs ??= {}, "$_", $format)("pages.migration.not-available") });
		$$renderer.push(`<!----></div> <div class="tab-pane" id="craftweb" role="tabpanel" aria-labelledby="craftweb-tab">`);
		CraftWebTribute($$renderer);
		$$renderer.push(`<!----></div></div></div></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
	});
}

export { MigrationPlatforms as M };
//# sourceMappingURL=MigrationPlatforms.js-QRgB5C5G.js.map
