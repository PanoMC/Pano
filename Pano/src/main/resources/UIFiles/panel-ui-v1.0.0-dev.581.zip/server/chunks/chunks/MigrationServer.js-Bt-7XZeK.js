import { J as getContext, S as unsubscribe_stores, Z as escape_html, Q as store_get, N as fallback, U as stringify, T as attr, $ as attr_style, P as ensure_array_like, V as attr_class, O as bind_props } from './index-server.js-DdhL7Abu.js';
import { b as ApiUtil } from './Store.js-DT3aZHRb.js';
import { $ as $format } from './runtime.js-BzHEw_ze.js';
import { D as DragAndDropZone } from './DragAndDropZone.js-DkRk4oSS.js';
import { N as NoContent } from './NoContent.js-Coj2fA9d.js';
import { S as SearchInput } from './SearchInput.js-DPW0WADK.js';
import { C as CardHeader } from './CardHeader.js-XBureLRg.js';
import { P as Pagination } from './Pagination.js-sd1xTcbW.js';

//#region src/lib/pages/settings/migration/BannedPlayersMigration.svelte
function BannedPlayersMigration($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let filteredItems, paginatedItems, totalPages, areAllFilteredSelected;
		let file = fallback($$props["file"], null);
		let isProcessing = fallback($$props["isProcessing"], false);
		let uploadProgress = fallback($$props["uploadProgress"], 0);
		let uploadError = fallback($$props["uploadError"], null);
		let currentStep = fallback($$props["currentStep"], "upload");
		let previewData = fallback($$props["previewData"], null);
		let selectedItems = fallback($$props["selectedItems"], () => /* @__PURE__ */ new Set(), true);
		let skipExpired = fallback($$props["skipExpired"], true);
		let overrideAlreadyBanned = fallback($$props["overrideAlreadyBanned"], false);
		let isImporting = fallback($$props["isImporting"], false);
		let importProgress = fallback($$props["importProgress"], 0);
		let importResult = fallback($$props["importResult"], null);
		let searchQuery = "";
		let currentPage = 1;
		const itemsPerPage = 10;
		function getKey(item) {
			return item.uuid || (item.name || "").toLowerCase();
		}
		async function uploadAndPreview() {
			if (!file) return;
			isProcessing = true;
			uploadProgress = 0;
			uploadError = null;
			try {
				const formData = new FormData();
				formData.append("file", file);
				const result = await ApiUtil.post({
					path: "/api/panel/migration/server/banned/upload",
					body: formData,
					onUploadProgress: (progress) => {
						uploadProgress = progress;
					}
				});
				if (result?.result === "error") {
					uploadError = result.message || result.error || store_get($$store_subs ??= {}, "$_", $format)("pages.migration.banned-players.error-upload-failed");
					return;
				}
				if (result) {
					previewData = result;
					const preselected = /* @__PURE__ */ new Set();
					result.items.forEach((item) => {
						if (item.status === "ready") preselected.add(getKey(item));
					});
					selectedItems = preselected;
					currentStep = "review";
				}
			} catch (error) {
				uploadError = error.message || store_get($$store_subs ??= {}, "$_", $format)("pages.migration.banned-players.error-upload-failed");
			} finally {
				isProcessing = false;
			}
		}
		async function importItems() {
			if (selectedItems.size === 0) return;
			isImporting = true;
			importProgress = 0;
			uploadError = null;
			const progressInterval = setInterval(() => {
				if (importProgress < .9) importProgress += .05;
			}, Math.max(100, selectedItems.size * 10));
			try {
				const result = await ApiUtil.post({
					path: "/api/panel/migration/server/banned/import",
					body: {
						selection: Array.from(selectedItems),
						skipExpired,
						overrideAlreadyBanned
					}
				});
				clearInterval(progressInterval);
				importProgress = 1;
				if (result?.result === "error") {
					uploadError = result.message || result.error || store_get($$store_subs ??= {}, "$_", $format)("pages.migration.banned-players.error-import-failed");
					return;
				}
				if (result) {
					importResult = result;
					currentStep = "result";
				}
			} catch (error) {
				clearInterval(progressInterval);
				uploadError = error.message || store_get($$store_subs ??= {}, "$_", $format)("pages.migration.banned-players.error-import-failed");
			} finally {
				isImporting = false;
			}
		}
		function resetForm() {
			file = null;
			isProcessing = false;
			uploadProgress = 0;
			uploadError = null;
			currentStep = "upload";
			previewData = null;
			selectedItems = /* @__PURE__ */ new Set();
			skipExpired = true;
			overrideAlreadyBanned = false;
			isImporting = false;
			importProgress = 0;
			importResult = null;
			searchQuery = "";
			currentPage = 1;
		}
		function formatExpires(ms) {
			if (!ms) return "-";
			try {
				return new Date(ms).toLocaleString();
			} catch (_) {
				return "-";
			}
		}
		if (searchQuery) currentPage = 1;
		filteredItems = previewData?.items?.filter((item) => {
			if (!searchQuery.trim()) return true;
			const q = searchQuery.toLowerCase();
			return (item.name || "").toLowerCase().includes(q) || (item.uuid || "").toLowerCase().includes(q) || (item.matchedUsername || "").toLowerCase().includes(q) || (item.reason || "").toLowerCase().includes(q);
		}) ?? [];
		paginatedItems = filteredItems.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);
		totalPages = Math.max(1, Math.ceil(filteredItems.length / itemsPerPage));
		areAllFilteredSelected = filteredItems.length > 0 && filteredItems.filter((i) => i.status !== "unmatched").every((i) => selectedItems.has(getKey(i)));
		if (currentStep === "upload") {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<div class="alert alert-info mb-3"><i class="fas fa-info-circle me-1"></i> <strong>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.banned-players.supported-info-title"))}</strong> <ul class="mb-0 mt-1"><li>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.banned-players.supported-format"))}</li> <li>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.banned-players.matching-info"))}</li> <li>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.banned-players.unmatched-note"))}</li></ul></div> <label class="form-label" for="uploadBannedFile">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.banned-players.upload-label"))}</label> `);
			if (file) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<div class="position-relative">`);
				DragAndDropZone($$renderer, {
					id: "uploadBannedFile",
					accept: [".json"],
					icon: "fas fa-file-alt fs-1",
					title: file.name,
					subtitle: `${stringify((file.size / 1024).toFixed(2))} KB`
				});
				$$renderer.push(`<!----> <button class="btn-close position-absolute top-0 end-0 m-2"${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("buttons.remove"))}${attr("title", store_get($$store_subs ??= {}, "$_", $format)("buttons.remove"))}></button></div>`);
			} else {
				$$renderer.push("<!--[-1-->");
				DragAndDropZone($$renderer, {
					id: "uploadBannedFile",
					accept: [".json"],
					title: store_get($$store_subs ??= {}, "$_", $format)("pages.migration.authme.drag-drop-file"),
					subtitle: store_get($$store_subs ??= {}, "$_", $format)("pages.migration.authme.click-to-browse")
				});
			}
			$$renderer.push(`<!--]--> `);
			if (isProcessing) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<div class="mt-3"><div class="d-flex justify-content-between mb-1"><small>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.authme.uploading-processing"))}</small> <small>${escape_html(Math.round(uploadProgress * 100))}%</small></div> <div class="progress" style="height: 6px;"><div class="progress-bar progress-bar-striped progress-bar-animated" role="progressbar"${attr_style(`width: ${stringify(uploadProgress * 100)}%`)}${attr("aria-valuenow", Math.round(uploadProgress * 100))} aria-valuemin="0" aria-valuemax="100"></div></div></div>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--> `);
			if (uploadError) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<div class="alert alert-danger mt-3" role="alert"><i class="fas fa-exclamation-triangle me-2"></i> ${escape_html(uploadError)}</div>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]-->`);
		} else if (currentStep === "review") {
			$$renderer.push("<!--[1-->");
			if (previewData.expiredCount > 0) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<div class="row align-items-center mb-3"><div class="col-9"><label class="fw-bold mb-0" for="skipExpired">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.banned-players.skip-expired"))}</label> <small class="d-block text-muted">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.banned-players.skip-expired-desc", { values: { count: previewData.expiredCount } }))}</small></div> <div class="col-3 text-end"><div class="form-check form-switch d-inline-block"><input class="form-check-input" type="checkbox" role="switch" id="skipExpired"${attr("checked", skipExpired, true)}/></div></div></div>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--> `);
			if (previewData.alreadyBannedCount > 0) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<div class="row align-items-center mb-3"><div class="col-9"><label class="fw-bold mb-0" for="overrideAlreadyBanned">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.banned-players.override-already-banned"))}</label> <small class="d-block text-muted">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.banned-players.override-already-banned-desc", { values: { count: previewData.alreadyBannedCount } }))}</small></div> <div class="col-3 text-end"><div class="form-check form-switch d-inline-block"><input class="form-check-input" type="checkbox" role="switch" id="overrideAlreadyBanned"${attr("checked", overrideAlreadyBanned, true)}/></div></div></div>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--> `);
			if (previewData.expiredCount > 0 || previewData.alreadyBannedCount > 0) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<hr/>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--> `);
			if (previewData.unmatchedCount > 0) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<div class="alert alert-warning mt-2 mb-3"><i class="fas fa-exclamation-triangle me-2"></i> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.banned-players.unmatched-warning", { values: { count: previewData.unmatchedCount } }))}</div>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--> <div class="card mb-3">`);
			CardHeader($$renderer, { $$slots: {
				left: ($$renderer) => {
					$$renderer.push(`<div slot="left"><span class="me-3"><strong>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.banned-players.total-entries", { values: { count: previewData.totalCount } }))}</strong></span> <span class="badge text-bg-success me-2">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.banned-players.matched", { values: { count: previewData.matchedCount } }))}</span> <span class="badge text-bg-secondary">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.banned-players.unmatched", { values: { count: previewData.unmatchedCount } }))}</span></div>`);
				},
				middle: ($$renderer) => {
					$$renderer.push(`<div slot="middle" style="width: 250px;">`);
					SearchInput($$renderer, {
						placeholderKey: "buttons.find",
						showSpinner: false
					});
					$$renderer.push(`<!----></div>`);
				},
				right: ($$renderer) => {
					$$renderer.push(`<div slot="right" class="d-flex flex-wrap gap-2"><button class="btn btn-link text-decoration-none px-0 px-md-2">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.banned-players.select-all-ready"))}</button></div>`);
				}
			} });
			$$renderer.push(`<!----> <div class="card-body p-0"><div class="table-responsive"><table class="table table-hover mb-0"><thead><tr><th class="align-middle text-nowrap" scope="col" style="width: 40px;"><input type="checkbox" class="form-check-input"${attr("checked", areAllFilteredSelected, true)}/></th><th class="align-middle text-nowrap" scope="col">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.players.table.name"))}</th><th class="align-middle text-nowrap" scope="col">UUID</th><th class="align-middle text-nowrap" scope="col">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.banned-players.reason"))}</th><th class="align-middle text-nowrap" scope="col">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.banned-players.duration"))}</th><th class="align-middle text-nowrap" scope="col">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.authme.status"))}</th></tr></thead><tbody><!--[-->`);
			const each_array = ensure_array_like(paginatedItems);
			for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
				let item = each_array[$$index];
				$$renderer.push(`<tr${attr_class("", void 0, { "opacity-50": item.status === "unmatched" })}><td><input type="checkbox" class="form-check-input"${attr("checked", selectedItems.has(getKey(item)), true)}${attr("disabled", item.status === "unmatched", true)}/></td><td class="fw-semibold">${escape_html(item.name || "-")} `);
				if (item.matchedUsername && item.matchedUsername !== item.name) {
					$$renderer.push("<!--[0-->");
					$$renderer.push(`<span class="badge text-bg-secondary ms-1 fw-normal">→ ${escape_html(item.matchedUsername)}</span>`);
				} else $$renderer.push("<!--[-1-->");
				$$renderer.push(`<!--]--></td><td>`);
				if (item.uuid) {
					$$renderer.push("<!--[0-->");
					$$renderer.push(`<code class="user-select-all fs-7 svelte-3zk2pp">${escape_html(item.uuid)}</code>`);
				} else {
					$$renderer.push("<!--[-1-->");
					$$renderer.push(`<span class="opacity-50">-</span>`);
				}
				$$renderer.push(`<!--]--></td><td class="text-truncate" style="max-width: 200px;">${escape_html(item.reason || "-")}</td><td class="text-nowrap">`);
				if (item.permanent) {
					$$renderer.push("<!--[0-->");
					$$renderer.push(`<span class="badge text-bg-danger">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.banned-players.permanent"))}</span>`);
				} else if (item.expiresAt) {
					$$renderer.push("<!--[1-->");
					$$renderer.push(`<span class="fs-7 svelte-3zk2pp">${escape_html(formatExpires(item.expiresAt))}</span>`);
				} else {
					$$renderer.push("<!--[-1-->");
					$$renderer.push(`-`);
				}
				$$renderer.push(`<!--]--></td><td>`);
				if (item.status === "ready") {
					$$renderer.push("<!--[0-->");
					$$renderer.push(`<span class="badge text-bg-success">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.banned-players.status-ready"))}</span>`);
				} else if (item.status === "already-banned") {
					$$renderer.push("<!--[1-->");
					$$renderer.push(`<span class="badge text-bg-warning">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.banned-players.status-already-banned"))}</span>`);
				} else if (item.status === "expired") {
					$$renderer.push("<!--[2-->");
					$$renderer.push(`<span class="badge text-bg-secondary">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.banned-players.status-expired"))}</span>`);
				} else {
					$$renderer.push("<!--[-1-->");
					$$renderer.push(`<span class="badge text-bg-danger">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.banned-players.status-unmatched"))}</span>`);
				}
				$$renderer.push(`<!--]--></td></tr>`);
			}
			$$renderer.push(`<!--]-->`);
			if (paginatedItems.length === 0) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<tr><td colspan="6" class="text-center text-muted py-4">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.banned-players.no-entries"))}</td></tr>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--></tbody></table></div></div> `);
			if (totalPages > 1) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<div class="card-footer">`);
				Pagination($$renderer, {
					page: currentPage,
					totalPage: totalPages
				});
				$$renderer.push(`<!----></div>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--></div> `);
			if (isImporting) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<div class="mt-3"><div class="d-flex justify-content-between mb-1"><small>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.banned-players.importing-status", { values: { count: selectedItems.size } }))}</small> <small>${escape_html(Math.round(importProgress * 100))}%</small></div> <div class="progress" style="height: 6px;"><div class="progress-bar progress-bar-striped progress-bar-animated bg-success" role="progressbar"${attr_style(`width: ${stringify(importProgress * 100)}%`)}${attr("aria-valuenow", Math.round(importProgress * 100))} aria-valuemin="0" aria-valuemax="100"></div></div></div>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--> `);
			if (uploadError) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<div class="alert alert-danger mt-3" role="alert"><i class="fas fa-exclamation-triangle me-2"></i> ${escape_html(uploadError)}</div>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--> <div class="mt-4 d-flex gap-2"><button class="btn btn-secondary"${attr("disabled", selectedItems.size === 0 || isImporting, true)}>`);
			if (isImporting) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<span class="spinner-border spinner-border-sm me-2" role="status"></span>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.import"))}</button> <button class="btn btn-link text-decoration-none"${attr("disabled", isImporting, true)}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.cancel"))}</button></div>`);
		} else if (currentStep === "result" && importResult) {
			$$renderer.push("<!--[2-->");
			$$renderer.push(`<div class="alert alert-success d-flex align-items-center" role="alert"><i class="fas fa-check-circle fs-4 me-3"></i> <div><h6 class="alert-heading mb-1">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.banned-players.result-title"))}</h6> <p class="mb-0 small"><strong>${escape_html(importResult.importedCount)}</strong> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.banned-players.result-imported"))}`);
			if (importResult.skippedCount > 0) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`, <strong>${escape_html(importResult.skippedCount)}</strong> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.banned-players.result-skipped"))}`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]-->.</p></div></div> `);
			if (importResult?.errors && importResult.errors.length > 0) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<div class="alert alert-warning mt-3"><h6 class="alert-heading mb-2"><i class="fas fa-exclamation-triangle me-1"></i> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.authme.some-issues-occurred"))}</h6> <ul class="mb-0 small"><!--[-->`);
				const each_array_1 = ensure_array_like(importResult.errors);
				for (let $$index_1 = 0, $$length = each_array_1.length; $$index_1 < $$length; $$index_1++) {
					let err = each_array_1[$$index_1];
					$$renderer.push(`<li><strong>${escape_html(err.item)}</strong>: ${escape_html(err.error)}</li>`);
				}
				$$renderer.push(`<!--]--></ul></div>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--> <button class="btn btn-primary"><i class="fas fa-redo me-2"></i> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.authme.start-new-migration"))}</button>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]-->`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
		bind_props($$props, {
			file,
			isProcessing,
			uploadProgress,
			uploadError,
			currentStep,
			previewData,
			selectedItems,
			skipExpired,
			overrideAlreadyBanned,
			isImporting,
			importProgress,
			importResult,
			resetForm,
			importItems,
			uploadAndPreview
		});
	});
}
//#endregion
//#region src/lib/pages/settings/migration/BannedIpMigration.svelte
function BannedIpMigration($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let filteredItems, paginatedItems, totalPages, areAllFilteredSelected;
		let file = fallback($$props["file"], null);
		let isProcessing = fallback($$props["isProcessing"], false);
		let uploadProgress = fallback($$props["uploadProgress"], 0);
		let uploadError = fallback($$props["uploadError"], null);
		let currentStep = fallback($$props["currentStep"], "upload");
		let previewData = fallback($$props["previewData"], null);
		let selectedItems = fallback($$props["selectedItems"], () => /* @__PURE__ */ new Set(), true);
		let skipExpired = fallback($$props["skipExpired"], true);
		let overrideExisting = fallback($$props["overrideExisting"], false);
		let isImporting = fallback($$props["isImporting"], false);
		let importProgress = fallback($$props["importProgress"], 0);
		let importResult = fallback($$props["importResult"], null);
		let searchQuery = "";
		let currentPage = 1;
		const itemsPerPage = 10;
		async function uploadAndPreview() {
			if (!file) return;
			isProcessing = true;
			uploadProgress = 0;
			uploadError = null;
			try {
				const formData = new FormData();
				formData.append("file", file);
				const result = await ApiUtil.post({
					path: "/api/panel/migration/server/banned-ips/upload",
					body: formData,
					onUploadProgress: (progress) => {
						uploadProgress = progress;
					}
				});
				if (result?.result === "error") {
					uploadError = result.message || result.error || store_get($$store_subs ??= {}, "$_", $format)("pages.migration.banned-ips.error-upload-failed");
					return;
				}
				if (result) {
					previewData = result;
					const preselected = /* @__PURE__ */ new Set();
					result.items.forEach((item) => {
						if (item.status === "new") preselected.add(item.ip);
					});
					selectedItems = preselected;
					currentStep = "review";
				}
			} catch (error) {
				uploadError = error.message || store_get($$store_subs ??= {}, "$_", $format)("pages.migration.banned-ips.error-upload-failed");
			} finally {
				isProcessing = false;
			}
		}
		async function importItems() {
			if (selectedItems.size === 0) return;
			isImporting = true;
			importProgress = 0;
			uploadError = null;
			const progressInterval = setInterval(() => {
				if (importProgress < .9) importProgress += .05;
			}, Math.max(100, selectedItems.size * 10));
			try {
				const result = await ApiUtil.post({
					path: "/api/panel/migration/server/banned-ips/import",
					body: {
						selection: Array.from(selectedItems),
						skipExpired,
						overrideExisting
					}
				});
				clearInterval(progressInterval);
				importProgress = 1;
				if (result?.result === "error") {
					uploadError = result.message || result.error || store_get($$store_subs ??= {}, "$_", $format)("pages.migration.banned-ips.error-import-failed");
					return;
				}
				if (result) {
					importResult = result;
					currentStep = "result";
				}
			} catch (error) {
				clearInterval(progressInterval);
				uploadError = error.message || store_get($$store_subs ??= {}, "$_", $format)("pages.migration.banned-ips.error-import-failed");
			} finally {
				isImporting = false;
			}
		}
		function resetForm() {
			file = null;
			isProcessing = false;
			uploadProgress = 0;
			uploadError = null;
			currentStep = "upload";
			previewData = null;
			selectedItems = /* @__PURE__ */ new Set();
			skipExpired = true;
			overrideExisting = false;
			isImporting = false;
			importProgress = 0;
			importResult = null;
			searchQuery = "";
			currentPage = 1;
		}
		function formatExpires(ms) {
			if (!ms) return "-";
			try {
				return new Date(ms).toLocaleString();
			} catch (_) {
				return "-";
			}
		}
		if (searchQuery) currentPage = 1;
		filteredItems = previewData?.items?.filter((item) => {
			if (!searchQuery.trim()) return true;
			const q = searchQuery.toLowerCase();
			return (item.ip || "").toLowerCase().includes(q) || (item.reason || "").toLowerCase().includes(q) || (item.source || "").toLowerCase().includes(q);
		}) ?? [];
		paginatedItems = filteredItems.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);
		totalPages = Math.max(1, Math.ceil(filteredItems.length / itemsPerPage));
		areAllFilteredSelected = filteredItems.length > 0 && filteredItems.every((i) => selectedItems.has(i.ip));
		if (currentStep === "upload") {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<div class="alert alert-info mb-3"><i class="fas fa-info-circle me-1"></i> <strong>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.banned-ips.supported-info-title"))}</strong> <ul class="mb-0 mt-1"><li>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.banned-ips.supported-format"))}</li> <li>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.banned-ips.enforce-info"))}</li></ul></div> <label class="form-label" for="uploadBannedIpFile">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.banned-ips.upload-label"))}</label> `);
			if (file) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<div class="position-relative">`);
				DragAndDropZone($$renderer, {
					id: "uploadBannedIpFile",
					accept: [".json"],
					icon: "fas fa-file-alt fs-1",
					title: file.name,
					subtitle: `${stringify((file.size / 1024).toFixed(2))} KB`
				});
				$$renderer.push(`<!----> <button class="btn-close position-absolute top-0 end-0 m-2"${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("buttons.remove"))}${attr("title", store_get($$store_subs ??= {}, "$_", $format)("buttons.remove"))}></button></div>`);
			} else {
				$$renderer.push("<!--[-1-->");
				DragAndDropZone($$renderer, {
					id: "uploadBannedIpFile",
					accept: [".json"],
					title: store_get($$store_subs ??= {}, "$_", $format)("pages.migration.authme.drag-drop-file"),
					subtitle: store_get($$store_subs ??= {}, "$_", $format)("pages.migration.authme.click-to-browse")
				});
			}
			$$renderer.push(`<!--]--> `);
			if (isProcessing) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<div class="mt-3"><div class="d-flex justify-content-between mb-1"><small>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.authme.uploading-processing"))}</small> <small>${escape_html(Math.round(uploadProgress * 100))}%</small></div> <div class="progress" style="height: 6px;"><div class="progress-bar progress-bar-striped progress-bar-animated" role="progressbar"${attr_style(`width: ${stringify(uploadProgress * 100)}%`)}${attr("aria-valuenow", Math.round(uploadProgress * 100))} aria-valuemin="0" aria-valuemax="100"></div></div></div>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--> `);
			if (uploadError) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<div class="alert alert-danger mt-3" role="alert"><i class="fas fa-exclamation-triangle me-2"></i> ${escape_html(uploadError)}</div>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]-->`);
		} else if (currentStep === "review") {
			$$renderer.push("<!--[1-->");
			if (previewData.expiredCount > 0) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<div class="row align-items-center mb-3"><div class="col-9"><label class="fw-bold mb-0" for="skipExpiredIp">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.banned-ips.skip-expired"))}</label> <small class="d-block text-muted">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.banned-ips.skip-expired-desc", { values: { count: previewData.expiredCount } }))}</small></div> <div class="col-3 text-end"><div class="form-check form-switch d-inline-block"><input class="form-check-input" type="checkbox" role="switch" id="skipExpiredIp"${attr("checked", skipExpired, true)}/></div></div></div>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--> `);
			if (previewData.existingCount > 0) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<div class="row align-items-center mb-3"><div class="col-9"><label class="fw-bold mb-0" for="overrideExistingIp">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.banned-ips.override-existing"))}</label> <small class="d-block text-muted">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.banned-ips.override-existing-desc", { values: { count: previewData.existingCount } }))}</small></div> <div class="col-3 text-end"><div class="form-check form-switch d-inline-block"><input class="form-check-input" type="checkbox" role="switch" id="overrideExistingIp"${attr("checked", overrideExisting, true)}/></div></div></div>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--> `);
			if (previewData.expiredCount > 0 || previewData.existingCount > 0) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<hr/>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--> <div class="card mb-3">`);
			CardHeader($$renderer, { $$slots: {
				left: ($$renderer) => {
					$$renderer.push(`<div slot="left"><span class="me-3"><strong>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.banned-ips.total-entries", { values: { count: previewData.totalCount } }))}</strong></span> <span class="badge text-bg-success me-2">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.banned-ips.new", { values: { count: previewData.newCount } }))}</span> <span class="badge text-bg-warning">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.banned-ips.existing", { values: { count: previewData.existingCount } }))}</span></div>`);
				},
				middle: ($$renderer) => {
					$$renderer.push(`<div slot="middle" style="width: 250px;">`);
					SearchInput($$renderer, {
						placeholderKey: "buttons.find",
						showSpinner: false
					});
					$$renderer.push(`<!----></div>`);
				},
				right: ($$renderer) => {
					$$renderer.push(`<div slot="right" class="d-flex flex-wrap gap-2"><button class="btn btn-link text-decoration-none px-0 px-md-2">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.banned-ips.select-all-new"))}</button></div>`);
				}
			} });
			$$renderer.push(`<!----> <div class="card-body p-0"><div class="table-responsive"><table class="table table-hover mb-0"><thead><tr><th class="align-middle text-nowrap" scope="col" style="width: 40px;"><input type="checkbox" class="form-check-input"${attr("checked", areAllFilteredSelected, true)}/></th><th class="align-middle text-nowrap" scope="col">IP</th><th class="align-middle text-nowrap" scope="col">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.banned-players.reason"))}</th><th class="align-middle text-nowrap" scope="col">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.banned-players.duration"))}</th><th class="align-middle text-nowrap" scope="col">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.authme.status"))}</th></tr></thead><tbody><!--[-->`);
			const each_array = ensure_array_like(paginatedItems);
			for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
				let item = each_array[$$index];
				$$renderer.push(`<tr><td><input type="checkbox" class="form-check-input"${attr("checked", selectedItems.has(item.ip), true)}/></td><td class="fw-semibold"><code class="user-select-all fs-7 svelte-13ecd7o">${escape_html(item.ip)}</code></td><td class="text-truncate" style="max-width: 200px;">${escape_html(item.reason || "-")}</td><td class="text-nowrap">`);
				if (item.permanent) {
					$$renderer.push("<!--[0-->");
					$$renderer.push(`<span class="badge text-bg-danger">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.banned-players.permanent"))}</span>`);
				} else if (item.expiresAt) {
					$$renderer.push("<!--[1-->");
					$$renderer.push(`<span class="fs-7 svelte-13ecd7o">${escape_html(formatExpires(item.expiresAt))}</span>`);
				} else {
					$$renderer.push("<!--[-1-->");
					$$renderer.push(`-`);
				}
				$$renderer.push(`<!--]--></td><td>`);
				if (item.status === "new") {
					$$renderer.push("<!--[0-->");
					$$renderer.push(`<span class="badge text-bg-success">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.authme.status-new"))}</span>`);
				} else if (item.status === "existing") {
					$$renderer.push("<!--[1-->");
					$$renderer.push(`<span class="badge text-bg-warning">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.authme.status-existing"))}</span>`);
				} else {
					$$renderer.push("<!--[-1-->");
					$$renderer.push(`<span class="badge text-bg-secondary">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.banned-players.status-expired"))}</span>`);
				}
				$$renderer.push(`<!--]--></td></tr>`);
			}
			$$renderer.push(`<!--]-->`);
			if (paginatedItems.length === 0) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<tr><td colspan="5" class="text-center text-muted py-4">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.banned-players.no-entries"))}</td></tr>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--></tbody></table></div></div> `);
			if (totalPages > 1) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<div class="card-footer">`);
				Pagination($$renderer, {
					page: currentPage,
					totalPage: totalPages
				});
				$$renderer.push(`<!----></div>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--></div> `);
			if (isImporting) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<div class="mt-3"><div class="d-flex justify-content-between mb-1"><small>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.banned-ips.importing-status", { values: { count: selectedItems.size } }))}</small> <small>${escape_html(Math.round(importProgress * 100))}%</small></div> <div class="progress" style="height: 6px;"><div class="progress-bar progress-bar-striped progress-bar-animated bg-success" role="progressbar"${attr_style(`width: ${stringify(importProgress * 100)}%`)}${attr("aria-valuenow", Math.round(importProgress * 100))} aria-valuemin="0" aria-valuemax="100"></div></div></div>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--> `);
			if (uploadError) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<div class="alert alert-danger mt-3" role="alert"><i class="fas fa-exclamation-triangle me-2"></i> ${escape_html(uploadError)}</div>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--> <div class="mt-4 d-flex gap-2"><button class="btn btn-secondary"${attr("disabled", selectedItems.size === 0 || isImporting, true)}>`);
			if (isImporting) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<span class="spinner-border spinner-border-sm me-2" role="status"></span>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.import"))}</button> <button class="btn btn-link text-decoration-none"${attr("disabled", isImporting, true)}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.cancel"))}</button></div>`);
		} else if (currentStep === "result" && importResult) {
			$$renderer.push("<!--[2-->");
			$$renderer.push(`<div class="alert alert-success d-flex align-items-center" role="alert"><i class="fas fa-check-circle fs-4 me-3"></i> <div><h6 class="alert-heading mb-1">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.banned-ips.result-title"))}</h6> <p class="mb-0 small"><strong>${escape_html(importResult.importedCount)}</strong> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.banned-ips.result-imported"))}`);
			if (importResult.updatedCount > 0) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`, <strong>${escape_html(importResult.updatedCount)}</strong> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.banned-ips.result-updated"))}`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]-->`);
			if (importResult.skippedCount > 0) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`, <strong>${escape_html(importResult.skippedCount)}</strong> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.banned-players.result-skipped"))}`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]-->.</p></div></div> `);
			if (importResult?.errors && importResult.errors.length > 0) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<div class="alert alert-warning mt-3"><h6 class="alert-heading mb-2"><i class="fas fa-exclamation-triangle me-1"></i> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.authme.some-issues-occurred"))}</h6> <ul class="mb-0 small"><!--[-->`);
				const each_array_1 = ensure_array_like(importResult.errors);
				for (let $$index_1 = 0, $$length = each_array_1.length; $$index_1 < $$length; $$index_1++) {
					let err = each_array_1[$$index_1];
					$$renderer.push(`<li><strong>${escape_html(err.item)}</strong>: ${escape_html(err.error)}</li>`);
				}
				$$renderer.push(`<!--]--></ul></div>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--> <button class="btn btn-primary"><i class="fas fa-redo me-2"></i> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.authme.start-new-migration"))}</button>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]-->`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
		bind_props($$props, {
			file,
			isProcessing,
			uploadProgress,
			uploadError,
			currentStep,
			previewData,
			selectedItems,
			skipExpired,
			overrideExisting,
			isImporting,
			importProgress,
			importResult,
			resetForm,
			importItems,
			uploadAndPreview
		});
	});
}
//#endregion
//#region src/lib/pages/settings/MigrationServer.svelte
function MigrationServer($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		const pageTitle = getContext("pageTitle");
		if (pageTitle) pageTitle.set("components.settings-layout.migration");
		let bannedFile;
		let bannedStep;
		let bannedPreview;
		let bannedSelected;
		let bannedSkipExpired;
		let bannedOverride;
		let bannedProcessing;
		let bannedImporting;
		let bannedResult;
		let bannedError;
		let bannedResetForm;
		let bannedImportItems;
		let bannedIpFile;
		let bannedIpStep;
		let bannedIpPreview;
		let bannedIpSelected;
		let bannedIpSkipExpired;
		let bannedIpOverride;
		let bannedIpProcessing;
		let bannedIpImporting;
		let bannedIpResult;
		let bannedIpError;
		let bannedIpResetForm;
		let bannedIpImportItems;
		let $$settled = true;
		let $$inner_renderer;
		function $$render_inner($$renderer) {
			$$renderer.push(`<div class="card"><div class="card-header pb-0 vstack gap-2"><ul class="nav nav-tabs border-bottom-0" id="serverMigrateTabs" role="tablist"><li class="nav-item" role="presentation"><button class="nav-link active" id="banned-tab" data-bs-toggle="tab" data-bs-target="#banned" type="button" role="tab" aria-controls="banned" aria-selected="true">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.banned"))}</button></li> <li class="nav-item" role="presentation"><button class="nav-link" id="banned-ips-tab" data-bs-toggle="tab" data-bs-target="#banned-ips" type="button" role="tab" aria-controls="banned-ips" aria-selected="false">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.banned-ips-title"))}</button></li> <li class="nav-item" role="presentation"><button class="nav-link" id="whitelist-tab" data-bs-toggle="tab" data-bs-target="#whitelist" type="button" role="tab" aria-controls="whitelist" aria-selected="false">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.whitelist"))}</button></li></ul></div> <div class="card-body"><div class="tab-content"><div class="tab-pane active" id="banned" role="tabpanel" aria-labelledby="banned-tab">`);
			BannedPlayersMigration($$renderer, {
				get file() {
					return bannedFile;
				},
				set file($$value) {
					bannedFile = $$value;
					$$settled = false;
				},
				get currentStep() {
					return bannedStep;
				},
				set currentStep($$value) {
					bannedStep = $$value;
					$$settled = false;
				},
				get previewData() {
					return bannedPreview;
				},
				set previewData($$value) {
					bannedPreview = $$value;
					$$settled = false;
				},
				get selectedItems() {
					return bannedSelected;
				},
				set selectedItems($$value) {
					bannedSelected = $$value;
					$$settled = false;
				},
				get skipExpired() {
					return bannedSkipExpired;
				},
				set skipExpired($$value) {
					bannedSkipExpired = $$value;
					$$settled = false;
				},
				get overrideAlreadyBanned() {
					return bannedOverride;
				},
				set overrideAlreadyBanned($$value) {
					bannedOverride = $$value;
					$$settled = false;
				},
				get isProcessing() {
					return bannedProcessing;
				},
				set isProcessing($$value) {
					bannedProcessing = $$value;
					$$settled = false;
				},
				get isImporting() {
					return bannedImporting;
				},
				set isImporting($$value) {
					bannedImporting = $$value;
					$$settled = false;
				},
				get importResult() {
					return bannedResult;
				},
				set importResult($$value) {
					bannedResult = $$value;
					$$settled = false;
				},
				get uploadError() {
					return bannedError;
				},
				set uploadError($$value) {
					bannedError = $$value;
					$$settled = false;
				},
				get resetForm() {
					return bannedResetForm;
				},
				set resetForm($$value) {
					bannedResetForm = $$value;
					$$settled = false;
				},
				get importItems() {
					return bannedImportItems;
				},
				set importItems($$value) {
					bannedImportItems = $$value;
					$$settled = false;
				}
			});
			$$renderer.push(`<!----></div> <div class="tab-pane" id="banned-ips" role="tabpanel" aria-labelledby="banned-ips-tab">`);
			BannedIpMigration($$renderer, {
				get file() {
					return bannedIpFile;
				},
				set file($$value) {
					bannedIpFile = $$value;
					$$settled = false;
				},
				get currentStep() {
					return bannedIpStep;
				},
				set currentStep($$value) {
					bannedIpStep = $$value;
					$$settled = false;
				},
				get previewData() {
					return bannedIpPreview;
				},
				set previewData($$value) {
					bannedIpPreview = $$value;
					$$settled = false;
				},
				get selectedItems() {
					return bannedIpSelected;
				},
				set selectedItems($$value) {
					bannedIpSelected = $$value;
					$$settled = false;
				},
				get skipExpired() {
					return bannedIpSkipExpired;
				},
				set skipExpired($$value) {
					bannedIpSkipExpired = $$value;
					$$settled = false;
				},
				get overrideExisting() {
					return bannedIpOverride;
				},
				set overrideExisting($$value) {
					bannedIpOverride = $$value;
					$$settled = false;
				},
				get isProcessing() {
					return bannedIpProcessing;
				},
				set isProcessing($$value) {
					bannedIpProcessing = $$value;
					$$settled = false;
				},
				get isImporting() {
					return bannedIpImporting;
				},
				set isImporting($$value) {
					bannedIpImporting = $$value;
					$$settled = false;
				},
				get importResult() {
					return bannedIpResult;
				},
				set importResult($$value) {
					bannedIpResult = $$value;
					$$settled = false;
				},
				get uploadError() {
					return bannedIpError;
				},
				set uploadError($$value) {
					bannedIpError = $$value;
					$$settled = false;
				},
				get resetForm() {
					return bannedIpResetForm;
				},
				set resetForm($$value) {
					bannedIpResetForm = $$value;
					$$settled = false;
				},
				get importItems() {
					return bannedIpImportItems;
				},
				set importItems($$value) {
					bannedIpImportItems = $$value;
					$$settled = false;
				}
			});
			$$renderer.push(`<!----></div> <div class="tab-pane" id="whitelist" role="tabpanel" aria-labelledby="whitelist-tab">`);
			NoContent($$renderer, { text: store_get($$store_subs ??= {}, "$_", $format)("pages.migration.not-available") });
			$$renderer.push(`<!----></div></div></div></div>`);
		}
		do {
			$$settled = true;
			$$inner_renderer = $$renderer.copy();
			$$render_inner($$inner_renderer);
		} while (!$$settled);
		$$renderer.subsume($$inner_renderer);
		if ($$store_subs) unsubscribe_stores($$store_subs);
	});
}

export { MigrationServer as M };
//# sourceMappingURL=MigrationServer.js-Bt-7XZeK.js.map
