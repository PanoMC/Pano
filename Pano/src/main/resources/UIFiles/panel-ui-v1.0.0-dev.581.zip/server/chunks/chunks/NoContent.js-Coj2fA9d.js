import { N as fallback, V as attr_class, a1 as clsx, Z as escape_html, W as slot, O as bind_props, Q as store_get, S as unsubscribe_stores } from './index-server.js-DdhL7Abu.js';
import { $ as $format } from './runtime.js-BzHEw_ze.js';

//#region src/lib/components/NoContent.svelte
function NoContent($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let icon = fallback($$props["icon"], "fa-solid fa-square fa-3x");
		let text = fallback($$props["text"], () => store_get($$store_subs ??= {}, "$_", $format)("components.no-content.here-is-empty"), true);
		$$renderer.push(`<div class="card border-0 opacity-50 bg-transparent"><div class="card-body vstack gap-3 text-center"><span${attr_class(clsx(icon))}></span> <p class="mb-0">${escape_html(text)}</p></div></div> <!--[-->`);
		slot($$renderer, $$props, "default", {}, null);
		$$renderer.push(`<!--]-->`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
		bind_props($$props, {
			icon,
			text
		});
	});
}

export { NoContent as N };
//# sourceMappingURL=NoContent.js-Coj2fA9d.js.map
