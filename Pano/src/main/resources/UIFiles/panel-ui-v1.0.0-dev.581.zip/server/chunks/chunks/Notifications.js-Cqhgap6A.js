import { J as getContext, a0 as onDestroy, Z as escape_html, Q as store_get, V as attr_class, P as ensure_array_like, T as attr, U as stringify, X as html, S as unsubscribe_stores, Y as get, F as writable } from './index-server.js-DdhL7Abu.js';
import { b as ApiUtil, f as avatarVersion } from './Store.js-DT3aZHRb.js';
import { $ as $format } from './runtime.js-BzHEw_ze.js';
import './ToastContainer.js-Bv1jJ2dr.js';
import { l as locale_exports } from './locale.js-DgLiJnqO.js';
import { s as sanitize } from './server2.js-z2LG8ejq.js';
import { s as sanitizeImageSrc } from './security.util.js-D4eJjJV6.js';
import { i as isPanelNotificationUnread, f as formatDistanceToNow } from './panelNotification.util.js-BhOOsCbR.js';
import { c as currentLanguage } from './language.util.js-ByanOnuS.js';
import { N as NoContent } from './NoContent.js-Coj2fA9d.js';
import { P as PageActions } from './PageActions.js-co-RIHDp.js';

function ConfirmRemoveAllNotificationsModal($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let loading;
		$$renderer.push(`<div aria-hidden="true" class="modal fade" role="dialog" tabindex="-1"><div class="modal-dialog modal-dialog-centered" role="dialog"><div class="modal-content"><div class="modal-body text-center"><div class="pb-3"><i class="fas fa-question-circle fa-3x d-block m-auto text-gray"></i></div> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.confirm-remove-all-notifications.title"))}</div> <div class="modal-footer flex-nowrap"><button${attr_class("btn btn-link col-6 m-0", void 0, { "disabled": loading })} type="button"${attr("aria-disabled", loading)}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.cancel"))}</button> <button${attr_class("btn btn-secondary col-6 m-0", void 0, { "disabled": loading })} type="button"${attr("aria-disabled", loading)}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.yes"))}</button></div></div></div></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
	});
}
//#endregion
//#region src/lib/pages/Notifications.svelte
var notifications = writable([]);
var count = writable(0);
Array.prototype.insert = function(index, item) {
	this.splice(index, 0, item);
	return this;
};
Array.prototype.remove = function(index) {
	this.splice(index, 1);
	return this;
};
function setNotifications(newNotifications) {
	if (get(notifications).length === 0 || newNotifications.length === 0) notifications.set(newNotifications);
	else {
		const listOfFilterIsNotificationExists = [];
		newNotifications.forEach((item, index) => {
			listOfFilterIsNotificationExists[index] = get(notifications).filter((filterItem) => filterItem.id === item.id);
		});
		newNotifications.forEach((item, index) => {
			if (listOfFilterIsNotificationExists[index].length === 0) notifications.set(get(notifications).insert(index, item));
		});
	}
}
/**
* @type {import('@sveltejs/kit').PageLoad}
*/
async function load(event) {
	const { parent } = event;
	await parent();
	const body = await ApiUtil.get({
		path: "/api/panel/notifications",
		request: event
	});
	setNotifications(body.notifications);
	count.set(parseInt(body.notificationCount));
	return body;
}
function Notifications($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		getContext("pageTitle").set("pages.notifications.title");
		let loadMoreLoading = false;
		let checkTime = 0;
		let interval;
		function stopnotificationCountdown() {
			clearInterval(interval);
		}
		function getTime(check, time, locale) {
			return formatDistanceToNow(time, { addSuffix: true });
		}
		onDestroy(() => {
			stopnotificationCountdown();
		});
		function sanitizeObject(obj) {
			return Object.keys(obj).reduce((sanitizedObj, key) => {
				sanitizedObj[key] = sanitize(obj[key]);
				return sanitizedObj;
			}, {});
		}
		$$renderer.push(`<div class="container vstack gap-3">`);
		PageActions($$renderer, {
			leftClasses: "d-lg-flex d-none",
			middleClasses: "d-lg-flex d-none",
			$$slots: { right: ($$renderer) => {
				$$renderer.push(`<div slot="right">`);
				if (store_get($$store_subs ??= {}, "$notifications", notifications).length !== 0) {
					$$renderer.push("<!--[0-->");
					$$renderer.push(`<button type="button"${attr("title", store_get($$store_subs ??= {}, "$_", $format)("pages.notifications.delete-all"))}${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("pages.notifications.delete-all"))} class="btn btn-link link-danger"><i class="fa fa-trash"></i></button>`);
				} else $$renderer.push("<!--[-1-->");
				$$renderer.push(`<!--]--></div>`);
			} }
		});
		$$renderer.push(`<!----> <div class="card"><div class="card-header">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.notifications.title"))}</div> <div${attr_class("card-body vstack gap-3", void 0, { "d-none": store_get($$store_subs ??= {}, "$notifications", notifications).length === 0 })}><div class="list-group"><!--[-->`);
		const each_array = ensure_array_like(store_get($$store_subs ??= {}, "$notifications", notifications));
		for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
			let notification = each_array[$$index];
			$$renderer.push(`<div${attr_class("panel-notification-row list-group-item list-group-item-action d-flex align-items-center gap-3 text-wrap", void 0, { "notification-unread": isPanelNotificationUnread(notification) })}><button type="button"${attr("title", store_get($$store_subs ??= {}, "$_", $format)("buttons.view"))} class="btn btn-link text-decoration-none flex-grow-1 text-start border-0 bg-transparent p-0 d-flex align-items-center gap-3"><span class="d-flex align-items-center">`);
			if (notification.details.faIcon) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<i${attr_class(`${stringify(notification.details.faIcon)} fa-fw fa-xl text-primary`)}></i>`);
			} else if (notification.details.image || notification.details.username) {
				$$renderer.push("<!--[1-->");
				$$renderer.push(`<img${attr("src", sanitizeImageSrc(notification.details.image || `/api/profile/picture/${notification.details.username}?${store_get($$store_subs ??= {}, "$avatarVersion", avatarVersion)}`, "/api/server/icon/default"))}${attr("alt", store_get($$store_subs ??= {}, "$_", $format)("buttons.view"))} width="30" height="30" class="rounded"/>`);
			} else {
				$$renderer.push("<!--[-1-->");
				$$renderer.push(`<i class="fa fa-bolt fa-xl fa-fw text-primary"></i>`);
			}
			$$renderer.push(`<!--]--></span> <div class="fw-normal"><span class="text-wrap markdown-renderer">${html(store_get($$store_subs ??= {}, "$_", $format)("notifications." + notification.type, { values: { ...sanitizeObject(notification.details || {}) } }))}</span> <br/> <small>${escape_html(getTime(checkTime, parseInt(notification.createdAt), locale_exports[store_get($$store_subs ??= {}, "$currentLanguage", currentLanguage).dateFnsCode]))}</small></div></button> <button type="button" class="btn-close ms-2"${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("pages.notifications.delete-notification"))}${attr("title", store_get($$store_subs ??= {}, "$_", $format)("pages.notifications.delete-notification"))}></button></div>`);
		}
		$$renderer.push(`<!--]--></div></div> `);
		if (store_get($$store_subs ??= {}, "$notifications", notifications).length === 0) {
			$$renderer.push("<!--[0-->");
			NoContent($$renderer, {});
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--> `);
		if (store_get($$store_subs ??= {}, "$notifications", notifications).length < store_get($$store_subs ??= {}, "$count", count) && store_get($$store_subs ??= {}, "$count", count) > 10) {
			$$renderer.push("<!--[0-->");
			const remaining = store_get($$store_subs ??= {}, "$count", count) - store_get($$store_subs ??= {}, "$notifications", notifications).length;
			const nextBatch = Math.min(10, remaining);
			$$renderer.push(`<div class="card-footer d-flex justify-content-center"><button${attr_class("btn btn-sm btn-outline-primary", void 0, { "disabled": loadMoreLoading })}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)(remaining <= 10 ? "pages.notifications.show-more-simple" : "pages.notifications.show-more", { values: {
				nextBatch,
				remaining
			} }))}</button></div>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--></div></div> `);
		ConfirmRemoveAllNotificationsModal($$renderer);
		$$renderer.push(`<!---->`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
	});
}

export { Notifications as N, load as l };
//# sourceMappingURL=Notifications.js-Cqhgap6A.js.map
