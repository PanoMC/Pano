import { a2 as sanitize_slots, N as fallback, V as attr_class, W as slot, O as bind_props, U as stringify } from './index-server.js-DdhL7Abu.js';

//#region src/lib/components/PageActions.svelte
function PageActions($$renderer, $$props) {
	const $$slots = sanitize_slots($$props);
	let leftClasses = fallback($$props["leftClasses"], void 0);
	let middleClasses = fallback($$props["middleClasses"], void 0);
	let rightClasses = fallback($$props["rightClasses"], void 0);
	$$renderer.push(`<div class="row d-flex align-items-center gy-3 justify-content-lg-between justify-content-center">`);
	if (leftClasses !== null && $$slots.left || leftClasses !== null && leftClasses !== void 0) {
		$$renderer.push("<!--[0-->");
		$$renderer.push(`<div${attr_class(`col-lg-auto col-12 d-flex justify-content-lg-start overflow-x-auto scroll-center ${stringify(leftClasses || "")}`, "svelte-cy2g2a")}><!--[-->`);
		slot($$renderer, $$props, "left", {}, null);
		$$renderer.push(`<!--]--></div>`);
	} else $$renderer.push("<!--[-1-->");
	$$renderer.push(`<!--]--> `);
	if (middleClasses !== null && $$slots.middle || middleClasses !== null && middleClasses !== void 0) {
		$$renderer.push("<!--[0-->");
		$$renderer.push(`<div${attr_class(`col-lg-auto col-12 order-lg-2 order-last d-flex justify-content-center overflow-x-auto scroll-center ${stringify(middleClasses || "")}`, "svelte-cy2g2a")}><!--[-->`);
		slot($$renderer, $$props, "middle", {}, null);
		$$renderer.push(`<!--]--></div>`);
	} else $$renderer.push("<!--[-1-->");
	$$renderer.push(`<!--]--> `);
	if (rightClasses !== null && $$slots.right || rightClasses !== null && rightClasses !== void 0) {
		$$renderer.push("<!--[0-->");
		$$renderer.push(`<div${attr_class(`col-lg-auto col-12 order-3 d-flex justify-content-lg-end overflow-x-auto scroll-center ${stringify(rightClasses || "")}`, "svelte-cy2g2a")}><!--[-->`);
		slot($$renderer, $$props, "right", {}, null);
		$$renderer.push(`<!--]--></div>`);
	} else $$renderer.push("<!--[-1-->");
	$$renderer.push(`<!--]--></div>`);
	bind_props($$props, {
		leftClasses,
		middleClasses,
		rightClasses
	});
}

export { PageActions as P };
//# sourceMappingURL=PageActions.js-co-RIHDp.js.map
