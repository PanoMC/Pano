import { V as attr_class, T as attr, O as bind_props } from './index-server.js-DdhL7Abu.js';

//#region src/lib/components/PageLoading.svelte
function PageLoading($$renderer, $$props) {
	let show = $$props["show"];
	$$renderer.push(`<div${attr_class("align-items-center justify-content-center w-100 h-75", void 0, { "d-flex": show })}${attr("hidden", !show)}><div class="spinner-border text-primary" role="status"></div></div>`);
	bind_props($$props, { show });
}

export { PageLoading as P };
//# sourceMappingURL=PageLoading.js-BAdCAKhL.js.map
