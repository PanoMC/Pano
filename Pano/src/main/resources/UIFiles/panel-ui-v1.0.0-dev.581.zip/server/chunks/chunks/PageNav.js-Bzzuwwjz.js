import { b as base } from './internal.js-BRN1McAa.js';
import { W as slot, V as attr_class, U as stringify, a3 as element, a5 as attributes, Q as store_get, S as unsubscribe_stores, y as derived } from './index-server.js-DdhL7Abu.js';
import { p as page } from './stores.js-D5xmrOAP.js';
import './server.js-BlClO2ED.js';
import './internal2.js-CNe5OZUJ.js';
import './routing.js-N-OPb2ye.js';

//#region src/lib/components/PageNavItem.svelte
function PageNavItem($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let { href, startsWith, disabled, active, button, onclick, classes, liClazz, children } = $$props;
		const aProps = derived(() => !button && { href: base + href });
		const buttonProps = derived(() => button && { type: "button" });
		function matching(path, pathName = "", startsWith = false) {
			return path.toUpperCase() === pathName.toUpperCase() || path.toUpperCase() === (pathName + "/").toUpperCase() || startsWith && path.startsWith(pathName);
		}
		$$renderer.push(`<li${attr_class(`nav-item ${stringify(liClazz || "")}`)}>`);
		element($$renderer, button ? "button" : "a", () => {
			$$renderer.push(`${attributes({
				class: `nav-link ${stringify(disabled && "disabled")} ${stringify(classes)}`,
				"aria-current": "page",
				"aria-disabled": disabled,
				...aProps(),
				...buttonProps()
			}, void 0, { active: active !== void 0 ? active : matching(store_get($$store_subs ??= {}, "$page", page).url.pathname, base + href, startsWith) })}`);
		}, () => {
			children($$renderer);
			$$renderer.push(`<!---->`);
		});
		$$renderer.push(`</li>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
	});
}
//#endregion
//#region src/lib/components/PageNav.svelte
function PageNav($$renderer, $$props) {
	$$renderer.push(`<ul class="nav nav-pills d-flex flex-nowrap overflow-x-auto text-nowrap no-scrollbar scroll-center svelte-glgdy8"><!--[-->`);
	slot($$renderer, $$props, "default", {}, null);
	$$renderer.push(`<!--]--></ul>`);
}

export { PageNav as P, PageNavItem as a };
//# sourceMappingURL=PageNav.js-Bzzuwwjz.js.map
