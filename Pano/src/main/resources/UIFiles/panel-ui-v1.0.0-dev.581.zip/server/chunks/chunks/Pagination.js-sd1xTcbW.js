import { V as attr_class, T as attr, Q as store_get, P as ensure_array_like, Z as escape_html, S as unsubscribe_stores, y as derived, F as writable } from './index-server.js-DdhL7Abu.js';
import { $ as $format } from './runtime.js-BzHEw_ze.js';

var targetPage = writable(1);
var maxPage = writable(1);
function JumpToPageModal($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		$$renderer.push(`<div aria-hidden="true" class="modal fade" role="dialog" tabindex="-1"><div class="modal-dialog modal-dialog-centered modal-sm" role="dialog"><div class="modal-content"><div class="modal-header"><h5 class="modal-title">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.pagination.jump-to-page"))}</h5> <button type="button" class="btn-close"${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("buttons.close"))}></button></div> <div class="modal-body"><div class="mb-3"><label for="pageInput" class="form-label">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.pagination.enter-page-number"))}</label> <input type="number" class="form-control" id="pageInput"${attr("value", store_get($$store_subs ??= {}, "$targetPage", targetPage))} min="1"${attr("max", store_get($$store_subs ??= {}, "$maxPage", maxPage))}/></div></div> <div class="modal-footer flex-nowrap"><button type="button" class="btn btn-link col-6 m-0 text-decoration-none">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.cancel"))}</button> <button type="button" class="btn btn-primary col-6 m-0">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.go"))}</button></div></div></div></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
	});
}
//#endregion
//#region src/lib/components/Pagination.svelte
function Pagination($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let { page = 1, totalPage = 1 } = $$props;
		const displayedPages = derived(() => {
			if (totalPage <= 5) return Array.from({ length: totalPage }, (_, i) => i + 1);
			const current = parseInt(page);
			const range = [];
			const rangeWithDots = [];
			range.push(1);
			let start = Math.max(2, current - 1);
			let end = Math.min(totalPage - 1, current + 1);
			if (current <= 3) end = Math.min(totalPage - 1, 4);
			else if (current >= totalPage - 2) start = Math.max(2, totalPage - 3);
			for (let i = start; i <= end; i++) range.push(i);
			if (totalPage > 1) range.push(totalPage);
			let l;
			for (const i of range) {
				if (l) {
					if (i - l === 2) rangeWithDots.push(l + 1);
					else if (i - l !== 1) rangeWithDots.push("...");
				}
				rangeWithDots.push(i);
				l = i;
			}
			return rangeWithDots;
		});
		$$renderer.push(`<nav><ul class="pagination pagination-sm mb-0 justify-content-start flex-wrap"><li${attr_class("page-item", void 0, { "disabled": parseInt(page) === 1 })}><button type="button" class="page-link"${attr("title", store_get($$store_subs ??= {}, "$_", $format)("components.pagination.previous-page"))}${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("components.pagination.previous-page"))}${attr("aria-hidden", parseInt(page) === 1)}><i class="fa-solid fa-caret-left"></i></button></li> <!--[-->`);
		const each_array = ensure_array_like(displayedPages());
		for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
			let index = each_array[$$index];
			$$renderer.push(`<li${attr_class("page-item", void 0, { "active": parseInt(page) === index })}${attr("aria-current", parseInt(page) === index ? "page" : "")}>`);
			if (index === "...") {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<button type="button" class="page-link">...</button>`);
			} else {
				$$renderer.push("<!--[-1-->");
				$$renderer.push(`<button type="button" class="page-link"${attr("aria-hidden", parseInt(page) === index)}>${escape_html(index)}</button>`);
			}
			$$renderer.push(`<!--]--></li>`);
		}
		$$renderer.push(`<!--]--> <li${attr_class("page-item", void 0, { "disabled": parseInt(page) === totalPage })}><button type="button" class="page-link"${attr("title", store_get($$store_subs ??= {}, "$_", $format)("components.pagination.next-page"))}${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("components.pagination.next-page"))}${attr("aria-hidden", parseInt(page) === totalPage)}><i class="fa-solid fa-caret-right"></i></button></li></ul></nav> `);
		JumpToPageModal($$renderer);
		$$renderer.push(`<!---->`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
	});
}

export { Pagination as P };
//# sourceMappingURL=Pagination.js-sd1xTcbW.js.map
