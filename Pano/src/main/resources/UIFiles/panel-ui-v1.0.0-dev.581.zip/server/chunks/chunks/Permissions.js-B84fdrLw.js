import { e as error } from './exports2.js-VkmSkXbz.js';
import { J as getContext, Q as store_get, Z as escape_html, T as attr, U as stringify, V as attr_class, $ as attr_style, P as ensure_array_like, S as unsubscribe_stores, O as bind_props, F as writable } from './index-server.js-DdhL7Abu.js';
import { b as beforeNavigate } from './stores.js-D5xmrOAP.js';
import { b as ApiUtil, P as PANO_WEBSITE_URL, f as avatarVersion } from './Store.js-DT3aZHRb.js';
import { $ as $format, c as $dictionary, b as $locale } from './runtime.js-BzHEw_ze.js';
import './ToastContainer.js-Bv1jJ2dr.js';
import { c as currentLanguage } from './language.util.js-ByanOnuS.js';
import { N as NoContent } from './NoContent.js-Coj2fA9d.js';
import { S as SearchInput } from './SearchInput.js-DPW0WADK.js';
import { P as PageActions } from './PageActions.js-co-RIHDp.js';
import { S as SearchPlayerModal } from './SearchPlayerModal.js-BcRLy3K7.js';

var allGroups = writable([]);
var lockGroupName = writable(false);
var originalGroupName = writable("");
var newGroup = writable({
	name: "",
	weight: 0,
	displayName: "",
	parents: []
});
function CreatePermissionGroupModal($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		const isValidGroupName = (raw) => {
			const name = String(raw || "").trim();
			if (!name) return false;
			if (name.length > 30) return false;
			return /^[a-zA-Z0-9._-]+$/.test(name);
		};
		let parentToAdd = "";
		let canSave = false;
		let availableParentGroups = [];
		const parentLabel = (name) => {
			return new Map((store_get($$store_subs ??= {}, "$allGroups", allGroups) || []).map((g) => [g.name, g])).get(name)?.displayName || name;
		};
		{
			const name = String(store_get($$store_subs ??= {}, "$newGroup", newGroup)?.name || "").trim();
			const nameLc = name.toLowerCase();
			const originalLc = String(store_get($$store_subs ??= {}, "$originalGroupName", originalGroupName) || "").trim().toLowerCase();
			const taken = !!nameLc && (store_get($$store_subs ??= {}, "$allGroups", allGroups) || []).some((g) => {
				const gn = String(g?.name || "").trim().toLowerCase();
				if (!gn) return false;
				if (gn === originalLc) return false;
				return gn === nameLc;
			});
			canSave = isValidGroupName(name) && !taken;
		}
		{
			const selfName = String(store_get($$store_subs ??= {}, "$newGroup", newGroup)?.name || "").trim();
			const selected = new Set((store_get($$store_subs ??= {}, "$newGroup", newGroup)?.parents || []).map((p) => String(p || "").trim()).filter(Boolean));
			availableParentGroups = (store_get($$store_subs ??= {}, "$allGroups", allGroups) || []).filter((g) => {
				const gn = String(g?.name || "").trim();
				if (!gn) return false;
				if (gn === selfName) return false;
				if (selected.has(gn)) return false;
				return true;
			});
		}
		$$renderer.push(`<div class="modal fade" tabindex="-1" role="dialog" aria-hidden="true"><div class="modal-dialog"><div class="modal-content"><div class="modal-header"><h5 class="modal-title">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.permission-groups.create-permission-group-button"))}</h5> <button type="button" class="btn-close"${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("buttons.close"))}></button></div> <div class="modal-body"><form><div class="form-floating mb-3"><input type="text" class="form-control form-control-lg" id="groupDisplayName"${attr("value", store_get($$store_subs ??= {}, "$newGroup", newGroup).displayName)} maxlength="30"/> <label for="groupDisplayName">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.permission-groups.form.display-name"))}</label></div> <div class="input-group mb-3"><div class="form-floating"><input type="text" class="form-control font-monospace" id="groupName"${attr("value", store_get($$store_subs ??= {}, "$newGroup", newGroup).name)}${attr("disabled", store_get($$store_subs ??= {}, "$lockGroupName", lockGroupName), true)}${attr("aria-disabled", store_get($$store_subs ??= {}, "$lockGroupName", lockGroupName))} maxlength="30" required=""/> <label for="groupName">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.permission-groups.form.group-name"))}</label></div> <div class="form-floating"><input type="number" class="form-control" id="groupWeight"${attr("value", store_get($$store_subs ??= {}, "$newGroup", newGroup).weight)} inputmode="numeric"/> <label for="groupWeight">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.permission-groups.form.weight"))}</label></div></div> <div class="form-label">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.permission-groups.form.parents"))}</div> `);
		if ((store_get($$store_subs ??= {}, "$newGroup", newGroup).parents || []).length === 0) {
			$$renderer.push("<!--[0-->");
			NoContent($$renderer, {});
		} else {
			$$renderer.push("<!--[-1-->");
			$$renderer.push(`<div class="list-group list-group"><!--[-->`);
			const each_array = ensure_array_like(store_get($$store_subs ??= {}, "$newGroup", newGroup).parents || []);
			for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
				let p = each_array[$$index];
				$$renderer.push(`<div class="list-group-item d-flex justify-content-between align-items-center"><div class="text-truncate">${escape_html(parentLabel(p))} <small>(${escape_html(p)})</small></div> <button type="button" class="btn-close"${attr("title", store_get($$store_subs ??= {}, "$_", $format)("buttons.remove"))}${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("buttons.remove"))}></button></div>`);
			}
			$$renderer.push(`<!--]--></div>`);
		}
		$$renderer.push(`<!--]--> `);
		if (availableParentGroups.length > 0) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<div class="hstack gap-2 mt-3">`);
			$$renderer.select({
				class: "form-select",
				value: parentToAdd
			}, ($$renderer) => {
				$$renderer.option({ value: "" }, ($$renderer) => {
					$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.permission-groups.form.select-option"))}`);
				});
				$$renderer.push(`<!--[-->`);
				const each_array_1 = ensure_array_like(availableParentGroups);
				for (let $$index_1 = 0, $$length = each_array_1.length; $$index_1 < $$length; $$index_1++) {
					let g = each_array_1[$$index_1];
					$$renderer.option({
						class: "font-monospace",
						value: g.name
					}, ($$renderer) => {
						$$renderer.push(`${escape_html(g.displayName || g.name)} (${escape_html(g.name)})`);
					});
				}
				$$renderer.push(`<!--]-->`);
			});
			$$renderer.push(` <button type="button" class="btn btn-link text-decoration-none"${attr("title", store_get($$store_subs ??= {}, "$_", $format)("buttons.add"))}${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("buttons.add"))}${attr("disabled", !String("").trim(), true)}${attr("aria-disabled", !String("").trim())}><i class="fa fa-plus"></i></button></div>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--></form></div> <div class="modal-footer">`);
		if (store_get($$store_subs ??= {}, "$originalGroupName", originalGroupName)) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<button type="button" class="btn btn-primary w-100"${attr("disabled", !canSave, true)}${attr("aria-disabled", !canSave)}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.save"))}</button>`);
		} else {
			$$renderer.push("<!--[-1-->");
			$$renderer.push(`<button type="button" class="btn btn-secondary w-100"${attr("disabled", !canSave, true)}${attr("aria-disabled", !canSave)}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.create"))}</button>`);
		}
		$$renderer.push(`<!--]--></div></div></div></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
	});
}
var permissionGroups$1 = writable([]);
var isEdit = writable(false);
var draft$1 = writable({
	name: "",
	description: "",
	groupNames: []
});
function EditPermTrackModal($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let sortedPermissionGroups = [];
		let draggingAvailableName = null;
		function groupLabel(name) {
			const n = String(name || "").trim();
			if (!n) return "";
			const g = (store_get($$store_subs ??= {}, "$permissionGroups", permissionGroups$1) || []).find((x) => String(x?.name || "").trim() === n);
			const dn = String(g?.displayName || "").trim();
			if (!dn || dn === n) return n;
			return `${dn} (${n})`;
		}
		sortedPermissionGroups = [...store_get($$store_subs ??= {}, "$permissionGroups", permissionGroups$1) || []].sort((a, b) => String(a?.name || "").localeCompare(String(b?.name || "")));
		$$renderer.push(`<div class="modal fade" tabindex="-1" role="dialog" aria-hidden="true"><div class="modal-dialog"><div class="modal-content"><div class="modal-header"><h5 class="modal-title">`);
		if (store_get($$store_subs ??= {}, "$isEdit", isEdit)) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.permission-groups.tracks.edit-permission-track"))}`);
		} else {
			$$renderer.push("<!--[-1-->");
			$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.permission-groups.tracks.add-permission-track"))}`);
		}
		$$renderer.push(`<!--]--></h5> <button type="button" class="btn-close"${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("buttons.close"))}></button></div> <div class="modal-body"><div class="form-floating mb-3"><input id="editTrackName" class="form-control" type="text"${attr("placeholder", store_get($$store_subs ??= {}, "$_", $format)("pages.permission-groups.tracks.form.name"))}${attr("value", store_get($$store_subs ??= {}, "$draft", draft$1).name)} maxlength="128"/> <label for="editTrackName">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.permission-groups.tracks.form.name"))}</label></div> <div class="form-floating mb-3"><textarea id="editTrackDescription" class="form-control"${attr("placeholder", store_get($$store_subs ??= {}, "$_", $format)("pages.permission-groups.tracks.form.description"))} rows="4" style="height: 140px;">`);
		const $$body = escape_html(store_get($$store_subs ??= {}, "$draft", draft$1).description);
		if ($$body) $$renderer.push(`${$$body}`);
		$$renderer.push(`</textarea> <label for="editTrackDescription">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.permission-groups.tracks.form.description"))}</label></div> <div class="mb-3"><label class="form-label" for="selectableGroups">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.permission-groups.tracks.groups.title"))}</label> <small class="d-block mb-2">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.permission-groups.tracks.groups.help"))}</small> `);
		if (store_get($$store_subs ??= {}, "$permissionGroups", permissionGroups$1).length === 0) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<small>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.permission-groups.tracks.groups.no-groups-available"))}</small>`);
		} else {
			$$renderer.push("<!--[-1-->");
			$$renderer.push(`<div id="selectableGroups" class="d-flex flex-wrap gap-2 mb-3" style="max-height: 160px; overflow-y: auto;"><!--[-->`);
			const each_array = ensure_array_like(sortedPermissionGroups.filter((g) => !(store_get($$store_subs ??= {}, "$draft", draft$1).groupNames || []).includes(g.name)));
			for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
				let group = each_array[$$index];
				$$renderer.push(`<button type="button"${attr_class(`btn btn-sm btn-secondary rounded-pill ${draggingAvailableName === group.name ? "opacity-50" : ""}`)} draggable="true"${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("pages.permission-groups.tracks.groups.drag-to-add", { values: { name: group.name } }))}${attr("title", store_get($$store_subs ??= {}, "$_", $format)("pages.permission-groups.tracks.groups.drag-to-add", { values: { name: group.name } }))}><span>${escape_html(groupLabel(group.name))}</span></button>`);
			}
			$$renderer.push(`<!--]--></div>`);
		}
		$$renderer.push(`<!--]--></div> `);
		if (store_get($$store_subs ??= {}, "$draft", draft$1).groupNames.length > 0) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<div class="mb-3"><label class="form-label" for="selectedNodes">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.permission-groups.tracks.selected.title"))}</label> <div id="selectedNodes"${attr_class("list-group ")} role="list"><!--[-->`);
			const each_array_1 = ensure_array_like(store_get($$store_subs ??= {}, "$draft", draft$1).groupNames);
			for (let idx = 0, $$length = each_array_1.length; idx < $$length; idx++) {
				let gname = each_array_1[idx];
				$$renderer.push(`<div class="list-group-item d-flex justify-content-between align-items-center" draggable="true" role="listitem"><div class="d-flex align-items-center overflow-hidden"><span class="me-2" style="cursor: grab;">≡</span> <span class="badge text-bg-secondary me-2 rounded-pill">${escape_html(idx + 1)}</span> <span class="text-truncate">${escape_html(groupLabel(gname))}</span></div> <button type="button" class="btn-close"${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("buttons.remove"))}${attr("title", store_get($$store_subs ??= {}, "$_", $format)("buttons.remove"))}></button></div> `);
				if (idx < store_get($$store_subs ??= {}, "$draft", draft$1).groupNames.length - 1) {
					$$renderer.push("<!--[0-->");
					$$renderer.push(`<div class="text-center"><i class="fa fa-arrow-down fa-fw"></i></div>`);
				} else $$renderer.push("<!--[-1-->");
				$$renderer.push(`<!--]-->`);
			}
			$$renderer.push(`<!--]--></div></div>`);
		} else {
			$$renderer.push("<!--[-1-->");
			$$renderer.push(`<div${attr_class("p-3 border rounded ")} role="region"${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("pages.permission-groups.tracks.selected.dropzone-aria"))}>`);
			NoContent($$renderer, {});
			$$renderer.push(`<!----></div>`);
		}
		$$renderer.push(`<!--]--></div> <div class="modal-footer">`);
		if (store_get($$store_subs ??= {}, "$isEdit", isEdit)) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<button type="button" class="btn btn-primary w-100">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.save"))}</button>`);
		} else {
			$$renderer.push("<!--[-1-->");
			$$renderer.push(`<button type="button" class="btn btn-secondary w-100">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.add"))}</button>`);
		}
		$$renderer.push(`<!--]--></div></div></div></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
	});
}
var node = writable(null);
var permissionGroups = writable([]);
var siblingNodes = writable([]);
var evaluationNodes = writable([]);
var evaluationUserId = writable(null);
var registeredPermissions = writable({});
var draft = writable({
	nodeValue: "",
	active: true,
	expiryType: "never",
	expiryDate: "",
	contexts: []
});
var isAddMode = writable(false);
function EditPermissionNodeModal($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let permsMap, panelNodes, nodeQuery, draftTrim, holderNodeSelfId, otherHolderNodes, duplicateNodeOnHolder, showDuplicateRowBanner, permEvalCtx, rawUserEffectiveBanner, userEffectiveBannerInsight, duplicateBlocksSave, suggestions;
		const LP_META_EDGE_PREFIXES = [
			"group.",
			"weight.",
			"displayname."
		];
		function evalSameHolderId(a, b) {
			if (a == null || b == null) return false;
			return String(a) === String(b);
		}
		function evalAssignableLuckNode(nodeStr) {
			const s = String(nodeStr || "").trim();
			if (!s) return false;
			return !LP_META_EDGE_PREFIXES.some((pre) => s.startsWith(pre));
		}
		/** Lightweight LP-style implication: equality, trailing .*, or * */
		function evalNodeImplies(candidateNodeStr, desiredPermTrim) {
			const c = String(candidateNodeStr || "").trim();
			const req = String(desiredPermTrim || "").trim();
			if (!c || !req) return false;
			if (c === req) return true;
			if (c === "*") return true;
			if (c.endsWith(".*")) {
				const base = c.slice(0, -2);
				return req === base || req.startsWith(`${base}.`);
			}
			return false;
		}
		function evalGroupIdByName(allGroups, name) {
			return (allGroups || []).find((x) => x?.name === name)?.id ?? null;
		}
		/** Transitive inheritance: USER-held group.<name> + GROUP-held group.<parent> edges */
		function evalExpandedGroupNames(userId, allNodes, allGroups) {
			const queue = [];
			const seen = /* @__PURE__ */ new Set();
			for (const n of allNodes || []) {
				if (n?.holderType !== "USER" || !evalSameHolderId(n?.holderId, userId)) continue;
				if (n.active === false) continue;
				if (typeof n.node !== "string" || !n.node.startsWith("group.")) continue;
				queue.push(String(n.node.slice(6) || "").trim());
			}
			while (queue.length) {
				const name = queue.pop();
				if (!name || seen.has(name)) continue;
				seen.add(name);
				const gid = evalGroupIdByName(allGroups, name);
				if (gid == null) continue;
				for (const n of allNodes || []) {
					if (n?.holderType !== "GROUP" || !evalSameHolderId(n?.holderId, gid)) continue;
					if (n.active === false) continue;
					if (typeof n.node !== "string" || !n.node.startsWith("group.")) continue;
					const pname = String(n.node.slice(6) || "").trim();
					if (pname && !seen.has(pname)) queue.push(pname);
				}
			}
			return seen;
		}
		function evalIndirectGrantFromGroups(expandedGroupNames, permTrim, allNodes, allGroups) {
			const trimmed = String(permTrim || "").trim();
			if (!trimmed || !(expandedGroupNames instanceof Set) || expandedGroupNames.size === 0) return false;
			for (const gName of expandedGroupNames) {
				const gid = evalGroupIdByName(allGroups, gName);
				if (gid == null) continue;
				for (const n of allNodes || []) {
					if (n?.holderType !== "GROUP" || !evalSameHolderId(n?.holderId, gid)) continue;
					if (n.active === false) continue;
					if (!evalAssignableLuckNode(n.node)) continue;
					if (evalNodeImplies(n.node, trimmed)) return true;
				}
			}
			return false;
		}
		/**
		* @param excludeDirectRowId — skip this USER-held permission row id (currently edited modal row)
		*/
		function analyzeUserEffective(userId, permTrim, allNodes, allGroups, excludeDirectRowId = null) {
			const trimmed = String(permTrim || "").trim();
			if (!trimmed || userId == null) return {
				hasDirect: false,
				hasIndirect: false
			};
			let hasDirect = false;
			for (const n of allNodes || []) {
				if (n?.holderType !== "USER" || !evalSameHolderId(n?.holderId, userId)) continue;
				if (n.active === false) continue;
				if (!evalAssignableLuckNode(n.node)) continue;
				if (!evalNodeImplies(n.node, trimmed)) continue;
				if (excludeDirectRowId != null && evalSameHolderId(n.id, excludeDirectRowId)) continue;
				hasDirect = true;
				break;
			}
			const hasIndirect = evalIndirectGrantFromGroups(evalExpandedGroupNames(userId, allNodes, allGroups), trimmed, allNodes, allGroups);
			return {
				hasDirect,
				hasIndirect
			};
		}
		function effectiveBannerLabel(ins) {
			if (!ins) return "";
			if (ins.hasDirect && ins.hasIndirect) return store_get($$store_subs ??= {}, "$_", $format)("components.modals.edit-permission-node.user-already-has-both-banner");
			if (ins.hasDirect) return store_get($$store_subs ??= {}, "$_", $format)("components.modals.edit-permission-node.user-already-has-direct-banner");
			if (ins.hasIndirect) return store_get($$store_subs ??= {}, "$_", $format)("components.modals.edit-permission-node.user-already-has-indirect-banner");
			return "";
		}
		permsMap = store_get($$store_subs ??= {}, "$registeredPermissions", registeredPermissions) || {};
		panelNodes = (permsMap.platform || []).map((p) => {
			const title = store_get($$store_subs ??= {}, "$_", $format)(`permissions.${p.key}.title`);
			const desc = store_get($$store_subs ??= {}, "$_", $format)(`permissions.${p.key}.description`);
			const node = p.node || "";
			const permKey = p.key || "";
			return {
				key: `PLATFORM:${node}`,
				permKey,
				node,
				icon: p.icon,
				title,
				desc,
				searchString: `${node} ${permKey} ${title} ${desc}`.toLowerCase(),
				type: "panel"
			};
		});
		Object.entries(permsMap).flatMap(([pluginId, perms]) => {
			if (pluginId === "platform") return [];
			const pluginTitle = store_get($$store_subs ??= {}, "$_", $format)(`plugins.${pluginId}.title`);
			return (perms || []).map((p) => {
				const title = store_get($$store_subs ??= {}, "$_", $format)(`plugins.${pluginId}.permissions.${p.key}.title`);
				const desc = store_get($$store_subs ??= {}, "$_", $format)(`plugins.${pluginId}.permissions.${p.key}.description`);
				const node = p.node || "";
				const permKey = p.key || "";
				return {
					key: `PLUGIN:${pluginId}:${node}`,
					permKey,
					node,
					icon: p.icon,
					title,
					desc,
					pluginId,
					pluginTitle,
					searchString: `${node} ${permKey} ${title} ${desc} ${pluginId} ${pluginTitle}`.toLowerCase(),
					type: "plugin"
				};
			});
		});
		panelNodes.length === 0 && Object.keys(store_get($$store_subs ??= {}, "$dictionary", $dictionary)[store_get($$store_subs ??= {}, "$locale", $locale)]?.permissions || {}).map((key) => {
			const title = store_get($$store_subs ??= {}, "$_", $format)(`permissions.${key}.title`);
			const desc = store_get($$store_subs ??= {}, "$_", $format)(`permissions.${key}.description`);
			const node = `pano.panel.${key.toLowerCase().replaceAll("_", ".")}`;
			return {
				key: `FALLBACK:${key}`,
				permKey: key,
				node,
				title,
				desc,
				searchString: `${node} ${key} ${title} ${desc}`.toLowerCase(),
				type: "panel"
			};
		});
		(store_get($$store_subs ??= {}, "$permissionGroups", permissionGroups) || []).map((g) => {
			const title = g.displayName || g.name;
			const desc = `(${g.name})`;
			const node = `group.${g.name}`;
			return {
				key: `GROUP:${g.name}`,
				node,
				title,
				desc,
				searchString: `${node} ${title} ${desc} group`.toLowerCase(),
				type: "group"
			};
		});
		nodeQuery = (store_get($$store_subs ??= {}, "$draft", draft)?.nodeValue || "").trim().toLowerCase();
		draftTrim = String(store_get($$store_subs ??= {}, "$draft", draft)?.nodeValue || "").trim();
		holderNodeSelfId = store_get($$store_subs ??= {}, "$node", node)?.id;
		otherHolderNodes = (store_get($$store_subs ??= {}, "$siblingNodes", siblingNodes) || []).filter((sn) => !(holderNodeSelfId != null && String(sn?.id ?? "") === String(holderNodeSelfId)));
		duplicateNodeOnHolder = !!draftTrim && otherHolderNodes.some((sn) => sn?.active !== false && typeof sn?.node === "string" && String(sn.node).trim() === draftTrim);
		showDuplicateRowBanner = duplicateNodeOnHolder;
		permEvalCtx = {
			uid: store_get($$store_subs ??= {}, "$evaluationUserId", evaluationUserId),
			nodes: store_get($$store_subs ??= {}, "$evaluationNodes", evaluationNodes) ?? [],
			groups: store_get($$store_subs ??= {}, "$permissionGroups", permissionGroups) ?? []
		};
		rawUserEffectiveBanner = !store_get($$store_subs ??= {}, "$node", node) || permEvalCtx.uid == null || !draftTrim || duplicateNodeOnHolder ? null : analyzeUserEffective(permEvalCtx.uid, draftTrim, permEvalCtx.nodes, permEvalCtx.groups, holderNodeSelfId ?? null);
		userEffectiveBannerInsight = rawUserEffectiveBanner && (rawUserEffectiveBanner.hasDirect || rawUserEffectiveBanner.hasIndirect) ? rawUserEffectiveBanner : null;
		duplicateBlocksSave = duplicateNodeOnHolder;
		new Set(otherHolderNodes.filter((sn) => sn?.active !== false && typeof sn?.node === "string").map((sn) => String(sn.node).trim()).filter(Boolean));
		suggestions = [];
		suggestions.filter((s) => {
			if (!nodeQuery) return true;
			return s.searchString.includes(nodeQuery);
		}).slice(0, 50);
		$$renderer.push(`<div class="modal fade" tabindex="-1" role="dialog" aria-hidden="true"><div class="modal-dialog"><div class="modal-content" style="overflow: visible;"><div class="modal-header"><h5 class="modal-title">${escape_html(store_get($$store_subs ??= {}, "$isAddMode", isAddMode) ? store_get($$store_subs ??= {}, "$_", $format)("components.modals.edit-permission-node.add-title") : store_get($$store_subs ??= {}, "$_", $format)("components.modals.edit-permission-node.title"))}</h5> <button type="button" class="btn-close"${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("buttons.close"))}></button></div> <div class="modal-body" style="overflow: visible;">`);
		if (!store_get($$store_subs ??= {}, "$node", node)) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<p class="mb-0">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.edit-permission-node.states.no-node-selected"))}</p>`);
		} else {
			$$renderer.push("<!--[-1-->");
			if (store_get($$store_subs ??= {}, "$draft", draft).contexts.some((ctx) => ctx.key?.trim() === "pano" && ctx.value?.toString().trim() === "true")) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<div class="alert alert-warning alert-dismissible fade show mb-3 p-2" role="alert"><i class="fa fa-info-circle me-1"></i> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.permissions.panel.nodes.pano-only-alert"))} <a${attr("href", `${stringify(PANO_WEBSITE_URL)}/docs/platform/integrations/luckperms/#%F0%9F%8C%90-pano-exclusive-permissions`)} target="_blank" class="alert-link ms-1">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.permissions.panel.nodes.pano-only-alert-link"))} <i class="fa fa-external-link-alt ms-1"></i></a></div>`);
			} else if (store_get($$store_subs ??= {}, "$draft", draft).contexts.some((ctx) => ctx.key?.trim() === "pano" && ctx.value?.toString().trim() === "false")) {
				$$renderer.push("<!--[1-->");
				$$renderer.push(`<div class="alert alert-info alert-dismissible fade show mb-3 p-2" role="alert"><i class="fa fa-info-circle me-1"></i> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.permissions.panel.nodes.game-only-alert"))} <a${attr("href", `${stringify(PANO_WEBSITE_URL)}/docs/platform/integrations/luckperms/#%F0%9F%8C%90-pano-exclusive-permissions`)} target="_blank" class="alert-link ms-1">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.permissions.panel.nodes.pano-only-alert-link"))} <i class="fa fa-external-link-alt ms-1"></i></a></div>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--> <div class="mb-3"><label class="form-label" for="nodeValue">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.edit-permission-node.form.node"))}</label> `);
			if (showDuplicateRowBanner && draftTrim) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<div class="d-flex align-items-center gap-1 small text-success mb-2 user-select-none" role="status"><i class="fa-solid fa-circle-check" aria-hidden="true"></i> <span>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.edit-permission-node.node-already-on-holder"))}</span></div>`);
			} else if (store_get($$store_subs ??= {}, "$evaluationUserId", evaluationUserId) != null && userEffectiveBannerInsight && draftTrim) {
				$$renderer.push("<!--[1-->");
				$$renderer.push(`<div class="d-flex align-items-center gap-1 small text-success mb-2 user-select-none" role="status"><i class="fa-solid fa-circle-check" aria-hidden="true"></i> <span>${escape_html(effectiveBannerLabel(userEffectiveBannerInsight))}</span></div>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--> <div class="position-relative"><input id="nodeValue" class="form-control form-control-lg font-monospace" type="text"${attr("value", store_get($$store_subs ??= {}, "$draft", draft).nodeValue)}${attr("placeholder", store_get($$store_subs ??= {}, "$_", $format)("components.modals.edit-permission-node.form.node-placeholder"))} autocomplete="off"/> `);
			$$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--></div></div> <div class="mb-3"><div class="form-check form-switch"><input id="nodeActive" class="form-check-input" type="checkbox" role="switch"${attr("checked", store_get($$store_subs ??= {}, "$draft", draft).active, true)}/> <label class="form-check-label" for="nodeActive">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.edit-permission-node.form.active"))}</label></div></div> <div class="mb-3"><label class="form-label" for="permExpiry">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.edit-permission-node.form.expiry"))}</label> <div id="permExpiry" class="btn-group w-100" role="group"${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("components.modals.edit-permission-node.form.expiry-aria"))}><input type="radio" class="btn-check" name="expiry-option-edit" id="expiry-never-edit" autocomplete="off"${attr("checked", store_get($$store_subs ??= {}, "$draft", draft).expiryType === "never", true)} value="never"/> <label class="btn btn-outline-primary" for="expiry-never-edit">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.edit-permission-node.form.expiry-never"))}</label> <input type="radio" class="btn-check" name="expiry-option-edit" id="expiry-date-edit" autocomplete="off"${attr("checked", store_get($$store_subs ??= {}, "$draft", draft).expiryType === "date", true)} value="date"/> <label class="btn btn-outline-primary" for="expiry-date-edit">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.edit-permission-node.form.expiry-date"))}</label></div> `);
			if (store_get($$store_subs ??= {}, "$draft", draft).expiryType === "date") {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<input type="datetime-local" class="form-control mt-2"${attr("value", store_get($$store_subs ??= {}, "$draft", draft).expiryDate)}/>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--></div> <div><label class="form-label" for="">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.edit-permission-node.contexts.title"))}</label> `);
			if (store_get($$store_subs ??= {}, "$draft", draft).contexts.length === 0) {
				$$renderer.push("<!--[0-->");
				NoContent($$renderer, {});
			} else {
				$$renderer.push("<!--[-1-->");
				$$renderer.push(`<!--[-->`);
				const each_array_1 = ensure_array_like(store_get($$store_subs ??= {}, "$draft", draft).contexts);
				for (let index = 0, $$length = each_array_1.length; index < $$length; index++) {
					let ctx = each_array_1[index];
					$$renderer.push(`<div class="hstack gap-2 mb-2"><div class="input-group"><input${attr_class(`form-control ${ctx.key?.trim() === "pano" && ctx.value?.toString().trim() === "true" ? "border-warning" : ctx.key?.trim() === "pano" && ctx.value?.toString().trim() === "false" ? "border-info" : ""}`)} type="text"${attr("placeholder", store_get($$store_subs ??= {}, "$_", $format)("components.modals.edit-permission-node.contexts.key-placeholder"))}${attr("value", ctx.key)}/> <input${attr_class(`form-control ${ctx.key?.trim() === "pano" && ctx.value?.toString().trim() === "true" ? "border-warning" : ctx.key?.trim() === "pano" && ctx.value?.toString().trim() === "false" ? "border-info" : ""}`)} type="text"${attr("placeholder", store_get($$store_subs ??= {}, "$_", $format)("components.modals.edit-permission-node.contexts.value-placeholder"))}${attr("value", ctx.value)}/></div> <button class="btn-close" type="button"${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("buttons.remove"))}${attr("title", store_get($$store_subs ??= {}, "$_", $format)("buttons.remove"))}></button></div>`);
				}
				$$renderer.push(`<!--]-->`);
			}
			$$renderer.push(`<!--]--> <button class="btn btn-link text-decoration-none w-100" type="button"><i class="fa fa-plus me-2"></i>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.add"))}</button></div>`);
		}
		$$renderer.push(`<!--]--></div> <div class="modal-footer">`);
		if (store_get($$store_subs ??= {}, "$isAddMode", isAddMode)) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<button type="button" class="btn btn-secondary w-100"${attr("disabled", !store_get($$store_subs ??= {}, "$node", node) || !store_get($$store_subs ??= {}, "$draft", draft).nodeValue.trim() || duplicateBlocksSave, true)}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.add"))}</button>`);
		} else {
			$$renderer.push("<!--[-1-->");
			$$renderer.push(`<button type="button" class="btn btn-primary w-100"${attr("disabled", !store_get($$store_subs ??= {}, "$node", node) || !store_get($$store_subs ??= {}, "$draft", draft).nodeValue.trim() || duplicateBlocksSave, true)}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.save"))}</button>`);
		}
		$$renderer.push(`<!--]--></div></div></div></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
	});
}
var track = writable(null);
function ConfirmRemovePermTrackModal($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let loading = false;
		$$renderer.push(`<div aria-hidden="true" class="modal fade" role="dialog" tabindex="-1"><div class="modal-dialog modal-dialog-centered" role="dialog"><div class="modal-content"><div class="modal-body text-center"><div class="pb-3"><i class="fas fa-question-circle fa-3x d-block m-auto text-gray"></i></div> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.confirm-remove-perm-track.title", { values: { trackName: store_get($$store_subs ??= {}, "$track", track)?.name || "-" } }))}</div> <div class="modal-footer flex-nowrap"><button${attr_class("btn btn-link col-6 m-0", void 0, { "disabled": loading })} type="button">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.cancel"))}</button> <button${attr_class("btn btn-danger col-6 m-0", void 0, { "disabled": loading })} type="button">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.yes"))}</button></div></div></div></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
	});
}
var group = writable(null);
var nodesStore = writable([]);
function ConfirmRemovePermGroupModal($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let isAdminGroup, totalAdminGroups, isOnlyAdminGroup;
		let loading = false;
		isAdminGroup = (store_get($$store_subs ??= {}, "$nodesStore", nodesStore) || []).some((n) => n.holderType === "GROUP" && n.holderId === store_get($$store_subs ??= {}, "$group", group)?.id && n.node === "*" && n.active !== false);
		totalAdminGroups = (store_get($$store_subs ??= {}, "$nodesStore", nodesStore) || []).filter((n) => n.holderType === "GROUP" && n.node === "*" && n.active !== false).map((n) => n.holderId).filter((v, i, a) => a.indexOf(v) === i).length;
		isOnlyAdminGroup = isAdminGroup && totalAdminGroups === 1;
		$$renderer.push(`<div aria-hidden="true" class="modal fade" role="dialog" tabindex="-1"><div class="modal-dialog modal-dialog-centered" role="dialog"><div class="modal-content"><div class="modal-body text-center"><div class="pb-3"><i${attr_class(`fas ${isAdminGroup ? "fa-exclamation-triangle text-warning" : "fa-question-circle text-gray"} fa-3x d-block m-auto`)}></i></div> <div class="mb-3">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.confirm-remove-perm-group.title", { values: { groupName: store_get($$store_subs ??= {}, "$group", group)?.displayName || store_get($$store_subs ??= {}, "$group", group)?.name || "-" } }))}</div> `);
		if (isAdminGroup) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<div${attr_class(`alert ${isOnlyAdminGroup ? "alert-danger" : "alert-warning"} py-2 small mb-0`)}><i class="fas fa-shield-alt me-2"></i> ${escape_html(isOnlyAdminGroup ? store_get($$store_subs ??= {}, "$_", $format)("pages.permissions.panel.nodes.admin-group-last-warning") : store_get($$store_subs ??= {}, "$_", $format)("pages.permissions.panel.nodes.admin-group-delete-warning"))}</div>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--></div> <div class="modal-footer flex-nowrap"><button${attr_class("btn btn-link col-6 m-0", void 0, { "disabled": loading })} type="button">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.cancel"))}</button> <button${attr_class("btn btn-danger col-6 m-0", void 0, { "disabled": loading })} type="button">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.yes"))}</button></div></div></div></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
	});
}
var user = writable(null);
function ConfirmRemovePermUserModal($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let loading = false;
		$$renderer.push(`<div aria-hidden="true" class="modal fade" role="dialog" tabindex="-1"><div class="modal-dialog modal-dialog-centered" role="dialog"><div class="modal-content"><div class="modal-body text-center"><div class="pb-3"><i class="fas fa-question-circle fa-3x d-block m-auto text-gray"></i></div> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.confirm-remove-perm-user.title", { values: { username: store_get($$store_subs ??= {}, "$user", user)?.username || "-" } }))}</div> <div class="modal-footer flex-nowrap"><button${attr_class("btn btn-link col-6 m-0", void 0, { "disabled": loading })} type="button">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.cancel"))}</button> <button${attr_class("btn btn-danger col-6 m-0", void 0, { "disabled": loading })} type="button">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.yes"))}</button></div></div></div></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
	});
}
function ConfirmResetPermissionsModal($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let loading = false;
		$$renderer.push(`<div aria-hidden="true" class="modal fade" role="dialog" tabindex="-1"><div class="modal-dialog modal-dialog-centered" role="dialog"><div class="modal-content"><div class="modal-body text-center"><div class="pb-3"><i class="fas fa-history fa-3x d-block m-auto"></i></div> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.permissions.panel.actions.confirm-reset-title"))}</div> <div class="modal-footer flex-nowrap"><button${attr_class("btn btn-link col-6 m-0", void 0, { "disabled": loading })} type="button">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.cancel"))}</button> <button${attr_class("btn btn-primary col-6 m-0", void 0, { "disabled": loading })} type="button">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.yes"))}</button></div></div></div></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
	});
}
//#endregion
//#region src/lib/pages/Permissions.svelte
async function load(event) {
	const res = await ApiUtil.get({
		path: "/api/panel/permission/snapshot",
		request: event
	});
	if (res?.error) throw error(500, res.error);
	return { snapshot: res };
}
function Permissions($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let hasChanges, newGroupIds, modifiedGroupIds, newNodeIds, modifiedNodeIds, groupIdsWithChangedNodes, newTrackIds, modifiedTrackIds, trackIdsWithChangedGroups, newUserIds, userIdsWithChangedNodes;
		let data = $$props["data"];
		const pageTitle = getContext("pageTitle");
		getContext("user");
		pageTitle.set("pages.permissions.title");
		let snapshot = JSON.parse(JSON.stringify(data?.snapshot || {}));
		let permissionGroups = snapshot.groups || [];
		let tracks = snapshot.tracks || [];
		let nodes = snapshot.nodes || [];
		let users = snapshot.users || [];
		let filteredGroups = permissionGroups;
		let filteredTracks = tracks;
		let filteredUsers = users;
		let currentNodes = [];
		beforeNavigate((navigation) => {
			if (hasChanges) {
				if (!confirm(store_get($$store_subs ??= {}, "$_", $format)("pages.translations.unsaved-changes-alert-text"))) navigation.cancel();
			}
		});
		function listStyle(maxHeight) {
			return `max-height: ${maxHeight}px; overflow-y: auto;`;
		}
		let globalSearchQuery = "";
		function getGroupWeight(group, currentNodesList) {
			if (!group) return 0;
			const weightNodes = (currentNodesList || []).filter((n) => n.holderType === "GROUP" && n.holderId === group.id && n.active !== false && typeof n.node === "string" && n.node.startsWith("weight."));
			if (weightNodes.length === 0) return 0;
			const weights = weightNodes.map((n) => parseInt(n.node.slice(7))).filter((w) => !isNaN(w));
			return weights.length > 0 ? Math.max(...weights) : 0;
		}
		function refreshCurrentNodes() {
			currentNodes = [];
		}
		const norm = (v) => String(v || "").toLocaleLowerCase(store_get($$store_subs ??= {}, "$currentLanguage", currentLanguage)?.code);
		function nodeSearchText(n) {
			if (!n || typeof n !== "object") return "";
			const parts = [
				n.holderType,
				n.holderName,
				n.node,
				n.context ? JSON.stringify(n.context) : ""
			];
			return norm(parts.filter(Boolean).join(" "));
		}
		function nodeMatchesQuery(n, q) {
			if (!q) return true;
			return nodeSearchText(n).includes(q);
		}
		const sortGroups = (gs, currentNodesList) => [...gs || []].sort((a, b) => getGroupWeight(b, currentNodesList) - getGroupWeight(a, currentNodesList) || String(a?.name ?? "").localeCompare(String(b?.name ?? ""), void 0, { sensitivity: "base" }));
		store_get($$store_subs ??= {}, "$_", $format)("buttons.edit"), store_get($$store_subs ??= {}, "$_", $format)("buttons.delete");
		hasChanges = (function() {
			const normalize = (gs, ts, ns) => {
				const sortedGroups = [...gs || []].map((g) => ({
					name: g.name,
					displayName: g.displayName || g.name
				})).sort((a, b) => a.name.localeCompare(b.name));
				const sortedTracks = [...ts || []].map((t) => ({
					name: t.name,
					description: t.description || "",
					groupNames: [...t.groupNames || []]
				})).sort((a, b) => a.name.localeCompare(b.name));
				const sortedNodes = [...ns || []].filter((n) => {
					if (n.holderType === "USER" && n.node === "group.default" && (n.active === true || n.active === void 0)) return false;
					return true;
				}).map((n) => {
					const ctx = n.context || {};
					const sortedCtx = Object.keys(ctx).sort().reduce((acc, key) => {
						acc[key] = ctx[key];
						return acc;
					}, {});
					return {
						holderType: n.holderType,
						holderKey: n.holderType === "GROUP" ? n.holderName : n.holderId,
						node: n.node,
						active: n.active !== false,
						context: JSON.stringify(sortedCtx),
						expiresAt: n.expiresAt || null
					};
				}).sort((a, b) => {
					const keyA = `${a.holderType}:${a.holderKey}:${a.node}:${a.active}:${a.context}`;
					const keyB = `${b.holderType}:${b.holderKey}:${b.node}:${b.active}:${b.context}`;
					return keyA.localeCompare(keyB);
				});
				return JSON.stringify({
					groups: sortedGroups,
					tracks: sortedTracks,
					nodes: sortedNodes
				});
			};
			return normalize(permissionGroups, tracks, nodes) !== normalize(snapshot.groups, snapshot.tracks, snapshot.nodes);
		})();
		newGroupIds = new Set((permissionGroups || []).filter((g) => g.id && !snapshot.groups?.some((og) => String(og.id) === String(g.id))).map((g) => String(g.id)));
		modifiedGroupIds = new Set((permissionGroups || []).filter((g) => {
			if (!g.id) return false;
			const og = snapshot.groups?.find((x) => String(x.id) === String(g.id));
			return og && (og.name !== g.name || og.displayName !== g.displayName);
		}).map((g) => String(g.id)));
		newNodeIds = new Set((nodes || []).filter((n) => n.id && !snapshot.nodes?.some((on) => String(on.id) === String(n.id))).map((n) => String(n.id)));
		modifiedNodeIds = new Set((nodes || []).filter((n) => {
			if (!n.id) return false;
			const on = snapshot.nodes?.find((x) => String(x.id) === String(n.id));
			return on && (on.node !== n.node || on.active !== n.active || on.expiresAt !== n.expiresAt || JSON.stringify(on.context || {}) !== JSON.stringify(n.context || {}));
		}).map((n) => String(n.id)));
		groupIdsWithChangedNodes = new Set((permissionGroups || []).filter((g) => {
			const gid = String(g.id);
			const hasNew = (nodes || []).some((n) => n.holderType === "GROUP" && String(n.holderId) === gid && newNodeIds.has(String(n.id)));
			const hasModified = (nodes || []).some((n) => n.holderType === "GROUP" && String(n.holderId) === gid && modifiedNodeIds.has(String(n.id)));
			const hasRemoved = (snapshot.nodes || []).some((sn) => sn.holderType === "GROUP" && String(sn.holderId) === gid && !(nodes || []).some((n) => String(n.id) === String(sn.id)));
			return hasNew || hasModified || hasRemoved;
		}).map((g) => String(g.id)));
		newTrackIds = new Set((tracks || []).filter((t) => t.id && !snapshot.tracks?.some((ot) => String(ot.id) === String(t.id))).map((t) => String(t.id)));
		modifiedTrackIds = new Set((tracks || []).filter((t) => {
			if (!t.id) return false;
			const ot = snapshot.tracks?.find((x) => String(x.id) === String(t.id));
			return ot && (norm(ot.name) !== norm(t.name) || (ot.description || "") !== (t.description || ""));
		}).map((t) => String(t.id)));
		trackIdsWithChangedGroups = new Set((tracks || []).filter((t) => {
			if (!t.id) return false;
			const ot = snapshot.tracks?.find((x) => String(x.id) === String(t.id));
			if (!ot) return false;
			return JSON.stringify(Array.isArray(ot.groupNames) ? ot.groupNames : []) !== JSON.stringify(Array.isArray(t.groupNames) ? t.groupNames : []);
		}).map((t) => String(t.id)));
		newUserIds = new Set((users || []).filter((u) => u.id && !snapshot.users?.some((ou) => String(ou.id) === String(u.id))).map((u) => String(u.id)));
		userIdsWithChangedNodes = new Set((users || []).filter((u) => {
			const uid = String(u.id);
			const hasNew = (nodes || []).some((n) => n.holderType === "USER" && String(n.holderId) === uid && newNodeIds.has(String(n.id)));
			const hasModified = (nodes || []).some((n) => n.holderType === "USER" && String(n.holderId) === uid && modifiedNodeIds.has(String(n.id)));
			const hasRemoved = (snapshot.nodes || []).some((sn) => sn.holderType === "USER" && String(sn.holderId) === uid && !(nodes || []).some((n) => String(n.id) === String(sn.id)));
			return hasNew || hasModified || hasRemoved;
		}).map((u) => String(u.id)));
		{
			const q = norm(globalSearchQuery);
			const hasQ = !!q;
			const groupDisplayByName = new Map((permissionGroups || []).map((g) => [String(g?.name || "").trim(), norm(g?.displayName || g?.name)]));
			filteredGroups = sortGroups(hasQ ? (permissionGroups || []).filter((g) => {
				const gid = g?.id;
				if (`${norm(g?.name)} ${norm(g?.displayName)}`.includes(q)) return true;
				if (gid == null) return false;
				return (nodes || []).some((n) => n?.holderType === "GROUP" && n?.holderId === gid && nodeMatchesQuery(n, q));
			}) : permissionGroups, nodes);
			filteredTracks = hasQ ? (tracks || []).filter((t) => {
				if (`${norm(t?.name)} ${norm(t?.description)}`.includes(q)) return true;
				if (!Array.isArray(t?.groupNames) || t.groupNames.length === 0) return false;
				return t.groupNames.some((gn) => {
					const name = String(gn || "").trim();
					if (!name) return false;
					if (norm(name).includes(q)) return true;
					const display = groupDisplayByName.get(name) || "";
					return !!display && display.includes(q);
				});
			}) : tracks || [];
			filteredUsers = hasQ ? (users || []).filter((u) => {
				const uid = u?.id;
				if (norm(u?.username).includes(q)) return true;
				if (Array.isArray(u?.groups) && u.groups.some((g) => norm(g).includes(q))) return true;
				if (uid == null) return false;
				return (nodes || []).some((n) => n?.holderType === "USER" && n?.holderId === uid && nodeMatchesQuery(n, q));
			}) : users || [];
			refreshCurrentNodes();
			hasQ && (currentNodes || []).filter((n) => nodeMatchesQuery(n, q));
		}
		$$renderer.push(`<div class="container vstack gap-3">`);
		$$renderer.push("<!--[0-->");
		$$renderer.push(`<div class="alert alert-info d-flex align-items-center mb-0 alert-dismissible" role="alert"><i class="fas fa-info-circle me-3"></i> <div>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.permissions.panel.luckperms-alert"))} <a${attr("href", `${stringify(PANO_WEBSITE_URL)}/docs/platform/integrations/luckperms`)} target="_blank" class="alert-link ms-1">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.permissions.panel.nodes.pano-only-alert-link"))} <i class="fas fa-external-link-alt ms-1"></i></a></div> <button type="button" class="btn-close"${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("buttons.close"))}></button></div>`);
		$$renderer.push(`<!--]--> `);
		PageActions($$renderer, {
			leftClasses: "d-lg-flex d-none",
			$$slots: {
				middle: ($$renderer) => {
					$$renderer.push(`<div slot="middle" class="hstack gap-2">`);
					SearchInput($$renderer, {
						showSpinner: false,
						placeholderKey: "pages.permissions.panel.search.placeholder",
						ariaLabelKey: "pages.permissions.panel.search.placeholder",
						debounceMs: 250
					});
					$$renderer.push(`<!----></div>`);
				},
				right: ($$renderer) => {
					$$renderer.push(`<div slot="right" class="hstack gap-2"><button type="button"${attr("title", store_get($$store_subs ??= {}, "$_", $format)("buttons.reset"))}${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("buttons.reset"))} class="btn btn-link"${attr("disabled", !hasChanges, true)}><i class="fa fa-undo"></i></button> `);
					$$renderer.push("<!--[-1-->");
					$$renderer.push(`<!--]--> <button type="button"${attr("title", store_get($$store_subs ??= {}, "$_", $format)("buttons.save"))}${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("buttons.save"))} class="btn btn-secondary"${attr("disabled", !hasChanges, true)}><i class="fa fa-save"></i> <span class="d-lg-inline d-none ms-1">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.save"))}</span></button></div>`);
				}
			}
		});
		$$renderer.push(`<!----> <div class="row g-3"><div class="col-lg-4"><div class="accordion" id="leftAccordion"><div class="accordion-item" role="button" tabindex="0"><h2 class="accordion-header" id="tracksHeading"><button${attr_class(`accordion-button collapsed`)} type="button" aria-controls="tracksCollapse"><span class="me-2">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.permissions.panel.accordions.tracks"))}</span></button></h2> <div id="tracksCollapse" class="accordion-collapse collapse" aria-labelledby="tracksHeading" data-bs-parent="#leftAccordion"><div class="accordion-body p-0"><div${attr_style(listStyle(260))}>`);
		if (Array.isArray(filteredTracks) && filteredTracks.length > 0) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<div class="accordion accordion-flush" id="tracksListAccordion"><!--[-->`);
			const each_array = ensure_array_like(filteredTracks);
			for (let $$index_1 = 0, $$length = each_array.length; $$index_1 < $$length; $$index_1++) {
				let track = each_array[$$index_1];
				$$renderer.push(`<div class="accordion-item"><h2 class="accordion-header"${attr("id", "trackHeading-" + (track.id ?? track.name))}><button type="button"${attr_class(`accordion-button collapsed py-2 ${newTrackIds.has(String(track.id)) ? "indicator-added" : trackIdsWithChangedGroups.has(String(track.id)) ? "indicator-modified" : ""}`)} data-bs-toggle="collapse"${attr("data-bs-target", "#trackCollapse-" + (track.id ?? track.name))}${attr("aria-controls", "trackCollapse-" + (track.id ?? track.name))}><div class="d-flex flex-column text-start w-100"><div${attr_class(`text-truncate ${newTrackIds.has(String(track.id)) ? "text-added" : modifiedTrackIds.has(String(track.id)) || trackIdsWithChangedGroups.has(String(track.id)) ? "text-modified" : ""}`)}>${escape_html(track.name)}</div> <small class="text-truncate">${escape_html(track.description)}</small></div></button></h2> <div${attr("id", "trackCollapse-" + (track.id ?? track.name))} class="accordion-collapse collapse"${attr("aria-labelledby", "trackHeading-" + (track.id ?? track.name))} data-bs-parent="#tracksListAccordion"><div class="accordion-body py-2">`);
				if (Array.isArray(track.groupNames) && track.groupNames.length > 0) {
					$$renderer.push("<!--[0-->");
					$$renderer.push(`<div class="list-group list-group-flush"><!--[-->`);
					const each_array_1 = ensure_array_like(track.groupNames);
					for (let $$index = 0, $$length = each_array_1.length; $$index < $$length; $$index++) {
						let gname = each_array_1[$$index];
						$$renderer.push(`<button type="button" class="list-group-item list-group-item-action py-1"${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("pages.permissions.panel.actions.go-to-group", { values: { name: gname } }))}${attr("title", store_get($$store_subs ??= {}, "$_", $format)("pages.permissions.panel.actions.go-to-group", { values: { name: gname } }))}>${escape_html(gname)}</button>`);
					}
					$$renderer.push(`<!--]--></div>`);
				} else {
					$$renderer.push("<!--[-1-->");
					NoContent($$renderer, {});
				}
				$$renderer.push(`<!--]--></div></div></div>`);
			}
			$$renderer.push(`<!--]--></div>`);
		} else {
			$$renderer.push("<!--[-1-->");
			NoContent($$renderer, {});
		}
		$$renderer.push(`<!--]--></div></div></div></div> <div class="accordion-item" role="button" tabindex="0"><h2 class="accordion-header" id="groupsHeading"><button${attr_class(`accordion-button collapsed`)} type="button" aria-controls="groupsCollapse"><span class="me-2">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.permissions.panel.accordions.groups"))}</span></button></h2> <div id="groupsCollapse" class="accordion-collapse collapse" aria-labelledby="groupsHeading" data-bs-parent="#leftAccordion"><div class="accordion-body p-0">`);
		if (Array.isArray(filteredGroups) && filteredGroups.length > 0) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<div class="list-group list-group-flush"${attr_style(listStyle(320))}><!--[-->`);
			const each_array_2 = ensure_array_like(filteredGroups);
			for (let $$index_2 = 0, $$length = each_array_2.length; $$index_2 < $$length; $$index_2++) {
				let group = each_array_2[$$index_2];
				$$renderer.push(`<button type="button"${attr_class(`list-group-item list-group-item-action d-flex justify-content-between align-items-center  ${newGroupIds.has(String(group.id)) ? "indicator-added" : groupIdsWithChangedNodes.has(String(group.id)) ? "indicator-modified" : ""}`)}><div><div${attr_class(`fw-normal ${newGroupIds.has(String(group.id)) ? "text-added" : modifiedGroupIds.has(String(group.id)) ? "text-modified" : ""}`)}>${escape_html(group.displayName)}</div> <small class="font-monospace">(${escape_html(group.name)})</small></div> <span class="badge bg-primary">${escape_html(getGroupWeight(group, nodes))}</span></button>`);
			}
			$$renderer.push(`<!--]--></div>`);
		} else {
			$$renderer.push("<!--[-1-->");
			$$renderer.push(`<div${attr_style(listStyle(320))}>`);
			NoContent($$renderer, {});
			$$renderer.push(`<!----></div>`);
		}
		$$renderer.push(`<!--]--></div></div></div> <div class="accordion-item" role="button" tabindex="0"><h2 class="accordion-header" id="usersHeading"><button${attr_class(`accordion-button collapsed`)} type="button" aria-controls="usersCollapse"><span class="me-2">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.permissions.panel.accordions.users"))}</span></button></h2> <div id="usersCollapse" class="accordion-collapse collapse" aria-labelledby="usersHeading" data-bs-parent="#leftAccordion"><div class="accordion-body p-0">`);
		if (Array.isArray(filteredUsers) && filteredUsers.length > 0) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<div class="list-group list-group-flush"${attr_style(listStyle(320))}><!--[-->`);
			const each_array_3 = ensure_array_like(filteredUsers);
			for (let i = 0, $$length = each_array_3.length; i < $$length; i++) {
				let user = each_array_3[i];
				$$renderer.push(`<div${attr_class(`list-group-item d-flex justify-content-between align-items-center  ${newUserIds.has(String(user.id)) ? "indicator-added" : userIdsWithChangedNodes.has(String(user.id)) ? "indicator-modified" : ""} ${i === filteredUsers.length - 1 ? "rounded-bottom" : ""}`)} role="button" tabindex="0"><div class="me-2 d-flex align-items-center overflow-hidden">`);
				if (user.username) {
					$$renderer.push("<!--[0-->");
					$$renderer.push(`<img${attr("src", `/api/profile/picture/${encodeURIComponent(user.username)}?${store_get($$store_subs ??= {}, "$avatarVersion", avatarVersion)}`)}${attr("alt", `${user.username}`)} width="24" height="24" class="rounded me-2 flex-shrink-0" loading="lazy"/>`);
				} else $$renderer.push("<!--[-1-->");
				$$renderer.push(`<!--]--> <div class="overflow-hidden"><div class="fw-bold text-truncate">${escape_html(user.username)}</div></div></div></div>`);
			}
			$$renderer.push(`<!--]--></div>`);
		} else {
			$$renderer.push("<!--[-1-->");
			$$renderer.push(`<div${attr_style(listStyle(320))} class="rounded-bottom">`);
			NoContent($$renderer, {});
			$$renderer.push(`<!----></div>`);
		}
		$$renderer.push(`<!--]--></div></div></div></div></div> <div class="col-lg-8">`);
		$$renderer.push("<!--[-1-->");
		$$renderer.push(`<div class="card d-flex align-items center justify-content-center h-100">`);
		NoContent($$renderer, { text: store_get($$store_subs ??= {}, "$_", $format)("pages.permissions.panel.empty.select-something") });
		$$renderer.push(`<!----></div>`);
		$$renderer.push(`<!--]--></div></div></div> `);
		CreatePermissionGroupModal($$renderer);
		$$renderer.push(`<!----> `);
		EditPermissionNodeModal($$renderer);
		$$renderer.push(`<!----> `);
		SearchPlayerModal($$renderer);
		$$renderer.push(`<!----> `);
		EditPermTrackModal($$renderer);
		$$renderer.push(`<!----> `);
		ConfirmRemovePermTrackModal($$renderer);
		$$renderer.push(`<!----> `);
		ConfirmRemovePermGroupModal($$renderer);
		$$renderer.push(`<!----> `);
		ConfirmRemovePermUserModal($$renderer);
		$$renderer.push(`<!----> `);
		ConfirmResetPermissionsModal($$renderer);
		$$renderer.push(`<!---->`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
		bind_props($$props, { data });
	});
}

export { Permissions as P, load as l };
//# sourceMappingURL=Permissions.js-B84fdrLw.js.map
