import { J as getContext, Q as store_get, S as unsubscribe_stores, O as bind_props, T as attr, Z as escape_html, P as ensure_array_like, X as html, V as attr_class, F as writable, y as derived } from './index-server.js-DdhL7Abu.js';
import './stores.js-D5xmrOAP.js';
import './server.js-BlClO2ED.js';
import './internal2.js-CNe5OZUJ.js';
import './routing.js-N-OPb2ye.js';
import { b as ApiUtil, e as buildQueryParams } from './Store.js-DT3aZHRb.js';
import { $ as $format } from './runtime.js-BzHEw_ze.js';
import './ToastContainer.js-Bv1jJ2dr.js';
import { D as Date_1 } from './Date.js-DCZp_jrB.js';
import { L as Languages } from './language.util.js-ByanOnuS.js';
import { N as NoContent } from './NoContent.js-Coj2fA9d.js';
import { P as Pagination } from './Pagination.js-sd1xTcbW.js';
import { P as PageActions } from './PageActions.js-co-RIHDp.js';
import { a as ConfirmSaveCriticalSettingsModal, C as ConfirmRestartPanoModal } from './ConfirmSaveCriticalSettingsModal.js-Coj5M9TO.js';

function ConfirmRemovePanoAccountModal($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let loading = false;
		$$renderer.push(`<div aria-hidden="true" class="modal fade" role="dialog" tabindex="-1"><div class="modal-dialog modal-dialog-centered" role="dialog"><div class="modal-content"><div class="modal-body text-center"><div class="pb-3"><i class="fas fa-question-circle fa-3x d-block m-auto text-gray"></i></div> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.confirm-remove-pano-account.title"))}</div> <div class="modal-footer flex-nowrap"><button${attr_class("btn btn-link col-6 m-0", void 0, { "disabled": loading })} type="button">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.cancel"))}</button> <button${attr_class("btn btn-danger col-6 m-0", void 0, { "disabled": loading })} type="button">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.yes"))}</button></div></div></div></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
	});
}
function ConfirmDisableEmailModal($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let loading = false;
		$$renderer.push(`<div aria-hidden="true" class="modal fade" role="dialog" tabindex="-1"><div class="modal-dialog modal-dialog-centered" role="dialog"><div class="modal-content"><div class="modal-body text-center"><div class="pb-3"><i class="fas fa-question-circle fa-3x d-block m-auto text-gray"></i></div> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.confirm-disable-email.title"))}</div> <div class="modal-footer flex-nowrap"><button${attr_class("btn btn-link col-6 m-0", void 0, { "disabled": loading })} type="button">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.cancel"))}</button> <button${attr_class("btn btn-danger col-6 m-0", void 0, { "disabled": loading })} type="button">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.yes"))}</button></div></div></div></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
	});
}
var loading$1 = writable(false);
var passwordError = writable(false);
var password = writable("");
function ConfirmStopPanoModal($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let confirmButtonDisabled;
		confirmButtonDisabled = store_get($$store_subs ??= {}, "$password", password).length === 0;
		$$renderer.push(`<div aria-hidden="true" class="modal fade" role="dialog" tabindex="-1"><div class="modal-dialog modal-dialog-centered" role="dialog"><div class="modal-content"><form><div class="modal-body text-center"><div class="pb-3"><i class="fas fa-stop-circle fa-3x d-block m-auto text-gray"></i></div> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.confirm-stop-pano.title"))} <input${attr_class("form-control mt-3", void 0, { "border-danger": store_get($$store_subs ??= {}, "$passwordError", passwordError) })}${attr("placeholder", store_get($$store_subs ??= {}, "$_", $format)("components.modals.confirm-stop-pano.account-password"))} type="password"${attr("value", store_get($$store_subs ??= {}, "$password", password))}/></div> <div class="modal-footer flex-nowrap"><button class="btn btn-link col-6 m-0" type="button"${attr("disabled", store_get($$store_subs ??= {}, "$loading", loading$1), true)}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.cancel"))}</button> <button class="btn btn-danger col-6 m-0" type="button"${attr("disabled", confirmButtonDisabled || store_get($$store_subs ??= {}, "$loading", loading$1), true)}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.yes"))} `);
		if (store_get($$store_subs ??= {}, "$loading", loading$1)) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<i class="fa-solid fa-spinner fa-spin"></i>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--></button></div></form></div></div></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
	});
}
//#endregion
//#region src/lib/components/modals/EditMaintenancePageModal.svelte
var TABS = [
	{
		key: "PAGE",
		label: "pages.settings.platform.maintenance.modal.tab-page",
		hint: "pages.settings.platform.maintenance.modal.hint-page"
	},
	{
		key: "LOGIN_FORM",
		label: "pages.settings.platform.maintenance.modal.tab-login-form",
		hint: "pages.settings.platform.maintenance.modal.hint-login-form"
	},
	{
		key: "LOGIN_BUTTON",
		label: "pages.settings.platform.maintenance.modal.tab-login-button",
		hint: "pages.settings.platform.maintenance.modal.hint-login-button"
	},
	{
		key: "SKIP",
		label: "pages.settings.platform.maintenance.modal.tab-skip",
		hint: "pages.settings.platform.maintenance.modal.hint-skip"
	},
	{
		key: "NOTICE",
		label: "pages.settings.platform.maintenance.modal.tab-notice",
		hint: "pages.settings.platform.maintenance.modal.hint-notice"
	}
];
var templates = writable({});
var activeTab = writable(TABS[0].key);
var previewHtml = writable("");
var previewLoading$1 = writable(false);
var busy = writable(false);
function EditMaintenancePageModal($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		const activeTabMeta = derived(() => TABS.find((tab) => tab.key === store_get($$store_subs ??= {}, "$activeTab", activeTab)) ?? TABS[0]);
		$$renderer.push(`<div aria-hidden="true" class="modal fade" role="dialog" tabindex="-1"><div class="modal-dialog modal-xl modal-dialog-centered modal-dialog-scrollable" role="dialog"><div class="modal-content"><div class="modal-header"><h5 class="modal-title">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.platform.maintenance.modal.title"))}</h5> <button${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("buttons.close"))} type="button" class="btn-close" data-bs-dismiss="modal"></button></div> <div class="modal-body"><ul class="nav nav-pills mb-3 flex-wrap"><!--[-->`);
		const each_array = ensure_array_like(TABS);
		for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
			let tab = each_array[$$index];
			$$renderer.push(`<li class="nav-item"><button type="button"${attr_class("nav-link", void 0, { "active": store_get($$store_subs ??= {}, "$activeTab", activeTab) === tab.key })}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)(tab.label))}</button></li>`);
		}
		$$renderer.push(`<!--]--></ul> <label class="form-label" for="maintenanceSource">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.platform.maintenance.modal.source"))} <small class="d-block text-muted">${escape_html(store_get($$store_subs ??= {}, "$_", $format)(activeTabMeta().hint))}</small></label> <textarea id="maintenanceSource" class="form-control font-monospace maintenance-source svelte-ilcrvu" spellcheck="false" autocomplete="off" autocapitalize="off" autocorrect="off">`);
		const $$body = escape_html(store_get($$store_subs ??= {}, "$templates", templates)[store_get($$store_subs ??= {}, "$activeTab", activeTab)] || "");
		if ($$body) $$renderer.push(`${$$body}`);
		$$renderer.push(`</textarea> <span class="form-label d-block mt-3">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.platform.maintenance.modal.preview"))}</span> <div class="maintenance-preview svelte-ilcrvu"><iframe${attr("title", store_get($$store_subs ??= {}, "$_", $format)("pages.settings.platform.maintenance.modal.preview"))} sandbox=""${attr("srcdoc", store_get($$store_subs ??= {}, "$previewHtml", previewHtml))} class="svelte-ilcrvu"></iframe> `);
		if (store_get($$store_subs ??= {}, "$previewLoading", previewLoading$1)) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<div class="maintenance-preview-overlay svelte-ilcrvu"><span class="spinner-border text-primary" role="status"></span></div>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--></div> <div class="mt-3"><button type="button" class="btn btn-link link-danger p-0 text-decoration-none"${attr("disabled", store_get($$store_subs ??= {}, "$busy", busy), true)}><i class="fa-regular fa-arrow-rotate-left me-1"></i> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.platform.maintenance.modal.reset-page"))}</button></div></div> <div class="modal-footer flex-nowrap"><button class="btn btn-link col-6 m-0" type="button">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.cancel"))}</button> <button class="btn btn-secondary col-6 m-0" type="button"${attr("disabled", store_get($$store_subs ??= {}, "$busy", busy), true)}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.save"))} `);
		if (store_get($$store_subs ??= {}, "$busy", busy)) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<span class="spinner-border spinner-border-sm ms-2" role="status"></span>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--></button></div></div></div></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
	});
}
var rows = writable([]);
var count = writable(0);
var page = writable(1);
var totalPage = writable(1);
var loading = writable(false);
var actionLoading = writable(false);
function MaintenanceBannedIpsModal($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		$$renderer.push(`<div aria-hidden="true" class="modal fade" role="dialog" tabindex="-1"><div class="modal-dialog modal-xl modal-dialog-centered modal-dialog-scrollable" role="dialog"><div class="modal-content"><div class="modal-header"><h5 class="modal-title">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.platform.maintenance.banned-ips.title"))} `);
		if (store_get($$store_subs ??= {}, "$count", count) > 0) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<span class="badge text-bg-danger ms-2">${escape_html(store_get($$store_subs ??= {}, "$count", count))}</span>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--> <small class="d-block text-muted fw-normal">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.platform.maintenance.banned-ips.sub"))}</small></h5> <button${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("buttons.close"))} type="button" class="btn-close" data-bs-dismiss="modal"></button></div> <div class="modal-body">`);
		if (store_get($$store_subs ??= {}, "$loading", loading)) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<div class="text-center py-5"><span class="spinner-border text-primary" role="status"></span></div>`);
		} else if (store_get($$store_subs ??= {}, "$rows", rows).length === 0) {
			$$renderer.push("<!--[1-->");
			NoContent($$renderer, {
				icon: "fa-solid fa-shield-halved fa-3x",
				text: store_get($$store_subs ??= {}, "$_", $format)("pages.settings.platform.maintenance.banned-ips.empty")
			});
		} else {
			$$renderer.push("<!--[-1-->");
			$$renderer.push(`<div class="table-responsive"><table class="table table-hover align-middle mb-0"><thead><tr><th class="align-middle text-nowrap" scope="col">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.platform.maintenance.banned-ips.ip"))}</th><th class="align-middle text-nowrap" scope="col">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.platform.maintenance.banned-ips.socket-peer"))}</th><th class="align-middle text-nowrap" scope="col">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.platform.maintenance.banned-ips.attempts"))}</th><th class="align-middle text-nowrap" scope="col">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.platform.maintenance.banned-ips.username-tried"))}</th><th class="align-middle text-nowrap" scope="col">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.platform.maintenance.banned-ips.banned-at"))}</th><th class="align-middle text-end" scope="col"></th></tr></thead><tbody><!--[-->`);
			const each_array = ensure_array_like(store_get($$store_subs ??= {}, "$rows", rows));
			for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
				let bannedIp = each_array[$$index];
				$$renderer.push(`<tr><td class="align-middle"><code class="user-select-all">${escape_html(bannedIp.ip)}</code></td><td class="align-middle font-monospace small opacity-75">${escape_html(bannedIp.socketPeer || "-")}</td><td class="align-middle text-nowrap">${escape_html(bannedIp.attempts ?? "-")}</td><td class="align-middle">${escape_html(bannedIp.lastUsernameTried || "-")}</td><td class="align-middle text-nowrap">`);
				if (bannedIp.bannedAt) {
					$$renderer.push("<!--[0-->");
					Date_1($$renderer, {
						time: bannedIp.bannedAt,
						fullFormat: true
					});
				} else {
					$$renderer.push("<!--[-1-->");
					$$renderer.push(`-`);
				}
				$$renderer.push(`<!--]--></td><td class="align-middle text-end"><button type="button" class="btn btn-link link-danger p-0"${attr("title", store_get($$store_subs ??= {}, "$_", $format)("pages.settings.platform.maintenance.banned-ips.remove"))}${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("pages.settings.platform.maintenance.banned-ips.remove"))}${attr("disabled", store_get($$store_subs ??= {}, "$actionLoading", actionLoading), true)}><i class="fas fa-trash"></i></button></td></tr>`);
			}
			$$renderer.push(`<!--]--></tbody></table></div> `);
			if (store_get($$store_subs ??= {}, "$totalPage", totalPage) > 1) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<div class="mt-3">`);
				Pagination($$renderer, {
					page: store_get($$store_subs ??= {}, "$page", page),
					totalPage: store_get($$store_subs ??= {}, "$totalPage", totalPage)
				});
				$$renderer.push(`<!----></div>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]-->`);
		}
		$$renderer.push(`<!--]--></div> <div class="modal-footer flex-nowrap"><button class="btn btn-link col-6 m-0" type="button">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.close"))}</button> <button class="btn btn-link link-danger col-6 m-0" type="button"${attr("disabled", store_get($$store_subs ??= {}, "$actionLoading", actionLoading) || store_get($$store_subs ??= {}, "$rows", rows).length === 0, true)}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.platform.maintenance.banned-ips.clear-all"))} `);
		if (store_get($$store_subs ??= {}, "$actionLoading", actionLoading)) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<span class="spinner-border spinner-border-sm ms-2" role="status"></span>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--></button></div></div></div></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
	});
}
//#endregion
//#region src/lib/components/modals/UsageDataModal.svelte
var PRIVACY_POLICY_URL = "https://panomc.com/privacy-policy";
var TELEMETRY_DOCS_URL = "https://panomc.com/docs/platform/configuration/telemetry/";
var previewOpen = writable(false);
var previewLoading = writable(false);
var previewFailed = writable(false);
var previewPayload = writable("");
function UsageDataModal($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		const OPTION_TOKEN = "\0";
		const turnOffParts = derived(() => store_get($$store_subs ??= {}, "$_", $format)("components.modals.usage-data.turn-off", { values: { option: OPTION_TOKEN } }).split(OPTION_TOKEN));
		const turnOffOption = derived(() => store_get($$store_subs ??= {}, "$_", $format)("components.modals.usage-data.turn-off-option"));
		$$renderer.push(`<div aria-hidden="true" class="modal fade" role="dialog" tabindex="-1"><div class="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable" role="dialog"><div class="modal-content"><div class="modal-header"><h5 class="modal-title">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.usage-data.title"))}</h5> <button${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("buttons.close"))} class="btn-close" type="button"></button></div> <div class="modal-body"><ul class="usage-data-list mb-3 svelte-15wue8v"><li class="svelte-15wue8v">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.usage-data.sent-platform"))}</li> <li class="svelte-15wue8v">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.usage-data.sent-system"))}</li> <li class="svelte-15wue8v">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.usage-data.sent-website"))}</li> <li class="svelte-15wue8v">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.usage-data.sent-ip"))}</li> <li class="svelte-15wue8v">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.usage-data.sent-resources"))}</li> <li class="svelte-15wue8v">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.usage-data.sent-counts"))}</li> <li class="svelte-15wue8v">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.usage-data.sent-account"))}</li> <li class="svelte-15wue8v">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.usage-data.sent-install"))}</li></ul> <p class="text-body-secondary mb-0">${escape_html(turnOffParts()[0])}<code>${escape_html(turnOffOption())}</code>${escape_html(turnOffParts()[1] ?? "")}</p> `);
		if (store_get($$store_subs ??= {}, "$previewOpen", previewOpen)) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<hr/> `);
			if (store_get($$store_subs ??= {}, "$previewLoading", previewLoading)) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<div class="text-center py-4"><span class="spinner-border spinner-border-sm text-primary" role="status"></span></div>`);
			} else if (store_get($$store_subs ??= {}, "$previewFailed", previewFailed)) {
				$$renderer.push("<!--[1-->");
				$$renderer.push(`<p class="text-body-secondary small mb-0">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.usage-data.preview-error"))}</p>`);
			} else {
				$$renderer.push("<!--[-1-->");
				$$renderer.push(`<pre class="usage-data-preview bg-body-tertiary border rounded small mb-0 p-3 svelte-15wue8v">${escape_html(store_get($$store_subs ??= {}, "$previewPayload", previewPayload))}</pre>`);
			}
			$$renderer.push(`<!--]-->`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--></div> <div class="modal-footer justify-content-between"><div class="hstack gap-3"><a${attr("href", PRIVACY_POLICY_URL)} rel="noopener" target="_blank">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.usage-data.privacy-policy"))}</a> <a${attr("href", TELEMETRY_DOCS_URL)} rel="noopener" target="_blank">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.usage-data.learn-more"))}</a></div> <button${attr("aria-expanded", store_get($$store_subs ??= {}, "$previewOpen", previewOpen))} class="btn btn-primary" type="button">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.usage-data.preview"))}</button></div></div></div></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
	});
}
//#endregion
//#region src/lib/components/PermissionNodeInput.svelte
function PermissionNodeInput($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		let { id = void 0, value = "", disabled = false, invalid = false, maxlength = void 0, placeholder = "" } = $$props;
		$$renderer.push(`<div class="position-relative"><input${attr("id", id)}${attr_class("form-control font-monospace", void 0, { "border-danger": invalid })} type="text" autocomplete="off" spellcheck="false"${attr("maxlength", maxlength)}${attr("placeholder", placeholder)}${attr("disabled", disabled, true)}${attr("value", value)}/> `);
		$$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--></div>`);
		bind_props($$props, { value });
	});
}
//#endregion
//#region src/lib/maintenance.util.js
/**
* Helpers for the maintenance mode card on the Platform settings page.
*
* Everything here is advisory: the backend re-validates and re-normalizes the same values,
* and it is the only side that can see the live router. These checks just keep the panel
* from sending an address the platform is already known to refuse.
*/
/** Prefixes the platform serves itself, so a custom login address may never live under them. */
var RESERVED_LOGIN_URL_PREFIXES = ["/api", "/panel/api"];
/** The single i18n key the card shows for every invalid custom login address. */
var CUSTOM_LOGIN_URL_ERROR = "pages.settings.platform.maintenance.custom-login-url-invalid";
/** The i18n key the card shows for a bypass node the platform would refuse. */
var BYPASS_PERMISSION_NODE_ERROR = "pages.settings.platform.maintenance.permission-node-invalid";
/** The i18n key the card shows when the custom permission mode is left without a node. */
var BYPASS_PERMISSION_NODE_REQUIRED_ERROR = "pages.settings.platform.maintenance.permission-node-required";
var LOGIN_URL_CHARS = /^\/[A-Za-z0-9\-._~/]*$/;
var MAX_BYPASS_PERMISSION_NODE_LENGTH = 128;
/**
* @param {unknown} value
* @returns {string} leading slash, collapsed slashes, no trailing slash ('' when blank)
*/
function normalizeLoginUrl(value) {
	let path = String(value ?? "").trim();
	if (!path) return "";
	if (!path.startsWith("/")) path = "/" + path;
	path = path.replace(/\/{2,}/g, "/");
	if (path.length > 1) path = path.replace(/\/+$/, "");
	return path;
}
/**
* @param {unknown} value
* @returns {string|null} i18n key of the error, or null when the address is usable
*/
function validateCustomLoginUrl(value) {
	const raw = String(value ?? "").trim();
	if (!raw) return null;
	if (/\s/.test(raw) || !raw.startsWith("/")) return CUSTOM_LOGIN_URL_ERROR;
	if (raw.includes("?") || raw.includes("#") || raw.includes("..")) return CUSTOM_LOGIN_URL_ERROR;
	if (!LOGIN_URL_CHARS.test(raw)) return CUSTOM_LOGIN_URL_ERROR;
	const normalized = normalizeLoginUrl(raw);
	if (normalized === "/" || normalized.length > 128) return CUSTOM_LOGIN_URL_ERROR;
	const lowered = normalized.toLowerCase();
	if (RESERVED_LOGIN_URL_PREFIXES.some((prefix) => lowered === prefix || lowered.startsWith(prefix + "/"))) return CUSTOM_LOGIN_URL_ERROR;
	return null;
}
/**
* Mirrors the platform rule for the bypass node: no wildcard (it is matched as a literal
* target, so `admins.*` would only ever match holders of that exact string), no whitespace,
* at most 128 characters.
*
* @param {unknown} value
* @param {boolean} [required] true while the card is in custom mode, where a blank node would
*   silently fall back to the default panel permission
* @returns {string|null} i18n key of the error, or null when the node is usable
*/
function validateBypassPermissionNode(value, required = false) {
	const node = String(value ?? "").trim();
	if (!node) return required ? BYPASS_PERMISSION_NODE_REQUIRED_ERROR : null;
	if (node.length > MAX_BYPASS_PERMISSION_NODE_LENGTH || node.includes("*") || /\s/.test(node)) return BYPASS_PERMISSION_NODE_ERROR;
	return null;
}
//#endregion
//#region src/lib/pages/settings/PlatformSettings.svelte
var UpdatePeriod = Object.freeze({
	NEVER: "NEVER",
	ONCE_PER_DAY: "ONCE_PER_DAY",
	ONCE_PER_WEEK: "ONCE_PER_WEEK",
	ONCE_PER_MONTH: "ONCE_PER_MONTH"
});
async function load(event) {
	const { parent, url: { searchParams } } = event;
	await parent();
	const [generalSettings, authSettings, maintenanceSettings] = await Promise.all([
		ApiUtil.get({
			path: "/api/panel/settings" + buildQueryParams({ type: "GENERAL" }),
			request: event
		}),
		ApiUtil.get({
			path: "/api/panel/settings" + buildQueryParams({ type: "AUTH" }),
			request: event
		}),
		ApiUtil.get({
			path: "/api/panel/settings" + buildQueryParams({ type: "MAINTENANCE" }),
			request: event
		})
	]);
	const body = {
		...generalSettings,
		...authSettings,
		...maintenanceSettings
	};
	body.oldSettings = structuredClone(body);
	const failed = searchParams.get("failed");
	const encodedData = searchParams.get("encodedData");
	const state = searchParams.get("state");
	return {
		...body,
		platformConnectFailed: failed,
		encodedData,
		state
	};
}
function PlatformSettings($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let telemetryLabelParts, preferencesSaveDisabled, authSaveDisabled, emailSaveDisabled, maintenanceDisabled, customLoginUrlDisabled, customLoginUrlError, bypassPermissionNodeError, maintenanceSaveDisabled, bannedIpCount;
		const pageTitle = getContext("pageTitle");
		const siteInfo = getContext("siteInfo");
		pageTitle.set("pages.settings.platform.title");
		let data = $$props["data"];
		let smtpDisabled;
		data.releaseChannel = data.releaseChannel || "RELEASE";
		if (data?.oldSettings) data.oldSettings.releaseChannel = data.oldSettings.releaseChannel || data.releaseChannel;
		const DEFAULT_MAINTENANCE = Object.freeze({
			enabled: false,
			bypassPermissionNode: "",
			showLoginButton: true,
			customLoginUrl: "",
			showSiteLogo: true,
			title: "",
			messageHtml: "",
			customCss: ""
		});
		data.maintenance = {
			...DEFAULT_MAINTENANCE,
			...data.maintenance || {}
		};
		if (data?.oldSettings) data.oldSettings.maintenance = {
			...DEFAULT_MAINTENANCE,
			...data.oldSettings.maintenance || {}
		};
		!data.panoAccount && data.state && data.encodedData;
		let toggleSmtpLoading;
		let toggleMaintenanceLoading;
		const TELEMETRY_LINK_TOKEN = "\0";
		smtpDisabled = !store_get($$store_subs ??= {}, "$siteInfo", siteInfo).emailEnabled;
		if (data.telemetryEnabled == null) data.telemetryEnabled = true;
		if (data.oldSettings && data.oldSettings.telemetryEnabled == null) data.oldSettings.telemetryEnabled = true;
		telemetryLabelParts = store_get($$store_subs ??= {}, "$_", $format)("pages.settings.platform.telemetry.label", { values: { link: TELEMETRY_LINK_TOKEN } }).split(TELEMETRY_LINK_TOKEN);
		preferencesSaveDisabled = data.oldSettings.updatePeriod === data.updatePeriod && data.oldSettings.releaseChannel === data.releaseChannel && data.oldSettings.locale === data.locale && data.oldSettings.allowUserLocaleSelection === data.allowUserLocaleSelection && data.oldSettings.telemetryEnabled === data.telemetryEnabled && data.oldSettings.developmentMode === data.developmentMode;
		authSaveDisabled = data.oldSettings.requireEmailVerification === data.requireEmailVerification && data.oldSettings.passwordHashAlgorithm === data.passwordHashAlgorithm;
		emailSaveDisabled = JSON.stringify(data.oldSettings.email) === JSON.stringify(data.email) || !data.email.password;
		if (!data.maintenance) data.maintenance = { ...DEFAULT_MAINTENANCE };
		if (data.oldSettings && !data.oldSettings.maintenance) data.oldSettings.maintenance = { ...DEFAULT_MAINTENANCE };
		maintenanceDisabled = !data.maintenance.enabled;
		customLoginUrlDisabled = maintenanceDisabled || data.maintenance.showLoginButton;
		customLoginUrlError = data.maintenance.showLoginButton ? null : validateCustomLoginUrl(data.maintenance.customLoginUrl);
		bypassPermissionNodeError = validateBypassPermissionNode(data.maintenance.bypassPermissionNode, false);
		maintenanceSaveDisabled = JSON.stringify(data.oldSettings.maintenance) === JSON.stringify(data.maintenance) || !!customLoginUrlError || !!bypassPermissionNodeError;
		bannedIpCount = data.maintenanceBannedIpCount ?? 0;
		let $$settled = true;
		let $$inner_renderer;
		function $$render_inner($$renderer) {
			if (!data.panoAccount && data.platformConnectFailed) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<div class="alert alert-danger alert-dismissible fade show mb-0" role="alert"><button type="button" class="btn-close" data-bs-dismiss="alert"${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("buttons.close"))}></button> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.platform.connect-failed-alert"))}</div>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--> `);
			PageActions($$renderer, {
				leftClasses: "d-lg-flex d-none",
				middleClasses: "d-none d-lg-flex",
				$$slots: { right: ($$renderer) => {
					$$renderer.push(`<div class="hstack gap-2" slot="right"><button class="btn btn-link link-danger"${attr("title", store_get($$store_subs ??= {}, "$_", $format)("buttons.stop"))}${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("buttons.stop"))}${attr("data-bs-target", store_get($$store_subs ??= {}, "$_", $format)("buttons.stop"))}><i class="fas fa-stop"></i></button> <button class="btn btn-secondary"><i class="fa-regular fa-arrows-rotate"></i> <span class="d-lg-inline d-none ms-2">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.restart"))}</span></button></div>`);
				} }
			});
			$$renderer.push(`<!----> `);
			$$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--> <div class="card"><div class="card-header">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.platform.preferences"))}</div> <div class="card-body"><div class="row mb-3"><label class="col-md-6" for="platformDevMode">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.platform.developer-mode"))}</label> <div class="col d-flex align-items-center"><div class="form-check form-switch"><input class="form-check-input" type="checkbox" role="switch" id="platformDevMode" autocomplete="off"${attr("checked", data.developmentMode, true)}/></div></div></div> <div class="row mb-3"><label class="col-md-6 col-form-label" for="platformLanguage">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.platform.display-language"))}</label> <div class="col-md-6">`);
			$$renderer.select({
				class: "form-control",
				id: "platformLanguage",
				value: data.locale
			}, ($$renderer) => {
				$$renderer.push(`<!--[-->`);
				const each_array = ensure_array_like(Object.keys(store_get($$store_subs ??= {}, "$Languages", Languages)));
				for (let index = 0, $$length = each_array.length; index < $$length; index++) {
					let language = each_array[index];
					$$renderer.option({ value: store_get($$store_subs ??= {}, "$Languages", Languages)[language].code }, ($$renderer) => {
						$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$Languages", Languages)[language].name)}`);
					});
				}
				$$renderer.push(`<!--]-->`);
			});
			$$renderer.push(` `);
			if (store_get($$store_subs ??= {}, "$siteInfo", siteInfo).userLocaleCode && store_get($$store_subs ??= {}, "$siteInfo", siteInfo).userLocaleCode !== store_get($$store_subs ??= {}, "$siteInfo", siteInfo).platformLocale) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<div class="alert alert-info mt-2 mb-0 py-2 px-3" role="alert"><i class="fa-solid fa-circle-info me-1"></i> <small>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.platform.user-locale-mismatch-warning"))}</small></div>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--></div></div> <div class="row mb-3"><label class="col-md-6" for="allowUserLocaleSelection">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.platform.allow-user-locale-selection"))} <small class="d-block">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.platform.allow-user-locale-selection-description"))}</small></label> <div class="col d-flex align-items-center"><div class="form-check form-switch"><input class="form-check-input" type="checkbox" role="switch" id="allowUserLocaleSelection" autocomplete="off"${attr("checked", data.allowUserLocaleSelection, true)}/></div></div></div> <div class="row mb-3"><label class="col-md-6 col-form-label" for="updatePeriod">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.platform.check-auto-updates"))}</label> <div class="col-md-6">`);
			$$renderer.select({
				class: "form-control",
				value: data.updatePeriod,
				id: "updatePeriod"
			}, ($$renderer) => {
				$$renderer.option({ value: UpdatePeriod.NEVER }, ($$renderer) => {
					$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.platform.inputs.check-auto-updates.never"))}`);
				});
				$$renderer.option({ value: UpdatePeriod.ONCE_PER_DAY }, ($$renderer) => {
					$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.platform.inputs.check-auto-updates.once-in-a-day"))}`);
				});
				$$renderer.option({ value: UpdatePeriod.ONCE_PER_WEEK }, ($$renderer) => {
					$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.platform.inputs.check-auto-updates.once-in-a-week"))}`);
				});
				$$renderer.option({ value: UpdatePeriod.ONCE_PER_MONTH }, ($$renderer) => {
					$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.platform.inputs.check-auto-updates.once-in-a-month"))}`);
				});
			});
			$$renderer.push(`</div></div> <div class="row mb-3"><label class="col-md-6 col-form-label" for="releaseChannel">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.platform.release-channel"))}</label> <div class="col-md-6">`);
			$$renderer.select({
				class: "form-control",
				value: data.releaseChannel,
				id: "releaseChannel"
			}, ($$renderer) => {
				$$renderer.option({ value: "ALPHA" }, ($$renderer) => {
					$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.platform.inputs.release-channel.alpha"))}`);
				});
				$$renderer.option({ value: "BETA" }, ($$renderer) => {
					$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.platform.inputs.release-channel.beta"))}`);
				});
				$$renderer.option({ value: "RELEASE" }, ($$renderer) => {
					$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.platform.inputs.release-channel.stable"))}`);
				});
			});
			$$renderer.push(` `);
			if (data.releaseChannel && data.releaseChannel !== "RELEASE") {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<div class="alert alert-warning mt-2" role="alert"><i class="fa-solid fa-triangle-exclamation me-2"></i> ${html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.platform.release-channel-warning"))} `);
				if (data.releaseChannel === "BETA") {
					$$renderer.push("<!--[0-->");
					$$renderer.push(`<br/> ${html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.platform.release-channel-warning-beta"))}`);
				} else $$renderer.push("<!--[-1-->");
				$$renderer.push(`<!--]--></div>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--></div></div> <div class="row mb-3"><label class="col-md-6" for="telemetryEnabled">${escape_html(telemetryLabelParts[0])}<button class="btn btn-link align-baseline p-0" type="button">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.platform.telemetry.label-link"))}</button>${escape_html(telemetryLabelParts[1] ?? "")} <small class="d-block text-muted">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.platform.telemetry.description"))}</small></label> <div class="col d-flex align-items-center"><div class="form-check form-switch"><input class="form-check-input" type="checkbox" role="switch" id="telemetryEnabled" autocomplete="off"${attr("checked", data.telemetryEnabled, true)}/></div></div></div> <button class="btn btn-secondary"${attr("disabled", preferencesSaveDisabled, true)}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.save"))}</button></div></div> <div class="card"><div class="card-header">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.platform.authentication"))}</div> <div class="card-body"><div class="row"><label class="col-md-6" for="requireEmailVerification">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.platform.auth.require-email-verification"))} <small class="d-block text-muted">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.platform.auth.require-email-verification-sub"))}</small></label> <div class="col d-flex align-items-center"><div class="form-check form-switch"><input class="form-check-input" type="checkbox" role="switch" id="requireEmailVerification" autocomplete="off"${attr("disabled", smtpDisabled, true)}${attr("checked", data.requireEmailVerification, true)}/></div></div></div> `);
			if (smtpDisabled) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<div class="alert alert-warning mt-3" role="alert"><div class="d-flex align-items-center"><i class="fa-solid fa-triangle-exclamation me-3"></i> <div>${html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.platform.auth.email-disabled-warning"))}</div></div></div>`);
			} else if (!data.requireEmailVerification) {
				$$renderer.push("<!--[1-->");
				$$renderer.push(`<div class="alert alert-warning mt-3" role="alert"><div class="d-flex align-items-center"><i class="fa-solid fa-triangle-exclamation me-3"></i> <div>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.platform.auth.require-email-verification-warning"))}</div></div></div>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--> <hr/> <div class="row mb-3"><label class="col-md-6 col-form-label" for="passwordHashAlgorithm">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.platform.auth.password-hash-algorithm"))} <small class="d-block text-muted">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.platform.auth.password-hash-algorithm-sub"))}</small></label> <div class="col-md-6">`);
			$$renderer.select({
				class: "form-control",
				id: "passwordHashAlgorithm",
				value: data.passwordHashAlgorithm
			}, ($$renderer) => {
				$$renderer.option({ value: "ARGON2ID" }, ($$renderer) => {
					$$renderer.push(`Argon2id (${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.platform.auth.recommended"))})`);
				});
				$$renderer.option({ value: "BCRYPT" }, ($$renderer) => {
					$$renderer.push(`BCrypt`);
				});
				$$renderer.option({ value: "SHA256" }, ($$renderer) => {
					$$renderer.push(`SHA-256`);
				});
				$$renderer.option({ value: "MD5" }, ($$renderer) => {
					$$renderer.push(`MD5`);
				});
			});
			$$renderer.push(`</div></div> `);
			if (data.passwordHashAlgorithm === "MD5") {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<div class="alert alert-danger mt-2"><div class="hstack gap-3"><i class="fa-solid fa-triangle-exclamation"></i> <div>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.platform.auth.password-hash-algorithm-warning"))}</div></div></div>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--> <div class="mt-3"><button class="btn btn-secondary"${attr("disabled", authSaveDisabled, true)}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.save"))}</button></div></div></div> <div class="card"><div class="card-header d-flex align-items-center justify-content-between gap-3"><div class="form-switch ps-0 d-flex align-items-center gap-2"><input class="form-check-input mt-0 ms-0 flex-shrink-0" type="checkbox" role="switch" id="maintenanceToggle" autocomplete="off"${attr("title", store_get($$store_subs ??= {}, "$_", $format)("pages.settings.platform.maintenance.enabled"))}${attr("checked", data.maintenance.enabled, true)}${attr("disabled", toggleMaintenanceLoading, true)}/> <label class="form-check-label mb-0" for="maintenanceToggle">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.platform.maintenance.title"))} <small class="d-block text-muted">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.platform.maintenance.enabled-sub"))}</small></label></div> `);
			$$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--></div> <div${attr_class("card-body", void 0, { "opacity-50": maintenanceDisabled })}>`);
			if (!maintenanceDisabled) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<div class="alert alert-danger border mb-3" role="alert"><div class="d-flex align-items-center"><i class="fa-solid fa-triangle-exclamation me-3"></i> <div>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.platform.maintenance.active-warning"))}</div></div></div>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--> <div class="row mb-3"><label class="col-md-6 col-form-label" for="maintenanceShowLoginButton">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.platform.maintenance.show-login-button"))} <small class="d-block text-muted">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.platform.maintenance.show-login-button-sub"))}</small></label> <div class="col col-form-label"><div class="form-check form-switch"><input class="form-check-input" type="checkbox" role="switch" id="maintenanceShowLoginButton" autocomplete="off"${attr("checked", data.maintenance.showLoginButton, true)}${attr("disabled", maintenanceDisabled, true)}/></div></div></div> <div class="row mb-3"><label class="col-md-6 col-form-label position-relative" for="maintenanceCustomLoginUrl"><span${attr_class("position-absolute start-0 top-0 bottom-0 border-start border-2", void 0, {
				"border-secondary": !customLoginUrlDisabled,
				"border-gray": customLoginUrlDisabled
			})} style="width: 2px;"></span> <span class="ps-3 d-block">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.platform.maintenance.custom-login-url"))} <small class="d-block text-muted">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.platform.maintenance.custom-login-url-sub"))}</small></span></label> <div class="col-md-6"><input${attr_class("form-control font-monospace", void 0, { "border-danger": !!customLoginUrlError })} id="maintenanceCustomLoginUrl" type="text" autocomplete="off" spellcheck="false" placeholder="/login"${attr("value", data.maintenance.customLoginUrl)}${attr("disabled", customLoginUrlDisabled, true)}/> `);
			if (customLoginUrlError) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<div class="small text-danger mt-1">${escape_html(store_get($$store_subs ??= {}, "$_", $format)(customLoginUrlError))}</div>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--></div></div> <hr/> <div class="row mb-3"><label class="col-md-6 col-form-label" for="maintenancePermissionNode">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.platform.maintenance.permission-node"))} <small class="d-block text-muted">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.platform.maintenance.permission-node-sub"))}</small></label> <div class="col-md-6">`);
			PermissionNodeInput($$renderer, {
				id: "maintenancePermissionNode",
				disabled: maintenanceDisabled,
				invalid: !!bypassPermissionNodeError,
				maxlength: 128,
				placeholder: data.defaultBypassPermissionNode || "",
				get value() {
					return data.maintenance.bypassPermissionNode;
				},
				set value($$value) {
					data.maintenance.bypassPermissionNode = $$value;
					$$settled = false;
				}
			});
			$$renderer.push(`<!----> `);
			if (bypassPermissionNodeError) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<div class="small text-danger mt-1">${escape_html(store_get($$store_subs ??= {}, "$_", $format)(bypassPermissionNodeError))}</div>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--></div></div> <hr/> <div class="row mb-3"><label class="col-md-6 col-form-label" for="maintenanceShowSiteLogo">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.platform.maintenance.show-site-logo"))} <small class="d-block text-muted">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.platform.maintenance.show-site-logo-sub"))}</small></label> <div class="col col-form-label"><div class="form-check form-switch"><input class="form-check-input" type="checkbox" role="switch" id="maintenanceShowSiteLogo" autocomplete="off"${attr("checked", data.maintenance.showSiteLogo, true)}${attr("disabled", maintenanceDisabled, true)}/></div></div></div> <div class="hstack gap-3 flex-wrap mb-3"><button type="button" class="btn btn-link p-0 text-decoration-none"><i class="fas fa-pencil me-1"></i> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.platform.maintenance.edit-page"))}</button> <a${attr_class("btn btn-link p-0 text-decoration-none", void 0, { "disabled": maintenanceDisabled })} href="/api/maintenance/exit" target="_blank" rel="noopener noreferrer"${attr("aria-disabled", maintenanceDisabled)}><i class="fas fa-external-link me-1"></i> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.platform.maintenance.preview-page"))}</a></div> <button class="btn btn-secondary"${attr("disabled", maintenanceSaveDisabled, true)}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.save"))} `);
			$$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--></button></div> <div class="card-footer"><button type="button" class="btn btn-link text-decoration-none p-0 text-start w-100 d-flex align-items-center justify-content-between gap-2"><span><i class="fa-solid fa-ban me-2 opacity-75"></i> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.platform.maintenance.banned-ips.title"))} `);
			if (bannedIpCount > 0) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<span class="badge text-bg-danger ms-2">${escape_html(bannedIpCount)}</span>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--> <small class="d-block text-muted">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.platform.maintenance.banned-ips.sub"))}</small></span> <i class="fa-solid fa-chevron-right"></i></button></div></div> `);
			$$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--> <div class="card"><div class="card-header"><div class="form-check form-switch"><input class="form-check-input" type="checkbox" id="smtpToggle"${attr("checked", store_get($$store_subs ??= {}, "$siteInfo", siteInfo).emailEnabled, true)}${attr("disabled", toggleSmtpLoading, true)}/> <label class="form-check-label" for="smtpToggle">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.platform.smtp-settings"))}</label></div></div> <div${attr_class("card-body", void 0, { "opacity-50": smtpDisabled })}>`);
			if (smtpDisabled) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<div class="alert alert-warning border mb-3" role="alert"><div class="d-flex align-items-center"><i class="fa-solid fa-triangle-exclamation me-3"></i> <div>${html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.platform.smtp.smtp-disabled-alert"))}</div></div></div>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--> <div class="row mb-3"><label class="col-md-6 col-form-label" for="mailUsername">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.platform.smtp.username"))}</label> <div class="col-md-6"><input class="form-control" id="mailUsername" type="text" placeholder="no-reply"${attr("value", data.email.username)}${attr("disabled", smtpDisabled, true)}/></div></div> <div class="row mb-3"><label class="col-md-6 col-form-label" for="mailUserPassword">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.platform.smtp.password"))}</label> <div class="col-md-6"><input class="form-control" id="mailUserPassword" placeholder="****************"${attr("value", data.email.password)} type="password"${attr("disabled", smtpDisabled, true)}/></div></div> <div class="row mb-3"><label class="col-md-6 col-form-label" for="useSSLCheck">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.platform.smtp.ssl"))}</label> <div class="col-md-6"><div class="form-check"><input class="form-check-input" type="checkbox" name="useSSLCheck" id="useSSLCheck"${attr("aria-checked", data.email.ssl)}${attr("checked", data.email.ssl, true)}${attr("disabled", smtpDisabled, true)}/></div></div></div> <div class="row mb-3"><label class="col-md-6 col-form-label" for="port">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.platform.smtp.tls-setting"))}</label> <div class="col-md-6">`);
			$$renderer.select({
				class: "form-select",
				id: "port",
				value: data.email.starttls,
				disabled: smtpDisabled
			}, ($$renderer) => {
				$$renderer.option({ value: "REQUIRED" }, ($$renderer) => {
					$$renderer.push(`REQUIRED`);
				});
				$$renderer.option({ value: "OPTIONAL" }, ($$renderer) => {
					$$renderer.push(`OPTIONAL`);
				});
				$$renderer.option({ value: "DISABLED" }, ($$renderer) => {
					$$renderer.push(`DISABLED`);
				});
			});
			$$renderer.push(`</div></div> <div class="row mb-3"><label class="col-md-6 col-form-label" for="senderAddress">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.platform.smtp.sender-address"))}</label> <div class="col-md-6"><input class="form-control" id="senderAddress" type="text" placeholder="no-reply@forexample.com"${attr("value", data.email.sender)}${attr("disabled", smtpDisabled, true)}/></div></div> <div class="row mb-3"><label class="col-md-6 col-form-label" for="hostAddress">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.platform.smtp.hostname"))}</label> <div class="col-md-6"><input class="form-control" id="hostAddress" type="text" placeholder="smtp.forexample.com"${attr("value", data.email.hostname)}${attr("disabled", smtpDisabled, true)}/></div></div> <div class="row mb-3"><label class="col-md-6 col-form-label" for="port">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.platform.smtp.port"))}</label> <div class="col-md-6"><input class="form-control" id="port" placeholder="465" type="number"${attr("value", data.email.port)}${attr("disabled", smtpDisabled, true)}/></div></div> <div class="row mb-3"><label class="col-md-6 col-form-label" for="authMethods">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.platform.smtp.auth-methods"))}</label> <div class="col-md-6">`);
			$$renderer.select({
				class: "form-select",
				id: "authMethods",
				value: data.email.authMethods,
				disabled: smtpDisabled
			}, ($$renderer) => {
				$$renderer.option({ value: "PLAIN" }, ($$renderer) => {
					$$renderer.push(`PLAIN`);
				});
				$$renderer.option({ value: "" }, ($$renderer) => {});
			});
			$$renderer.push(`</div></div> <button class="btn btn-secondary"${attr("disabled", true, true)}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)(!store_get($$store_subs ??= {}, "$siteInfo", siteInfo).emailEnabled ? "buttons.enable" : "buttons.save"))}</button> `);
			if (!emailSaveDisabled) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<button class="btn btn-outline-primary"${attr("disabled", smtpDisabled, true)}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.validate"))} `);
				$$renderer.push("<!--[-1-->");
				$$renderer.push(`<!--]--></button>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--></div></div> `);
			EditMaintenancePageModal($$renderer);
			$$renderer.push(`<!----> `);
			MaintenanceBannedIpsModal($$renderer);
			$$renderer.push(`<!----> `);
			ConfirmSaveCriticalSettingsModal($$renderer);
			$$renderer.push(`<!----> `);
			ConfirmRemovePanoAccountModal($$renderer);
			$$renderer.push(`<!----> `);
			ConfirmDisableEmailModal($$renderer);
			$$renderer.push(`<!----> `);
			ConfirmStopPanoModal($$renderer);
			$$renderer.push(`<!----> `);
			ConfirmRestartPanoModal($$renderer, { runMode: data.runMode });
			$$renderer.push(`<!----> `);
			UsageDataModal($$renderer);
			$$renderer.push(`<!---->`);
		}
		do {
			$$settled = true;
			$$inner_renderer = $$renderer.copy();
			$$render_inner($$inner_renderer);
		} while (!$$settled);
		$$renderer.subsume($$inner_renderer);
		if ($$store_subs) unsubscribe_stores($$store_subs);
		bind_props($$props, { data });
	});
}

export { PlatformSettings as P, load as l };
//# sourceMappingURL=PlatformSettings.js-BOHofOJp.js.map
