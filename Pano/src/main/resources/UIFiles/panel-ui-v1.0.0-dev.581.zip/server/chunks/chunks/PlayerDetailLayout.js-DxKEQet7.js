import { _ as __exportAll } from './rolldown-runtime.js-BMnQIuNT.js';
import { e as error } from './exports2.js-VkmSkXbz.js';
import { b as base } from './internal.js-BRN1McAa.js';
import { J as getContext, a0 as onDestroy, Z as escape_html, T as attr, V as attr_class, U as stringify, Q as store_get, S as unsubscribe_stores, x as setContext, y as derived } from './index-server.js-DdhL7Abu.js';
import { b as beforeNavigate } from './stores.js-D5xmrOAP.js';
import './server.js-BlClO2ED.js';
import './internal2.js-CNe5OZUJ.js';
import './routing.js-N-OPb2ye.js';
import { e as buildQueryParams, b as ApiUtil, f as avatarVersion } from './Store.js-DT3aZHRb.js';
import { $ as $format } from './runtime.js-BzHEw_ze.js';
import { h as hasPermission, P as Permissions } from './auth.util.js-C77uoaNq.js';
import { D as Date_1 } from './Date.js-DCZp_jrB.js';
import './tooltip.util.js-BeLZL-Tj.js';
import { e as executeHookLoad, H as Hook } from './SiteNavigationMenu.js-DeoPp7eK.js';
import { P as PageActions } from './PageActions.js-co-RIHDp.js';
import { P as PageNav, a as PageNavItem } from './PageNav.js-Bzzuwwjz.js';
import './ToastContainer.js-Bv1jJ2dr.js';
import { P as PlayerStatusBadge, a as PlayerPermissionBadge } from './PlayerPermissionBadge.js-CZpeO_Jh.js';

//#region src/lib/layouts/PlayerDetailLayout.svelte
var PlayerDetailLayout_exports = /* @__PURE__ */ __exportAll({
	default: () => PlayerDetailLayout,
	initSlots: () => initSlots,
	load: () => load
});
var key = "layout-slots";
function initSlots() {
	const slots = {
		right: null,
		left: null
	};
	setContext(key, slots);
	return slots;
}
/**
* @type {import('@sveltejs/kit').LayoutLoad}
*/
async function load(event) {
	const { parent, url: { searchParams } } = event;
	await parent();
	const username = event.params.username;
	const ticketsPage = searchParams.get("ticketsPage") || 1;
	const banHistoryPage = searchParams.get("banHistoryPage") || 1;
	const queryParams = buildQueryParams({
		ticketsPage,
		banHistoryPage
	});
	const body = await ApiUtil.get({
		path: `/api/panel/players/${username}` + queryParams,
		request: event
	});
	if (body.error) {
		if (body.error === "NOT_EXISTS" || body.error === "PAGE_NOT_FOUND") throw error(404, body.error);
		throw error(500, body.error);
	}
	body.username = username;
	body.ticketsPage = parseInt(ticketsPage);
	body.banHistoryPage = parseInt(banHistoryPage);
	body.hookProps = {};
	body.hookProps["panel:player-detail:bottom"] = await executeHookLoad("panel:player-detail:bottom", event);
	body.hookProps["panel:player-detail:sidebar"] = await executeHookLoad("panel:player-detail:sidebar", event);
	return body;
}
function PlayerDetailLayout($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let { data, children } = $$props;
		const slots = initSlots();
		const user = getContext("user");
		const siteInfo = getContext("siteInfo");
		getContext("pageTitle");
		beforeNavigate(({ from, to }) => {
			if (from?.route.id !== to?.route.id) Object.assign(slots, {
				right: null,
				left: null
			});
		});
		let checkTime = 0;
		let interval;
		const isOnline = derived(() => data.player.lastActivityTime > Date.now() - 3e5 || data.player.inGame);
		onDestroy(() => {
			clearInterval(interval);
		});
		$$renderer.push(`<div class="container vstack gap-3">`);
		PageActions($$renderer, { $$slots: {
			left: ($$renderer) => {
				$$renderer.push(`<div slot="left">`);
				if (slots.left) {
					$$renderer.push("<!--[0-->");
					slots.left($$renderer);
					$$renderer.push(`<!---->`);
				} else {
					$$renderer.push("<!--[-1-->");
					PageNav($$renderer, {
						children: ($$renderer) => {
							PageNavItem($$renderer, {
								href: `/players/detail/${stringify(data.player.username)}`,
								children: ($$renderer) => {
									$$renderer.push(`<!---->${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.player-detail.overview"))}`);
								}});
							$$renderer.push(`<!----> `);
							PageNavItem($$renderer, {
								href: `/players/detail/${stringify(data.player.username)}/sessions`,
								children: ($$renderer) => {
									$$renderer.push(`<!---->${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.player-detail.sessions"))}`);
								}});
							$$renderer.push(`<!---->`);
						},
						$$slots: { default: true }
					});
				}
				$$renderer.push(`<!--]--></div>`);
			},
			right: ($$renderer) => {
				$$renderer.push(`<div slot="right" class="hstack gap-2" data-layout-actions="right">`);
				if (slots.right) {
					$$renderer.push("<!--[0-->");
					slots.right($$renderer);
					$$renderer.push(`<!---->`);
				} else {
					$$renderer.push("<!--[-1-->");
					$$renderer.push(`<div class="hstack gap-2">`);
					if (hasPermission(Permissions.MANAGE_PLAYERS)) {
						$$renderer.push("<!--[0-->");
						$$renderer.push(`<button${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("buttons.delete"))}${attr_class("btn btn-link link-danger", void 0, { "disabled": store_get($$store_subs ??= {}, "$user", user).username === data.player.username || data.player.permissionGroup === "admin" && !store_get($$store_subs ??= {}, "$user", user).admin })}${attr("title", store_get($$store_subs ??= {}, "$_", $format)("buttons.delete"))}><i class="fas fa-trash"></i></button> `);
						if (data.player.isBanned) {
							$$renderer.push("<!--[0-->");
							$$renderer.push(`<button${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("pages.player-detail.un-ban"))}${attr_class("btn btn-link", void 0, { "disabled": store_get($$store_subs ??= {}, "$user", user).username === data.player.username || data.player.permissionGroup === "admin" && !store_get($$store_subs ??= {}, "$user", user).admin })}${attr("title", store_get($$store_subs ??= {}, "$_", $format)("pages.player-detail.un-ban"))}><i class="fas fa-gavel"></i></button>`);
						} else {
							$$renderer.push("<!--[-1-->");
							$$renderer.push(`<button${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("pages.player-detail.ban"))}${attr_class("btn btn-link link-danger", void 0, { "disabled": store_get($$store_subs ??= {}, "$user", user).username === data.player.username || data.player.permissionGroup === "admin" && !store_get($$store_subs ??= {}, "$user", user).admin })}${attr("title", store_get($$store_subs ??= {}, "$_", $format)("pages.player-detail.ban"))}><i class="fas fa-gavel"></i></button>`);
						}
						$$renderer.push(`<!--]--> `);
						if (!data.player.isEmailVerified) {
							$$renderer.push("<!--[0-->");
							$$renderer.push(`<button${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("pages.player-detail.send-verification-mail"))}${attr_class("btn btn-link", void 0, { "disabled": store_get($$store_subs ??= {}, "$user", user).username === data.player.username || data.player.permissionGroup === "admin" && !store_get($$store_subs ??= {}, "$user", user).admin || !store_get($$store_subs ??= {}, "$siteInfo", siteInfo).emailEnabled })}${attr("title", store_get($$store_subs ??= {}, "$_", $format)("pages.player-detail.send-verification-mail"))}><i class="fas fa-envelope"></i></button>`);
						} else $$renderer.push("<!--[-1-->");
						$$renderer.push(`<!--]--> <a${attr("href", `${stringify(base)}/permissions`)}${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("pages.player-detail.authorize"))}${attr_class("btn btn-link", void 0, { "disabled": store_get($$store_subs ??= {}, "$user", user).username === data.player.username || data.player.permissionGroup === "admin" && !store_get($$store_subs ??= {}, "$user", user).admin })}${attr("title", store_get($$store_subs ??= {}, "$_", $format)("pages.player-detail.authorize"))}><i class="fas fa-user-circle"></i></a>`);
					} else $$renderer.push("<!--[-1-->");
					$$renderer.push(`<!--]--> `);
					if (hasPermission(Permissions.MANAGE_PLAYERS) || store_get($$store_subs ??= {}, "$user", user).username === data.player.username) {
						$$renderer.push("<!--[0-->");
						$$renderer.push(`<button${attr_class("btn btn-secondary", void 0, { "disabled": data.player.permissionGroup === "admin" && !store_get($$store_subs ??= {}, "$user", user).admin })}><i class="fas fa-pencil-alt"></i> <span class="d-lg-inline d-none ms-2">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.edit"))}</span></button>`);
					} else $$renderer.push("<!--[-1-->");
					$$renderer.push(`<!--]--></div>`);
				}
				$$renderer.push(`<!--]--></div>`);
			}
		} });
		$$renderer.push(`<!----> <div class="row g-3"><div class="col-lg-9 vstack gap-3">`);
		children($$renderer);
		$$renderer.push(`<!----></div> <div class="col-lg-3"><div class="card"><div class="card-header bg-transparent">${escape_html(data.player.username)}</div> <div class="card-body d-flex flex-column align-items-center vstack gap-3"><img${attr("alt", data.player.username)}${attr_class("img-thumbnail rounded", void 0, {
			"border": isOnline() || data.player.isBanned,
			"border-3": isOnline() || data.player.isBanned,
			"border-success": !data.player.isBanned && isOnline(),
			"border-danger": data.player.isBanned
		})} width="128" height="128"${attr("src", `/api/profile/picture/${stringify(data.player.username)}?${stringify(store_get($$store_subs ??= {}, "$avatarVersion", avatarVersion))}`)} onload="this.__e=event" onerror="this.__e=event"/></div> <div class="card-body"><table class="table table-sm table-borderless mb-0"><tbody><tr><td>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.player-detail.status"))}</td><td>`);
		PlayerStatusBadge($$renderer, {
			banned: data.player.isBanned,
			lastActivityTime: data.player.lastActivityTime,
			inGame: data.player.inGame,
			checkTime
		});
		$$renderer.push(`<!----></td></tr><tr><td>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.players.table.perm-group"))}</td><td>`);
		PlayerPermissionBadge($$renderer, { permissionGroup: data.player.permissionGroup });
		$$renderer.push(`<!----></td></tr><tr><td>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.player-detail.email"))}</td><td><span${attr_class(`badge ${data.player.isEmailVerified ? "text-bg-success" : "text-bg-danger"}`)}>`);
		if (data.player.isEmailVerified) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.player-detail.email-verified"))}`);
		} else {
			$$renderer.push("<!--[-1-->");
			$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.player-detail.email-not-verified"))}`);
		}
		$$renderer.push(`<!--]--></span></td></tr><tr><td>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.player-detail.last-entrance"))}</td><td>`);
		Date_1($$renderer, { time: data.player.lastLoginDate });
		$$renderer.push(`<!----></td></tr><tr><td>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.player-detail.register-date"))}</td><td>`);
		Date_1($$renderer, { time: data.player.registerDate });
		$$renderer.push(`<!----></td></tr><tr><td>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.player-detail.register-ip"))}</td><td>${escape_html(data.player.registeredIp)}</td></tr></tbody></table></div></div> `);
		Hook($$renderer, {
			name: "panel:player-detail:sidebar",
			playerData: data
		});
		$$renderer.push(`<!----></div></div></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
	});
}

export { PlayerDetailLayout_exports as P, PlayerDetailLayout as a, load as l };
//# sourceMappingURL=PlayerDetailLayout.js-DxKEQet7.js.map
