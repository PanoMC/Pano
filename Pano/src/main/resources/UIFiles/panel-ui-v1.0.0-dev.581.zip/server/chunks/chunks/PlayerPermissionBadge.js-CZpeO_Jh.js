import { b as base } from './internal.js-BRN1McAa.js';
import { N as fallback, Z as escape_html, Q as store_get, S as unsubscribe_stores, O as bind_props, T as attr, U as stringify } from './index-server.js-DdhL7Abu.js';
import './server.js-BlClO2ED.js';
import './internal2.js-CNe5OZUJ.js';
import './routing.js-N-OPb2ye.js';
import { $ as $format } from './runtime.js-BzHEw_ze.js';
import './tooltip.util.js-BeLZL-Tj.js';

//#region src/lib/components/badges/PlayerStatusBadge.svelte
String.prototype.capitalize = function() {
	return this.charAt(0).toUpperCase() + this.slice(1);
};
function PlayerStatusBadge($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let isOnline;
		let banned = fallback($$props["banned"], false);
		let lastActivityTime = fallback($$props["lastActivityTime"], 0);
		let inGame = fallback($$props["inGame"], 0);
		let checkTime = fallback($$props["checkTime"], 0);
		isOnline = lastActivityTime > Date.now() - 3e5 || inGame;
		if (banned) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<div class="badge rounded-pill text-bg-danger"><i class="fa-solid fa-hammer me-1"></i> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.player-status-badge.banned"))}</div>`);
		} else if (isOnline) {
			$$renderer.push("<!--[1-->");
			$$renderer.push(`<div class="badge rounded-pill text-bg-success"><span>`);
			if (inGame) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<i class="fa-solid fa-gamepad me-1"></i>`);
			} else {
				$$renderer.push("<!--[-1-->");
				$$renderer.push(`<i class="fa-solid fa-globe me-1"></i>`);
			}
			$$renderer.push(`<!--]--> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.player-status-badge.online"))}</span></div>`);
		} else {
			$$renderer.push("<!--[-1-->");
			$$renderer.push(`<div class="badge rounded-pill text-bg-primary"><span>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.player-status-badge.offline"))}</span></div>`);
		}
		$$renderer.push(`<!--]-->`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
		bind_props($$props, {
			banned,
			lastActivityTime,
			inGame,
			checkTime
		});
	});
}
//#endregion
//#region src/lib/components/badges/PlayerPermissionBadge.svelte
String.prototype.capitalize = function() {
	return this.charAt(0).toUpperCase() + this.slice(1);
};
function PlayerPermissionBadge($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let permissionGroup = $$props["permissionGroup"];
		String.prototype.capitalize = function() {
			return this.charAt(0).toUpperCase() + this.slice(1);
		};
		$$renderer.push(`<a class="badge rounded-pill text-bg-secondary focus-ring text-decoration-none"${attr("title", store_get($$store_subs ??= {}, "$_", $format)("components.player-permission-badge.filter"))}${attr("href", `${stringify(base)}/players?permissionGroup=${stringify(permissionGroup.name)}`)}>${escape_html(permissionGroup.displayName.capitalize())}</a>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
		bind_props($$props, { permissionGroup });
	});
}

export { PlayerStatusBadge as P, PlayerPermissionBadge as a };
//# sourceMappingURL=PlayerPermissionBadge.js-CZpeO_Jh.js.map
