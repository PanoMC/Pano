import { e as error } from './exports2.js-VkmSkXbz.js';
import { Z as escape_html, Q as store_get, P as ensure_array_like, V as attr_class, T as attr, S as unsubscribe_stores } from './index-server.js-DdhL7Abu.js';
import './stores.js-D5xmrOAP.js';
import { b as ApiUtil } from './Store.js-DT3aZHRb.js';
import { $ as $format } from './runtime.js-BzHEw_ze.js';
import './ToastContainer.js-Bv1jJ2dr.js';
import { D as Date_1 } from './Date.js-DCZp_jrB.js';
import './tooltip.util.js-BeLZL-Tj.js';
import { N as NoContent } from './NoContent.js-Coj2fA9d.js';
import { p as parseUserAgent } from './string.util.js-Pwbw6tDM.js';

//#region src/lib/pages/players/PlayerSessions.svelte
async function load(event) {
	const data = { ...await event.parent() };
	const username = event.params.username;
	const body = await ApiUtil.get({
		path: `/api/panel/players/${username}/sessions`,
		request: event
	});
	if (!body.error) data.sessions = body.sessions;
	else throw error(500, body.error);
	return data;
}
function PlayerSessions($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let { data } = $$props;
		let loadingSessionId = null;
		$$renderer.push(`<div class="card"><div class="card-header">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.player-detail.sessions"))}</div> `);
		if (!data.sessions || data.sessions.length === 0) {
			$$renderer.push("<!--[0-->");
			NoContent($$renderer, {});
		} else {
			$$renderer.push("<!--[-1-->");
			$$renderer.push(`<div class="table-responsive"><table class="table table-hover"><thead><tr><th class="align-middle">ID</th><th class="align-middle"></th><th class="align-middle">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.player-detail.browser"))}</th><th class="align-middle">IP</th><th class="align-middle">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.player-detail.last-entrance"))}</th><th class="align-middle">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.player-detail.expire-date"))}</th><th class="align-middle"></th></tr></thead><tbody><!--[-->`);
			const each_array = ensure_array_like(data.sessions);
			for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
				let session = each_array[$$index];
				$$renderer.push(`<tr${attr_class("", void 0, { "table-active": session.isCurrent })}><td class="align-middle"><code>#${escape_html(session.id)}</code></td><td class="align-middle">`);
				if (session.isCurrent) {
					$$renderer.push("<!--[0-->");
					$$renderer.push(`<span class="badge text-bg-primary">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.player-detail.current-session"))}</span>`);
				} else $$renderer.push("<!--[-1-->");
				$$renderer.push(`<!--]--></td><td class="align-middle"><span>${escape_html(parseUserAgent(session.userAgent))}</span></td><td class="align-middle"><code>${escape_html(session.ip)}</code></td><td class="align-middle">`);
				Date_1($$renderer, { time: session.lastActivityTime });
				$$renderer.push(`<!----></td><td class="align-middle">`);
				Date_1($$renderer, { time: session.expireDate });
				$$renderer.push(`<!----></td><td class="align-middle text-end"><button class="btn btn-link text-danger"${attr("title", store_get($$store_subs ??= {}, "$_", $format)("buttons.logout"))}${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("buttons.logout"))}${attr("disabled", loadingSessionId === session.id, true)}>`);
				if (loadingSessionId === session.id) {
					$$renderer.push("<!--[0-->");
					$$renderer.push(`<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>`);
				} else {
					$$renderer.push("<!--[-1-->");
					$$renderer.push(`<i class="fas fa-sign-out-alt"></i>`);
				}
				$$renderer.push(`<!--]--></button></td></tr>`);
			}
			$$renderer.push(`<!--]--></tbody></table></div>`);
		}
		$$renderer.push(`<!--]--></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
	});
}

export { PlayerSessions as P, load as l };
//# sourceMappingURL=PlayerSessions.js-Bn9kodNX.js.map
