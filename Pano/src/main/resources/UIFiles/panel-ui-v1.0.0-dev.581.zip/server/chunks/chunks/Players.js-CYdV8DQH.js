import { e as error } from './exports2.js-VkmSkXbz.js';
import { b as base } from './internal.js-BRN1McAa.js';
import { J as getContext, a0 as onDestroy, Q as store_get, Z as escape_html, P as ensure_array_like, V as attr_class, S as unsubscribe_stores, O as bind_props, T as attr, U as stringify, N as fallback } from './index-server.js-DdhL7Abu.js';
import './stores.js-D5xmrOAP.js';
import './server.js-BlClO2ED.js';
import './internal2.js-CNe5OZUJ.js';
import './routing.js-N-OPb2ye.js';
import { e as buildQueryParams, b as ApiUtil, f as avatarVersion } from './Store.js-DT3aZHRb.js';
import { $ as $format } from './runtime.js-BzHEw_ze.js';
import './ToastContainer.js-Bv1jJ2dr.js';
import { h as hasPermission, P as Permissions } from './auth.util.js-C77uoaNq.js';
import { l as locale_exports } from './locale.js-DgLiJnqO.js';
import { i as intervalToDuration } from './intervalToDuration.js-Bqoo9ab3.js';
import { B as BanHistoryRow, a as BanSourceBadge, f as formatDuration } from './BanHistoryRow.js-5e9qraff.js';
import { D as Date_1 } from './Date.js-DCZp_jrB.js';
import { c as currentLanguage } from './language.util.js-ByanOnuS.js';
import './tooltip.util.js-BeLZL-Tj.js';
import { H as Hook } from './SiteNavigationMenu.js-DeoPp7eK.js';
import { N as NoContent } from './NoContent.js-Coj2fA9d.js';
import { S as SearchInput } from './SearchInput.js-DPW0WADK.js';
import { C as CardHeader } from './CardHeader.js-XBureLRg.js';
import { P as Pagination } from './Pagination.js-sd1xTcbW.js';
import { C as CardFilters, a as CardFiltersItem } from './CardFiltersItem.js-n0hSsrtm.js';
import { P as PageActions } from './PageActions.js-co-RIHDp.js';
import { P as PageNav, a as PageNavItem } from './PageNav.js-Bzzuwwjz.js';
import { a as PlayerPermissionBadge, P as PlayerStatusBadge } from './PlayerPermissionBadge.js-CZpeO_Jh.js';

//#region src/lib/components/rows/PlayerRow.svelte
function PlayerRow($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		const user = getContext("user");
		let player = $$props["player"];
		let checkTime = $$props["checkTime"];
		let hideStatus = fallback($$props["hideStatus"], false);
		$$renderer.push(`<tr${attr_class("", void 0, { "table-active": player.selected })}><th scope="row" class="align-middle text-center"><div class="dropdown position-static"><button type="button" class="btn btn-link" aria-expanded="false" aria-haspopup="true" data-bs-toggle="dropdown"${attr("title", store_get($$store_subs ??= {}, "$_", $format)("components.player-row.actions"))}${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("components.player-row.actions"))}><span class="fas fa-ellipsis-v"></span></button> <div class="dropdown-menu dropdown-menu-start">`);
		if (!hideStatus && hasPermission(Permissions.MANAGE_PERMISSION_GROUPS)) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<a${attr("href", `${stringify(base)}/permissions`)}${attr_class("dropdown-item", void 0, { "disabled": store_get($$store_subs ??= {}, "$user", user).username === player.username || player.permissionGroup === "admin" && !store_get($$store_subs ??= {}, "$user", user).admin })}><i class="fas fa-user-circle me-2"></i> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.player-row.authorize"))}</a>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--> <button type="button"${attr_class("dropdown-item", void 0, { "disabled": player.permissionGroup === "admin" && !store_get($$store_subs ??= {}, "$user", user).admin })}><i class="fa-solid fa-pencil-alt me-2"></i> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.edit"))}</button> <button type="button"${attr_class("dropdown-item", void 0, {
			"link-danger": !player.isBanned,
			"disabled": store_get($$store_subs ??= {}, "$user", user).username === player.username || player.permissionGroup === "admin" && !store_get($$store_subs ??= {}, "$user", user).admin
		})}><i class="fas fa-gavel me-2"></i> `);
		if (player.isBanned) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.player-row.remove-ban"))}`);
		} else {
			$$renderer.push("<!--[-1-->");
			$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.player-row.ban"))}`);
		}
		$$renderer.push(`<!--]--></button></div></div></th>`);
		Hook($$renderer, {
			name: "panel:players:table:row:start",
			player,
			tag: "td",
			class: "align-middle text-nowrap"
		});
		$$renderer.push(`<!----><td class="align-middle" style="max-width: 200px;"><div class="text-truncate d-flex align-items-center"><a${attr_class("rounded focus-ring text-decoration-none text-truncate d-flex align-items-center", void 0, {
			"text-danger": player.isBanned,
			"text-decoration-line-through": player.isBanned
		})}${attr("title", player.username)}${attr("href", `${stringify(base)}/players/detail/${stringify(player.username)}`)}><img${attr("src", `/api/profile/picture/${stringify(player.username)}?${stringify(store_get($$store_subs ??= {}, "$avatarVersion", avatarVersion))}`)}${attr("alt", player.username)} width="32" height="32" class="rounded-circle me-2 flex-shrink-0"/> <span class="text-truncate">${escape_html(player.username)}</span></a></div></td>`);
		Hook($$renderer, {
			name: "panel:players:table:row:after-name",
			player,
			tag: "td",
			class: "align-middle text-nowrap"
		});
		$$renderer.push(`<!----><td class="align-middle text-nowrap text-capitalize">`);
		PlayerPermissionBadge($$renderer, { permissionGroup: player.permissionGroup });
		$$renderer.push(`<!----></td>`);
		Hook($$renderer, {
			name: "panel:players:table:row:after-perm-group",
			player,
			tag: "td",
			class: "align-middle text-nowrap"
		});
		$$renderer.push(`<!---->`);
		if (!hideStatus) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<td class="align-middle text-nowrap">`);
			PlayerStatusBadge($$renderer, {
				banned: player.isBanned,
				lastActivityTime: player.lastActivityTime,
				inGame: player.inGame,
				checkTime
			});
			$$renderer.push(`<!----></td> `);
			Hook($$renderer, {
				name: "panel:players:table:row:after-status",
				player,
				tag: "td",
				class: "align-middle text-nowrap"
			});
			$$renderer.push(`<!---->`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--><td class="align-middle text-nowrap">`);
		Date_1($$renderer, { time: hideStatus ? player.bannedAt : player.lastLoginDate });
		$$renderer.push(`<!----></td>`);
		Hook($$renderer, {
			name: "panel:players:table:row:after-last-login",
			player,
			tag: "td",
			class: "align-middle text-nowrap"
		});
		$$renderer.push(`<!----><td class="align-middle text-nowrap">`);
		Date_1($$renderer, { time: player.registerDate });
		$$renderer.push(`<!----></td>`);
		Hook($$renderer, {
			name: "panel:players:table:row:end",
			player,
			tag: "td",
			class: "align-middle text-nowrap"
		});
		$$renderer.push(`<!----></tr>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
		bind_props($$props, {
			player,
			checkTime,
			hideStatus
		});
	});
}
//#endregion
//#region src/lib/components/rows/IpBanRow.svelte
function IpBanRow($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let bannedIp = $$props["bannedIp"];
		function isActive(bannedUntil) {
			return bannedUntil > Date.now();
		}
		function getRemainingDurationText(bannedUntil) {
			const duration = intervalToDuration({
				start: Date.now(),
				end: new Date(bannedUntil)
			});
			const obj = {};
			if (duration.years) obj.years = duration.years;
			if (duration.months) obj.months = duration.months;
			if (duration.days) obj.days = duration.days;
			if (duration.hours) obj.hours = duration.hours;
			if (duration.minutes && !duration.years && !duration.months) obj.minutes = duration.minutes;
			if (Object.keys(obj).length === 0) obj.minutes = 1;
			return formatDuration(obj, { locale: locale_exports[store_get($$store_subs ??= {}, "$currentLanguage", currentLanguage).dateFnsCode] });
		}
		$$renderer.push(`<tr><th scope="row" class="align-middle text-center">`);
		if (hasPermission(Permissions.MANAGE_PLAYERS)) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<div class="dropdown position-static"><button type="button" class="btn btn-link" aria-expanded="false" aria-haspopup="true" data-bs-toggle="dropdown"${attr("title", store_get($$store_subs ??= {}, "$_", $format)("components.player-row.actions"))}${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("components.player-row.actions"))}><span class="fas fa-ellipsis-v"></span></button> <div class="dropdown-menu dropdown-menu-start"><button type="button" class="dropdown-item link-danger"><i class="fas fa-trash me-2"></i> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.ip-bans.remove"))}</button></div></div>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--></th><td class="align-middle"><code class="user-select-all">${escape_html(bannedIp.ip)}</code></td><td class="align-middle text-nowrap">`);
		if (bannedIp.bannedUntil) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<span>${escape_html(isActive(bannedIp.bannedUntil) ? getRemainingDurationText(bannedIp.bannedUntil) : store_get($$store_subs ??= {}, "$_", $format)("pages.ip-bans.expired"))}</span>`);
		} else {
			$$renderer.push("<!--[-1-->");
			$$renderer.push(`<span>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.player-detail.permanent-ban"))}</span>`);
		}
		$$renderer.push(`<!--]--></td><td class="align-middle" style="max-width: 280px;"><div class="text-truncate">`);
		if (bannedIp.reason) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<span>${escape_html(bannedIp.reason)}</span>`);
		} else {
			$$renderer.push("<!--[-1-->");
			$$renderer.push(`<span>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.player-detail.no-reason"))}</span>`);
		}
		$$renderer.push(`<!--]--></div></td><td class="align-middle">`);
		if (bannedIp.source) {
			$$renderer.push("<!--[0-->");
			BanSourceBadge($$renderer, { source: bannedIp.source });
		} else {
			$$renderer.push("<!--[-1-->");
			$$renderer.push(`<span class="opacity-50">-</span>`);
		}
		$$renderer.push(`<!--]--></td><td class="align-middle" style="max-width: 180px;"><div class="text-truncate d-flex align-items-center">`);
		if (bannedIp.bannedBy) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<a${attr("href", `${stringify(base)}/players/detail/${stringify(bannedIp.bannedBy)}`)}${attr("title", store_get($$store_subs ??= {}, "$_", $format)("buttons.view"))} class="rounded focus-ring text-decoration-none text-truncate d-flex align-items-center"><img${attr("src", `/api/profile/picture/${stringify(bannedIp.bannedBy)}?${stringify(store_get($$store_subs ??= {}, "$avatarVersion", avatarVersion))}`)}${attr("alt", bannedIp.bannedBy)} class="rounded-circle me-2 flex-shrink-0" height="24" width="24"/> <span class="text-truncate">${escape_html(bannedIp.bannedBy)}</span></a>`);
		} else {
			$$renderer.push("<!--[-1-->");
			$$renderer.push(`<span class="badge text-bg-primary">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.player-detail.system-ban"))}</span>`);
		}
		$$renderer.push(`<!--]--></div></td><td class="align-middle text-nowrap">`);
		Date_1($$renderer, { time: bannedIp.createdAt });
		$$renderer.push(`<!----></td></tr>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
		bind_props($$props, { bannedIp });
	});
}
//#endregion
//#region src/lib/pages/Players.svelte
var Views = Object.freeze({
	PLAYERS: "PLAYERS",
	BANS: "BANS",
	IP_BANS: "IP_BANS"
});
var PageTypes = Object.freeze({
	ALL: "ALL",
	HAS_PERM: "HAS_PERM",
	BANNED: "BANNED"
});
var DefaultPageType = PageTypes.ALL;
var IpBanStatuses = Object.freeze({
	ACTIVE: "ACTIVE",
	HISTORY: "HISTORY"
});
var DefaultIpBanStatus = IpBanStatuses.ACTIVE;
async function load(event) {
	const { parent, url: { searchParams } } = event;
	await parent();
	const page = parseInt(searchParams.get("page")) || 1;
	const permissionGroup = searchParams.get("permissionGroup");
	const view = searchParams.get("view") || Views.PLAYERS;
	const pageType = view === Views.BANS ? PageTypes.BANNED : searchParams.get("pageType") || DefaultPageType;
	const search = searchParams.get("search");
	const ipBanParam = searchParams.get("ipBanStatus")?.toUpperCase();
	const ipBanStatus = view === Views.IP_BANS && Object.values(IpBanStatuses).includes(ipBanParam) ? ipBanParam : DefaultIpBanStatus;
	if (!Object.values(PageTypes).includes(pageType)) throw error(404, "PAGE_NOT_FOUND");
	const queryParams = buildQueryParams({
		page,
		status: pageType,
		view,
		permissionGroup,
		search,
		ipBanStatus: view === Views.IP_BANS ? ipBanStatus : void 0
	});
	const body = await ApiUtil.get({
		path: `/api/panel/players` + queryParams,
		request: event
	});
	if (body.error) {
		if (body.error === "PAGE_NOT_FOUND") throw error(404, body.error);
		throw error(500, body.error);
	}
	body.page = page;
	body.pageType = pageType;
	body.search = search;
	body.view = view;
	body.ipBanStatus = view === Views.IP_BANS ? ipBanStatus : void 0;
	return body;
}
function Players($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let data = $$props["data"];
		let search = data.search || "";
		let isSearching = false;
		let checkTime = 0;
		let interval;
		const pageTitle = getContext("pageTitle");
		getContext("user");
		/**
		* @param {'ACTIVE' | 'HISTORY'} status
		*/
		function ipBansFilterQuery(status) {
			return buildQueryParams({
				view: "IP_BANS",
				ipBanStatus: status,
				page: 1,
				search: search || void 0
			});
		}
		onDestroy(() => {
			clearInterval(interval);
		});
		search = data.search || "";
		pageTitle.set(data.permissionGroup ? store_get($$store_subs ??= {}, "$_", $format)("pages.players.by-perm-group-title", { values: { permissionGroupName: data.permissionGroup.displayName || data.permissionGroup.name } }) : data.view === Views.BANS ? store_get($$store_subs ??= {}, "$_", $format)("pages.players.bans-history-title") : data.view === Views.IP_BANS ? store_get($$store_subs ??= {}, "$_", $format)("pages.players.ip-bans-title") : store_get($$store_subs ??= {}, "$_", $format)("pages.players.title", { values: { pageType: data.pageType === PageTypes.HAS_PERM ? store_get($$store_subs ??= {}, "$_", $format)("pages.players.authorized") + " " : data.pageType === PageTypes.BANNED ? store_get($$store_subs ??= {}, "$_", $format)("pages.players.banned") + " " : "" } }));
		$$renderer.push(`<div class="container vstack gap-3">`);
		PageActions($$renderer, { $$slots: {
			left: ($$renderer) => {
				PageNav($$renderer, {
					slot: "left",
					children: ($$renderer) => {
						PageNavItem($$renderer, {
							href: `/players?view=${stringify(Views.PLAYERS)}`,
							active: data.view === Views.PLAYERS,
							children: ($$renderer) => {
								$$renderer.push(`<!---->${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.players"))}`);
							}});
						$$renderer.push(`<!----> `);
						PageNavItem($$renderer, {
							href: `/players?view=${stringify(Views.BANS)}`,
							active: data.view === Views.BANS,
							children: ($$renderer) => {
								$$renderer.push(`<!---->${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.players.bans-history-title"))}`);
							}});
						$$renderer.push(`<!----> `);
						PageNavItem($$renderer, {
							href: `/players?view=${stringify(Views.IP_BANS)}`,
							active: data.view === Views.IP_BANS,
							children: ($$renderer) => {
								$$renderer.push(`<!---->${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.players.ip-bans-title"))}`);
							}});
						$$renderer.push(`<!---->`);
					},
					$$slots: { default: true }
				});
			},
			right: ($$renderer) => {
				$$renderer.push(`<div slot="right" class="hstack gap-2">`);
				if (data.view === Views.PLAYERS) {
					$$renderer.push("<!--[0-->");
					$$renderer.push(`<a${attr("href", `${stringify(base)}/migration`)} class="btn btn-secondary"><i class="fa fa-file-import"></i> <span class="d-lg-inline d-none ms-2">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.import"))}</span></a>`);
				} else $$renderer.push("<!--[-1-->");
				$$renderer.push(`<!--]--> `);
				if (data.view === Views.BANS) {
					$$renderer.push("<!--[0-->");
					$$renderer.push(`<button type="button" class="btn btn-danger"${attr("title", store_get($$store_subs ??= {}, "$_", $format)("pages.player-detail.ban"))}${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("pages.player-detail.ban"))}><i class="fas fa-gavel"></i> <span class="d-lg-inline d-none ms-2">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.player-detail.ban"))}</span></button>`);
				} else if (data.view === Views.IP_BANS) {
					$$renderer.push("<!--[1-->");
					$$renderer.push(`<button type="button" class="btn btn-danger"${attr("title", store_get($$store_subs ??= {}, "$_", $format)("pages.ip-bans.add-ban"))}${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("pages.ip-bans.add-ban"))}><i class="fas fa-network-wired"></i> <span class="d-lg-inline d-none ms-2">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.ip-bans.add-ban"))}</span></button>`);
				} else $$renderer.push("<!--[-1-->");
				$$renderer.push(`<!--]--></div>`);
			}
		} });
		$$renderer.push(`<!----> <div class="card">`);
		CardHeader($$renderer, { $$slots: {
			left: ($$renderer) => {
				$$renderer.push(`<div slot="left">`);
				if (data.view === Views.PLAYERS) {
					$$renderer.push("<!--[0-->");
					$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.players.table-title", { values: {
						playerCount: data.playerCount,
						pageType: data.pageType === PageTypes.HAS_PERM ? store_get($$store_subs ??= {}, "$_", $format)("pages.players.authorized") + " " : data.pageType === PageTypes.BANNED ? store_get($$store_subs ??= {}, "$_", $format)("pages.players.banned") + " " : ""
					} }))}`);
				} else if (data.view === Views.BANS) {
					$$renderer.push("<!--[1-->");
					$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.players.bans-history-title"))}`);
				} else {
					$$renderer.push("<!--[-1-->");
					$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.players.ip-bans-title"))}`);
				}
				$$renderer.push(`<!--]--></div>`);
			},
			middle: ($$renderer) => {
				$$renderer.push(`<div slot="middle" style="width: 250px;">`);
				SearchInput($$renderer, {
					initialValue: search,
					searching: isSearching,
					debounceMs: 500
				});
				$$renderer.push(`<!----></div>`);
			},
			right: ($$renderer) => {
				CardFilters($$renderer, {
					slot: "right",
					children: ($$renderer) => {
						if (data.view === Views.PLAYERS && !data.permissionGroup) {
							$$renderer.push("<!--[0-->");
							CardFiltersItem($$renderer, {
								href: "/players",
								active: data.pageType === PageTypes.ALL,
								children: ($$renderer) => {
									$$renderer.push(`<!---->${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.players.all"))}`);
								}});
							$$renderer.push(`<!----> `);
							CardFiltersItem($$renderer, {
								href: "/players?pageType=HAS_PERM",
								active: data.pageType === PageTypes.HAS_PERM,
								children: ($$renderer) => {
									$$renderer.push(`<!---->${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.players.authorized"))}`);
								}});
							$$renderer.push(`<!----> `);
							CardFiltersItem($$renderer, {
								href: "/players?pageType=BANNED",
								active: data.pageType === PageTypes.BANNED,
								children: ($$renderer) => {
									$$renderer.push(`<!---->${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.players.banned"))}`);
								}});
							$$renderer.push(`<!---->`);
						} else if (data.view === Views.IP_BANS) {
							$$renderer.push("<!--[1-->");
							CardFiltersItem($$renderer, {
								href: `/players${stringify(ipBansFilterQuery("ACTIVE"))}`,
								active: data.ipBanStatus === "ACTIVE",
								children: ($$renderer) => {
									$$renderer.push(`<!---->${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.ip-bans.filter-active"))}`);
								}});
							$$renderer.push(`<!----> `);
							CardFiltersItem($$renderer, {
								href: `/players${stringify(ipBansFilterQuery("HISTORY"))}`,
								active: data.ipBanStatus === "HISTORY",
								children: ($$renderer) => {
									$$renderer.push(`<!---->${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.ip-bans.filter-history"))}`);
								}});
							$$renderer.push(`<!---->`);
						} else $$renderer.push("<!--[-1-->");
						$$renderer.push(`<!--]-->`);
					},
					$$slots: { default: true }
				});
			}
		} });
		$$renderer.push(`<!----> `);
		if (data.playerCount === 0) {
			$$renderer.push("<!--[0-->");
			NoContent($$renderer, {});
		} else {
			$$renderer.push("<!--[-1-->");
			if (data.view === Views.BANS) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<div class="table-responsive"><table class="table table-hover"><thead><tr><th class="align-middle text-nowrap" scope="col">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.players.table.name"))}</th><th class="align-middle text-nowrap" scope="col">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.player-detail.ban-duration"))}</th><th class="align-middle text-nowrap" scope="col">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.player-detail.ban-reason"))}</th><th class="align-middle text-nowrap text-center" scope="col">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.player-detail.email-notification"))}</th><th class="align-middle text-nowrap" scope="col">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.player-detail.banned-by"))}</th><th class="align-middle text-nowrap" scope="col">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.player-detail.ban-source"))}</th><th class="align-middle text-nowrap" scope="col">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.player-detail.banned-at"))}</th></tr></thead><tbody><!--[-->`);
				const each_array = ensure_array_like(data.players);
				for (let index = 0, $$length = each_array.length; index < $$length; index++) {
					let banHistory = each_array[index];
					BanHistoryRow($$renderer, {
						banHistory,
						showBannedPlayer: true
					});
				}
				$$renderer.push(`<!--]--></tbody></table></div>`);
			} else if (data.view === Views.IP_BANS) {
				$$renderer.push("<!--[1-->");
				$$renderer.push(`<div class="table-responsive"><table class="table table-hover"><thead><tr><th class="align-middle text-nowrap" scope="col"></th><th class="align-middle text-nowrap" scope="col">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.ip-bans.ip"))}</th><th class="align-middle text-nowrap" scope="col">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.player-detail.ban-duration"))}</th><th class="align-middle text-nowrap" scope="col">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.player-detail.ban-reason"))}</th><th class="align-middle text-nowrap" scope="col">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.player-detail.ban-source"))}</th><th class="align-middle text-nowrap" scope="col">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.player-detail.banned-by"))}</th><th class="align-middle text-nowrap" scope="col">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.player-detail.banned-at"))}</th></tr></thead><tbody><!--[-->`);
				const each_array_1 = ensure_array_like(data.players);
				for (let $$index_1 = 0, $$length = each_array_1.length; $$index_1 < $$length; $$index_1++) {
					let bannedIp = each_array_1[$$index_1];
					IpBanRow($$renderer, { bannedIp });
				}
				$$renderer.push(`<!--]--></tbody></table></div>`);
			} else {
				$$renderer.push("<!--[-1-->");
				$$renderer.push(`<div class="table-responsive"><table class="table table-hover"><thead><tr><th class="align-middle text-nowrap" scope="col"></th>`);
				Hook($$renderer, {
					name: "panel:players:table:header:start",
					tag: "th",
					class: "align-middle text-nowrap",
					scope: "col"
				});
				$$renderer.push(`<!----><th class="align-middle text-nowrap" scope="col">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.players.table.name"))}</th>`);
				Hook($$renderer, {
					name: "panel:players:table:header:after-name",
					tag: "th",
					class: "align-middle text-nowrap",
					scope: "col"
				});
				$$renderer.push(`<!----><th${attr_class("align-middle text-nowrap", void 0, { "table-active": data.permissionGroup })} scope="col">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.players.table.perm-group"))}</th>`);
				Hook($$renderer, {
					name: "panel:players:table:header:after-perm-group",
					tag: "th",
					class: "align-middle text-nowrap",
					scope: "col"
				});
				$$renderer.push(`<!----><th class="align-middle text-nowrap" scope="col">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.players.table.status"))}</th>`);
				Hook($$renderer, {
					name: "panel:players:table:header:after-status",
					tag: "th",
					class: "align-middle text-nowrap",
					scope: "col"
				});
				$$renderer.push(`<!----><th class="align-middle text-nowrap" scope="col">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.players.table.last-login"))}</th>`);
				Hook($$renderer, {
					name: "panel:players:table:header:after-last-login",
					tag: "th",
					class: "align-middle text-nowrap",
					scope: "col"
				});
				$$renderer.push(`<!----><th class="align-middle text-nowrap" scope="col">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.players.table.register-date"))}</th>`);
				Hook($$renderer, {
					name: "panel:players:table:header:end",
					tag: "th",
					class: "align-middle text-nowrap",
					scope: "col"
				});
				$$renderer.push(`<!----></tr></thead><tbody><!--[-->`);
				const each_array_2 = ensure_array_like(data.players);
				for (let $$index_2 = 0, $$length = each_array_2.length; $$index_2 < $$length; $$index_2++) {
					let player = each_array_2[$$index_2];
					PlayerRow($$renderer, {
						player,
						checkTime
					});
				}
				$$renderer.push(`<!--]--></tbody></table></div>`);
			}
			$$renderer.push(`<!--]--> <div class="card-footer">`);
			Pagination($$renderer, {
				page: data.page,
				totalPage: data.totalPage
			});
			$$renderer.push(`<!----></div>`);
		}
		$$renderer.push(`<!--]--></div></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
		bind_props($$props, { data });
	});
}

export { Players as P, load as l };
//# sourceMappingURL=Players.js-CYdV8DQH.js.map
