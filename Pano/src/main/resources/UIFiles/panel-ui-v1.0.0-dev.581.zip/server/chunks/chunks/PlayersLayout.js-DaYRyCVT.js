import { _ as __exportAll } from './rolldown-runtime.js-BMnQIuNT.js';
import { r as redirect } from './exports2.js-VkmSkXbz.js';
import { b as base } from './internal.js-BRN1McAa.js';
import { W as slot } from './index-server.js-DdhL7Abu.js';
import './server.js-BlClO2ED.js';
import './internal2.js-CNe5OZUJ.js';
import './routing.js-N-OPb2ye.js';
import { h as hasPermission, P as Permissions } from './auth.util.js-C77uoaNq.js';
import { E as EditPlayerModal, C as ConfirmBanPlayerModal, U as UnbanPlayerModal } from './UnbanPlayerModal.js-BlpULLWg.js';
import { S as SearchPlayerModal } from './SearchPlayerModal.js-BcRLy3K7.js';
import { C as ConfirmBanIpModal, U as UnbanIpModal } from './UnbanIpModal.js-DUSG5GwD.js';
import { C as ConfirmDeletePlayerModal, a as ConfirmSendVerificationEmailModal } from './ConfirmSendVerificationEmailModal.js-CMMYyDqx.js';

//#region src/lib/layouts/PlayersLayout.svelte
var PlayersLayout_exports = /* @__PURE__ */ __exportAll({
	default: () => PlayersLayout,
	load: () => load
});
async function load({ parent, url: { pathname } }) {
	const parentData = await parent();
	const { user } = parentData;
	if (pathname.startsWith("/players/detail/")) return parentData;
	if (!hasPermission(Permissions.MANAGE_PLAYERS, user)) throw redirect(302, base);
	return parentData;
}
function PlayersLayout($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		$$renderer.push(`<!--[-->`);
		slot($$renderer, $$props, "default", {}, null);
		$$renderer.push(`<!--]--> `);
		EditPlayerModal($$renderer);
		$$renderer.push(`<!----> `);
		ConfirmBanPlayerModal($$renderer);
		$$renderer.push(`<!----> `);
		ConfirmBanIpModal($$renderer);
		$$renderer.push(`<!----> `);
		SearchPlayerModal($$renderer);
		$$renderer.push(`<!----> `);
		ConfirmDeletePlayerModal($$renderer);
		$$renderer.push(`<!----> `);
		UnbanPlayerModal($$renderer);
		$$renderer.push(`<!----> `);
		UnbanIpModal($$renderer);
		$$renderer.push(`<!----> `);
		ConfirmSendVerificationEmailModal($$renderer);
		$$renderer.push(`<!---->`);
	});
}

export { PlayersLayout_exports as P, PlayersLayout as a, load as l };
//# sourceMappingURL=PlayersLayout.js-DaYRyCVT.js.map
