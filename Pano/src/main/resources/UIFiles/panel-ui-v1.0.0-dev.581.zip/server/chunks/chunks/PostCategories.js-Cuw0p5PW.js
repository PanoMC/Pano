import { e as error } from './exports2.js-VkmSkXbz.js';
import { b as base } from './internal.js-BRN1McAa.js';
import { J as getContext, Z as escape_html, Q as store_get, P as ensure_array_like, S as unsubscribe_stores, O as bind_props, V as attr_class, T as attr, U as stringify, F as writable } from './index-server.js-DdhL7Abu.js';
import './stores.js-D5xmrOAP.js';
import './server.js-BlClO2ED.js';
import './internal2.js-CNe5OZUJ.js';
import './routing.js-N-OPb2ye.js';
import { e as buildQueryParams, b as ApiUtil } from './Store.js-DT3aZHRb.js';
import { $ as $format } from './runtime.js-BzHEw_ze.js';
import './ToastContainer.js-Bv1jJ2dr.js';
import { H as Hook } from './SiteNavigationMenu.js-DeoPp7eK.js';
import { N as NoContent } from './NoContent.js-Coj2fA9d.js';
import { S as SearchInput } from './SearchInput.js-DPW0WADK.js';
import { C as CardHeader } from './CardHeader.js-XBureLRg.js';
import { P as Pagination } from './Pagination.js-sd1xTcbW.js';
import { A as AddEditPostCategoryModal } from './AddEditPostCategoryModal.js-D1eTG-f5.js';

var category = writable({ posts: [] });
function ConfirmDeletePostCategoryModal($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let loading = false;
		$$renderer.push(`<div aria-hidden="true" class="modal fade" role="dialog" tabindex="-1"><div class="modal-dialog modal-dialog-centered" role="dialog"><div class="modal-content"><div class="modal-body text-center"><div class="pb-3"><i class="fas fa-question-circle fa-3x d-block m-auto text-gray"></i></div> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.confirm-delete-post-category.title"))} `);
		if (store_get($$store_subs ??= {}, "$category", category).postCount !== 0) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<div class="mt-3 alert alert-warning text-start mb-0"><p>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.confirm-delete-post-category.description"))}</p> <ul class="list-unstyled"><!--[-->`);
			const each_array = ensure_array_like(store_get($$store_subs ??= {}, "$category", category).posts);
			for (let index = 0, $$length = each_array.length; index < $$length; index++) {
				let post = each_array[index];
				$$renderer.push(`<li><a class="badge bg-warning rounded-pill"${attr("href", `${stringify(base)}/posts/detail/${stringify(post.id)}`)} target="_blank">${escape_html(post.title)}</a></li>`);
			}
			$$renderer.push(`<!--]--></ul></div> `);
			if (store_get($$store_subs ??= {}, "$category", category).postCount > 5) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.confirm-delete-post-category.more-posts", { values: { count: store_get($$store_subs ??= {}, "$category", category).postCount - 5 } }))}`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]-->`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--></div> <div class="modal-footer flex-nowrap"><button${attr_class("btn btn-link col-6 m-0", void 0, { "disabled": loading })} type="button">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.cancel"))}</button> <button${attr_class("btn btn-danger col-6 m-0", void 0, { "disabled": loading })} type="button">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.yes"))}</button></div></div></div></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
	});
}
//#endregion
//#region src/lib/components/rows/PostCategoryRow.svelte
function PostCategoryRow($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let category = $$props["category"];
		let index = $$props["index"];
		$$renderer.push(`<tr${attr_class("", void 0, { "table-active": category.selected })}><th scope="row" class="align-middle text-center"><button type="button"${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("buttons.delete"))}${attr("title", store_get($$store_subs ??= {}, "$_", $format)("buttons.delete"))} class="btn btn-link link-danger"><i class="fas fa-trash"></i></button></th>`);
		Hook($$renderer, {
			name: "panel:post-categories:table:row:start",
			category,
			tag: "td",
			class: "align-middle text-nowrap"
		});
		$$renderer.push(`<!----><td class="align-middle" style="max-width: 250px;"><div class="text-truncate"><button class="btn btn-link p-0 text-start text-decoration-none w-100 text-truncate" type="button"${attr("title", category.title)}>${escape_html(category.title)}</button></div></td>`);
		Hook($$renderer, {
			name: "panel:post-categories:table:row:after-category",
			category,
			tag: "td",
			class: "align-middle text-nowrap"
		});
		$$renderer.push(`<!----><td class="align-middle" style="max-width: 300px;"><div class="text-truncate"${attr("title", category.description)}>${escape_html(category.description)}</div></td>`);
		Hook($$renderer, {
			name: "panel:post-categories:table:row:after-description",
			category,
			tag: "td",
			class: "align-middle text-nowrap"
		});
		$$renderer.push(`<!----><td class="align-middle"><a class="rounded focus-ring"${attr("href", `${stringify("")}/blog/category/${stringify(category.url)}`)} target="_blank"${attr("title", store_get($$store_subs ??= {}, "$_", $format)("buttons.view"))}>/category/${escape_html(category.url)}</a></td>`);
		Hook($$renderer, {
			name: "panel:post-categories:table:row:after-url",
			category,
			tag: "td",
			class: "align-middle text-nowrap"
		});
		$$renderer.push(`<!----><td class="d-none"><input${attr("value", `#${stringify(category.color)}`)} class="form-control form-control-sm bg-transparent" disabled="" type="color"/></td>`);
		Hook($$renderer, {
			name: "panel:post-categories:table:row:end",
			category,
			tag: "td",
			class: "align-middle text-nowrap"
		});
		$$renderer.push(`<!----></tr>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
		bind_props($$props, {
			category,
			index
		});
	});
}
//#endregion
//#region src/lib/pages/posts/PostCategories.svelte
async function load(event) {
	const { parent, url: { searchParams } } = event;
	await parent();
	const page = searchParams.get("page") || 1;
	const search = searchParams.get("search");
	const queryParams = buildQueryParams({
		page,
		search
	});
	const body = await ApiUtil.get({
		path: `/api/panel/post/categories` + queryParams,
		request: event
	});
	if (body.error) {
		if (body.error === "NOT_EXISTS" || body.error === "PAGE_NOT_FOUND") throw error(404, body.error);
		throw error(500, body.error);
	}
	body.page = parseInt(page);
	body.search = search;
	return body;
}
function PostCategories($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		const { data = void 0 } = $$props;
		const pageTitle = getContext("pageTitle");
		const slots = getContext("layout-slots");
		Object.assign(slots, { right });
		pageTitle.set("pages.post-categories.title");
		let search = data.search || "";
		let isSearching = false;
		function right($$renderer) {
			$$renderer.push(`<button class="btn btn-secondary" type="button"><i class="fas fa-plus"></i> <span class="d-lg-inline d-none ms-2">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.post-categories.create-category-button"))}</span></button>`);
		}
		$$renderer.push(`<div class="card">`);
		CardHeader($$renderer, { $$slots: {
			left: ($$renderer) => {
				$$renderer.push(`<div slot="left">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.post-categories.card-title", { values: { count: data.categoryCount } }))}</div>`);
			},
			right: ($$renderer) => {
				$$renderer.push(`<div slot="right" style="width: 250px;">`);
				SearchInput($$renderer, {
					initialValue: search,
					searching: isSearching,
					debounceMs: 500
				});
				$$renderer.push(`<!----></div>`);
			}
		} });
		$$renderer.push(`<!----> `);
		if (data.categoryCount === 0) {
			$$renderer.push("<!--[0-->");
			NoContent($$renderer, {});
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--> `);
		if (data.categoryCount > 0) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<div class="table-responsive"><table class="table table-hover"><thead><tr><th scope="col"></th>`);
			Hook($$renderer, {
				name: "panel:post-categories:table:header:start",
				tag: "th",
				class: "align-middle text-nowrap",
				scope: "col"
			});
			$$renderer.push(`<!----><th class="align-middle text-nowrap" scope="col">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.post-categories.category"))}</th>`);
			Hook($$renderer, {
				name: "panel:post-categories:table:header:after-category",
				tag: "th",
				class: "align-middle text-nowrap",
				scope: "col"
			});
			$$renderer.push(`<!----><th scope="col" class="align-middle text-nowrap">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.post-categories.description"))}</th>`);
			Hook($$renderer, {
				name: "panel:post-categories:table:header:after-description",
				tag: "th",
				class: "align-middle text-nowrap",
				scope: "col"
			});
			$$renderer.push(`<!----><th scope="col" class="align-middle text-nowrap">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.post-categories.url"))}</th>`);
			Hook($$renderer, {
				name: "panel:post-categories:table:header:after-url",
				tag: "th",
				class: "align-middle text-nowrap",
				scope: "col"
			});
			$$renderer.push(`<!----><th scope="col" class="d-none align-middle text-nowrap">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.post-categories.color"))}</th>`);
			Hook($$renderer, {
				name: "panel:post-categories:table:header:end",
				tag: "th",
				class: "align-middle text-nowrap",
				scope: "col"
			});
			$$renderer.push(`<!----></tr></thead><tbody><!--[-->`);
			const each_array = ensure_array_like(data.categories);
			for (let index = 0, $$length = each_array.length; index < $$length; index++) {
				let category = each_array[index];
				PostCategoryRow($$renderer, {
					category,
					index
				});
			}
			$$renderer.push(`<!--]--></tbody></table></div> <div class="card-footer">`);
			Pagination($$renderer, {
				page: data.page,
				totalPage: data.totalPage
			});
			$$renderer.push(`<!----></div>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--></div> `);
		ConfirmDeletePostCategoryModal($$renderer);
		$$renderer.push(`<!----> `);
		AddEditPostCategoryModal($$renderer);
		$$renderer.push(`<!---->`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
		bind_props($$props, { data });
	});
}

export { PostCategories as P, load as l };
//# sourceMappingURL=PostCategories.js-Cuw0p5PW.js.map
