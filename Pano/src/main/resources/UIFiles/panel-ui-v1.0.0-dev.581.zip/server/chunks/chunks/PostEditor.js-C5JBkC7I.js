import { e as error } from './exports2.js-VkmSkXbz.js';
import { b as base } from './internal.js-BRN1McAa.js';
import { J as getContext, T as attr, U as stringify, Z as escape_html, Q as store_get, V as attr_class, S as unsubscribe_stores, O as bind_props, P as ensure_array_like } from './index-server.js-DdhL7Abu.js';
import './stores.js-D5xmrOAP.js';
import './server.js-BlClO2ED.js';
import './internal2.js-CNe5OZUJ.js';
import './routing.js-N-OPb2ye.js';
import { b as ApiUtil } from './Store.js-DT3aZHRb.js';
import { $ as $format } from './runtime.js-BzHEw_ze.js';
import './ToastContainer.js-Bv1jJ2dr.js';
import { D as Date_1 } from './Date.js-DCZp_jrB.js';
import { D as DragAndDropZone } from './DragAndDropZone.js-DkRk4oSS.js';
import { e as executeHookLoad, H as Hook } from './SiteNavigationMenu.js-DeoPp7eK.js';
import { E as Editor_1 } from './Editor.js-Cs5tQi--.js';
import { A as AddEditPostCategoryModal } from './AddEditPostCategoryModal.js-D1eTG-f5.js';

//#region src/lib/pages/PostEditor.svelte
var Modes = Object.freeze({
	EDIT: "edit",
	CREATE: "create"
});
var StatusTypes = Object.freeze({
	PUBLISHED: "PUBLISHED",
	DRAFT: "DRAFT",
	TRASH: "TRASH"
});
var DefaultMode = Modes.CREATE;
async function load(event, mode = DefaultMode) {
	const { parent } = event;
	await parent();
	let data = {
		post: {
			id: -1,
			title: "",
			text: "",
			category: -1,
			status: -1,
			date: 0,
			thumbnailUrl: ""
		},
		categoryCount: 0,
		categories: [],
		mode,
		error: {},
		hookProps: {}
	};
	if (mode === Modes.EDIT) {
		const id = parseInt(event.params.id) || -1;
		const postBody = await ApiUtil.get({
			path: `/api/panel/posts/${id}`,
			request: event
		});
		if (postBody.error) {
			if (postBody.error === "POST_NOT_FOUND") throw error(404, postBody.error);
			throw error(500, postBody.error);
		}
		postBody.id = id;
		data.post = postBody.post;
	}
	const categoriesBody = await ApiUtil.get({
		path: "/api/panel/post/categories",
		request: event
	});
	data = {
		...data,
		...categoriesBody
	};
	data.hookProps["panel:post-editor:content:bottom"] = await executeHookLoad("panel:post-editor:content:bottom", event);
	return data;
}
function PostEditor($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		const { data = void 0 } = $$props;
		let post = { ...data.post };
		let isEditorEmpty = true;
		let loading = false;
		const pageTitle = getContext("pageTitle");
		const slots = getContext("layout-slots");
		Object.assign(slots, {
			left,
			right
		});
		pageTitle.set(data.mode === Modes.EDIT ? "pages.post-editor.title-edit" : "pages.post-editor.title-create");
		function getStatusByPostStatus(status) {
			return status === StatusTypes.TRASH ? "pages.post-editor.trash" : status === StatusTypes.PUBLISHED ? "pages.post-editor.published" : status === StatusTypes.DRAFT ? "pages.post-editor.draft" : "pages.post-editor.new";
		}
		function left($$renderer) {
			$$renderer.push(`<a${attr("href", `${stringify(base)}/posts${post.status === StatusTypes.TRASH ? "?pageType=TRASH" : post.status === StatusTypes.DRAFT ? "?pageType=DRAFT" : ""}`)} class="btn btn-link" role="button"><i class="fas fa-arrow-left"></i> <span class="d-lg-inline d-none ms-2">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.post-editor.posts"))}</span></a>`);
		}
		function right($$renderer) {
			if (data.mode === Modes.EDIT) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<button${attr("title", store_get($$store_subs ??= {}, "$_", $format)("buttons.remove"))}${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("buttons.remove"))} class="btn btn-link" type="button"><i class="fas fa-trash"></i></button>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--> `);
			if (post.status !== StatusTypes.DRAFT && data.mode === Modes.EDIT) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<button${attr("title", store_get($$store_subs ??= {}, "$_", $format)("pages.post-editor.move-to-drafts"))}${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("pages.post-editor.move-to-drafts"))}${attr_class("btn btn-link", void 0, { "disabled": loading })} type="button"><i class="fa-solid fa-sheet-plastic"></i></button>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--> <a class="btn btn-link" role="button"${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("buttons.view"))}${attr("title", store_get($$store_subs ??= {}, "$_", $format)("buttons.view"))} target="_blank"${attr("href", `${stringify("")}/preview/post/${stringify(post.id)}`)}><i class="fas fa-eye"></i></a> `);
			if (post.status !== StatusTypes.PUBLISHED) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<button${attr("title", store_get($$store_subs ??= {}, "$_", $format)(data.mode === Modes.CREATE ? "buttons.save" : "buttons.update"))}${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)(data.mode === Modes.CREATE ? "buttons.save" : "buttons.update"))}${attr_class("btn btn-link", void 0, { "disabled": isEditorEmpty || post.title.length === 0 })} type="button"><i class="fas fa-save"></i></button>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--> <button${attr_class("btn btn-secondary", void 0, { "disabled": isEditorEmpty || post.title.length === 0 })} type="button"><i class="fas fa-save"></i> <span class="d-lg-inline d-none ms-2">${escape_html(post.status === StatusTypes.PUBLISHED ? store_get($$store_subs ??= {}, "$_", $format)("buttons.update") : store_get($$store_subs ??= {}, "$_", $format)("pages.post-editor.publish"))}</span></button> `);
			Hook($$renderer, {
				name: "panel:post-editor:actions:right",
				post
			});
			$$renderer.push(`<!---->`);
		}
		let $$settled = true;
		let $$inner_renderer;
		function $$render_inner($$renderer) {
			$$renderer.push(`<section class="row g-3"><div class="col-lg-9"><div class="card h-100 w-100"><div class="card-body d-flex flex-column gap-3"><input class="form-control form-control-lg" type="text"${attr("placeholder", store_get($$store_subs ??= {}, "$_", $format)("pages.post-editor.inputs.title.placeholder"))}${attr("value", post.title)}/> <div class="w-100 flex-grow-1 d-flex flex-column">`);
			Editor_1($$renderer, {
				get content() {
					return post.text;
				},
				set content($$value) {
					post.text = $$value;
					$$settled = false;
				},
				get isEmpty() {
					return isEditorEmpty;
				},
				set isEmpty($$value) {
					isEditorEmpty = $$value;
					$$settled = false;
				}
			});
			$$renderer.push(`<!----></div></div></div></div> <div class="col-lg-3">`);
			Hook($$renderer, {
				name: "panel:post-editor:sidebar:before",
				post
			});
			$$renderer.push(`<!----> <div class="card"><div class="card-body"><ul class="list-group p-0 m-0"><li class="list-group-item"><div class="d-flex justify-content-between align-items-center">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.post-editor.status"))} <div>${escape_html(store_get($$store_subs ??= {}, "$_", $format)(getStatusByPostStatus(post.status)))}</div></div></li> <li class="list-group-item"><div class="d-flex justify-content-between align-items-center">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.post-editor.views"))} <div>${escape_html(data.mode === Modes.CREATE ? "0" : post.views)}</div></div></li> `);
			if (post.status === StatusTypes.PUBLISHED) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<li class="list-group-item"><div class="d-flex justify-content-between align-items-center">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.post-editor.created-at"))} <div class="text-end">`);
				Date_1($$renderer, {
					time: post.date,
					relativeFormat: true
				});
				$$renderer.push(`<!----></div></div></li> `);
				if (post.moveDate) {
					$$renderer.push("<!--[0-->");
					$$renderer.push(`<li class="list-group-item"><div class="d-flex justify-content-between align-items-center">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.post-editor.updated-at"))} <div>`);
					Date_1($$renderer, {
						time: post.moveDate,
						relativeFormat: true
					});
					$$renderer.push(`<!----></div></div></li>`);
				} else $$renderer.push("<!--[-1-->");
				$$renderer.push(`<!--]-->`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--> <li class="list-group-item"><div class="d-flex justify-content-between align-items-center">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.post-editor.category"))} <form>`);
			$$renderer.select({
				class: "form-control form-control-sm",
				value: post.category
			}, ($$renderer) => {
				$$renderer.option({
					class: "text-primary",
					value: -1
				}, ($$renderer) => {
					$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.post-editor.no-category"))}`);
				});
				$$renderer.push(`<!--[-->`);
				const each_array = ensure_array_like(data.categories);
				for (let index = 0, $$length = each_array.length; index < $$length; index++) {
					let category = each_array[index];
					$$renderer.option({ value: category.id }, ($$renderer) => {
						$$renderer.push(`${escape_html(category.title)}`);
					});
				}
				$$renderer.push(`<!--]-->`);
			});
			$$renderer.push(`</form></div></li> <li class="list-group-item p-2">`);
			if (post.thumbnailUrl) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<div class="thumbnail-wrapper svelte-t22i6x"><div class="ratio ratio-16x9 w-100 rounded overflow-hidden shadow-sm">`);
				DragAndDropZone($$renderer, {
					accept: ["image/*"],
					class: "p-0 border-0",
					children: ($$renderer) => {
						$$renderer.push(`<img${attr("src", post.thumbnailUrl)} class="img-fluid w-100 h-100 object-fit-cover"${attr("alt", store_get($$store_subs ??= {}, "$_", $format)("pages.post-editor.small-image"))}/>`);
					},
					$$slots: { default: true }
				});
				$$renderer.push(`<!----></div> <button type="button" class="btn btn-sm btn-danger position-absolute top-0 start-100 translate-middle shadow-sm"${attr("title", store_get($$store_subs ??= {}, "$_", $format)("buttons.remove"))}${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("buttons.remove"))}><i class="fas fa-minus"></i></button></div>`);
			} else {
				$$renderer.push("<!--[-1-->");
				DragAndDropZone($$renderer, {
					accept: ["image/*"],
					icon: "fas fa-image fa-3x",
					title: store_get($$store_subs ??= {}, "$_", $format)("pages.post-editor.thumbnail-not-determined"),
					style: "height: 240px;"
				});
			}
			$$renderer.push(`<!--]--></li></ul></div></div> `);
			Hook($$renderer, {
				name: "panel:post-editor:sidebar:after",
				post
			});
			$$renderer.push(`<!----></div></section> `);
			Hook($$renderer, {
				name: "panel:post-editor:content:bottom",
				post
			});
			$$renderer.push(`<!----> `);
			AddEditPostCategoryModal($$renderer);
			$$renderer.push(`<!---->`);
		}
		do {
			$$settled = true;
			$$inner_renderer = $$renderer.copy();
			$$render_inner($$inner_renderer);
		} while (!$$settled);
		$$renderer.subsume($$inner_renderer);
		if ($$store_subs) unsubscribe_stores($$store_subs);
		bind_props($$props, { data });
	});
}

export { Modes as M, PostEditor as P, load as l };
//# sourceMappingURL=PostEditor.js-C5JBkC7I.js.map
