import { a0 as onDestroy, T as attr, V as attr_class, Q as store_get, S as unsubscribe_stores } from './index-server.js-DdhL7Abu.js';
import { $ as $format } from './runtime.js-BzHEw_ze.js';

//#region src/lib/components/SearchInput.svelte
function SearchInput($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let { placeholderKey = "buttons.find", ariaLabelKey = "buttons.find", debounceMs = 250, initialValue = "", searching = false, showSpinner = true, onchange, inputId = void 0 } = $$props;
		let value = "";
		let pending = false;
		onDestroy(() => {});
		$$renderer.push(`<div class="input-group"><input type="text"${attr("id", inputId)}${attr_class(`form-control form-control-sm focus-ring ${String("").trim() ? "border-secondary" : ""}`)}${attr("placeholder", store_get($$store_subs ??= {}, "$_", $format)(placeholderKey))}${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)(ariaLabelKey))} aria-describedby="find-addon"${attr("value", value)}/> `);
		if (showSpinner && (searching || pending)) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<span class="input-group-text"${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("components.search-input.searching"))}><span class="spinner-border spinner-border-sm" role="status"></span></span>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
	});
}

export { SearchInput as S };
//# sourceMappingURL=SearchInput.js-DPW0WADK.js.map
