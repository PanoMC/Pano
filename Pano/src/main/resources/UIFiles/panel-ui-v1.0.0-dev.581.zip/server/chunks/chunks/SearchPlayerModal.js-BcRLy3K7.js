import { Q as store_get, Z as escape_html, T as attr, P as ensure_array_like, S as unsubscribe_stores, F as writable } from './index-server.js-DdhL7Abu.js';
import { f as avatarVersion, b as ApiUtil } from './Store.js-DT3aZHRb.js';
import { $ as $format } from './runtime.js-BzHEw_ze.js';
import { N as NoContent } from './NoContent.js-Coj2fA9d.js';

var query = writable("");
var loading = writable(false);
var errorText = writable("");
var results = writable([]);
var localPlayers = writable(null);
var allGroups = writable([]);
var allNodes = writable([]);
var existingUserIds = writable([]);
var selectOnlyBadge = writable(false);
function SearchPlayerModal($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let debounceTimer;
		let activeSearchToken = 0;
		function formatGroups(user) {
			const userId = user?.id;
			if (userId == null) return "";
			const directGroupNames = (store_get($$store_subs ??= {}, "$allNodes", allNodes) || []).filter((n) => n?.holderType === "USER" && n?.holderId != null && String(n.holderId) === String(userId) && n?.active !== false && typeof n?.node === "string" && n.node.startsWith("group.")).map((n) => String(n.node).slice(6)).map((x) => String(x || "").trim()).filter(Boolean);
			const unique = Array.from(new Set(directGroupNames));
			const groupNames = unique.length ? unique : ["default"];
			const byName = new Map((store_get($$store_subs ??= {}, "$allGroups", allGroups) || []).map((g) => [g.name, g]));
			return groupNames.map((name) => (byName.get(name)?.displayName || name || "").trim()).filter(Boolean).join(", ");
		}
		function isExisting(user) {
			const id = user?.id;
			if (id == null) return false;
			return (store_get($$store_subs ??= {}, "$existingUserIds", existingUserIds) || []).some((x) => String(x) === String(id));
		}
		async function search(q, token) {
			if (token !== activeSearchToken) return;
			errorText.set("");
			try {
				const qq = q.toLowerCase();
				const localResults = Array.isArray(store_get($$store_subs ??= {}, "$localPlayers", localPlayers)) && store_get($$store_subs ??= {}, "$localPlayers", localPlayers).length > 0 ? store_get($$store_subs ??= {}, "$localPlayers", localPlayers).filter((p) => (p?.username || "").toLowerCase().includes(qq)).slice(0, 10) : [];
				if (localResults.length > 0) results.set(localResults);
				const res = await ApiUtil.get({ path: `/api/panel/player/search?q=${encodeURIComponent(q)}` });
				if (token !== activeSearchToken) return;
				if (res?.error) {
					errorText.set(res.error);
					if (localResults.length === 0) results.set([]);
				} else {
					const apiPlayers = Array.isArray(res?.players) ? res.players : [];
					const seen = /* @__PURE__ */ new Set();
					const merged = [];
					const pushUnique = (u) => {
						if (!u) return;
						const key = u.id != null ? `id:${u.id}` : `u:${String(u.username || "").toLowerCase()}`;
						if (!key || key === "u:") return;
						if (seen.has(key)) return;
						seen.add(key);
						merged.push(u);
					};
					localResults.forEach(pushUnique);
					apiPlayers.forEach(pushUnique);
					results.set(merged.slice(0, 10));
				}
			} catch (e) {
				if (token !== activeSearchToken) return;
				errorText.set("SEARCH_FAILED");
				if (!(Array.isArray(store_get($$store_subs ??= {}, "$localPlayers", localPlayers)) && store_get($$store_subs ??= {}, "$localPlayers", localPlayers).length > 0)) results.set([]);
			} finally {
				if (token === activeSearchToken) loading.set(false);
			}
		}
		{
			const q = (store_get($$store_subs ??= {}, "$query", query) || "").trim();
			clearTimeout(debounceTimer);
			if (!q) {
				results.set([]);
				errorText.set("");
				loading.set(false);
			} else {
				loading.set(true);
				errorText.set("");
				const token = ++activeSearchToken;
				debounceTimer = setTimeout(() => search(q, token), 250);
			}
		}
		$$renderer.push(`<div class="modal fade" tabindex="-1" role="dialog" aria-hidden="true"><div class="modal-dialog"><div class="modal-content"><div class="modal-header"><h5 class="modal-title">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.search-player.title"))}</h5> <button type="button" class="btn-close"${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("buttons.close"))}></button></div> <div class="modal-body"><div class="vstack gap-2"><div class="position-relative"><input class="form-control form-control-lg" type="text"${attr("value", store_get($$store_subs ??= {}, "$query", query))}${attr("placeholder", store_get($$store_subs ??= {}, "$_", $format)("buttons.find"))}/> `);
		if (store_get($$store_subs ??= {}, "$query", query).trim().length > 0) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<button type="button" class="btn-close position-absolute top-50 end-0 translate-middle-y me-2"${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("buttons.clear"))}${attr("title", store_get($$store_subs ??= {}, "$_", $format)("buttons.clear"))}></button>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--></div> <small>`);
		if (store_get($$store_subs ??= {}, "$loading", loading)) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.search-player.states.loading"))}`);
		} else if (store_get($$store_subs ??= {}, "$query", query).trim().length === 0) {
			$$renderer.push("<!--[1-->");
			$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.search-player.states.start-typing"))}`);
		} else {
			$$renderer.push("<!--[-1-->");
			$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.search-player.states.max-results"))}`);
		}
		$$renderer.push(`<!--]--></small></div> `);
		if (store_get($$store_subs ??= {}, "$errorText", errorText)) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<div class="alert alert-danger">${escape_html(store_get($$store_subs ??= {}, "$errorText", errorText))}</div>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--> `);
		if (store_get($$store_subs ??= {}, "$results", results).length > 0) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<div class="list-group mt-3"><!--[-->`);
			const each_array = ensure_array_like(store_get($$store_subs ??= {}, "$results", results));
			for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
				let u = each_array[$$index];
				$$renderer.push(`<button type="button" class="list-group-item list-group-item-action d-flex justify-content-between align-items-center"><div class="d-flex align-items-center overflow-hidden">`);
				if (u.username) {
					$$renderer.push("<!--[0-->");
					$$renderer.push(`<img${attr("src", `/api/profile/picture/${encodeURIComponent(u.username)}?${store_get($$store_subs ??= {}, "$avatarVersion", avatarVersion)}`)}${attr("alt", `${u.username}`)} width="24" height="24" class="rounded me-2 flex-shrink-0" loading="lazy"/>`);
				} else $$renderer.push("<!--[-1-->");
				$$renderer.push(`<!--]--> <div class="overflow-hidden"><div class="fw-bold text-truncate">${escape_html(u.username)}</div> <small class="d-block text-truncate">${escape_html(formatGroups(u) || "-")}</small></div></div> <span class="badge text-bg-primary">${escape_html(store_get($$store_subs ??= {}, "$selectOnlyBadge", selectOnlyBadge) || isExisting(u) ? store_get($$store_subs ??= {}, "$_", $format)("components.modals.search-player.badges.select") : store_get($$store_subs ??= {}, "$_", $format)("components.modals.search-player.badges.add"))}</span></button>`);
			}
			$$renderer.push(`<!--]--></div>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--> `);
		if (store_get($$store_subs ??= {}, "$results", results).length === 0 && store_get($$store_subs ??= {}, "$query", query).trim().length > 0 && !store_get($$store_subs ??= {}, "$loading", loading) && !store_get($$store_subs ??= {}, "$errorText", errorText)) {
			$$renderer.push("<!--[0-->");
			NoContent($$renderer, {});
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--></div></div></div></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
	});
}

export { SearchPlayerModal as S };
//# sourceMappingURL=SearchPlayerModal.js-BcRLy3K7.js.map
