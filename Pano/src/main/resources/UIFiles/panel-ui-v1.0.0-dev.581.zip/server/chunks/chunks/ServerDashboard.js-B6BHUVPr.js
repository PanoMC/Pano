import { r as redirect } from './exports2.js-VkmSkXbz.js';
import { b as base } from './internal.js-BRN1McAa.js';
import { J as getContext, a0 as onDestroy, Z as escape_html, Q as store_get, S as unsubscribe_stores, O as bind_props, N as fallback } from './index-server.js-DdhL7Abu.js';
import './server.js-BlClO2ED.js';
import './internal2.js-CNe5OZUJ.js';
import './routing.js-N-OPb2ye.js';
import { s as PANEL_SERVER_LIVE_LOAD_KEY, b as ApiUtil } from './Store.js-DT3aZHRb.js';
import { $ as $format } from './runtime.js-BzHEw_ze.js';
import { i as intervalToDuration } from './intervalToDuration.js-Bqoo9ab3.js';
import { C as Chart, L as LineController, a as LineElement, P as PointElement, b as LinearScale, c as CategoryScale, T as TimeScale, i as index, d as PieController, A as ArcElement, p as plugin_tooltip, e as plugin_legend, f as plugin_colors } from './chartjs-adapter-date-fns.esm.js-D4KsVK21.js';
import { D as Date_1 } from './Date.js-DCZp_jrB.js';
import { C as CardHeader } from './CardHeader.js-XBureLRg.js';
import { P as PageLoading } from './PageLoading.js-BAdCAKhL.js';

//#region src/lib/components/charts/Server/ServerPlayerChart.svelte
function ServerPlayerChart($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		Chart.register(PieController, ArcElement, plugin_tooltip, plugin_legend, plugin_colors);
		let playerCount = fallback($$props["playerCount"], 0);
		let maxPlayerCount = fallback($$props["maxPlayerCount"], 0);
		onDestroy(() => {});
		$$renderer.push(`<div class="chart-container svelte-pvv1d8"><canvas></canvas></div>`);
		bind_props($$props, {
			playerCount,
			maxPlayerCount
		});
	});
}
//#endregion
//#region src/lib/components/charts/Server/ServerActivityMiniChart.svelte
function ServerActivityMiniChart($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		Chart.register(LineController, LineElement, PointElement, LinearScale, CategoryScale, TimeScale, index);
		let activityData = fallback($$props["activityData"], () => ({}), true);
		onDestroy(() => {});
		$$renderer.push(`<div class="mini-chart-container svelte-lq2o7x"><canvas class="svelte-lq2o7x"></canvas></div>`);
		bind_props($$props, { activityData });
	});
}
//#endregion
//#region src/lib/pages/server/ServerDashboard.svelte
var ServerStatus = Object.freeze({
	ONLINE: "ONLINE",
	OFFLINE: "OFFLINE"
});
async function load(event) {
	const { parent, depends } = event;
	depends(PANEL_SERVER_LIVE_LOAD_KEY);
	const { selectedServer } = await parent();
	if (!selectedServer) throw redirect(302, base);
	return await ApiUtil.get({
		path: `/api/panel/servers/${selectedServer.id}/dashboard`,
		request: event
	});
}
function ServerDashboard($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		getContext("pageTitle").set("pages.server.dashboard.title");
		let data = $$props["data"];
		let interval;
		function getUptime(time, checkTime) {
			const now = /* @__PURE__ */ new Date();
			const duration = intervalToDuration({
				start: new Date(time),
				end: now
			});
			return `${duration.days || 0}:${duration["hours"] || 0}:${duration["minutes"] || 0}:${duration["seconds"] || 0}`;
		}
		onDestroy(() => {
			clearInterval(interval);
		});
		if (!data.server) {
			$$renderer.push("<!--[0-->");
			PageLoading($$renderer, {});
		} else {
			$$renderer.push("<!--[-1-->");
			$$renderer.push(`<div class="container vstack gap-3"><div class="row g-3"><div class="col-lg-3"><div class="card aspect-ratio-1x1">`);
			CardHeader($$renderer, { $$slots: {
				left: ($$renderer) => {
					$$renderer.push(`<span slot="left">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.server.dashboard.server-status").split("{")[0].trim())}</span>`);
				},
				right: ($$renderer) => {
					$$renderer.push(`<span slot="right">${escape_html(data.server?.status === ServerStatus.ONLINE ? store_get($$store_subs ??= {}, "$_", $format)("pages.server.dashboard.online") : store_get($$store_subs ??= {}, "$_", $format)("pages.server.dashboard.offline"))}</span>`);
				}
			} });
			$$renderer.push(`<!----> <div class="card-body p-0 d-flex align-items-center justify-content-center overflow-hidden">`);
			if (data.server.status === ServerStatus.ONLINE) {
				$$renderer.push("<!--[0-->");
				ServerActivityMiniChart($$renderer, { activityData: data.server.activityData });
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--></div></div></div> <div class="col-lg-3"><div class="card aspect-ratio-1x1">`);
			CardHeader($$renderer, { $$slots: {
				left: ($$renderer) => {
					$$renderer.push(`<span slot="left">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.statistics.total-statistics.players").replace(":", ""))}</span>`);
				},
				right: ($$renderer) => {
					$$renderer.push(`<span slot="right">${escape_html(data.server.playerCount)} / ${escape_html(data.server.maxPlayerCount)}</span>`);
				}
			} });
			$$renderer.push(`<!----> <div class="card-body d-flex flex-column align-items-center justify-content-center overflow-hidden"><div class="w-100 p-2">`);
			ServerPlayerChart($$renderer, {
				playerCount: data.server.playerCount,
				maxPlayerCount: data.server.maxPlayerCount
			});
			$$renderer.push(`<!----></div></div></div></div> <div class="col-lg-3"><div class="card aspect-ratio-1x1">`);
			CardHeader($$renderer, { $$slots: {
				left: ($$renderer) => {
					$$renderer.push(`<span slot="left">${escape_html((store_get($$store_subs ??= {}, "$_", $format)("pages.server.dashboard.working-time") || "").split(":")[0])}</span>`);
				},
				right: ($$renderer) => {
					$$renderer.push(`<span slot="right">${escape_html(data.server?.status === ServerStatus.ONLINE ? "Active" : "Offline")}</span>`);
				}
			} });
			$$renderer.push(`<!----> <div class="card-body d-flex align-items-center justify-content-center text-center">`);
			if (data.server?.status === ServerStatus.ONLINE) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<div class="fs-4 font-monospace fw-bold">${escape_html(getUptime(data.server?.startTime))}</div>`);
			} else {
				$$renderer.push("<!--[-1-->");
				Date_1($$renderer, { time: data.server.stopTime });
			}
			$$renderer.push(`<!--]--></div></div></div> <div class="col-lg-3"><div class="card aspect-ratio-1x1">`);
			CardHeader($$renderer, { $$slots: {
				left: ($$renderer) => {
					$$renderer.push(`<span slot="left">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.server.dashboard.server-version").replace(":", ""))}</span>`);
				},
				right: ($$renderer) => {
					$$renderer.push(`<span slot="right">Stable</span>`);
				}
			} });
			$$renderer.push(`<!----> <div class="card-body d-flex align-items-center justify-content-center text-center"><div class="fs-4 font-monospace fw-bold">${escape_html(data.server.version)}</div></div></div></div></div> `);
			$$renderer.push(`<style>
      .aspect-ratio-1x1 {
        aspect-ratio: 1 / 1;
      }
    </style>`);
			$$renderer.push(` <div class="card">`);
			CardHeader($$renderer, { $$slots: { left: ($$renderer) => {
				$$renderer.push(`<span slot="left">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.server.dashboard.statistics"))}</span>`);
			} } });
			$$renderer.push(`<!----> <div class="table-responsive"><table class="table table-hover"><tbody><tr><th scope="row">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.server.dashboard.server-name"))}</th><td>${escape_html(data.server.customName || data.server.name)}</td></tr><tr><th scope="row">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.server.dashboard.server-type"))}</th><td>${escape_html(data.server.type)}</td></tr><tr><th scope="row">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.server.dashboard.local-ip-address"))}</th><td>${escape_html(data.server.host)}:${escape_html(data.server.port)}</td></tr><tr><th scope="row">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.server.dashboard.server-version"))}</th><td>${escape_html(data.server.version)}</td></tr><tr><th scope="row">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.server.dashboard.total-connected-servers"))}</th><td>${escape_html(data.connectedServerCount)}</td></tr><tr><th scope="row">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.server.dashboard.date-added"))}</th><td>`);
			Date_1($$renderer, { time: data.server.acceptedTime });
			$$renderer.push(`<!----></td></tr></tbody></table></div></div></div>`);
		}
		$$renderer.push(`<!--]-->`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
		bind_props($$props, { data });
	});
}

export { ServerDashboard as S, load as l };
//# sourceMappingURL=ServerDashboard.js-B6BHUVPr.js.map
