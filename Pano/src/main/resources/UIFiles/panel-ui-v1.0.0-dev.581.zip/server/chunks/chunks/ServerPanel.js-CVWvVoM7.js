import 'node:module';
import { b as base } from './internal.js-BRN1McAa.js';
import { J as getContext, Q as store_get, T as attr, Z as escape_html, V as attr_class, S as unsubscribe_stores } from './index-server.js-DdhL7Abu.js';
import './server.js-BlClO2ED.js';
import './internal2.js-CNe5OZUJ.js';
import './routing.js-N-OPb2ye.js';
import { $ as $format } from './runtime.js-BzHEw_ze.js';
import { s as sanitizeImageSrc } from './security.util.js-D4eJjJV6.js';
import './tooltip.util.js-BeLZL-Tj.js';
import { N as NoContent } from './NoContent.js-Coj2fA9d.js';
import { C as CardHeader } from './CardHeader.js-XBureLRg.js';
import { r as require_copy_to_clipboard } from './copy-to-clipboard.js-Doa_mbw4.js';
import './ServersModal.js-BMcMWCMK.js';
import { V as ViewAllLink } from './ViewAllLink.js-Cn_c9MC0.js';

require_copy_to_clipboard();
//#endregion
//#region src/lib/pages/server/ServerPanel.svelte
async function load(event) {
	const { parent } = event;
	await parent();
	return {};
}
function ServerPanel($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		const selectedServer = getContext("selectedServer");
		getContext("pageTitle").set("components.site-navigation-menu.panel");
		function getPrimaryAddress(server) {
			return String(server?.remoteAddress || "").trim() || server?.host || "";
		}
		function getLocalAddress(server) {
			return `${server?.host || ""}:${server?.port ?? ""}`;
		}
		$$renderer.push(`<div class="container vstack gap-3"><div class="card server-card svelte-v8nic9">`);
		CardHeader($$renderer, {
			truncateLeftSlot: false,
			leftClasses: "pe-sm-2",
			$$slots: {
				left: ($$renderer) => {
					$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.navbar.selected-server"))}`);
				},
				right: ($$renderer) => {
					ViewAllLink($$renderer, {});
				}
			}
		});
		$$renderer.push(`<!----> <div class="card-body d-flex flex-column align-items-center text-center p-3">`);
		if (store_get($$store_subs ??= {}, "$selectedServer", selectedServer)) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<img${attr("src", sanitizeImageSrc(store_get($$store_subs ??= {}, "$selectedServer", selectedServer).favicon ? store_get($$store_subs ??= {}, "$selectedServer", selectedServer).favicon : base + "/assets/img/server-icon.png", base + "/assets/img/server-icon.png"))} class="rounded border mb-2" height="64" width="64"${attr("alt", store_get($$store_subs ??= {}, "$selectedServer", selectedServer).customName || store_get($$store_subs ??= {}, "$selectedServer", selectedServer).name)}/> <div class="fw-bold text-break w-100 mb-1 px-1 server-name">${escape_html(store_get($$store_subs ??= {}, "$selectedServer", selectedServer).customName || store_get($$store_subs ??= {}, "$selectedServer", selectedServer).name)}</div> <div class="w-100 mb-1 server-ip px-1"><button type="button" class="bg-transparent border-0 p-0 focus-ring w-100 text-break"><code class="user-select-all cursor-pointer text-break d-inline-block">${escape_html(getPrimaryAddress(store_get($$store_subs ??= {}, "$selectedServer", selectedServer)))}</code></button></div> <div class="w-100 mb-1 px-1 server-local-ip text-body-secondary text-break svelte-v8nic9">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.local"))}: <span class="font-monospace user-select-all">${escape_html(getLocalAddress(store_get($$store_subs ??= {}, "$selectedServer", selectedServer)))}</span></div> <div class="mt-2 w-100"><div${attr_class("badge rounded-pill mb-1", void 0, {
				"text-bg-success": store_get($$store_subs ??= {}, "$selectedServer", selectedServer).status === "ONLINE",
				"text-bg-danger": store_get($$store_subs ??= {}, "$selectedServer", selectedServer).status !== "ONLINE"
			})}>${escape_html(store_get($$store_subs ??= {}, "$selectedServer", selectedServer).type)}</div> <div class="player-count">${escape_html(store_get($$store_subs ??= {}, "$selectedServer", selectedServer).playerCount)}/${escape_html(store_get($$store_subs ??= {}, "$selectedServer", selectedServer).maxPlayerCount)}</div></div>`);
		} else {
			$$renderer.push("<!--[-1-->");
			NoContent($$renderer, {});
		}
		$$renderer.push(`<!--]--></div></div></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
	});
}

export { ServerPanel as S, load as l };
//# sourceMappingURL=ServerPanel.js-CVWvVoM7.js.map
