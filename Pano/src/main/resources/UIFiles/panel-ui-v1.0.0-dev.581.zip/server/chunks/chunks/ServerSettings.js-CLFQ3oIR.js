import { r as redirect } from './exports2.js-VkmSkXbz.js';
import { b as base } from './internal.js-BRN1McAa.js';
import { J as getContext, Q as store_get, Z as escape_html, T as attr, V as attr_class, S as unsubscribe_stores, O as bind_props, F as writable } from './index-server.js-DdhL7Abu.js';
import './server.js-BlClO2ED.js';
import './internal2.js-CNe5OZUJ.js';
import './routing.js-N-OPb2ye.js';
import './stores.js-D5xmrOAP.js';
import { b as ApiUtil } from './Store.js-DT3aZHRb.js';
import { $ as $format } from './runtime.js-BzHEw_ze.js';
import './ToastContainer.js-Bv1jJ2dr.js';
import { P as PageLoading } from './PageLoading.js-BAdCAKhL.js';

var server$1 = writable({});
var loading$1 = writable(false);
function MakeMainServerModal($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		$$renderer.push(`<div aria-hidden="true" class="modal fade" role="dialog" tabindex="-1"><div class="modal-dialog modal-dialog-centered" role="dialog"><div class="modal-content"><div class="modal-body text-center"><div class="pb-3"><i class="fas fa-question-circle fa-3x d-block m-auto text-gray"></i></div> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.make-main-server.title", { values: { serverName: store_get($$store_subs ??= {}, "$server", server$1).name } }))}</div> <div class="modal-footer flex-nowrap"><button${attr_class("btn btn-link col-6 m-0", void 0, { "disabled": store_get($$store_subs ??= {}, "$loading", loading$1) })} type="button">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.no"))}</button> <button${attr_class("btn btn-secondary col-6 m-0", void 0, { "disabled": store_get($$store_subs ??= {}, "$loading", loading$1) })} type="button">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.yes"))}</button></div></div></div></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
	});
}
var passwordError = writable(false);
var currentPassword = writable("");
function RemoveServerModal($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let confirmButtonDisabled;
		confirmButtonDisabled = store_get($$store_subs ??= {}, "$currentPassword", currentPassword).length === 0;
		$$renderer.push(`<div aria-hidden="true" class="modal fade" role="dialog" tabindex="-1"><div class="modal-dialog modal-dialog-centered" role="dialog"><div class="modal-content"><form><div class="modal-body text-center"><div class="pb-3"><i class="fas fa-question-circle fa-3x d-block m-auto text-gray"></i></div> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.remove-server.title"))} <input${attr_class("form-control zmt-3", void 0, { "border-danger": store_get($$store_subs ??= {}, "$passwordError", passwordError) })}${attr("placeholder", store_get($$store_subs ??= {}, "$_", $format)("components.modals.remove-server.account-password"))} type="password"${attr("value", store_get($$store_subs ??= {}, "$currentPassword", currentPassword))}/></div> <div class="modal-footer flex-nowrap"><button class="btn btn-link col-6 m-0" type="button">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.cancel"))}</button> <button${attr_class("btn btn-danger col-6 m-0", void 0, { "disabled": confirmButtonDisabled })} type="button"${attr("disabled", confirmButtonDisabled, true)}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.yes"))}</button></div></form></div></div></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
	});
}
//#endregion
//#region src/lib/pages/server/ServerSettings.svelte
async function load(event) {
	const { parent } = event;
	const { selectedServer } = await parent();
	if (!selectedServer) throw redirect(302, base);
	const { server } = await ApiUtil.get({
		path: `/api/panel/servers/${selectedServer.id}`,
		request: event
	});
	if (!server.customName) server.customName = server.name;
	return {
		server,
		serverOriginal: structuredClone(server)
	};
}
function ServerSettings($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let saveDisabled;
		let data = $$props["data"];
		let server;
		let serverOriginal;
		const mainServer = getContext("mainServer");
		const selectedServer = getContext("selectedServer");
		getContext("pageTitle").set("pages.server.settings.title");
		if (data?.server) {
			server = data.server;
			serverOriginal = structuredClone(data.serverOriginal);
		}
		saveDisabled = JSON.stringify(server) === JSON.stringify(serverOriginal) || !server.customName || server.customName === server.name;
		if (store_get($$store_subs ??= {}, "$selectedServer", selectedServer) && server) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<div class="card"><div class="card-header">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.server.settings.preferences"))}</div> <div class="card-body"><div class="row mb-3"><label class="col-md-6 col-form-label" for="serverName">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.server.settings.server-name"))}</label> <div class="col"><div class="mb-3"><input type="text" class="form-control" name="serverName" id="serverName"${attr("value", server.customName)}${attr("placeholder", store_get($$store_subs ??= {}, "$_", $format)("pages.server.settings.server-name"))}/></div></div></div> <div class="row mb-3"><label class="col-md-6 col-form-label" for="mainServer">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.server.settings.main-server"))} <small class="d-block">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.server.settings.main-server-info"))}</small></label> <div class="col col-form-label">`);
			if (store_get($$store_subs ??= {}, "$mainServer", mainServer) && store_get($$store_subs ??= {}, "$selectedServer", selectedServer).id === store_get($$store_subs ??= {}, "$mainServer", mainServer).id) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<button class="btn btn-secondary btn-sm disabled" disabled=""><i class="fa-solid fa-check me-1"></i> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.server.settings.already-main-server", { values: { serverName: store_get($$store_subs ??= {}, "$selectedServer", selectedServer).customName || store_get($$store_subs ??= {}, "$selectedServer", selectedServer).name } }))}</button>`);
			} else {
				$$renderer.push("<!--[-1-->");
				$$renderer.push(`<button class="btn btn-secondary btn-sm"><i class="fas fa-crown me-1"></i> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.server.settings.make-main-server"))}</button>`);
			}
			$$renderer.push(`<!--]--></div></div> <div class="row mb-3"><label class="col-md-6 col-form-label" for="removeServer">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.server.settings.remove-server"))}</label> <div class="col hstack gap-2"><span class="badge text-bg-primary">${escape_html(store_get($$store_subs ??= {}, "$selectedServer", selectedServer).customName || store_get($$store_subs ??= {}, "$selectedServer", selectedServer).name)}</span> <button type="button"${attr("title", store_get($$store_subs ??= {}, "$_", $format)("buttons.remove"))}${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("buttons.remove"))} class="btn-close"></button></div></div> <button${attr_class("btn btn-secondary", void 0, { "disabled": saveDisabled })}${attr("aria-disabled", saveDisabled)}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.save"))}</button></div></div>`);
		} else {
			$$renderer.push("<!--[-1-->");
			PageLoading($$renderer, {});
		}
		$$renderer.push(`<!--]--> `);
		MakeMainServerModal($$renderer);
		$$renderer.push(`<!----> `);
		RemoveServerModal($$renderer);
		$$renderer.push(`<!---->`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
		bind_props($$props, { data });
	});
}

export { ServerSettings as S, load as l };
//# sourceMappingURL=ServerSettings.js-CLFQ3oIR.js.map
