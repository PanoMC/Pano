import { _ as __exportAll } from './rolldown-runtime.js-BMnQIuNT.js';
import { W as slot, Z as escape_html, Q as store_get, S as unsubscribe_stores } from './index-server.js-DdhL7Abu.js';
import { $ as $format } from './runtime.js-BzHEw_ze.js';
import { P as PageActions } from './PageActions.js-co-RIHDp.js';
import { P as PageNav, a as PageNavItem } from './PageNav.js-Bzzuwwjz.js';

//#region src/lib/layouts/ServerSettingsLayout.svelte
var ServerSettingsLayout_exports = /* @__PURE__ */ __exportAll({ default: () => ServerSettingsLayout });
function ServerSettingsLayout($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		$$renderer.push(`<div class="container">`);
		PageActions($$renderer, {
			leftClasses: "d-none",
			rightClasses: "d-none",
			$$slots: { middle: ($$renderer) => {
				$$renderer.push(`<div slot="middle">`);
				PageNav($$renderer, {
					children: ($$renderer) => {
						PageNavItem($$renderer, {
							href: "/server/settings",
							children: ($$renderer) => {
								$$renderer.push(`<!---->${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.server-settings-layout.server"))}`);
							}});
						$$renderer.push(`<!----> `);
						PageNavItem($$renderer, {
							href: "/server/settings/game-integration",
							startsWith: true,
							children: ($$renderer) => {
								$$renderer.push(`<!---->${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.server-settings-layout.game-integration"))}`);
							}});
						$$renderer.push(`<!---->`);
					},
					$$slots: { default: true }
				});
				$$renderer.push(`<!----></div>`);
			} }
		});
		$$renderer.push(`<!----> <div class="mt-3"><!--[-->`);
		slot($$renderer, $$props, "default", {}, null);
		$$renderer.push(`<!--]--></div></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
	});
}

export { ServerSettingsLayout_exports as S, ServerSettingsLayout as a };
//# sourceMappingURL=ServerSettingsLayout.js-DUjy1RdU.js.map
