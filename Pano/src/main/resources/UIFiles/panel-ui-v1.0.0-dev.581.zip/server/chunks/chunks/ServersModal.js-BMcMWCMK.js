import { b as __toESM } from './rolldown-runtime.js-BMnQIuNT.js';
import { b as base } from './internal.js-BRN1McAa.js';
import { J as getContext, a0 as onDestroy, Q as store_get, Z as escape_html, T as attr, P as ensure_array_like, S as unsubscribe_stores, V as attr_class, F as writable, O as bind_props, a4 as store_set } from './index-server.js-DdhL7Abu.js';
import { i as invalidateAll } from './stores.js-D5xmrOAP.js';
import './server.js-BlClO2ED.js';
import './internal2.js-CNe5OZUJ.js';
import './routing.js-N-OPb2ye.js';
import { P as PANO_WEBSITE_URL, b as ApiUtil } from './Store.js-DT3aZHRb.js';
import { $ as $format } from './runtime.js-BzHEw_ze.js';
import { s as showSuccess, a as showError } from './ToastContainer.js-Bv1jJ2dr.js';
import { s as sanitizeImageSrc } from './security.util.js-D4eJjJV6.js';
import './tooltip.util.js-BeLZL-Tj.js';
import { N as NoContent } from './NoContent.js-Coj2fA9d.js';
import { S as SearchInput } from './SearchInput.js-DPW0WADK.js';
import { r as require_copy_to_clipboard } from './copy-to-clipboard.js-Doa_mbw4.js';

//#region src/lib/components/modals/ConnectServerModal.svelte
var import_copy_to_clipboard = /* @__PURE__ */ __toESM(require_copy_to_clipboard());
function ConnectServerModal($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		getContext("platformServerMatchKey");
		getContext("platformKeyRefreshedTime");
		getContext("platformHostAddress");
		const session = getContext("session");
		let timeToRefreshKey = "...";
		let commandText;
		let isRemoteConnection = false;
		let acceptPluginAuth = store_get($$store_subs ??= {}, "$session", session).basicData.acceptPluginAuth;
		let toggleLoading;
		$$renderer.push(`<div aria-hidden="true" class="modal modal fade" id="connectServer" role="document" tabindex="-1"><div class="modal-dialog" role="document"><div class="modal-content"><div class="modal-header"><div class="hstack gap-2"><div class="form-check form-switch position-relative">`);
		$$renderer.push("<!--[-1-->");
		$$renderer.push(`<input${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("components.modals.connect-server.toggle-connect-server"))} class="form-check-input" type="checkbox" id="toggleConnectServer"${attr("checked", acceptPluginAuth, true)}${attr("disabled", toggleLoading, true)} autocomplete="off"/>`);
		$$renderer.push(`<!--]--></div> <h5 class="modal-title">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.connect-server.title"))}</h5></div> <button class="btn-close"${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("buttons.close"))} data-bs-dismiss="modal" type="button"></button></div> <div${attr_class("modal-body", void 0, { "opacity-50": !acceptPluginAuth })}><ol class="list-group list-group-numbered"><li class="list-group-item">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.connect-server.steps.1"))} <br/> <a${attr_class("btn btn-secondary mt-2 d-block shadow-none", void 0, { "disabled": !acceptPluginAuth })}${attr("href", `${PANO_WEBSITE_URL}/download`)} target="_blank"${attr("tabindex", acceptPluginAuth ? 0 : -1)}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.download"))} <i class="fa fa-external-link ms-2"></i></a></li> <li class="list-group-item">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.connect-server.steps.2"))} <br/> `);
		if (acceptPluginAuth) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<small>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.connect-server.code-refresh", { values: { timeToRefreshKey } }))}</small> <div class="mt-2"><ul class="nav nav-tabs border-bottom-0"><li class="nav-item"><button type="button"${attr_class("nav-link", void 0, { "active": true })}${attr("disabled", !acceptPluginAuth, true)}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.local"))}</button></li> <li class="nav-item"><button type="button"${attr_class("nav-link", void 0, { "active": isRemoteConnection })}${attr("disabled", !acceptPluginAuth, true)}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.remote"))}</button></li></ul></div>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--> <div class="input-group"><input type="text" class="form-control rounded-top-0 rounded-end-0"${attr("value", commandText)} readonly=""${attr("disabled", !acceptPluginAuth, true)}/> <button class="btn border shadow-none btn-outline-primary" type="button"${attr("disabled", !acceptPluginAuth, true)}${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("components.modals.connect-server.copy"))}><i class="fa-regular fa-clipboard"></i></button> <button class="btn border shadow-none btn-outline-secondary" type="button"${attr("disabled", !acceptPluginAuth, true)}${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("components.modals.connect-server.copy-for-console"))}><i class="fa-solid fa-terminal"></i></button></div></li> <li class="list-group-item">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.connect-server.steps.3"))} <br/> <small>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.connect-server.notification-will-come"))}</small></li></ol></div></div></div></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
	});
}
//#endregion
//#region src/lib/components/modals/ServersModalServerCard.svelte
function ServersModalServerCard($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let server = $$props["server"];
		/** @type {import('svelte/store').Readable<unknown> | null} */
		const selectedServer = getContext("selectedServer");
		const mainServer = getContext("mainServer");
		let selectingServerId = $$props["selectingServerId"];
		let copiedId = $$props["copiedId"];
		let onSelectCard = $$props["onSelectCard"];
		let onCopy = $$props["onCopy"];
		function getPrimaryAddress(server) {
			return String(server?.remoteAddress || "").trim() || server?.host || "";
		}
		$$renderer.push(`<div class="col svelte-1umj6bz"><div${attr_class("card h-100 server-card position-relative svelte-1umj6bz", void 0, {
			"is-selecting": selectingServerId === server.id,
			"border-primary": store_get($$store_subs ??= {}, "$selectedServer", selectedServer)?.id === server.id,
			"border-2": store_get($$store_subs ??= {}, "$selectedServer", selectedServer)?.id === server.id,
			"shadow-sm": store_get($$store_subs ??= {}, "$selectedServer", selectedServer)?.id === server.id,
			"opacity-50": selectingServerId != null && selectingServerId !== server.id
		})} tabindex="0" role="button"${attr("aria-busy", selectingServerId === server.id ? "true" : void 0)}>`);
		if (selectingServerId === server.id) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<div class="selecting-overlay svelte-1umj6bz"><div class="d-flex flex-column align-items-center gap-2 px-2 text-center text-primary svelte-1umj6bz"><div class="spinner-border svelte-1umj6bz" style="width: 2.25rem; height: 2.25rem;" role="status"><span class="visually-hidden svelte-1umj6bz">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.servers.selecting-server"))}</span></div> <span class="small fw-semibold text-body svelte-1umj6bz">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.servers.selecting-server"))}</span></div></div>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--> `);
		if (store_get($$store_subs ??= {}, "$mainServer", mainServer) && server.id === store_get($$store_subs ??= {}, "$mainServer", mainServer).id) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<div class="position-absolute top-0 end-0 p-2 text-warning svelte-1umj6bz"><i class="fa-solid fa-crown svelte-1umj6bz"></i></div>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--> <div class="card-body d-flex flex-column flex-grow-1 align-items-center text-center p-3 min-w-0 svelte-1umj6bz"><img${attr("src", sanitizeImageSrc(server.favicon ? server.favicon : base + "/assets/img/server-icon.png", base + "/assets/img/server-icon.png"))} class="rounded border mb-2 svelte-1umj6bz" height="32" width="32"${attr("alt", server.customName || server.name)}/> <div class="fw-bold text-break w-100 mb-1 px-1 server-name svelte-1umj6bz">${escape_html(server.customName || server.name)}</div> <div class="small w-100 mb-1 px-1 server-ip text-break svelte-1umj6bz"><code class="user-select-all cursor-pointer text-break d-inline-block svelte-1umj6bz" tabindex="0">${escape_html(getPrimaryAddress(server))}</code></div> <div class="mt-auto w-100 svelte-1umj6bz"><div${attr_class("badge rounded-pill mb-1 svelte-1umj6bz", void 0, {
			"text-bg-success": server.status === "ONLINE",
			"text-bg-danger": server.status !== "ONLINE"
		})}>${escape_html(server.type)}</div> <div class="player-count svelte-1umj6bz">${escape_html(server.playerCount)}/${escape_html(server.maxPlayerCount)}</div></div></div> `);
		if (store_get($$store_subs ??= {}, "$selectedServer", selectedServer)?.id === server.id) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<div class="card-footer bg-primary text-white text-center py-1 small svelte-1umj6bz"><i class="fas fa-check-circle me-1 svelte-1umj6bz"></i> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.selected") || "Selected")}</div>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--></div></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
		bind_props($$props, {
			server,
			selectingServerId,
			copiedId,
			onSelectCard,
			onCopy
		});
	});
}
//#endregion
//#region src/lib/components/modals/ServersModal.svelte
var modalElement = writable();
var modal;
var pinnedServers = writable([]);
var otherServers = writable([]);
var loading = writable(true);
var selectingServer = writable(null);
var searchTerm = writable("");
function hide() {
	modal.hide();
}
function initData() {
	ApiUtil.get({
		path: `/api/panel/servers`,
		handler: (body, reject) => {
			if (body.error) {
				reject();
				return;
			}
			const hasNewShape = body.pinned != null || body.otherServers != null;
			const list = body.servers ?? [];
			if (hasNewShape) {
				pinnedServers.set(body.pinned ?? []);
				otherServers.set(body.otherServers ?? []);
			} else {
				pinnedServers.set([]);
				otherServers.set(list);
			}
			loading.set(false);
		}
	});
}
function ServersModal($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let filteredOtherServers;
		const selectedServer = getContext("selectedServer");
		const SERVERS_MODAL_SEARCH_INPUT_ID = "servers-modal-search-input";
		let modalEl;
		let copiedId = null;
		let copiedTimeout;
		function onCopy(e, server) {
			e.stopPropagation();
			(0, import_copy_to_clipboard.default)(getPrimaryAddress(server));
			copiedId = server.id;
			if (copiedTimeout) clearTimeout(copiedTimeout);
			copiedTimeout = setTimeout(() => {
				copiedId = null;
			}, 2e3);
		}
		function getPrimaryAddress(server) {
			return String(server?.remoteAddress || "").trim() || server?.host || "";
		}
		function getLocalAddress(server) {
			return `${server?.host || ""}:${server?.port ?? ""}`;
		}
		onDestroy(() => {});
		function onSelect(server) {
			selectingServer.set(server.id);
			ApiUtil.post({
				path: `/api/panel/servers/${server.id}/select`,
				handler: async (body, reject) => {
					if (body.result === "ok") {
						store_set(selectedServer, server);
						await invalidateAll();
						selectingServer.set(null);
						hide();
						await showSuccess("components.toasts.server-selected", { name: server.customName || server.name });
						return;
					} else if (body.error && body.error === "NOT_EXISTS") {
						selectingServer.set(null);
						await showError("components.toasts.server-not-exists");
						initData();
						return;
					}
					selectingServer.set(null);
					reject();
				}
			});
		}
		modalElement.set(modalEl);
		filteredOtherServers = store_get($$store_subs ??= {}, "$otherServers", otherServers).filter((s) => {
			const term = store_get($$store_subs ??= {}, "$searchTerm", searchTerm).toLowerCase();
			return (s.customName || s.name || "").toLowerCase().includes(term) || getPrimaryAddress(s).toLowerCase().includes(term) || getLocalAddress(s).toLowerCase().includes(term);
		});
		$$renderer.push(`<div class="modal fade" role="dialog" data-bs-scroll="true" tabindex="-1"><div class="modal-dialog modal-xl"><div class="modal-content"><div class="modal-header flex-column align-items-stretch gap-3"><div class="d-flex w-100 align-items-start justify-content-between gap-2"><div class="d-flex flex-wrap align-items-center gap-2 min-w-0"><h5 class="modal-title mb-0 text-break">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.servers.servers"))}</h5> <button class="btn btn-sm btn-primary flex-shrink-0" type="button"${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("components.modals.servers.connect-server-button"))}><i class="fa-solid fa-plug me-1" aria-hidden="true"></i> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.servers.connect-server-button"))}</button></div> <button${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("buttons.close"))} class="btn-close flex-shrink-0 mt-1" type="button"></button></div> `);
		if (!store_get($$store_subs ??= {}, "$loading", loading) && store_get($$store_subs ??= {}, "$otherServers", otherServers).length > 0) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<div class="w-100">`);
			SearchInput($$renderer, {
				inputId: SERVERS_MODAL_SEARCH_INPUT_ID,
				placeholderKey: "components.modals.servers.search-placeholder",
				initialValue: store_get($$store_subs ??= {}, "$searchTerm", searchTerm),
				onchange: (v) => searchTerm.set(v)
			});
			$$renderer.push(`<!----></div>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--></div> <div class="modal-body">`);
		if (store_get($$store_subs ??= {}, "$loading", loading)) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 row-cols-lg-4 g-3"><!--[-->`);
			const each_array = ensure_array_like(Array(4));
			for (let i = 0, $$length = each_array.length; i < $$length; i++) {
				each_array[i];
				$$renderer.push(`<div class="col"><div class="card h-100"><div class="card-body"><div class="card-text placeholder-glow"><span class="placeholder col-3"></span></div> <div class="placeholder-glow"><span class="placeholder col-7"></span></div> <div class="card-text placeholder-glow"><span class="placeholder col-3"></span></div></div></div></div>`);
			}
			$$renderer.push(`<!--]--></div>`);
		} else if (store_get($$store_subs ??= {}, "$pinnedServers", pinnedServers).length === 0 && store_get($$store_subs ??= {}, "$otherServers", otherServers).length === 0) {
			$$renderer.push("<!--[1-->");
			NoContent($$renderer, {});
		} else {
			$$renderer.push("<!--[-1-->");
			$$renderer.push(`<div class="d-flex flex-column gap-3">`);
			if (store_get($$store_subs ??= {}, "$pinnedServers", pinnedServers).length > 0) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 row-cols-lg-4 row-cols-xl-5 g-3"><!--[-->`);
				const each_array_1 = ensure_array_like(store_get($$store_subs ??= {}, "$pinnedServers", pinnedServers));
				for (let $$index_1 = 0, $$length = each_array_1.length; $$index_1 < $$length; $$index_1++) {
					let server = each_array_1[$$index_1];
					ServersModalServerCard($$renderer, {
						server,
						selectingServerId: store_get($$store_subs ??= {}, "$selectingServer", selectingServer),
						copiedId,
						onSelectCard: onSelect,
						onCopy
					});
				}
				$$renderer.push(`<!--]--></div>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--> `);
			if (store_get($$store_subs ??= {}, "$otherServers", otherServers).length > 0) {
				$$renderer.push("<!--[0-->");
				if (store_get($$store_subs ??= {}, "$pinnedServers", pinnedServers).length > 0) {
					$$renderer.push("<!--[0-->");
					$$renderer.push(`<div class="d-flex align-items-center gap-2 my-1" role="separator"${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("components.modals.servers.other-servers-heading"))}><hr class="flex-grow-1 m-0 opacity-50"/> <span class="small text-body-secondary text-nowrap px-1">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.servers.other-servers-heading"))}</span> <hr class="flex-grow-1 m-0 opacity-50"/></div>`);
				} else $$renderer.push("<!--[-1-->");
				$$renderer.push(`<!--]--> `);
				if (filteredOtherServers.length > 0) {
					$$renderer.push("<!--[0-->");
					$$renderer.push(`<div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 row-cols-lg-4 row-cols-xl-5 g-3"><!--[-->`);
					const each_array_2 = ensure_array_like(filteredOtherServers);
					for (let $$index_2 = 0, $$length = each_array_2.length; $$index_2 < $$length; $$index_2++) {
						let server = each_array_2[$$index_2];
						ServersModalServerCard($$renderer, {
							server,
							selectingServerId: store_get($$store_subs ??= {}, "$selectingServer", selectingServer),
							copiedId,
							onSelectCard: onSelect,
							onCopy
						});
					}
					$$renderer.push(`<!--]--></div>`);
				} else if (store_get($$store_subs ??= {}, "$searchTerm", searchTerm)) {
					$$renderer.push("<!--[1-->");
					$$renderer.push(`<div class="d-flex w-100 justify-content-center align-items-center text-center text-body-secondary small py-4">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.servers.search-no-matches"))}</div>`);
				} else $$renderer.push("<!--[-1-->");
				$$renderer.push(`<!--]-->`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--></div>`);
		}
		$$renderer.push(`<!--]--></div></div></div></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
	});
}

export { ConnectServerModal as C, ServersModal as S };
//# sourceMappingURL=ServersModal.js-BMcMWCMK.js.map
