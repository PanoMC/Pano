import { _ as __exportAll } from './rolldown-runtime.js-BMnQIuNT.js';
import { r as redirect } from './exports2.js-VkmSkXbz.js';
import { b as base } from './internal.js-BRN1McAa.js';
import { W as slot, O as bind_props, Z as escape_html, Q as store_get, S as unsubscribe_stores } from './index-server.js-DdhL7Abu.js';
import './server.js-BlClO2ED.js';
import './internal2.js-CNe5OZUJ.js';
import './routing.js-N-OPb2ye.js';
import { $ as $format } from './runtime.js-BzHEw_ze.js';
import { h as hasPermission, P as Permissions } from './auth.util.js-C77uoaNq.js';
import { P as PageActions } from './PageActions.js-co-RIHDp.js';
import { P as PageNav, a as PageNavItem } from './PageNav.js-Bzzuwwjz.js';

//#region src/lib/layouts/SettingsLayout.svelte
var SettingsLayout_exports = /* @__PURE__ */ __exportAll({
	default: () => SettingsLayout,
	load: () => load
});
async function load({ parent }) {
	const parentData = await parent();
	const { user } = parentData;
	if (!hasPermission(Permissions.MANAGE_PLATFORM_SETTINGS, user)) throw redirect(302, base);
	return parentData;
}
function SettingsLayout($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let data = $$props["data"];
		$$renderer.push(`<div class="container vstack gap-3">`);
		PageActions($$renderer, { $$slots: { left: ($$renderer) => {
			$$renderer.push(`<div slot="left">`);
			PageNav($$renderer, {
				children: ($$renderer) => {
					PageNavItem($$renderer, {
						href: "/settings",
						children: ($$renderer) => {
							$$renderer.push(`<!---->${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.settings-layout.website"))}`);
						}});
					$$renderer.push(`<!----> `);
					PageNavItem($$renderer, {
						href: "/settings/platform",
						startsWith: true,
						children: ($$renderer) => {
							$$renderer.push(`<!---->${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.settings-layout.platform"))}`);
						}});
					$$renderer.push(`<!----> `);
					PageNavItem($$renderer, {
						href: "/settings/updates",
						classes: "position-relative",
						startsWith: true,
						children: ($$renderer) => {
							$$renderer.push(`<!---->${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.settings-layout.updates"))} `);
							if (data.session.basicData.hasUpdate) {
								$$renderer.push("<!--[0-->");
								$$renderer.push(`<span class="position-absolute bg-warning rounded-circle p-1" style="top: 7px; right: 6px;"></span>`);
							} else $$renderer.push("<!--[-1-->");
							$$renderer.push(`<!--]-->`);
						}});
					$$renderer.push(`<!----> `);
					PageNavItem($$renderer, {
						href: "/settings/about",
						startsWith: true,
						children: ($$renderer) => {
							$$renderer.push(`<!---->${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.settings-layout.about"))}`);
						}});
					$$renderer.push(`<!---->`);
				},
				$$slots: { default: true }
			});
			$$renderer.push(`<!----></div>`);
		} } });
		$$renderer.push(`<!----> <!--[-->`);
		slot($$renderer, $$props, "default", {}, null);
		$$renderer.push(`<!--]--></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
		bind_props($$props, { data });
	});
}

export { SettingsLayout_exports as S, SettingsLayout as a, load as l };
//# sourceMappingURL=SettingsLayout.js-DDNsZN_1.js.map
