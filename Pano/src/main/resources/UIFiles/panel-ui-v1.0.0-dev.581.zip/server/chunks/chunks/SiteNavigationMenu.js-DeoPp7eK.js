import { b as __toESM } from './rolldown-runtime.js-BMnQIuNT.js';
import { e as error, r as redirect } from './exports2.js-VkmSkXbz.js';
import { b as base } from './internal.js-BRN1McAa.js';
import { Y as get, J as getContext, T as attr, U as stringify, Z as escape_html, Q as store_get, V as attr_class, P as ensure_array_like, S as unsubscribe_stores, O as bind_props, F as writable, a3 as element, K as derived$1, y as derived, N as fallback, R as spread_props, $ as attr_style } from './index-server.js-DdhL7Abu.js';
import { p as page } from './stores.js-D5xmrOAP.js';
import './server.js-BlClO2ED.js';
import './internal2.js-CNe5OZUJ.js';
import './routing.js-N-OPb2ye.js';
import { e as buildQueryParams, b as ApiUtil, f as avatarVersion } from './Store.js-DT3aZHRb.js';
import { $ as $format } from './runtime.js-BzHEw_ze.js';
import './ToastContainer.js-Bv1jJ2dr.js';
import { h as hasPermission, P as Permissions } from './auth.util.js-C77uoaNq.js';
import { D as Date_1 } from './Date.js-DCZp_jrB.js';
import { N as NoContent } from './NoContent.js-Coj2fA9d.js';
import { S as SearchInput } from './SearchInput.js-DPW0WADK.js';
import { C as CardHeader } from './CardHeader.js-XBureLRg.js';
import { o as originalThemeMenuItems } from './Themes.js-B8ffV7iF.js';
import { P as Pagination } from './Pagination.js-sd1xTcbW.js';
import { C as CategoryBadge } from './CategoryBadge.js-DjLui7ZD.js';
import { C as CardFilters, a as CardFiltersItem } from './CardFiltersItem.js-n0hSsrtm.js';
import fs from 'fs';

//#region node_modules/@panomc/sdk/src/internal/pano-context.js
var GLOBAL_KEY$1 = "__PANO_CONTEXT__";
function getStore$1() {
	if (!globalThis[GLOBAL_KEY$1]) globalThis[GLOBAL_KEY$1] = {
		context: {},
		listeners: []
	};
	return globalThis[GLOBAL_KEY$1];
}
/**
* @typedef {import('../types.js').Pano} Pano
*/
/**
* @param {Partial<Pano>} partial
*/
function setPanoContext(partial) {
	const store = getStore$1();
	if (typeof partial !== "object" || partial === null) {
		console.warn("[PanoSDK] setPanoContext expects an object");
		return;
	}
	Object.assign(store.context, partial);
	store.listeners.forEach((fn) => {
		try {
			fn(store.context);
		} catch (e) {
			console.error("[PanoSDK] listener error", e);
		}
	});
}
//#endregion
//#region node_modules/@panomc/sdk/src/api/plugin-context.js
var GLOBAL_KEY = "__PANO_PLUGIN_CONTEXTS__";
function getStore() {
	if (!globalThis[GLOBAL_KEY]) globalThis[GLOBAL_KEY] = Object.create(null);
	return globalThis[GLOBAL_KEY];
}
function createPluginContext(pluginId) {
	if (!pluginId) throw new Error("[PanoSDK] pluginId is required");
	const store = getStore();
	if (!store[pluginId]) store[pluginId] = {
		context: {},
		listeners: []
	};
	const pluginStore = store[pluginId];
	return {
		context: pluginStore.context,
		set(partial) {
			if (typeof partial !== "object" || partial === null) return;
			Object.assign(pluginStore.context, partial);
			pluginStore.listeners.forEach((fn) => {
				try {
					fn(pluginStore.context);
				} catch (e) {
					console.error(`[PanoSDK][${pluginId}] listener error`, e);
				}
			});
		},
		subscribe(fn) {
			pluginStore.listeners.push(fn);
			return () => {
				pluginStore.listeners = pluginStore.listeners.filter((l) => l !== fn);
			};
		},
		destroy() {
			delete store[pluginId];
		}
	};
}
//#endregion
//#region node_modules/@panomc/sdk/src/api/plugin.js
/**
* @typedef {import('../types.js').Pano} Pano
* @typedef {import('../types.js').PanoPluginContext} PanoPluginContext
*/
var PanoPlugin = class {
	static isPanoPlugin = true;
	/** @type {Pano} */
	pano;
	/** @type {PanoPluginContext} */
	contextApi;
	/** @type {any} */
	context;
	constructor({ pluginId, scope } = {}) {
		if (!pluginId) throw new Error("[PanoPlugin] pluginId is required");
		this.contextApi = createPluginContext(pluginId);
		this.context = this.contextApi.context;
		this._unsubscribers = [];
	}
	/**
	* @param {Pano} pano
	*/
	onLoad(pano) {}
	onUnload() {}
	/** plugin context helper */
	setContext(partial) {
		this.contextApi.set(partial);
	}
	/** internal cleanup */
	__destroy() {
		this._unsubscribers.forEach((fn) => fn());
		this.contextApi.destroy?.();
		this.onUnload();
	}
};
//#endregion
//#region node_modules/@panomc/sdk/core/js/RouteMatcher.js
/**
* Simple route matcher that supports literals, dynamic segments [param],
* catch-all segments [...param], and basic regex patterns.
*/
var RouteMatcher = class {
	/**
	* Matches a path against a pattern.
	* @param {string} pattern - The route pattern (e.g., '/announcements/[id]')
	* @param {string} path - The actual path (e.g., '/announcements/123')
	* @returns {object|null} - Params object if matched, null otherwise
	*/
	static match(pattern, path) {
		const [pathOnly] = path.split("?");
		const normalizedPath = pathOnly === "/" ? "/" : pathOnly.replace(/\/$/, "");
		const normalizedPattern = pattern === "/" ? "/" : pattern.replace(/\/$/, "");
		if (normalizedPattern === normalizedPath) return {};
		if (pattern.startsWith("re:")) try {
			const regex = new RegExp(`^(?:${pattern.slice(3)})$`);
			const match = normalizedPath.match(regex);
			if (match) return match.groups || {};
		} catch (e) {
			console.error("Invalid regex pattern:", pattern, e);
		}
		const patternSegments = normalizedPattern.split("/").filter(Boolean);
		const pathSegments = normalizedPath.split("/").filter(Boolean);
		const params = {};
		const catchAllIndex = patternSegments.findIndex((s) => s.startsWith("[...") && s.endsWith("]"));
		if (catchAllIndex !== -1) {
			if (catchAllIndex !== patternSegments.length - 1) return null;
			if (pathSegments.length < catchAllIndex) return null;
			for (let i = 0; i < catchAllIndex; i++) if (!this.segmentsMatch(patternSegments[i], pathSegments[i], params)) return null;
			const paramName = patternSegments[catchAllIndex].slice(4, -1);
			params[paramName] = pathSegments.slice(catchAllIndex).join("/");
			return params;
		}
		if (patternSegments.length !== pathSegments.length) return null;
		for (let i = 0; i < patternSegments.length; i++) if (!this.segmentsMatch(patternSegments[i], pathSegments[i], params)) return null;
		return params;
	}
	static segmentsMatch(patternSegment, pathSegment, params) {
		if (patternSegment.startsWith("[") && patternSegment.endsWith("]")) {
			const paramName = patternSegment.slice(1, -1);
			params[paramName] = pathSegment;
			return true;
		}
		if (patternSegment.startsWith(":")) {
			const paramName = patternSegment.slice(1);
			params[paramName] = pathSegment;
			return true;
		}
		return patternSegment === pathSegment;
	}
};
/**
* Canonical form of a route key/path used for the exact-match fast path: query stripped and a
* single trailing slash removed (but `/` preserved). Used at BOTH registration and lookup so
* `/foo` and `/foo/` collapse to one entry and the exact-match map lookup always hits instead
* of falling through to the slower (and buggier) regex/segment branch.
* @param {string} path
* @returns {string}
*/
function canonicalizeRouteKey(path) {
	const [pathOnly] = String(path).split("?");
	return pathOnly === "/" ? "/" : pathOnly.replace(/\/$/, "");
}
/**
* Finds a registered page matching the given path.
* @param {Object} registeredPages - Map of patterns to page objects
* @param {string} path - The path to match
* @returns {Object|null} - The matching page object with params, or null
*/
function findMatch(registeredPages, path) {
	const normalizedPath = canonicalizeRouteKey(path);
	if (registeredPages[normalizedPath]) return {
		...registeredPages[normalizedPath],
		params: {}
	};
	for (const pattern in registeredPages) {
		const params = RouteMatcher.match(pattern, path);
		if (params) return {
			...registeredPages[pattern],
			params
		};
	}
	return null;
}
//#endregion
//#region node_modules/@panomc/sdk/core/js/PluginManager.js
var registeredPages = {};
var path;
var url;
var admZip;
var serverSidePrepared = false;
var serverSideInitialized = false;
var lastProcessedBackendHash = null;
var lastProcessedFrontendHash = null;
var preparePluginsInflight = null;
var initializePluginsInflight = null;
var initializePluginsInflightHash = null;
{
	const pathStuff = await import('path');
	const urlStuff = await import('url');
	const admZipStuff = await import('./adm-zip.js-zyGHrRJ4.js').then((m) => /* @__PURE__ */ __toESM(m.default, 1));
	path = pathStuff;
	url = urlStuff;
	admZip = admZipStuff.default;
}
var plugins = writable({});
var pluginsFolder = "plugins";
var manifestFileName = "manifest.json";
var pluginUiZipFileName = "plugin-ui.zip";
function createPluginsFolder() {
	if (!fs.existsSync(pluginsFolder)) fs.mkdirSync(pluginsFolder, { recursive: true });
}
function isDirectory(path) {
	try {
		return fs.statSync(path).isDirectory();
	} catch (error) {
		return false;
	}
}
async function downloadAndExtractZip(file, outputDir) {
	const arrayBuffer = await file.arrayBuffer();
	const buffer = Buffer.from(arrayBuffer);
	new admZip(buffer, {}).extractAllTo(outputDir, true);
}
function readPluginsFromFolder(siteInfo) {
	const readPluginsFolder = fs.readdirSync(pluginsFolder);
	const plugins = {};
	readPluginsFolder.filter((pluginId) => isDirectory(path.join(pluginsFolder, pluginId))).forEach((pluginId) => {
		try {
			const manifestFile = fs.readFileSync(path.join(pluginsFolder, pluginId, manifestFileName), {
				encoding: "utf8",
				flag: "r"
			});
			plugins[pluginId] = JSON.parse(manifestFile);
		} catch (_) {}
	});
	return plugins;
}
async function downloadPluginUiZip(pluginId) {
	return await ApiUtil.get({
		path: `/api/plugins/${pluginId}/resources/${pluginUiZipFileName}`,
		blob: true
	});
}
function isPluginFolderIntact(pluginFolder) {
	return fs.existsSync(path.join(pluginFolder, manifestFileName)) && isDirectory(path.join(pluginFolder, "server")) && isDirectory(path.join(pluginFolder, "client"));
}
function purgeIncompletePluginFolders() {
	let entries;
	try {
		entries = fs.readdirSync(pluginsFolder);
	} catch {
		return;
	}
	entries.forEach((entry) => {
		const entryPath = path.join(pluginsFolder, entry);
		if (!isDirectory(entryPath)) return;
		if (entry.startsWith(".")) {
			fs.rmSync(entryPath, {
				recursive: true,
				force: true
			});
			return;
		}
		if (!isPluginFolderIntact(entryPath)) {
			fs.rmSync(entryPath, {
				recursive: true,
				force: true
			});
			plugins.update((p) => {
				delete p[entry];
				return p;
			});
		}
	});
}
async function verifyPlugins(siteInfo) {
	const pluginsInfo = siteInfo.plugins;
	purgeIncompletePluginFolders();
	const pluginsInFolder = readPluginsFromFolder();
	const pluginIdInFolderList = Object.keys(pluginsInFolder);
	pluginIdInFolderList.forEach((pluginId) => {
		if (!pluginsInfo[pluginId]) {
			fs.rmSync(path.join(pluginsFolder, pluginId), {
				recursive: true,
				force: true
			});
			plugins.update((p) => {
				delete p[pluginId];
				return p;
			});
			return;
		}
		plugins.update((p) => {
			p[pluginId] = siteInfo.developmentMode ? {
				...pluginsInFolder[pluginId],
				uiHash: `dev-stale-${Date.now()}`
			} : pluginsInFolder[pluginId];
			return p;
		});
	});
	Object.keys(get(plugins)).filter((pluginId) => !pluginIdInFolderList.includes(pluginId)).forEach((pluginId) => {
		plugins.update((p) => {
			delete p[pluginId];
			return p;
		});
	});
	const notInstalledPlugins = Object.keys(pluginsInfo).filter((pluginId) => !get(plugins)[pluginId]);
	await Promise.all(notInstalledPlugins.map((pluginId) => downloadAndInstallPlugin(pluginId, pluginsInfo[pluginId], "install")));
	await Promise.all(Object.keys(get(plugins)).map(async (pluginId) => {
		const pluginInfoManifest = pluginsInfo[pluginId];
		if (!pluginInfoManifest) return;
		const pluginManifest = get(plugins)[pluginId];
		if (pluginManifest.version === pluginInfoManifest.version && pluginManifest.uiHash === pluginInfoManifest.uiHash) return;
		await downloadAndInstallPlugin(pluginId, pluginInfoManifest, "update");
	}));
}
/**
* Download the plugin-ui.zip for a plugin and atomically replace its folder with the new
* content. Used for both first-time installs and updates — the two used to have separate
* code paths and the update path's per-subdir swap could leave the folder as a manifest-
* only shell when the downloaded zip was malformed (no server/ or no client/ inside).
* One code path means one set of invariants to enforce.
*
* Invariant after a successful return: pluginFolder contains manifest.json + server/ +
* client/, and the `plugins` store entry matches what's on disk.
*
* On any failure (download error, malformed zip, missing server/ or client/, fs error)
* we leave the previous on-disk state untouched (so an old working build keeps serving)
* and drop the plugin from the store so the rest of the SSR pass and the browser-side
* loader skip it cleanly instead of trying to import files that don't exist. The
* `bun dev` workflow is unaffected: BE bumps the uiHash on rebuild, this function runs,
* and the new build replaces the old one wholesale.
*/
async function downloadAndInstallPlugin(pluginId, pluginManifest, mode) {
	const pluginFolder = path.join(pluginsFolder, pluginId);
	const tmpDir = path.join(pluginsFolder, `.${pluginId}.${mode}.${process.pid}.${Date.now()}`);
	try {
		await downloadAndExtractZip(await downloadPluginUiZip(pluginId), tmpDir);
		if (!isDirectory(path.join(tmpDir, "server")) || !isDirectory(path.join(tmpDir, "client"))) {
			fs.rmSync(tmpDir, {
				recursive: true,
				force: true
			});
			`${pluginId}`;
			plugins.update((p) => {
				delete p[pluginId];
				return p;
			});
			return;
		}
		fs.writeFileSync(path.join(tmpDir, manifestFileName), JSON.stringify(pluginManifest, null, 2));
		fs.rmSync(pluginFolder, {
			recursive: true,
			force: true
		});
		fs.renameSync(tmpDir, pluginFolder);
		plugins.update((p) => {
			p[pluginId] = structuredClone(pluginManifest);
			return p;
		});
		`${pluginId}`;
	} catch (e) {
		fs.rmSync(tmpDir, {
			recursive: true,
			force: true
		});
		`${mode}${pluginId}${e?.message ?? e}`;
		plugins.update((p) => {
			delete p[pluginId];
			return p;
		});
	}
}
async function preparePlugins(siteInfo) {
	if (!siteInfo || typeof siteInfo !== "object" || !siteInfo.plugins) throw error(503, "Pano backend is not reachable yet");
	const currentBackendHash = JSON.stringify(siteInfo.plugins);
	while (true) {
		if (preparePluginsInflight) {
			try {
				await preparePluginsInflight;
			} catch {}
			continue;
		}
		if (!siteInfo.developmentMode && serverSidePrepared && lastProcessedBackendHash === currentBackendHash) break;
		preparePluginsInflight = (async () => {
			createPluginsFolder();
			await verifyPlugins(siteInfo);
			serverSidePrepared = true;
			lastProcessedBackendHash = currentBackendHash;
		})();
		try {
			await preparePluginsInflight;
		} finally {
			preparePluginsInflight = null;
		}
		break;
	}
	const newSiteInfoPlugins = {};
	const loadedPlugins = get(plugins);
	Object.keys(loadedPlugins).forEach((pluginId) => {
		const plugin = loadedPlugins[pluginId];
		const vObj = plugin.version;
		const { version, uiHash } = vObj && typeof vObj === "object" ? vObj : plugin;
		const deps = plugin.dependencies;
		newSiteInfoPlugins[pluginId] = {
			version,
			uiHash,
			...deps ? { dependencies: deps } : {}
		};
	});
	siteInfo.plugins = newSiteInfoPlugins;
}
function generateStablePluginHash(siteInfoPlugins) {
	const stableData = {};
	for (const id of Object.keys(siteInfoPlugins || {}).sort()) {
		const plugin = siteInfoPlugins[id];
		const vObj = plugin.version;
		const { version, uiHash } = vObj && typeof vObj === "object" ? vObj : plugin;
		stableData[id] = {
			version,
			uiHash,
			dependencies: Array.isArray(plugin.dependencies) ? [...plugin.dependencies].sort() : []
		};
	}
	return JSON.stringify(stableData);
}
function isInitializeCacheHit(siteInfo, currentFrontendHash) {
	if (!siteInfo.developmentMode && serverSideInitialized && lastProcessedFrontendHash === currentFrontendHash) return true;
	return false;
}
async function doInitializePlugins(siteInfo, currentFrontendHash) {
	const previousRegisteredPages = registeredPages;
	registeredPages = {};
	try {
		await init();
		await loadPlugins(siteInfo);
	} catch (e) {
		registeredPages = previousRegisteredPages;
		throw e;
	}
	serverSideInitialized = true;
	lastProcessedFrontendHash = currentFrontendHash;
}
async function initializePlugins(siteInfo) {
	const currentFrontendHash = generateStablePluginHash(siteInfo.plugins);
	while (true) {
		if (isInitializeCacheHit(siteInfo, currentFrontendHash)) return;
		if (initializePluginsInflight) {
			const sameHash = initializePluginsInflightHash === currentFrontendHash;
			try {
				await initializePluginsInflight;
			} catch {}
			if (sameHash && isInitializeCacheHit(siteInfo, currentFrontendHash)) return;
			continue;
		}
		initializePluginsInflightHash = currentFrontendHash;
		initializePluginsInflight = doInitializePlugins(siteInfo, currentFrontendHash);
		try {
			await initializePluginsInflight;
		} finally {
			initializePluginsInflight = null;
			initializePluginsInflightHash = null;
		}
		return;
	}
}
var moduleCache = /* @__PURE__ */ new Map();
function buildPluginDependencyGraph(loadedPlugins) {
	const pluginIds = new Set(Object.keys(loadedPlugins));
	const graph = {};
	for (const pluginId of pluginIds) graph[pluginId] = (loadedPlugins[pluginId].dependencies || []).filter((dep) => pluginIds.has(dep));
	return graph;
}
function topologicalSortPlugins(graph) {
	const inDegree = {};
	const adj = {};
	for (const node of Object.keys(graph)) {
		if (!(node in inDegree)) inDegree[node] = 0;
		if (!(node in adj)) adj[node] = [];
	}
	for (const [node, deps] of Object.entries(graph)) for (const dep of deps) {
		if (!(dep in adj)) adj[dep] = [];
		if (!(dep in inDegree)) inDegree[dep] = 0;
		adj[dep].push(node);
		inDegree[node] = (inDegree[node] || 0) + 1;
	}
	const levels = [];
	let queue = Object.keys(inDegree).filter((n) => inDegree[n] === 0);
	while (queue.length > 0) {
		levels.push([...queue]);
		const nextQueue = [];
		for (const node of queue) for (const neighbor of adj[node] || []) {
			inDegree[neighbor]--;
			if (inDegree[neighbor] === 0) nextQueue.push(neighbor);
		}
		queue = nextQueue;
	}
	const resolved = new Set(levels.flat());
	const unresolved = Object.keys(graph).filter((n) => !resolved.has(n));
	if (unresolved.length > 0) levels.push(unresolved);
	return levels;
}
async function loadPlugins(siteInfo) {
	const pluginIds = Object.keys(get(plugins));
	await Promise.all(pluginIds.map(async (pluginId) => {
		const plugin = get(plugins)[pluginId];
		if (!plugin) return;
		{
			const pluginFolder = path.join(pluginsFolder, pluginId);
			const pluginHash = plugin.uiHash || "no-hash";
			const cacheKey = `${pluginId}-${pluginHash}`;
			if (moduleCache.has(cacheKey) && !siteInfo.developmentMode) {
				plugin.module = moduleCache.get(cacheKey);
				return;
			}
			const importSuffix = siteInfo.developmentMode ? `?${Date.now()}` : pluginHash !== "no-hash" ? `?v=${pluginHash}` : "";
			const mainPath = path.join(pluginFolder, "server", "server.mjs") + importSuffix;
			const __filename = url.fileURLToPath(import.meta.url);
			const currentDir = path.dirname(__filename);
			const targetFile = path.resolve(currentDir, process.cwd());
			const levels = path.relative(currentDir, targetFile).split(path.sep).length;
			const upDirs = `..${path.sep}`.repeat(levels);
			let module;
			try {
				module = await import(
					/* @vite-ignore */
					upDirs + mainPath
);
			} catch {
				try {
					module = await import(
						/* @vite-ignore */
						"file://" + path.join(path.resolve(upDirs + mainPath, process.cwd(), mainPath))
);
				} catch (e) {
					plugins.update((p) => {
						delete p[pluginId];
						return p;
					});
					return;
				}
			}
			plugin.module = module;
			if (!siteInfo.developmentMode) {
				const prefix = `${pluginId}-`;
				for (const key of moduleCache.keys()) if (key !== cacheKey && key.startsWith(prefix)) moduleCache.delete(key);
				moduleCache.set(cacheKey, module);
			}
		}
	}));
	const loadLevels = topologicalSortPlugins(buildPluginDependencyGraph(get(plugins)));
	for (const level of loadLevels) await Promise.all(level.map(async (pluginId) => {
		const plugin = get(plugins)[pluginId];
		if (!plugin?.module?.default) return;
		const PluginClass = plugin.module.default;
		if (!(typeof PluginClass === "function" && (PluginClass === PanoPlugin || PluginClass.prototype instanceof PanoPlugin || PluginClass.isPanoPlugin === true))) {
			plugins.update((p) => {
				delete p[pluginId];
				return p;
			});
			return;
		}
		const instance = new PluginClass({ pluginId });
		instance.pano = panoApiServer;
		try {
			await instance.onLoad();
		} catch (e) {}
	}));
}
var baseAPI = {
	isPanel: base === "/panel",
	debug: false
};
var pageAPI = { page: {
	register(page = {
		path: "",
		component: Promise,
		systemLayout: String,
		restLayout: Boolean
	}) {
		registeredPages[canonicalizeRouteKey(page.path)] = page;
	},
	unregister(path = "") {
		delete registeredPages[canonicalizeRouteKey(path)];
	},
	isPluginPage: (path = "") => registeredPages[canonicalizeRouteKey(path)] !== void 0
} };
//#endregion
//#region src/lib/components/sidebar/ServerNavigationMenu.svelte
var originalServerNavItems = [
	{
		href: "/dashboard",
		icon: "fas fa-table-columns",
		text: "components.site-navigation-menu.panel",
		startsWith: false
	},
	{
		href: "/statistics",
		icon: "fas fa-chart-pie",
		text: "components.server-navigation-menu.statistics",
		startsWith: false
	},
	{
		href: "/settings",
		icon: "fas fa-cog",
		text: "components.server-navigation-menu.settings",
		startsWith: true
	}
];
function ServerNavigationMenu($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		const selectedServer = getContext("selectedServer");
		const connectedServerCount = getContext("connectedServerCount");
		function matching(path, pathName, startsWith = false) {
			return path.toUpperCase() === pathName.toUpperCase() || path.toUpperCase() === (pathName + "/").toUpperCase() || startsWith && path.startsWith(pathName);
		}
		if (store_get($$store_subs ??= {}, "$selectedServer", selectedServer)) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<ul class="nav flex-column svelte-x2mkx5" data-bs-theme="dark"><!--[-->`);
			const each_array = ensure_array_like(store_get($$store_subs ??= {}, "$serverNavigationItems", serverNavigationItems));
			for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
				let item = each_array[$$index];
				$$renderer.push(`<li class="nav-item"><a${attr_class("nav-link text-truncate svelte-x2mkx5", void 0, { "active": matching(store_get($$store_subs ??= {}, "$page", page).url.pathname, base + "/server" + item.href, item.startsWith) })}${attr("href", base + "/server" + item.href)}><i${attr_class(`${stringify(item.icon)} me-2`, "svelte-x2mkx5")}></i> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)(item.text))}</a></li>`);
			}
			$$renderer.push(`<!--]--></ul>`);
		} else if (store_get($$store_subs ??= {}, "$connectedServerCount", connectedServerCount) > 0) {
			$$renderer.push("<!--[1-->");
			$$renderer.push(`<div data-bs-theme="dark">`);
			NoContent($$renderer, {
				icon: "fas fa-cube fa-3x",
				text: store_get($$store_subs ??= {}, "$_", $format)("components.server-navigation-menu.no-selected-server")
			});
			$$renderer.push(`<!----></div>`);
		} else {
			$$renderer.push("<!--[-1-->");
			$$renderer.push(`<div data-bs-theme="dark">`);
			NoContent($$renderer, {
				icon: "fas fa-cube fa-3x",
				text: store_get($$store_subs ??= {}, "$_", $format)("components.server-navigation-menu.no-server-text")
			});
			$$renderer.push(`<!----></div>`);
		}
		$$renderer.push(`<!--]-->`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
	});
}
var post = writable({});
function ConfirmDeletePostModal($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let loading = false;
		$$renderer.push(`<div aria-hidden="true" class="modal fade" role="dialog" tabindex="-1"><div class="modal-dialog modal-dialog-centered" role="dialog"><div class="modal-content"><div class="modal-body text-center"><div class="pb-3"><i class="fas fa-question-circle fa-3x d-block m-auto text-gray"></i></div> ${escape_html(store_get($$store_subs ??= {}, "$post", post).status === 0 ? store_get($$store_subs ??= {}, "$_", $format)("components.modals.confirm-delete-post.title-permanent") : store_get($$store_subs ??= {}, "$_", $format)("components.modals.confirm-delete-post.title-trash"))}</div> <div class="modal-footer flex-nowrap"><button${attr_class("btn btn-link col-6 m-0", void 0, { "disabled": loading })} type="button">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.cancel"))}</button> <button${attr_class("btn btn-danger col-6 m-0", void 0, { "disabled": loading })} type="button">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.yes"))}</button></div></div></div></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
	});
}
//#endregion
//#region src/lib/components/Hook.svelte
function Hook($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let { name, tag = "div", $$slots, $$events, ...rest } = $$props;
		const hookStore = derived(() => panoApiClient.ui.hook.get(name));
		const filteredHooks = derived(() => store_get($$store_subs ??= {}, "$hookStore", hookStore()) || []);
		let resolvedHooks = [];
		const hookList = derived(() => resolvedHooks.length > 0 ? resolvedHooks.map((h) => h.component || h) : filteredHooks().map((h) => h.component || h));
		const hookProps = derived(() => store_get($$store_subs ??= {}, "$page", page).data.hookProps?.[name] || []);
		$$renderer.push(`<!--[-->`);
		const each_array = ensure_array_like(hookList());
		for (let i = 0, $$length = each_array.length; i < $$length; i++) {
			let module = each_array[i];
			const props = hookProps()[i] || {};
			const hasPerm = !filteredHooks()[i]?.permission || hasPermission(filteredHooks()[i]?.permission, store_get($$store_subs ??= {}, "$page", page).data.user);
			if (module && hasPerm && typeof module !== "function") {
				$$renderer.push("<!--[0-->");
				const Component = module.default || module;
				if (!(props.hookOptions?.invisible || filteredHooks()[i]?.invisible)) {
					$$renderer.push("<!--[0-->");
					element($$renderer, tag, () => {
						$$renderer.push(`${attr_class(`hook-view-container ${stringify(rest.class || "")}`)}${attr_style(`${tag === "div" ? "display: contents;" : ""} ${stringify(rest.style || "")}`)}${attr("hookname", name)}`);
					}, () => {
						if (Component) {
							$$renderer.push("<!--[-->");
							Component($$renderer, spread_props([
								{ hookName: name },
								props,
								rest
							]));
							$$renderer.push("<!--]-->");
						} else {
							$$renderer.push("<!--[!-->");
							$$renderer.push("<!--]-->");
						}
					});
				} else $$renderer.push("<!--[-1-->");
				$$renderer.push(`<!--]-->`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]-->`);
		}
		$$renderer.push(`<!--]-->`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
	});
}
function ConfirmDraftPostModal($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let loading = false;
		$$renderer.push(`<div aria-hidden="true" class="modal fade" role="dialog" tabindex="-1"><div class="modal-dialog modal-dialog-centered" role="dialog"><div class="modal-content"><div class="modal-body text-center"><div class="pb-3"><i class="fas fa-question-circle fa-3x d-block m-auto text-gray"></i></div> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.confirm-draft-post.title"))}</div> <div class="modal-footer flex-nowrap"><button${attr_class("btn btn-link col-6 m-0", void 0, { "disabled": loading })} type="button">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.cancel"))}</button> <button${attr_class("btn btn-secondary col-6 m-0", void 0, { "disabled": loading })} type="button">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.yes"))}</button></div></div></div></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
	});
}
function ConfirmPublishPostModal($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let loading = false;
		$$renderer.push(`<div aria-hidden="true" class="modal fade" role="dialog" tabindex="-1"><div class="modal-dialog modal-dialog-centered" role="dialog"><div class="modal-content"><div class="modal-body text-center"><div class="pb-3"><i class="fas fa-question-circle fa-3x d-block m-auto text-gray"></i></div> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.confirm-publish-post.title"))}</div> <div class="modal-footer flex-nowrap"><button${attr_class("btn btn-link col-6 m-0", void 0, { "disabled": loading })} type="button">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.cancel"))}</button> <button${attr_class("btn btn-secondary col-6 m-0", void 0, { "disabled": loading })} type="button">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.yes"))}</button></div></div></div></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
	});
}
//#endregion
//#region src/lib/components/rows/TableThumbnail.svelte
function TableThumbnail($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let src = fallback($$props["src"], null);
		let alt = fallback($$props["alt"], "");
		let href = fallback($$props["href"], "#");
		let target = fallback($$props["target"], "_blank");
		let tooltipText = fallback($$props["tooltipText"], () => store_get($$store_subs ??= {}, "$_", $format)("buttons.view"), true);
		let icon = fallback($$props["icon"], "fa-image");
		let preview = fallback($$props["preview"], true);
		let anchorClass = fallback($$props["anchorClass"], "");
		function getPreviewUrl(originalUrl) {
			if (!originalUrl) return originalUrl;
			if (originalUrl.startsWith("http")) return originalUrl;
			const lastDotIndex = originalUrl.lastIndexOf(".");
			return lastDotIndex > 0 ? originalUrl.substring(0, lastDotIndex) + "-preview" + originalUrl.substring(lastDotIndex) : originalUrl + "-preview";
		}
		$$renderer.push(`<div class="table-thumbnail svelte-r1tmu">`);
		if (src) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<a${attr("href", href)}${attr("target", target)}${attr("title", tooltipText)}${attr_class(`focus-ring d-block ${stringify(anchorClass)}`, "svelte-r1tmu")}><div class="ratio ratio-16x9 thumbnail-frame bg-primary-subtle svelte-r1tmu"><img${attr("src", preview ? getPreviewUrl(src) : src)}${attr("alt", alt)}${attr("title", alt)} class="w-100 h-100 object-fit-cover svelte-r1tmu"/></div></a>`);
		} else {
			$$renderer.push("<!--[-1-->");
			$$renderer.push(`<div class="ratio ratio-16x9 thumbnail-frame bg-primary-subtle border-0 svelte-r1tmu"><div class="d-flex align-items-center justify-content-center h-100"><i${attr_class(`fas ${stringify(icon)} opacity-50 fs-5 text-primary`, "svelte-r1tmu")}></i></div></div>`);
		}
		$$renderer.push(`<!--]--></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
		bind_props($$props, {
			src,
			alt,
			href,
			target,
			tooltipText,
			icon,
			preview,
			anchorClass
		});
	});
}
//#endregion
//#region src/lib/components/rows/PostRow.svelte
function PostRow($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let post = $$props["post"];
		let pageType = $$props["pageType"];
		let buttonsLoading = $$props["buttonsLoading"];
		$$renderer.push(`<tr${attr_class("", void 0, { "table-active": post.selected })}><th scope="row" class="align-middle text-center"><div class="dropdown position-static"><button type="button" class="btn btn-link" data-bs-toggle="dropdown"${attr("title", store_get($$store_subs ??= {}, "$_", $format)("components.post-row.actions"))}${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("components.post-row.actions"))}><span class="fas fa-ellipsis-v"></span></button> <div class="dropdown-menu dropdown-menu-start"><a class="dropdown-item" target="_blank"${attr("href", `${stringify("")}/preview/post/${stringify(post.id)}`)}${attr("title", store_get($$store_subs ??= {}, "$_", $format)("buttons.view"))}><i class="fas fa-eye me-2"></i> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.view"))}</a> `);
		if (pageType !== PageTypes.DRAFT) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<button type="button"${attr_class("dropdown-item", void 0, { "disabled": buttonsLoading })}><span><i class="fa-solid fa-sheet-plastic me-2"></i> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.post-row.move-to-draft"))}</span></button>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--> `);
		if (pageType !== PageTypes.PUBLISHED) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<button type="button"${attr_class("dropdown-item", void 0, { "disabled": buttonsLoading })}><span><i class="fas fa-asterisk me-2"></i> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.post-row.publish"))}</span></button>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--> <button type="button" class="dropdown-item link-danger"><i class="fas fa-trash me-2"></i> `);
		if (pageType !== PageTypes.TRASH) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.post-row.move-to-trash"))}`);
		} else {
			$$renderer.push("<!--[-1-->");
			$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.delete"))}`);
		}
		$$renderer.push(`<!--]--></button></div></div></th>`);
		Hook($$renderer, {
			name: "panel:posts:table:row:start",
			post,
			tag: "td",
			class: "align-middle text-nowrap"
		});
		$$renderer.push(`<!----><td class="align-middle">`);
		TableThumbnail($$renderer, {
			src: post.thumbnailUrl,
			alt: post.title,
			href: `${stringify("")}/preview/post/${stringify(post.id)}`
		});
		$$renderer.push(`<!----></td>`);
		Hook($$renderer, {
			name: "panel:posts:table:row:after-thumbnail",
			post,
			tag: "td",
			class: "align-middle text-nowrap"
		});
		$$renderer.push(`<!----><td class="align-middle" style="max-width: 300px;"><a${attr("href", base + "/posts/detail/" + post.id)}${attr("title", post.title)} class="rounded focus-ring text-decoration-none d-block text-truncate">${escape_html(post.title)}</a></td>`);
		Hook($$renderer, {
			name: "panel:posts:table:row:after-title",
			post,
			tag: "td",
			class: "align-middle text-nowrap"
		});
		$$renderer.push(`<!----><td class="align-middle text-nowrap">`);
		CategoryBadge($$renderer, {
			category: post.category,
			pageType: "posts",
			filterTitle: store_get($$store_subs ??= {}, "$_", $format)("components.post-row.filter"),
			noCategoryText: store_get($$store_subs ??= {}, "$_", $format)("components.post-row.no-category")
		});
		$$renderer.push(`<!----></td>`);
		Hook($$renderer, {
			name: "panel:posts:table:row:after-category",
			post,
			tag: "td",
			class: "align-middle text-nowrap"
		});
		$$renderer.push(`<!----><td class="align-middle text-nowrap">${escape_html(post.views)}</td>`);
		Hook($$renderer, {
			name: "panel:posts:table:row:after-views",
			post,
			tag: "td",
			class: "align-middle text-nowrap"
		});
		$$renderer.push(`<!----><td class="align-middle"><a${attr("href", `${stringify(base)}/players/detail/${stringify(post.writer.username)}`)} class="d-inline-block focus-ring rounded-circle"${attr("title", post.writer.username)}><img${attr("alt", post.writer.username)} class="rounded-circle" width="32" height="32"${attr("src", `/api/profile/picture/${stringify(post.writer.username)}?${stringify(store_get($$store_subs ??= {}, "$avatarVersion", avatarVersion))}`)}/></a></td>`);
		Hook($$renderer, {
			name: "panel:posts:table:row:after-author",
			post,
			tag: "td",
			class: "align-middle text-nowrap"
		});
		$$renderer.push(`<!----><td class="align-middle text-nowrap">`);
		Date_1($$renderer, { time: post.date });
		$$renderer.push(`<!----></td>`);
		Hook($$renderer, {
			name: "panel:posts:table:row:end",
			post,
			tag: "td",
			class: "align-middle text-nowrap"
		});
		$$renderer.push(`<!----></tr>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
		bind_props($$props, {
			post,
			pageType,
			buttonsLoading
		});
	});
}
//#endregion
//#region src/lib/pages/Posts.svelte
var PageTypes = Object.freeze({
	PUBLISHED: "PUBLISHED",
	DRAFT: "DRAFT",
	TRASH: "TRASH"
});
var DefaultPageType = PageTypes.PUBLISHED;
var originalPostMenuItems = [{
	href: "/posts",
	text: "pages.post-categories.posts"
}, {
	href: "/posts/categories",
	text: "pages.posts.post-categories-button",
	startsWith: true
}];
async function load(event) {
	const { parent, url: { searchParams } } = event;
	await parent();
	let page = searchParams.get("page") || 1;
	const categoryUrl = searchParams.get("categoryUrl");
	const pageType = searchParams.get("pageType") || DefaultPageType;
	const search = searchParams.get("search");
	if (!Object.values(PageTypes).includes(pageType)) throw error(404, "PAGE_NOT_FOUND");
	const queryParams = buildQueryParams({
		page,
		pageType,
		categoryUrl,
		search
	});
	const body = await ApiUtil.get({
		path: `/api/panel/posts` + queryParams,
		request: event
	}).catch((err) => {
		throw error(500, err);
	});
	if (body.error === "PAGE_NOT_FOUND") {
		page = 1;
		const queryParams = buildQueryParams({
			page,
			categoryUrl,
			pageType
		});
		throw redirect(302, queryParams);
	}
	if (body.error) throw error(500, body.error);
	body.page = parseInt(page);
	body.pageType = pageType;
	body.categoryUrl = categoryUrl;
	body.search = search;
	await executeLifecycle("panel:posts:load", body, event);
	body.hookProps = {};
	body.hookProps["panel:posts:table:header:after-views"] = await executeHookLoad("panel:posts:table:header:after-views", event);
	body.hookProps["panel:posts:table:row:after-views"] = await executeHookLoad("panel:posts:table:row:after-views", event);
	return body;
}
function Posts($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		const { data = void 0 } = $$props;
		getContext("pageTitle");
		const slots = getContext("layout-slots");
		Object.assign(slots, { right });
		let buttonsLoading = false;
		let search = data.search || "";
		let isSearching = false;
		function right($$renderer) {
			if (!data.categoryUrl) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<a${attr("href", `${stringify(base)}/posts/create-post`)} class="btn btn-secondary" role="button"><i class="fas fa-plus"></i> <span class="d-lg-inline d-none ms-2">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.posts.create-post-button"))}</span></a>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]-->`);
		}
		$$renderer.push(`<div class="card">`);
		CardHeader($$renderer, { $$slots: {
			left: ($$renderer) => {
				$$renderer.push(`<div slot="left">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.posts.table-title", { values: {
					postCount: data.postCount,
					pageType: data.pageType === PageTypes.PUBLISHED ? store_get($$store_subs ??= {}, "$_", $format)("pages.posts.published") + " " : data.pageType === PageTypes.DRAFT ? store_get($$store_subs ??= {}, "$_", $format)("pages.posts.draft") + " " : data.pageType === PageTypes.BANNED ? store_get($$store_subs ??= {}, "$_", $format)("pages.posts.banned") + " " : ""
				} }))}</div>`);
			},
			middle: ($$renderer) => {
				$$renderer.push(`<div slot="middle" style="width: 250px;">`);
				SearchInput($$renderer, {
					initialValue: search,
					searching: isSearching,
					debounceMs: 500
				});
				$$renderer.push(`<!----></div>`);
			},
			right: ($$renderer) => {
				CardFilters($$renderer, {
					slot: "right",
					children: ($$renderer) => {
						if (!data.categoryUrl) {
							$$renderer.push("<!--[0-->");
							CardFiltersItem($$renderer, {
								href: "/posts",
								active: data.pageType === PageTypes.PUBLISHED,
								children: ($$renderer) => {
									$$renderer.push(`<!---->${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.posts.published"))}`);
								}});
							$$renderer.push(`<!----> `);
							CardFiltersItem($$renderer, {
								href: "/posts?pageType=DRAFT",
								active: data.pageType === PageTypes.DRAFT,
								children: ($$renderer) => {
									$$renderer.push(`<!---->${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.posts.draft"))}`);
								}});
							$$renderer.push(`<!----> `);
							CardFiltersItem($$renderer, {
								href: "/posts?pageType=TRASH",
								active: data.pageType === PageTypes.TRASH,
								children: ($$renderer) => {
									$$renderer.push(`<!---->${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.posts.trash"))}`);
								}});
							$$renderer.push(`<!---->`);
						} else $$renderer.push("<!--[-1-->");
						$$renderer.push(`<!--]-->`);
					},
					$$slots: { default: true }
				});
			}
		} });
		$$renderer.push(`<!----> `);
		if (data.postCount === 0) {
			$$renderer.push("<!--[0-->");
			NoContent($$renderer, {});
		} else {
			$$renderer.push("<!--[-1-->");
			$$renderer.push(`<div class="table-responsive"><table class="table table-hover"><thead><tr><th scope="col"></th>`);
			Hook($$renderer, {
				name: "panel:posts:table:header:start",
				tag: "th",
				class: "align-middle text-nowrap",
				scope: "col"
			});
			$$renderer.push(`<!----><th scope="col" class="align-middle text-nowrap">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.posts.table.image"))}</th><th class="align-middle text-nowrap" scope="col">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.posts.table.title"))}</th>`);
			Hook($$renderer, {
				name: "panel:posts:table:header:after-title",
				tag: "th",
				class: "align-middle text-nowrap",
				scope: "col"
			});
			$$renderer.push(`<!----><th scope="col"${attr_class("align-middle text-nowrap", void 0, { "table-active": data.categoryUrl })}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.posts.table.category"))}</th>`);
			Hook($$renderer, {
				name: "panel:posts:table:header:after-category",
				tag: "th",
				class: "align-middle text-nowrap",
				scope: "col"
			});
			$$renderer.push(`<!----><th scope="col" class="align-middle text-nowrap">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.posts.table.views"))}</th>`);
			Hook($$renderer, {
				name: "panel:posts:table:header:after-views",
				tag: "th",
				class: "align-middle text-nowrap",
				scope: "col"
			});
			$$renderer.push(`<!----><th scope="col" class="align-middle text-nowrap">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.posts.table.author"))}</th>`);
			Hook($$renderer, {
				name: "panel:posts:table:header:after-author",
				tag: "th",
				class: "align-middle text-nowrap",
				scope: "col"
			});
			$$renderer.push(`<!----><th scope="col" class="align-middle text-nowrap">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.posts.table.last-update"))}</th>`);
			Hook($$renderer, {
				name: "panel:posts:table:header:end",
				tag: "th",
				class: "align-middle text-nowrap",
				scope: "col"
			});
			$$renderer.push(`<!----></tr></thead><tbody><!--[-->`);
			const each_array = ensure_array_like(data.posts);
			for (let index = 0, $$length = each_array.length; index < $$length; index++) {
				let post = each_array[index];
				PostRow($$renderer, {
					post,
					pageType: data.pageType,
					buttonsLoading
				});
			}
			$$renderer.push(`<!--]--></tbody></table></div> <div class="card-footer">`);
			Pagination($$renderer, {
				page: data.page,
				totalPage: data.totalPage
			});
			$$renderer.push(`<!----></div>`);
		}
		$$renderer.push(`<!--]--></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
		bind_props($$props, { data });
	});
}
//#endregion
//#region node_modules/@panomc/theme-core/src/plugin-engine/engine.js
/**
* Pano plugin engine — the profile-agnostic machinery shared by every PluginAPI profile
* (the theme profile in `$lib/PluginAPI.js` and the panel profile in panel-ui).
*
* A "profile" is the thin file plugins actually import (`$lib/PluginAPI.js`). It composes the
* factories exported here — {@link createLifecycleRegistry}, {@link createHookEngine},
* {@link createSlotRegistry} — into its own `pano.*` namespace tree and re-exports the host
* contract (`init`, `panoApiClient`, `panoApiServer`). All the ordering/caching/SSR-safety
* fixes live here once, so both profiles get them.
*
* Nothing in this module reads SvelteKit app aliases ($app/environment, the PluginManager) or a
* theme's utils directly — the profile injects `plugins` and `browser` so this file stays a pure,
* portable engine that both the theme and panel bundles can consume.
*/
/**
* Deduplicate items by id, keeping the last occurrence. Items without an id are all kept
* (each gets a fresh Symbol key). Mutates `arr` in place.
*/
function deduplicateById(arr) {
	const seen = /* @__PURE__ */ new Map();
	for (const item of arr) if (item.id) seen.set(item.id, item);
	else seen.set(Symbol(), item);
	arr.length = 0;
	arr.push(...seen.values());
}
/**
* Deep-clone a slot item's serializable parts without touching its `component`
* (a function / component module that is not structured-cloneable). Used on the server so
* resolved load() props are merged into a per-request copy instead of the shared global entry.
*/
function structuredCloneSafe(item) {
	const { component, ...rest } = item;
	let cloned;
	try {
		cloned = structuredClone(rest);
	} catch {
		try {
			cloned = JSON.parse(JSON.stringify(rest));
		} catch {
			cloned = {
				...rest,
				props: rest.props ? { ...rest.props } : void 0
			};
		}
	}
	cloned.component = component;
	return cloned;
}
/**
* Sort hooks by their stable registration index. Sorting by the hook's importer `.toString()`
* is unsafe — that source contains build-specific chunk hashes that differ between the server
* and client bundles, so the two sides produce different orders -> hydration mismatch. The
* monotonic `_seq` captured at register time is identical across bundles, so it is the only
* deterministic key.
*/
function sortHooks(rawHooks) {
	return [...rawHooks].sort((a, b) => {
		const seqA = a._seq ?? 0;
		const seqB = b._seq ?? 0;
		if (seqA !== seqB) return seqA - seqB;
		return String(a.id ?? a.name ?? "").localeCompare(String(b.id ?? b.name ?? ""));
	});
}
/**
* Comparator for view-slot items: higher priority first, then stable registration sequence
* (so equal-priority items keep a stable order across SSR and client instead of depending on
* array insertion order), then id as the final deterministic tiebreak.
*/
function compareViewItems(a, b) {
	if (b.priority !== a.priority) return b.priority - a.priority;
	const seqA = a._seq ?? 0;
	const seqB = b._seq ?? 0;
	if (seqA !== seqB) return seqA - seqB;
	return String(a.id ?? "").localeCompare(String(b.id ?? ""));
}
/** A private monotonic counter. Each registry gets its own so hook/view sequences never collide. */
function createSeq() {
	let n = 0;
	return () => n++;
}
/**
* Named lifecycle hooks (theme:profile:load, panel:posts:load, …). Handlers run with
* Promise.allSettled so one throwing handler never blocks the others.
*/
function createLifecycleRegistry() {
	const lifecycleHandlers = writable({});
	function on(name, handler) {
		lifecycleHandlers.update((h) => {
			if (!h[name]) h[name] = [];
			h[name].push(handler);
			return h;
		});
	}
	async function executeLifecycle(name, data, event) {
		const handlers = get(lifecycleHandlers)[name] || [];
		await Promise.allSettled(handlers.map(async (handler) => {
			try {
				await handler(data, event);
			} catch (e) {
				console.error(`[Lifecycle:${name}] failed`, e);
			}
		}));
	}
	function reset() {
		lifecycleHandlers.set({});
	}
	return {
		lifecycleHandlers,
		on,
		executeLifecycle,
		reset
	};
}
/**
* Registry of render "hooks" — components mounted into named extension points that can also
* contribute load() props. Deterministic ordering (via {@link sortHooks}) is crucial for
* server/client prop synchronization; without it SSR and CSR insertion order drift and hydrate
* out of sync.
*/
function createHookEngine() {
	const hooks = writable({});
	const nextSeq = createSeq();
	const hookExecutionCache = /* @__PURE__ */ new WeakMap();
	const componentLoadCache = /* @__PURE__ */ new WeakMap();
	function register(options) {
		const { name } = options;
		const entry = options._seq === void 0 ? {
			...options,
			_seq: nextSeq()
		} : options;
		hooks.update((h) => {
			if (!h[name]) h[name] = [];
			h[name].push(entry);
			return h;
		});
	}
	function getHook(name) {
		return derived$1(hooks, ($h) => {
			return sortHooks($h[name] || []);
		});
	}
	function setVisible(name, component, visible) {
		hooks.update((h) => {
			if (!h[name]) return h;
			const idx = h[name].findIndex((item) => item.component === component || item.component?._original === component);
			if (idx !== -1) h[name][idx].invisible = !visible;
			return h;
		});
	}
	async function executeHookLoad(name, originalEvent) {
		const event = originalEvent ? {
			...originalEvent,
			hookName: name
		} : { hookName: name };
		const cacheKey = originalEvent && typeof originalEvent === "object" ? originalEvent : event;
		if (cacheKey) {
			if (!hookExecutionCache.has(cacheKey)) hookExecutionCache.set(cacheKey, {});
			const cache = hookExecutionCache.get(cacheKey);
			if (cache[name]) return cache[name];
		}
		let list = sortHooks(get(hooks)[name] || []);
		const results = await Promise.all(list.map(async (entry) => {
			const raw = entry.component || entry;
			let module = raw;
			if (typeof raw === "function" && !raw.prototype) {
				try {
					module = await raw();
				} catch (e) {
					console.error(`[Hook:${name}] Failed to load plugin module`, e);
					return {};
				}
				hooks.update((h) => {
					if (h[name]) {
						const actualIdx = h[name].findIndex((item) => (item.component || item) === raw);
						if (actualIdx !== -1) {
							const resolved = {
								...module,
								_original: raw
							};
							if (module.default) resolved.default = module.default;
							if (h[name][actualIdx].component) h[name][actualIdx].component = resolved;
							else h[name][actualIdx] = {
								...resolved,
								_seq: h[name][actualIdx]._seq
							};
						}
					}
					return h;
				});
			} else if (typeof raw !== "object" || !raw.default) module = { default: raw };
			let props = {};
			const Component = module.default || module;
			const loadFn = module.load || Component && Component.load;
			if (loadFn && !entry.skipLoad) {
				let eventCache = null;
				if (cacheKey) {
					if (!componentLoadCache.has(cacheKey)) componentLoadCache.set(cacheKey, /* @__PURE__ */ new Map());
					eventCache = componentLoadCache.get(cacheKey);
				}
				if (eventCache && eventCache.has(module)) props = eventCache.get(module);
				else try {
					props = await loadFn(event);
					if (eventCache) eventCache.set(module, props);
				} catch (e) {
					console.warn(`[Hook:${name}] Load failed`, e);
				}
			}
			return props && typeof props === "object" ? { ...props } : {};
		}));
		if (cacheKey && results.length > 0) {
			const cache = hookExecutionCache.get(cacheKey);
			cache[name] = results;
		}
		return results;
	}
	function reset() {
		hooks.set({});
	}
	return {
		hooks,
		register,
		get: getHook,
		setVisible,
		executeHookLoad,
		reset
	};
}
/**
* Registry of view-slot items — the components plugins inject into named containers
* (profile-content, navbar-right, login-content, …), plus the SSR-safe load() pipeline that
* resolves their code-split modules and merges their load() props.
*
* @param {object} deps
* @param {() => Record<string, any>} deps.getPlugins  returns the current plugin map (already
*   `get()`-resolved from the PluginManager `plugins` store). A thunk, not the store itself, so
*   this factory never reads the store at construction — the PluginManager<->PluginAPI import
*   cycle would otherwise put that binding in the temporal dead zone at module-eval time.
* @param {boolean} deps.browser  `$app/environment`'s browser flag — decides whether to clone
*   items per-request on the server.
* @param {(name: string, data: any, event: any) => Promise<void>} [deps.executeLifecycle]
*   the lifecycle registry's executor, used by executeViewLoad/executeSidebarLoad.
* @param {string} [deps.lifecyclePrefix]  lifecycle-event namespace (default "theme").
*/
function createSlotRegistry({ getPlugins, browser, executeLifecycle, lifecyclePrefix = "theme" }) {
	const uiItems = writable({});
	const nextSeq = createSeq();
	const uiLoadedCacheKeys = /* @__PURE__ */ new Map();
	function generatePluginCacheKey() {
		const loadedPlugins = getPlugins();
		if (!loadedPlugins || typeof loadedPlugins !== "object") return "";
		return Object.keys(loadedPlugins).sort().map((pluginId) => {
			const plugin = loadedPlugins[pluginId];
			return `${pluginId}:${plugin.version?.version || plugin.version || "dev"}`;
		}).join(",");
	}
	/** The register+dedupe pattern shared by every `.content.edit` / `.cardRows.edit` helper. */
	function edit(slotId, callback) {
		uiItems.update((items) => {
			if (!items[slotId]) items[slotId] = [];
			callback(items[slotId]);
			deduplicateById(items[slotId]);
			return items;
		});
	}
	/** Upsert a raw item by id (no dedup/priority/seq stamping) — used by alternativeMethods.add. */
	function upsert(slotId, item) {
		uiItems.update((items) => {
			if (!items[slotId]) items[slotId] = [];
			const existing = items[slotId].findIndex((i) => i.id === item.id);
			if (existing !== -1) items[slotId][existing] = item;
			else items[slotId].push(item);
			return items;
		});
	}
	function register(options) {
		const { viewId, id, component, priority = 10 } = options;
		uiItems.update((items) => {
			if (!items[viewId]) items[viewId] = [];
			const existingIdx = items[viewId].findIndex((i) => i.id === id);
			if (existingIdx !== -1) items[viewId][existingIdx] = {
				...items[viewId][existingIdx],
				component,
				priority,
				_seq: items[viewId][existingIdx]._seq ?? nextSeq()
			};
			else items[viewId].push({
				id,
				component,
				priority,
				hidden: false,
				_seq: nextSeq()
			});
			return items;
		});
	}
	function hide(viewId, id) {
		uiItems.update((items) => {
			if (!items[viewId]) return items;
			const item = items[viewId].find((i) => i.id === id);
			if (item) item.hidden = true;
			return items;
		});
	}
	function show(viewId, id) {
		uiItems.update((items) => {
			if (!items[viewId]) return items;
			const item = items[viewId].find((i) => i.id === id);
			if (item) item.hidden = false;
			return items;
		});
	}
	function move(viewId, id, priority) {
		uiItems.update((items) => {
			if (!items[viewId]) return items;
			const item = items[viewId].find((i) => i.id === id);
			if (item) item.priority = priority;
			return items;
		});
	}
	function getView(viewId) {
		return derived$1(uiItems, ($items) => {
			return ($items[viewId] || []).filter((item) => !item.hidden).sort(compareViewItems);
		});
	}
	async function executeComponentLoad(containerId, type, event) {
		const freshPluginCacheKey = generatePluginCacheKey();
		const items = get(uiItems)[containerId] || [];
		const resolvedItems = await Promise.all(items.map(async (item) => {
			let module = item.component;
			if (typeof item.component === "function" && !item.component.prototype) try {
				module = await item.component();
			} catch (e) {
				console.error(`[${type}:${containerId}] Failed to load component ${item.id}`, e);
				return item;
			}
			if (!module) return item;
			const Component = module.default || module;
			const loadFn = module.load || Component && Component.load;
			let props = null;
			if (loadFn) try {
				props = await loadFn(event);
			} catch (e) {
				console.warn(`[${type}:${containerId}:${item.id}] Load failed`, e);
			}
			const updatedItem = {
				...structuredCloneSafe(item),
				component: module
			};
			if (props && typeof props === "object" && Object.keys(props).length > 0) {
				if (!updatedItem.props) updatedItem.props = {};
				updatedItem.props.data = {
					...updatedItem.props.data,
					...props
				};
			}
			return updatedItem;
		}));
		uiItems.update((current) => ({
			...current,
			[containerId]: resolvedItems
		}));
		uiLoadedCacheKeys.set(containerId, freshPluginCacheKey);
		return resolvedItems;
	}
	async function executeViewLoad(viewId, event) {
		if (executeLifecycle) await executeLifecycle(`${lifecyclePrefix}:view:${viewId}:load`, {}, event);
		return await executeComponentLoad(viewId, "View", event);
	}
	async function executeSidebarLoad(sidebarId, event) {
		if (executeLifecycle) await executeLifecycle(`${lifecyclePrefix}:sidebar:${sidebarId}:load`, {}, event);
		return await executeComponentLoad(sidebarId, "Sidebar", event);
	}
	function reset() {
		uiItems.set({});
		uiLoadedCacheKeys.clear();
	}
	return {
		uiItems,
		uiLoadedCacheKeys,
		generatePluginCacheKey,
		edit,
		upsert,
		register,
		hide,
		show,
		move,
		get: getView,
		executeComponentLoad,
		executeViewLoad,
		executeSidebarLoad,
		reset
	};
}
//#endregion
//#region src/lib/PluginAPI.js
var lifecycle = createLifecycleRegistry();
var hooks = createHookEngine();
var slots = createSlotRegistry({
	getPlugins: () => get(plugins),
	browser: false,
	executeLifecycle: lifecycle.executeLifecycle,
	lifecyclePrefix: "panel"
});
var siteNavigationItems = writable([]);
var serverNavigationItems = writable([]);
var themeMenuItems = writable([]);
var postMenuItems = writable([]);
async function init() {
	siteNavigationItems.set(structuredClone(originalSiteNavItems));
	serverNavigationItems.set(structuredClone(originalServerNavItems));
	themeMenuItems.set(structuredClone(originalThemeMenuItems));
	postMenuItems.set(structuredClone(originalPostMenuItems));
	hooks.reset();
	slots.reset();
	lifecycle.reset();
}
var executeLifecycle = lifecycle.executeLifecycle;
var executeHookLoad = hooks.executeHookLoad;
var panoApi = {
	...baseAPI,
	ui: {
		...pageAPI,
		nav: {
			site: { async editNavLinks(handler = async (navigationItems) => navigationItems) {
				siteNavigationItems.set(await handler(get(siteNavigationItems)));
			} },
			server: { async editNavLinks(handler = async (navigationItems) => navigationItems) {
				serverNavigationItems.set(await handler(get(serverNavigationItems)));
			} }
		},
		view: { themes: { async editMenu(handler = async (items) => items) {
			themeMenuItems.set(await handler(get(themeMenuItems)));
		} } },
		posts: {
			async editMenu(handler = async (items) => items) {
				postMenuItems.set(await handler(get(postMenuItems)));
			},
			onLoad(handler) {
				panoApi.ui.lifecycle.on("panel:posts:load", handler);
			}
		},
		addon: { onLoad(handler) {
			panoApi.ui.lifecycle.on("panel:addon-detail:load", handler);
		} },
		player: {
			onEditLoad(handler) {
				panoApi.ui.lifecycle.on("panel:player-detail:edit-modal:load", handler);
			},
			editModal: { cardRows: {
				edit(callback) {
					slots.edit("player-edit-modal-rows", callback);
				},
				get() {
					return derived$1(slots.uiItems, ($items) => {
						return ($items["player-edit-modal-rows"] || []).filter((item) => !item.hidden).sort((a, b) => (b.priority || 0) - (a.priority || 0));
					});
				}
			} }
		},
		lifecycle: { on(name, handler) {
			lifecycle.on(name, handler);
		} },
		hook: {
			register(options) {
				hooks.register(options);
			},
			get(name) {
				return hooks.get(name);
			}
		},
		avatar: {
			updateVersion() {
				avatarVersion.set(`&v=${Date.now()}`);
			},
			getVersion() {
				return avatarVersion;
			}
		}
	}
};
var panoApiServer = { ...panoApi };
var panoApiClient = { ...panoApi };
//#endregion
//#region src/lib/components/sidebar/SiteNavigationMenu.svelte
var originalSiteNavItems = [
	{
		href: "/",
		icon: "fas fa-table-columns",
		text: "components.site-navigation-menu.panel",
		startsWith: false
	},
	{
		href: "/statistics",
		icon: "fas fa-chart-simple",
		text: "components.site-navigation-menu.statistics",
		startsWith: true
	},
	{
		href: "/posts",
		icon: "fas fa-pen",
		text: "components.site-navigation-menu.posts",
		startsWith: true,
		permission: Permissions.MANAGE_POSTS
	},
	{
		href: "/tickets",
		icon: "fas fa-ticket",
		text: "components.site-navigation-menu.tickets",
		startsWith: true,
		permission: Permissions.MANAGE_TICKETS
	},
	{
		href: "/players",
		icon: "fas fa-users",
		text: "components.site-navigation-menu.players",
		startsWith: true,
		permission: Permissions.MANAGE_PLAYERS
	},
	{
		href: "/permissions",
		icon: "fas fa-gavel",
		text: "components.site-navigation-menu.permissions",
		startsWith: true,
		permission: Permissions.MANAGE_PERMISSION_GROUPS
	},
	{
		href: "/view",
		icon: "fas fa-palette",
		text: "components.site-navigation-menu.view",
		startsWith: true,
		permission: Permissions.MANAGE_VIEW
	},
	{
		href: "/translations",
		icon: "fa-solid fa-language",
		text: "components.site-navigation-menu.translations",
		startsWith: true,
		permission: Permissions.MANAGE_TRANSLATIONS
	},
	{
		href: "/addons",
		icon: "fas fa-puzzle-piece",
		text: "components.site-navigation-menu.addons",
		startsWith: true,
		permission: Permissions.MANAGE_ADDONS
	},
	{
		href: "/logs",
		icon: "fas fa-align-left",
		text: "components.site-navigation-menu.logs",
		startsWith: true
	},
	{
		href: "/migration",
		icon: "fas fa-right-left",
		text: "components.settings-layout.migration",
		startsWith: true,
		permission: Permissions.MANAGE_PLATFORM_SETTINGS
	},
	{
		href: "/settings",
		icon: "fas fa-cog",
		text: "components.site-navigation-menu.settings",
		startsWith: true,
		permission: Permissions.MANAGE_PLATFORM_SETTINGS,
		hasUpdate: true
	}
];
function SiteNavigationMenu($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		const session = getContext("session");
		function matching(path, pathName, startsWith = false) {
			return path.toUpperCase() === pathName.toUpperCase() || path.toUpperCase() === (pathName + "/").toUpperCase() || startsWith && path.startsWith(pathName);
		}
		$$renderer.push(`<ul class="nav flex-column svelte-1vrds5d" data-bs-theme="dark"><!--[-->`);
		const each_array = ensure_array_like(store_get($$store_subs ??= {}, "$siteNavigationItems", siteNavigationItems));
		for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
			let item = each_array[$$index];
			if (!item.permission || hasPermission(item.permission)) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<li class="nav-item"><a${attr_class("nav-link text-truncate svelte-1vrds5d", void 0, { "active": matching(store_get($$store_subs ??= {}, "$page", page).url.pathname, base + item.href, item.startsWith) })}${attr("href", base + item.href)}>`);
				if (item.hasUpdate) {
					$$renderer.push("<!--[0-->");
					$$renderer.push(`<span${attr_class("position-relative", void 0, { "pe-2": store_get($$store_subs ??= {}, "$session", session).basicData.hasUpdate })}><i${attr_class(`${stringify(item.icon)} me-2`, "svelte-1vrds5d")}></i> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)(item.text))} `);
					if (store_get($$store_subs ??= {}, "$session", session).basicData.hasUpdate) {
						$$renderer.push("<!--[0-->");
						$$renderer.push(`<span class="position-absolute bg-warning rounded-circle p-1 top-0 end-0"></span>`);
					} else $$renderer.push("<!--[-1-->");
					$$renderer.push(`<!--]--></span>`);
				} else {
					$$renderer.push("<!--[-1-->");
					$$renderer.push(`<i${attr_class(`${stringify(item.icon)} me-2`, "svelte-1vrds5d")}></i> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)(item.text))}`);
				}
				$$renderer.push(`<!--]--></a></li>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]-->`);
		}
		$$renderer.push(`<!--]--></ul>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
	});
}

export { ConfirmDeletePostModal as C, Hook as H, Posts as P, SiteNavigationMenu as S, ServerNavigationMenu as a, executeLifecycle as b, ConfirmDraftPostModal as c, ConfirmPublishPostModal as d, executeHookLoad as e, postMenuItems as f, findMatch as g, panoApiClient as h, initializePlugins as i, load as l, preparePlugins as p, registeredPages as r, setPanoContext as s, themeMenuItems as t };
//# sourceMappingURL=SiteNavigationMenu.js-DeoPp7eK.js.map
