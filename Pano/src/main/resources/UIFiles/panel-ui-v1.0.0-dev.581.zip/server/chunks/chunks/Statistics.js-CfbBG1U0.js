import { e as error } from './exports2.js-VkmSkXbz.js';
import { J as getContext, Q as store_get, Z as escape_html, S as unsubscribe_stores, O as bind_props, N as fallback, a0 as onDestroy, V as attr_class, U as stringify } from './index-server.js-DdhL7Abu.js';
import { e as buildQueryParams, b as ApiUtil } from './Store.js-DT3aZHRb.js';
import { $ as $format } from './runtime.js-BzHEw_ze.js';
import './stores.js-D5xmrOAP.js';
import { e as addMonths } from './differenceInYears.js-BVSYOnW_.js';
import { C as Chart, L as LineController, a as LineElement, P as PointElement, b as LinearScale, c as CategoryScale, i as index, p as plugin_tooltip, T as TimeScale, g as plugin_title, e as plugin_legend, f as plugin_colors, h as addWeeks } from './chartjs-adapter-date-fns.esm.js-D4KsVK21.js';
import { a as startOfDay } from './parseISO.js-Cr7JVAUm.js';
import { a as endOfDay } from './differenceInMonths.js-dJH89BLU.js';
import { c as currentLanguage } from './language.util.js-ByanOnuS.js';
import './tooltip.util.js-BeLZL-Tj.js';
import { C as CardHeader } from './CardHeader.js-XBureLRg.js';
import { C as CardFilters, a as CardFiltersItem } from './CardFiltersItem.js-n0hSsrtm.js';

//#region node_modules/date-fns/subMonths.js
/**
* The subMonths function options.
*/
/**
* @name subMonths
* @category Month Helpers
* @summary Subtract the specified number of months from the given date.
*
* @description
* Subtract the specified number of months from the given date.
*
* @typeParam DateType - The `Date` type, the function operates on. Gets inferred from passed arguments. Allows to use extensions like [`UTCDate`](https://github.com/date-fns/utc).
* @typeParam ResultDate - The result `Date` type, it is the type returned from the context function if it is passed, or inferred from the arguments.
*
* @param date - The date to be changed
* @param amount - The amount of months to be subtracted.
* @param options - An object with options
*
* @returns The new date with the months subtracted
*
* @example
* // Subtract 5 months from 1 February 2015:
* const result = subMonths(new Date(2015, 1, 1), 5)
* //=> Mon Sep 01 2014 00:00:00
*/
function subMonths(date, amount, options) {
	return addMonths(date, -1, options);
}
//#endregion
//#region node_modules/date-fns/subWeeks.js
/**
* The {@link subWeeks} function options.
*/
/**
* @name subWeeks
* @category Week Helpers
* @summary Subtract the specified number of weeks from the given date.
*
* @description
* Subtract the specified number of weeks from the given date.
*
* @typeParam DateType - The `Date` type, the function operates on. Gets inferred from passed arguments. Allows to use extensions like [`UTCDate`](https://github.com/date-fns/utc).
* @typeParam ResultDate - The result `Date` type, it is the type returned from the context function if it is passed, or inferred from the arguments.
*
* @param date - The date to be changed
* @param amount - The amount of weeks to be subtracted.
* @param options - An object with options
*
* @returns The new date with the weeks subtracted
*
* @example
* // Subtract 4 weeks from 1 September 2014:
* const result = subWeeks(new Date(2014, 8, 1), 4)
* //=> Mon Aug 04 2014 00:00:00
*/
function subWeeks(date, amount, options) {
	return addWeeks(date, -1, options);
}
//#endregion
//#region src/lib/components/charts/Dashboard/WebsiteActivityChart.svelte
function WebsiteActivityChart($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		Chart.register(LineController, LineElement, PointElement, LinearScale, TimeScale, plugin_title, plugin_tooltip, plugin_legend, index, plugin_colors);
		let newRegisterData = $$props["newRegisterData"];
		let ticketsData = $$props["ticketsData"];
		let visitorData = $$props["visitorData"];
		let viewData = $$props["viewData"];
		let period = $$props["period"];
		const unsubscribeCurrentLanguage = currentLanguage.subscribe(() => {});
		onDestroy(() => {
			unsubscribeCurrentLanguage();
		});
		{
			const currentDate = /* @__PURE__ */ new Date();
			if (period === DashboardPeriod.WEEK) {
				const from = startOfDay(subWeeks(currentDate));
				const to = endOfDay(currentDate);
				from.getTime();
				to.getTime();
			} else {
				const from = startOfDay(subMonths(currentDate));
				const to = endOfDay(currentDate);
				from.getTime();
				to.getTime();
			}
		}
		$$renderer.push(`<div class="chart-container svelte-rbb5kf"><canvas id="websiteActivityChart"></canvas></div>`);
		bind_props($$props, {
			newRegisterData,
			ticketsData,
			visitorData,
			viewData,
			period
		});
	});
}
//#endregion
//#region src/lib/components/charts/SummaryStatCard.svelte
function SummaryStatCard($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let formattedValue, diff, formattedDiff, trend;
		Chart.register(LineController, LineElement, PointElement, LinearScale, CategoryScale, index, plugin_tooltip);
		let title = fallback($$props["title"], "");
		let value = fallback($$props["value"], 0);
		let previousValue = fallback($$props["previousValue"], null);
		let data = fallback($$props["data"], () => ({}), true);
		let secondaryValue = fallback($$props["secondaryValue"], "");
		let color = fallback($$props["color"], "#0d6efd");
		let colorClass = fallback($$props["colorClass"], "");
		let valueFormatter = fallback($$props["valueFormatter"], null);
		let hasComparison = fallback($$props["hasComparison"], true);
		function computeSortedEntries(d) {
			if (!d) return [];
			const entries = Object.keys(d).map((key) => ({
				date: Number(key),
				value: Number(d[key] ?? 0)
			}));
			entries.sort((a, b) => a.date - b.date);
			return entries;
		}
		function computeTrend(current, previous) {
			if (previous === null || previous === void 0) return "neutral";
			const currentNum = Number(current);
			const previousNum = Number(previous);
			if (Number.isNaN(currentNum) || Number.isNaN(previousNum)) return "neutral";
			if (currentNum > previousNum) return "up";
			if (currentNum < previousNum) return "down";
			return "neutral";
		}
		function computeDiff(current, previous) {
			if (previous === null || previous === void 0) return 0;
			const currentNum = Number(current);
			const previousNum = Number(previous);
			if (Number.isNaN(currentNum) || Number.isNaN(previousNum)) return 0;
			return currentNum - previousNum;
		}
		function formatDiff(value, customFormatter) {
			if (value === 0 || Number.isNaN(Number(value))) return "0";
			const abs = Math.abs(value);
			return customFormatter ? customFormatter(abs) : formatNumber(abs);
		}
		function computeTooltip(t, current, previous, direction) {
			if (previous === null || previous === void 0) return "";
			const diff = Number(current) - Number(previous);
			const sign = diff > 0 ? "+" : "";
			return `${direction === "up" ? t("components.summary-stat-card.trend-up") : direction === "down" ? t("components.summary-stat-card.trend-down") : t("components.summary-stat-card.trend-same")} (${sign}${formatNumber(diff)})`;
		}
		function formatNumber(n) {
			if (n === null || n === void 0 || Number.isNaN(Number(n))) return "-";
			return Number(n).toLocaleString();
		}
		onDestroy(() => {
		});
		formattedValue = valueFormatter ? valueFormatter(value) : formatNumber(value);
		diff = computeDiff(value, previousValue);
		formattedDiff = formatDiff(diff, valueFormatter);
		trend = computeTrend(value, previousValue);
		computeTooltip(store_get($$store_subs ??= {}, "$_", $format), value, previousValue, trend);
		computeSortedEntries(data);
		$$renderer.push(`<div${attr_class(`card summary-stat-card ${stringify(colorClass)}`, "svelte-1m6jjka")}><div class="card-body"><div class="card-top svelte-1m6jjka"><div class="d-flex justify-content-between align-items-start"><p class="text-truncate m-0 small">${escape_html(title)}</p> `);
		if (hasComparison) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<span${attr_class("badge rounded-pill", void 0, {
				"text-bg-success": trend === "up",
				"text-bg-danger": trend === "down",
				"text-bg-secondary": trend === "neutral"
			})}>`);
			if (trend === "up") {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<i class="fa-solid fa-arrow-up me-1"></i>`);
			} else if (trend === "down") {
				$$renderer.push("<!--[1-->");
				$$renderer.push(`<i class="fa-solid fa-arrow-down me-1"></i>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--> <span>${escape_html(formattedDiff)}</span></span>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--></div> <div class="d-flex align-items-baseline gap-2"><span class="fs-2 lh-1">${escape_html(formattedValue)}</span> `);
		if (secondaryValue) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<span class="text-truncate small">${escape_html(secondaryValue)}</span>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--></div></div> <div class="sparkline-wrapper svelte-1m6jjka"><canvas></canvas></div></div></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
		bind_props($$props, {
			title,
			value,
			previousValue,
			data,
			secondaryValue,
			color,
			colorClass,
			valueFormatter,
			hasComparison
		});
	});
}
//#endregion
//#region src/lib/pages/Statistics.svelte
var DashboardPeriod = Object.freeze({
	WEEK: "WEEK",
	MONTH: "MONTH"
});
async function load(event) {
	const { parent, url: { searchParams } } = event;
	await parent();
	const period = searchParams.get("period") || DashboardPeriod.WEEK;
	const queryParams = buildQueryParams({ period });
	const stats = await ApiUtil.get({
		path: `/api/panel/statistics` + queryParams,
		request: event
	});
	if (!stats.result) throw error(404, stats);
	return {
		...stats,
		period
	};
}
function Statistics($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let periodLabel;
		let data = $$props["data"];
		getContext("pageTitle").set("pages.statistics.title");
		periodLabel = data.period === DashboardPeriod.WEEK ? store_get($$store_subs ??= {}, "$_", $format)("pages.statistics.period-label.week") : store_get($$store_subs ??= {}, "$_", $format)("pages.statistics.period-label.month");
		$$renderer.push(`<div class="container vstack gap-3"><!---->`);
		$$renderer.push(`<div class="row g-3"><div class="col-lg-4">`);
		SummaryStatCard($$renderer, {
			title: store_get($$store_subs ??= {}, "$_", $format)("pages.statistics.online-player-card.title"),
			value: data.onlinePlayerCount,
			previousValue: data.previousOnlinePlayerCount,
			data: data.websiteActivityDataList?.onlinePlayerData || {},
			secondaryValue: periodLabel,
			color: "#ffffff",
			colorClass: "text-bg-success"
		});
		$$renderer.push(`<!----></div> <div class="col-lg-4">`);
		SummaryStatCard($$renderer, {
			title: store_get($$store_subs ??= {}, "$_", $format)("pages.statistics.new-register-card.title"),
			value: data.newRegisterCount,
			previousValue: data.previousNewRegisterCount,
			data: data.websiteActivityDataList?.newRegisterData || {},
			secondaryValue: periodLabel,
			color: "#ffffff",
			colorClass: "text-bg-info"
		});
		$$renderer.push(`<!----></div> <div class="col-lg-4">`);
		SummaryStatCard($$renderer, {
			title: store_get($$store_subs ??= {}, "$_", $format)("pages.statistics.total-player-card.title"),
			value: data.registeredPlayerCount,
			previousValue: data.previousRegisteredPlayerCount,
			data: data.websiteActivityDataList?.totalPlayerData || {},
			secondaryValue: periodLabel,
			color: "#ffffff",
			colorClass: "text-bg-primary"
		});
		$$renderer.push(`<!----></div></div>`);
		$$renderer.push(`<!----> <div class="card">`);
		CardHeader($$renderer, { $$slots: {
			left: ($$renderer) => {
				$$renderer.push(`<div slot="left">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.statistics.website-graph.title"))}</div>`);
			},
			right: ($$renderer) => {
				CardFilters($$renderer, {
					slot: "right",
					children: ($$renderer) => {
						CardFiltersItem($$renderer, {
							href: `/statistics?period=${stringify(DashboardPeriod.WEEK)}`,
							active: data.period === DashboardPeriod.WEEK,
							children: ($$renderer) => {
								$$renderer.push(`<!---->${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.statistics.website-graph.week"))}`);
							}});
						$$renderer.push(`<!----> `);
						CardFiltersItem($$renderer, {
							href: `/statistics?period=${stringify(DashboardPeriod.MONTH)}`,
							active: data.period === DashboardPeriod.MONTH,
							children: ($$renderer) => {
								$$renderer.push(`<!---->${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.statistics.website-graph.month"))}`);
							}});
						$$renderer.push(`<!---->`);
					},
					$$slots: { default: true }
				});
			}
		} });
		$$renderer.push(`<!----> <div class="d-flex"><!---->`);
		WebsiteActivityChart($$renderer, {
			newRegisterData: data.websiteActivityDataList.newRegisterData,
			visitorData: data.websiteActivityDataList.visitorData,
			viewData: data.websiteActivityDataList.viewData,
			period: data.period
		});
		$$renderer.push(`<!----></div></div> <div class="card">`);
		CardHeader($$renderer, { $$slots: { left: ($$renderer) => {
			$$renderer.push(`<div slot="left">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.statistics.total-statistics.title"))}</div>`);
		} } });
		$$renderer.push(`<!----> <div class="table-responsive"><table class="table"><tbody><tr><th scope="row">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.statistics.total-statistics.posts"))}</th><td>${escape_html(data.postCount)}</td></tr><tr><th scope="row">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.statistics.total-statistics.players"))}</th><td>${escape_html(data.registeredPlayerCount)}</td></tr><tr><th scope="row">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.statistics.total-statistics.admins"))}</th><td>${escape_html(data.adminCount)}</td></tr><tr><th scope="row">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.statistics.total-statistics.connected-servers"))}</th><td>${escape_html(data.connectedServerCount)}</td></tr><tr><th scope="row">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.statistics.total-statistics.addons"))}</th><td>${escape_html(data.installedPlugins)}</td></tr><tr><th scope="row">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.statistics.total-statistics.active-addons"))}</th><td>${escape_html(data.activePlugins)}</td></tr><tr><th scope="row">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.statistics.total-statistics.themes"))}</th><td>${escape_html(data.installedThemes)}</td></tr></tbody></table></div></div></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
		bind_props($$props, { data });
	});
}

export { Statistics as S, load as l };
//# sourceMappingURL=Statistics.js-CfbBG1U0.js.map
