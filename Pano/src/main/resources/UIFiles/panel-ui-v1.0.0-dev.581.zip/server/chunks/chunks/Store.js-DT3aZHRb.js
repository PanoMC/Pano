import { _ as __exportAll } from './rolldown-runtime.js-BMnQIuNT.js';
import { Y as get, F as writable } from './index-server.js-DdhL7Abu.js';
import './stores.js-D5xmrOAP.js';
import './server.js-BlClO2ED.js';
import './internal2.js-CNe5OZUJ.js';
import './routing.js-N-OPb2ye.js';
import './ToastContainer.js-Bv1jJ2dr.js';

//#region node_modules/@panomc/sdk/core/js/variables.js
var API_URL = "http://localhost:8088/panel/api";
var PANEL_URL = "/panel";
var PANO_WEBSITE_URL = "https://dev.panomc.com";
var PANO_WEBSITE_API_URL = "https://api-dev.panomc.com";
var PRERELEASE = "true";
var COOKIE_PREFIX = "pano_";
var CSRF_TOKEN_COOKIE_NAME = "csrf_token";
var JWT_COOKIE_NAME = "auth_token";
var CSRF_HEADER = "X-CSRF-Token";
function checkDomainRedirection() {
	if (typeof window === "undefined" || !API_URL || API_URL.startsWith("/")) return;
}
function updateApiUrl(apiUrl) {
	API_URL = apiUrl;
}
function updatePanoWebsiteUrl(panoWebsiteUrl) {
	PANO_WEBSITE_URL = panoWebsiteUrl;
}
function updatePanoWebsiteApiUrl(panoWebsiteApiUrl) {
	PANO_WEBSITE_API_URL = panoWebsiteApiUrl;
}
//#endregion
//#region node_modules/@panomc/sdk/core/js/api.util.js
var NETWORK_ERROR = "NETWORK_ERROR";
var networkErrorBody = {
	result: "error",
	error: NETWORK_ERROR
};
function buildQueryParams(params) {
	const queryString = Object.keys(params).filter((key) => params[key]).map((key) => `${encodeURIComponent(key)}=${encodeURIComponent(params[key])}`).join("&");
	return queryString === "" ? "" : "?" + queryString;
}
var ApiUtil = {
	interceptors: {},
	async get({ path, request, csrfToken, token, blob, handler }) {
		return this.customRequest({
			path,
			request,
			csrfToken,
			token,
			blob,
			handler
		});
	},
	async post({ path, request, body, headers, csrfToken, token, blob, handler, onUploadProgress }) {
		return this.customRequest({
			path,
			data: {
				method: "POST",
				credentials: "include",
				body,
				headers
			},
			request,
			csrfToken,
			token,
			blob,
			handler,
			onUploadProgress
		});
	},
	async put({ path, request, body, headers, csrfToken, token, blob, handler, onUploadProgress }) {
		return this.customRequest({
			path,
			data: {
				method: "PUT",
				credentials: "include",
				body,
				headers
			},
			request,
			csrfToken,
			token,
			blob,
			handler,
			onUploadProgress
		});
	},
	async delete({ path, request, headers, csrfToken, token, blob, handler }) {
		return this.customRequest({
			path,
			data: {
				method: "DELETE",
				headers
			},
			request,
			csrfToken,
			token,
			blob,
			handler
		});
	},
	async customRequest({ path, data = {}, request, csrfToken, token, blob, handler, onUploadProgress }) {
		if (!csrfToken) {
			let session;
			if (request && typeof request.parent === "function") session = (await request.parent()).session;
			csrfToken = session && session.csrfToken;
		}
		const CSRFHeader = csrfToken ? { [CSRF_HEADER]: csrfToken } : {};
		if (!(data.body instanceof FormData)) {
			data.body = JSON.stringify(data.body);
			data.headers = {
				"Content-Type": "application/json",
				...data.headers
			};
		}
		const options = {
			...data,
			headers: {
				...data.headers,
				...CSRFHeader
			}
		};
		if (token) options.headers["Authorization"] = `Bearer ${token}`;
		else if ("credentials" in Request.prototype) options["credentials"] = "include";
		const hasEventFetch = request && request.fetch;
		const isReverseProxied = !API_URL.includes(".panomc.com");
		if (hasEventFetch && isReverseProxied) {
			if (!path.startsWith("/api/")) path = `/api/${path.replace("/api/", "")}`;
		} else if (request && !get(initialized) || true) {
			let apiUrl = API_URL;
			if (!API_URL.includes(".panomc.com") && false);
			path = `${apiUrl}/${path.replace("/api/", "")}`;
		}
		const bodyHandler = (response) => blob ? response.blob() : response.text();
		const jsonParseHandler = (json) => {
			try {
				return JSON.parse(json);
			} catch (err) {
				return json;
			}
		};
		const requestCall = (rejectHandler) => {
			const reject = async (err) => {
				console.log(err);
				if (rejectHandler) throw new Error(err);
				if (!this.interceptors.errorHandler || !handler) return;
				this.interceptors.errorHandler(requestCall);
			};
			return (request && request.fetch ? request.fetch(path, options) : fetch(path, options)).then(bodyHandler).then(jsonParseHandler).then(async (parsedJson) => {
				if (parsedJson?.error === "DISABLED_FOR_DEMO") return;
				return handler ? await handler(parsedJson, reject) : parsedJson;
			}).catch(reject);
		};
		return requestCall();
	}
};
//#endregion
//#region src/lib/api.util.js
var api_util_exports = /* @__PURE__ */ __exportAll({
	NETWORK_ERROR: () => NETWORK_ERROR,
	buildQueryParams: () => buildQueryParams,
	default: () => ApiUtil,
	networkErrorBody: () => networkErrorBody
});
//#endregion
//#region src/lib/panelRealtime.js
/**
* SvelteKit `load` functions that call `depends(PANEL_SERVER_LIVE_LOAD_KEY)` re-run when
* `invalidate(PANEL_SERVER_LIVE_LOAD_KEY)` is called (e.g. after WebSocket server updates).
*/
var PANEL_SERVER_LIVE_LOAD_KEY = "pano:panel-server-live";
//#endregion
//#region src/lib/Store.js
var options = Object.freeze({ DEFAULT_PAGE_TITLE: "Pano" });
var networkErrorCallbacks = writable([]);
var retryingNetworkErrors = writable(false);
var quickNotifications = writable([]);
var logoutLoading = writable(false);
var initialized = writable(false);
var avatarVersion = writable("");

export { API_URL as A, COOKIE_PREFIX as C, JWT_COOKIE_NAME as J, PANO_WEBSITE_URL as P, CSRF_TOKEN_COOKIE_NAME as a, ApiUtil as b, updatePanoWebsiteUrl as c, updatePanoWebsiteApiUrl as d, buildQueryParams as e, avatarVersion as f, api_util_exports as g, networkErrorCallbacks as h, checkDomainRedirection as i, PRERELEASE as j, PANO_WEBSITE_API_URL as k, logoutLoading as l, PANEL_URL as m, networkErrorBody as n, options as o, CSRF_HEADER as p, quickNotifications as q, retryingNetworkErrors as r, PANEL_SERVER_LIVE_LOAD_KEY as s, updateApiUrl as u };
//# sourceMappingURL=Store.js-DT3aZHRb.js.map
