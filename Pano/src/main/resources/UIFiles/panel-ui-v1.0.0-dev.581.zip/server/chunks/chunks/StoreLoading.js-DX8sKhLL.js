import 'node:module';
import { r as redirect } from './exports2.js-VkmSkXbz.js';
import { b as base } from './internal.js-BRN1McAa.js';
import { J as getContext, Q as store_get, S as unsubscribe_stores, O as bind_props, V as attr_class, T as attr, $ as attr_style, U as stringify, Z as escape_html, F as writable } from './index-server.js-DdhL7Abu.js';
import './stores.js-D5xmrOAP.js';
import './server.js-BlClO2ED.js';
import './internal2.js-CNe5OZUJ.js';
import './routing.js-N-OPb2ye.js';
import { k as PANO_WEBSITE_API_URL } from './Store.js-DT3aZHRb.js';
import { $ as $format } from './runtime.js-BzHEw_ze.js';
import './ToastContainer.js-Bv1jJ2dr.js';
import { h as hasPermission, P as Permissions } from './auth.util.js-C77uoaNq.js';
import './tooltip.util.js-BeLZL-Tj.js';
import { r as require_copy_to_clipboard } from './copy-to-clipboard.js-Doa_mbw4.js';
import { P as PageActions } from './PageActions.js-co-RIHDp.js';
import { f as formatBytes } from './string.util.js-Pwbw6tDM.js';
import { F as FreemiumBadge } from './FreemiumBadge.js-DKfLAS4Z.js';
import { C as ChangelogModal } from './ChangelogModal.js-Bs6ZUEs3.js';

require_copy_to_clipboard();
var versionInfoObj = writable({ version: { resourceId: "" } });
var type = writable("ADDON");
function ConfirmInstallResourceModal($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		$$renderer.push(`<div aria-hidden="true" class="modal fade" role="dialog" tabindex="-1"><div class="modal-dialog modal-dialog-centered" role="document"><div class="modal-content"><div class="modal-body text-center"><div class="pb-3">`);
		if (store_get($$store_subs ??= {}, "$versionInfoObj", versionInfoObj)?.action === "DOWNGRADE") {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<i class="fa-solid fa-triangle-exclamation fa-3x d-block m-auto text-gray"></i>`);
		} else if (store_get($$store_subs ??= {}, "$versionInfoObj", versionInfoObj)?.action === "UPDATE") {
			$$renderer.push("<!--[1-->");
			$$renderer.push(`<i class="fa-solid fa-sync fa-3x d-block m-auto text-gray"></i>`);
		} else if (store_get($$store_subs ??= {}, "$versionInfoObj", versionInfoObj)?.action === "REINSTALL") {
			$$renderer.push("<!--[2-->");
			$$renderer.push(`<i class="fa-solid fa-rotate-right fa-3x d-block m-auto text-gray"></i>`);
		} else {
			$$renderer.push("<!--[-1-->");
			$$renderer.push(`<i class="fa-solid fa-download fa-3x d-block m-auto text-gray"></i>`);
		}
		$$renderer.push(`<!--]--></div> <h5 class="mb-3">`);
		if (store_get($$store_subs ??= {}, "$versionInfoObj", versionInfoObj)?.action === "INSTALL") {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.store-loading.install-title", { values: {
				name: store_get($$store_subs ??= {}, "$versionInfoObj", versionInfoObj).version.resourceTitle,
				version: store_get($$store_subs ??= {}, "$versionInfoObj", versionInfoObj).version.tag
			} }))}`);
		} else if (store_get($$store_subs ??= {}, "$versionInfoObj", versionInfoObj)?.action === "UPDATE") {
			$$renderer.push("<!--[1-->");
			$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.store-loading.update-title", { values: {
				name: store_get($$store_subs ??= {}, "$versionInfoObj", versionInfoObj).version.resourceTitle,
				version: store_get($$store_subs ??= {}, "$versionInfoObj", versionInfoObj).version.tag
			} }))}`);
		} else if (store_get($$store_subs ??= {}, "$versionInfoObj", versionInfoObj)?.action === "DOWNGRADE") {
			$$renderer.push("<!--[2-->");
			$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.store-loading.downgrade-title", { values: {
				name: store_get($$store_subs ??= {}, "$versionInfoObj", versionInfoObj).version.resourceTitle,
				version: store_get($$store_subs ??= {}, "$versionInfoObj", versionInfoObj).version.tag
			} }))}`);
		} else {
			$$renderer.push("<!--[-1-->");
			$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.store-loading.reinstall-title", { values: {
				name: store_get($$store_subs ??= {}, "$versionInfoObj", versionInfoObj).version.resourceTitle,
				version: store_get($$store_subs ??= {}, "$versionInfoObj", versionInfoObj).version.tag
			} }))}`);
		}
		$$renderer.push(`<!--]--></h5> `);
		if (store_get($$store_subs ??= {}, "$versionInfoObj", versionInfoObj) && !store_get($$store_subs ??= {}, "$versionInfoObj", versionInfoObj).version.verified) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<div class="alert alert-warning text-start d-flex gap-2 align-items-center mb-3" role="alert"><i class="fa-solid fa-triangle-exclamation me-2"></i> <div><strong>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.store-loading.unverified-resource-warning-title"))}</strong> <br/> <small>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.store-loading.unverified-resource-warning-description"))}</small></div></div>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--> `);
		if (store_get($$store_subs ??= {}, "$versionInfoObj", versionInfoObj)) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<div class="card"><div class="card-body"><div class="row align-items-center"><div class="col-auto"><div class="d-flex align-items-center justify-content-center rounded border overflow-hidden position-relative" style="width: 64px; height: 64px;">`);
			if (store_get($$store_subs ??= {}, "$type", type) === "ADDON") {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<img${attr("src", `${stringify(PANO_WEBSITE_API_URL)}/resources/${stringify(store_get($$store_subs ??= {}, "$versionInfoObj", versionInfoObj).version.resourceId)}/icon?preview=true`)} alt="Icon" width="64" height="64" class="object-fit-contain w-100 h-100 p-1" loading="lazy"/> <i class="fa-solid fa-puzzle-piece text-primary fs-4" style="display: none;"></i>`);
			} else if (store_get($$store_subs ??= {}, "$versionInfoObj", versionInfoObj).version.screenshots?.length > 0) {
				$$renderer.push("<!--[1-->");
				$$renderer.push(`<img${attr("src", `${stringify(PANO_WEBSITE_API_URL)}/resources/${stringify(store_get($$store_subs ??= {}, "$versionInfoObj", versionInfoObj).version.resourceId)}/screenshots/${stringify(store_get($$store_subs ??= {}, "$versionInfoObj", versionInfoObj).version.screenshots[0])}?preview=true`)} alt="Screenshot" width="64" height="64" class="object-fit-cover w-100 h-100" loading="lazy"/>`);
			} else {
				$$renderer.push("<!--[-1-->");
				$$renderer.push(`<i class="fa-solid fa-palette text-primary fs-4"></i>`);
			}
			$$renderer.push(`<!--]--></div> <div class="d-flex align-items-center justify-content-center gap-1 mt-1"><button class="btn btn-sm btn-link"${attr("title", store_get($$store_subs ??= {}, "$_", $format)("pages.settings.updates.changelog"))}${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("pages.settings.updates.changelog"))}><i class="fa-regular fa-file-lines fa-lg"></i></button> <button class="btn btn-sm btn-link"${attr("title", store_get($$store_subs ??= {}, "$_", $format)("pages.settings.updates.copy-hash"))}${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("pages.settings.updates.copy-hash"))}><i class="fa-solid fa-hashtag fa-lg"></i></button></div></div> <div class="col text-start"><div class="d-flex align-items-center gap-2 mb-1 flex-wrap"><div class="d-flex align-items-center gap-2"><h5 class="mb-0 text-truncate">${escape_html(store_get($$store_subs ??= {}, "$versionInfoObj", versionInfoObj).version.resourceTitle)}</h5> `);
			if (store_get($$store_subs ??= {}, "$versionInfoObj", versionInfoObj).version.verified) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<i class="fa-solid fa-circle-check text-success small"${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("pages.settings.updates.verified"))}></i>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--> `);
			if (store_get($$store_subs ??= {}, "$versionInfoObj", versionInfoObj).version.freemium) {
				$$renderer.push("<!--[0-->");
				FreemiumBadge($$renderer);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--></div> <div class="small font-monospace">${escape_html(store_get($$store_subs ??= {}, "$versionInfoObj", versionInfoObj).version.resourceId)}</div></div> <div class="small d-flex align-items-center gap-3 mt-3"><span${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("components.store-loading.author"))}><i class="fas fa-user me-1"></i> ${escape_html(store_get($$store_subs ??= {}, "$versionInfoObj", versionInfoObj).version.author)}</span> `);
			if (store_get($$store_subs ??= {}, "$versionInfoObj", versionInfoObj).version.size > 0) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<span${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("components.store-loading.size"))}><i class="fas fa-database me-1"></i> ${escape_html(formatBytes(store_get($$store_subs ??= {}, "$versionInfoObj", versionInfoObj).version.size))}</span>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--> `);
			if (store_get($$store_subs ??= {}, "$versionInfoObj", versionInfoObj).action === "UPDATE" || store_get($$store_subs ??= {}, "$versionInfoObj", versionInfoObj).action === "DOWNGRADE") {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<span class="badge text-bg-secondary ms-auto">${escape_html(store_get($$store_subs ??= {}, "$versionInfoObj", versionInfoObj).installed?.version || "?")} <i class="fas fa-arrow-right fa-xs mx-1"></i> ${escape_html(store_get($$store_subs ??= {}, "$versionInfoObj", versionInfoObj).version.tag)}</span>`);
			} else {
				$$renderer.push("<!--[-1-->");
				$$renderer.push(`<span class="badge text-bg-secondary ms-auto">${escape_html(store_get($$store_subs ??= {}, "$versionInfoObj", versionInfoObj).version.tag)}</span>`);
			}
			$$renderer.push(`<!--]--></div></div></div></div></div> `);
			if (store_get($$store_subs ??= {}, "$versionInfoObj", versionInfoObj).action === "DOWNGRADE") {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<div class="alert alert-warning mt-3 text-start d-flex gap-2 align-items-start mb-0"><div class="flex-shrink-0 mt-1"><i class="fa-solid fa-triangle-exclamation me-2"></i></div> <div class="small"><strong>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.store-loading.downgrade-warning-title"))}</strong> <br/> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.store-loading.downgrade-warning-description"))}</div></div>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]-->`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--></div> <div class="modal-footer flex-nowrap"><button class="btn btn-link col-6 m-0" type="button">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.cancel"))}</button> <button${attr_class("btn btn-secondary col-6 m-0", void 0, { "btn-warning": store_get($$store_subs ??= {}, "$versionInfoObj", versionInfoObj)?.action === "DOWNGRADE" })} type="button">`);
		if (store_get($$store_subs ??= {}, "$versionInfoObj", versionInfoObj)?.action === "INSTALL") {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<i class="fa-solid fa-download me-2"></i> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.install"))}`);
		} else if (store_get($$store_subs ??= {}, "$versionInfoObj", versionInfoObj)?.action === "UPDATE") {
			$$renderer.push("<!--[1-->");
			$$renderer.push(`<i class="fa-solid fa-sync me-2"></i> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.update"))}`);
		} else if (store_get($$store_subs ??= {}, "$versionInfoObj", versionInfoObj)?.action === "DOWNGRADE") {
			$$renderer.push("<!--[2-->");
			$$renderer.push(`<i class="fa-solid fa-arrow-down me-2"></i> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.downgrade"))}`);
		} else {
			$$renderer.push("<!--[-1-->");
			$$renderer.push(`<i class="fa-solid fa-rotate-right me-2"></i> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.reinstall"))}`);
		}
		$$renderer.push(`<!--]--></button></div></div></div></div> `);
		ChangelogModal($$renderer);
		$$renderer.push(`<!---->`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
	});
}
//#endregion
//#region src/lib/pages/StoreLoading.svelte
var PageTypes = Object.freeze({
	ADDON: "ADDON",
	THEME: "THEME"
});
async function load(event, pageType) {
	const { parent, url: { searchParams } } = event;
	await parent();
	const back = searchParams.has("back");
	const install = searchParams.get("install");
	const fromInstall = searchParams.get("fromInstall");
	const previousPage = base + `/` + (pageType === PageTypes.ADDON ? "addons" : "view");
	if (back) throw redirect(302, previousPage);
	if (searchParams.has("failedLogin")) throw redirect(302, previousPage + "?failedLogin");
	return {
		pageType,
		accountConnected: true,
		installingView: !!install,
		install,
		fromInstall
	};
}
function StoreLoading($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let canConnectPanoAccount;
		let data = $$props["data"];
		getContext("showSplash");
		getContext("panelTheme");
		const user = getContext("user");
		canConnectPanoAccount = hasPermission(Permissions.MANAGE_PLATFORM_SETTINGS, store_get($$store_subs ??= {}, "$user", user));
		function accountNotConnectedSnippet($$renderer) {
			$$renderer.push(`<div${attr_class("alert alert-secondary connect-account-board border mb-0 focus-ring svelte-1x9jr9l", void 0, {
				"interactive": canConnectPanoAccount && true,
				"opacity-75": !canConnectPanoAccount,
				"pe-none": !canConnectPanoAccount
			})} role="alert"${attr("aria-disabled", !canConnectPanoAccount)}${attr_style(`background-image: var(--welcome-gradient), url('${stringify(base)}/assets/img/connect-pano-bg.png');`)}><div class="row align-items-center"><div class="col-lg-9"><h5 class="alert-heading mb-2"><i class="fa-solid fa-user-circle me-2"></i> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.platform.online-account"))}</h5> <p class="mb-0 text-body">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.platform.connect-online-account-alert"))}</p></div> <div class="col-lg-3 text-lg-end mt-3 mt-lg-0"><div${attr_class("connect-prompt alert-link rounded border-0 bg-transparent p-0 svelte-1x9jr9l", void 0, { "text-body-secondary": !canConnectPanoAccount })}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.connect"))} `);
			$$renderer.push("<!--[-1-->");
			$$renderer.push(`<i class="fa-solid fa-arrow-right ms-1"></i>`);
			$$renderer.push(`<!--]--></div></div></div></div>`);
		}
		function loadingSnippet($$renderer) {
			$$renderer.push(`<div class="vstack gap-3 text-center"><div class="spinner-border text-primary mx-auto" role="status" style="width: 1.5rem; height: 1.5rem;"><span class="visually-hidden">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.store-loading.loading"))}</span></div> <div><strong>`);
			if (data.installingView) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.store-loading.version-loading"))}`);
			} else {
				$$renderer.push("<!--[-1-->");
				$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.store-loading.store-loading"))}`);
			}
			$$renderer.push(`<!--]--></strong><br/> <small>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.store-loading.please-wait"))}</small></div></div>`);
		}
		$$renderer.push(`<div class="w-100 flex-grow-1 d-flex flex-column">`);
		if (!data.accountConnected) {
			$$renderer.push("<!--[1-->");
			$$renderer.push(`<div class="container mt-3">`);
			PageActions($$renderer, {
				leftClasses: "d-flex",
				$$slots: { left: ($$renderer) => {
					$$renderer.push(`<button class="btn btn-link" slot="left"><i class="fas fa-arrow-left"></i> <span class="d-lg-inline d-none ms-2">${escape_html(store_get($$store_subs ??= {}, "$_", $format)(data.pageType === PageTypes.ADDON ? "buttons.addons" : "buttons.themes"))}</span></button>`);
				} }
			});
			$$renderer.push(`<!----></div>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--> <div class="flex-grow-1 d-flex flex-column justify-content-center align-items-center"><div class="container"><div class="col-lg-10 mx-auto vstack gap-3">`);
		if (!data.accountConnected) {
			$$renderer.push("<!--[1-->");
			accountNotConnectedSnippet($$renderer);
		} else {
			$$renderer.push("<!--[2-->");
			loadingSnippet($$renderer);
		}
		$$renderer.push(`<!--]--></div></div></div></div> `);
		ConfirmInstallResourceModal($$renderer);
		$$renderer.push(`<!---->`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
		bind_props($$props, { data });
	});
}

export { PageTypes as P, StoreLoading as S, load as l };
//# sourceMappingURL=StoreLoading.js-DX8sKhLL.js.map
