import { e as error } from './exports2.js-VkmSkXbz.js';
import { b as base } from './internal.js-BRN1McAa.js';
import { J as getContext, T as attr, U as stringify, Z as escape_html, Q as store_get, V as attr_class, P as ensure_array_like, S as unsubscribe_stores, O as bind_props, y as derived, F as writable } from './index-server.js-DdhL7Abu.js';
import './server.js-BlClO2ED.js';
import './internal2.js-CNe5OZUJ.js';
import './routing.js-N-OPb2ye.js';
import './stores.js-D5xmrOAP.js';
import { b as ApiUtil, P as PANO_WEBSITE_URL } from './Store.js-DT3aZHRb.js';
import { $ as $format } from './runtime.js-BzHEw_ze.js';
import './ToastContainer.js-Bv1jJ2dr.js';
import { D as Date_1 } from './Date.js-DCZp_jrB.js';
import { w as websiteDisplayHost } from './website-display.util.js-DvL-i3X3.js';
import './tooltip.util.js-BeLZL-Tj.js';
import { V as VerifiedStatus } from './VerifiedStatus.js-BWWM3WML.js';
import { L as LicenseStatusBadge } from './LicenseStatusBadge.js-C5qJr3_k.js';
import { f as formatBytes } from './string.util.js-Pwbw6tDM.js';

var active = writable(false);
function ConfirmRemoveThemeModal($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let loading = false;
		$$renderer.push(`<div aria-hidden="true" class="modal fade" role="dialog" tabindex="-1"><div class="modal-dialog modal-dialog-centered" role="dialog"><div class="modal-content"><div class="modal-body text-center"><div class="pb-3"><i class="fas fa-question-circle fa-3x d-block m-auto text-gray"></i></div> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.confirm-remove-theme.title" + (store_get($$store_subs ??= {}, "$active", active) ? "-active" : "")))}</div> <div class="modal-footer flex-nowrap"><button${attr_class("btn btn-link col-6 m-0", void 0, { "disabled": loading })} type="button">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.cancel"))}</button> <button${attr_class("btn btn-danger col-6 m-0", void 0, { "disabled": loading })} type="button">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.yes"))}</button></div></div></div></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
	});
}
//#endregion
//#region src/lib/components/ThemeLicenseCard.svelte
function ThemeLicenseCard($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let { theme } = $$props;
		let refreshing = false;
		const websiteI18n = derived(() => ({ values: { website: websiteDisplayHost() } }));
		const purchaseUrl = derived(() => theme?.id ? `${PANO_WEBSITE_URL}/themes/${theme.id}` : null);
		if (theme.premium) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<div class="card"><div class="card-header d-flex align-items-center justify-content-between"><div class="d-flex align-items-center gap-2"><strong>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-detail.license-section", { default: "License" }))}</strong> `);
			LicenseStatusBadge($$renderer, {
				status: theme.licenseStatus,
				labeled: false
			});
			$$renderer.push(`<!----></div> `);
			if (theme.licenseStatus !== "LICENSED") {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<button type="button" class="btn btn-sm btn-link"${attr("disabled", refreshing, true)}${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("buttons.refresh"))}>`);
				$$renderer.push("<!--[-1-->");
				$$renderer.push(`<i class="fa-solid fa-rotate me-1"></i>`);
				$$renderer.push(`<!--]--> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.refresh"))}</button>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--></div> <div class="card-body">`);
			if (theme.licenseStatus === "LICENSED") {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<p class="mb-0 text-body-secondary">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-detail.license.active", { default: "License is active for this Pano installation." }))}</p>`);
			} else if (theme.licenseStatus === "NOT_CONNECTED") {
				$$renderer.push("<!--[1-->");
				$$renderer.push(`<p class="mb-3">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-detail.license.not-connected", {
					...websiteI18n(),
					default: "Connect your panomc.com account to verify this theme’s license."
				}))}</p> <a class="btn btn-primary"${attr("href", `${stringify(base)}/settings/platform`)}><i class="fa-solid fa-link me-2"></i> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.connect-pano-account", { default: "Connect panomc.com account" }))}</a>`);
			} else if (theme.licenseStatus === "EXPIRED") {
				$$renderer.push("<!--[2-->");
				$$renderer.push(`<p class="mb-0">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-detail.license.expired", { default: "Your license has expired. Renew it on panomc.com to keep using this theme." }))}</p>`);
			} else if (theme.licenseStatus === "NETWORK_ERROR") {
				$$renderer.push("<!--[3-->");
				$$renderer.push(`<p class="mb-0">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-detail.license.network-error", {
					...websiteI18n(),
					default: "Could not reach {website}. Check your network and try refresh."
				}))}</p>`);
			} else if (theme.licenseStatus === "VERSION_MISMATCH" || theme.licenseStatus === "AUDIENCE_MISMATCH" || theme.licenseStatus === "PLATFORM_MISMATCH") {
				$$renderer.push("<!--[4-->");
				$$renderer.push(`<p class="mb-0">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-detail.license.version-mismatch", {
					...websiteI18n(),
					default: "This theme version is not licensed for your account on {website}."
				}))}</p>`);
			} else {
				$$renderer.push("<!--[-1-->");
				$$renderer.push(`<p class="mb-3">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-detail.license.no-purchase", {
					...websiteI18n(),
					default: "No valid license found for this theme on {website}."
				}))}</p> `);
				if (purchaseUrl()) {
					$$renderer.push("<!--[0-->");
					$$renderer.push(`<a class="btn btn-warning"${attr("href", purchaseUrl())} target="_blank" rel="noopener"><i class="fa-solid fa-store me-2"></i> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.buy-theme-on-market", {
						...websiteI18n(),
						default: "Buy on {website}"
					}))}</a>`);
				} else $$renderer.push("<!--[-1-->");
				$$renderer.push(`<!--]-->`);
			}
			$$renderer.push(`<!--]--></div></div>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]-->`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
	});
}
var loading = writable(false);
var passwordError = writable(false);
var password = writable("");
function ConfirmStopThemeModal($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let confirmButtonDisabled;
		confirmButtonDisabled = store_get($$store_subs ??= {}, "$password", password).length === 0;
		$$renderer.push(`<div aria-hidden="true" class="modal fade" role="dialog" tabindex="-1"><div class="modal-dialog modal-dialog-centered" role="dialog"><div class="modal-content"><form><div class="modal-body text-center"><div class="pb-3"><i class="fas fa-question-circle fa-3x d-block m-auto text-gray"></i></div> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.confirm-stop-theme.title"))} <input${attr_class("form-control mt-3", void 0, { "border-danger": store_get($$store_subs ??= {}, "$passwordError", passwordError) })}${attr("placeholder", store_get($$store_subs ??= {}, "$_", $format)("components.modals.confirm-stop-theme.account-password"))} type="password"${attr("value", store_get($$store_subs ??= {}, "$password", password))}/></div> <div class="modal-footer flex-nowrap"><button class="btn btn-link col-6 m-0" type="button"${attr("disabled", store_get($$store_subs ??= {}, "$loading", loading), true)}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.cancel"))}</button> <button class="btn btn-danger col-6 m-0" type="submit"${attr("disabled", confirmButtonDisabled || store_get($$store_subs ??= {}, "$loading", loading), true)}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.yes"))} `);
		if (store_get($$store_subs ??= {}, "$loading", loading)) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<i class="fas fa-sync fa-spin ms-2"></i>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--></button></div></form></div></div></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
	});
}
//#endregion
//#region src/lib/pages/view/ThemeDetail.svelte
async function load(event) {
	const { parent } = event;
	await parent();
	const themeId = event.params.themeId;
	const body = await ApiUtil.get({
		path: `/api/panel/themes/${themeId}`,
		request: event
	});
	if (body.error === "NOT_FOUND") throw error(404, body.error);
	return { theme: body.data };
}
function ThemeDetail($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		const pageTitle = getContext("pageTitle");
		let data = $$props["data"];
		let theme;
		const slots = getContext("layout-slots");
		Object.assign(slots, {
			left,
			right
		});
		let activating;
		let removing;
		let stoping;
		pageTitle.set("pages.theme-detail.title");
		theme = data.theme;
		function left($$renderer) {
			$$renderer.push(`<a${attr("href", `${stringify(base)}/view`)} class="btn btn-link"><i class="fas fa-arrow-left"></i> <span class="d-lg-inline d-none ms-2">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.themes"))}</span></a>`);
		}
		function right($$renderer) {
			if (theme.installedBy !== "SYSTEM") {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<button${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("buttons.remove"))}${attr_class("btn btn-link", void 0, { "disabled": removing })} type="button"${attr("title", store_get($$store_subs ??= {}, "$_", $format)("buttons.remove"))}><i class="fas fa-trash"></i></button>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--> `);
			if (theme.verifyStatus !== "UNKNOWN") {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<a${attr("href", `${PANO_WEBSITE_URL}/themes/${theme.id}`)} target="_blank" class="btn btn-link"${attr("title", store_get($$store_subs ??= {}, "$_", $format)("buttons.show-in-store"))}${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("buttons.show-in-store"))}><i class="fas fa-store"></i></a>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--> `);
			if (theme.updateVersion) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<button type="button" class="btn btn-link position-relative"${attr("title", store_get($$store_subs ??= {}, "$_", $format)("pages.themes.update-available") + " (v" + theme.updateVersion + ")")}${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("pages.themes.update-available"))}><i class="fas fa-sync"></i> <span class="position-absolute top-0 start-100 translate-middle mt-2 badge rounded-pill bg-secondary p-1"><span class="visually-hidden">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.themes.update-available"))}</span></span></button>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--> `);
			if (theme.running) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<button${attr_class("btn btn-danger", void 0, { "disabled": stoping })} type="button"${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("buttons.stop"))}><i class="fas fa-stop"></i> <span class="d-lg-inline d-none ms-2">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.stop"))}</span></button>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--> `);
			if (!theme.running && theme.active) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<button${attr_class("btn btn-secondary", void 0, { "disabled": stoping })} type="button"><i class="fas fa-play"></i> <span class="d-lg-inline d-none ms-2">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.start"))}</span></button>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--> `);
			if (!theme.active && (!theme.premium || theme.licenseStatus === "LICENSED")) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<button class="btn btn-secondary"${attr("disabled", activating, true)}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.activate"))}`);
				$$renderer.push("<!--[-1-->");
				$$renderer.push(`<!--]--></button>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]-->`);
		}
		$$renderer.push(`<div class="card"><div class="card-body"><div class="row g-3"><div class="col-lg-6"><div id="themeCarousel" class="carousel carousel-dark slide rounded overflow-hidden" data-bs-ride="carousel"><div class="carousel-indicators"><!--[-->`);
		const each_array = ensure_array_like(theme.screenshots.length === 0 ? { "screenshot.png": "" } : Object.keys(theme.screenshots));
		for (let i = 0, $$length = each_array.length; i < $$length; i++) {
			each_array[i];
			$$renderer.push(`<button type="button" data-bs-target="#themeCarousel" data-bs-slide-to="i" class="active" aria-current="true"${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("pages.theme-detail.screenshot") + ` ${i + 1}`)}></button>`);
		}
		$$renderer.push(`<!--]--></div> <div class="carousel-inner"><!--[-->`);
		const each_array_1 = ensure_array_like(theme.screenshots.length === 0 ? { "screenshot.png": "" } : Object.keys(theme.screenshots));
		for (let i = 0, $$length = each_array_1.length; i < $$length; i++) {
			let key = each_array_1[i];
			$$renderer.push(`<div${attr_class("carousel-item" + (i === 0 ? " active" : ""))}><div class="ratio ratio-16x9"><img${attr("src", `/api/panel/themes/${theme.id}/screenshots/${key}?hash=${theme.screenshots[key]}`)} class="d-block w-100" style="object-fit: cover; object-position: top;"${attr("alt", store_get($$store_subs ??= {}, "$_", $format)("pages.theme-detail.screenshot") + ` ${i + 1}`)}/></div></div>`);
		}
		$$renderer.push(`<!--]--></div> `);
		if (theme.screenshots.length > 1) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<button class="carousel-control-prev" type="button" data-bs-target="#themeCarousel" data-bs-slide="prev"${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("buttons.previous"))}><span class="carousel-control-prev-icon"></span></button> <button class="carousel-control-next" type="button" data-bs-target="#themeCarousel" data-bs-slide="next"${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("buttons.next"))}><span class="carousel-control-next-icon"></span></button>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--></div></div> <div class="col-lg-6"><div class="d-flex flex-column h-100 justify-content-between"><div><div class="d-flex justify-content-between align-items-start"><h5 class="card-title d-flex align-items-center gap-2">${escape_html(theme.title)}`);
		VerifiedStatus($$renderer, { status: theme.verifyStatus });
		$$renderer.push(`<!----> `);
		LicenseStatusBadge($$renderer, { status: theme.licenseStatus });
		$$renderer.push(`<!----></h5> `);
		if (theme.active) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<span class="badge text-bg-success">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-detail.in-use"))}</span>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--></div> <div class="small mb-2 hstack gap-2"><span class="user-select-all font-monospace">${escape_html(theme.id)}</span> <span class="vr"></span> <span class="user-select-all font-monospace">${escape_html(theme.version)}</span> <span class="vr"></span> <span class="user-select-all font-monospace">${escape_html(theme.panoVersion)}</span></div> <p>${escape_html(theme.description)}</p></div> <ul class="list-group"><li class="list-group-item"><strong>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-detail.developer"))}:</strong> <a target="_blank"${attr("href", `${stringify(PANO_WEBSITE_URL)}/users/${stringify(theme.author)}`)}>${escape_html(theme.author)} <i class="fa-solid fa-arrow-up-right-from-square ms-1"></i></a></li> <li class="list-group-item"><strong>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-detail.license"))}:</strong> ${escape_html(theme.license || store_get($$store_subs ??= {}, "$_", $format)("pages.theme-detail.unknown"))}</li> <li class="list-group-item"><strong>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-detail.source"))}:</strong> <a class="text-truncate d-block"${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("pages.theme-detail.source"))}${attr("href", theme.sourceUrl ? theme.sourceUrl : null)} target="_blank">${escape_html(theme.sourceUrl || store_get($$store_subs ??= {}, "$_", $format)("pages.theme-detail.unknown"))} <i class="fa-solid fa-arrow-up-right-from-square ms-1"></i></a></li> <li class="list-group-item"><strong>Hash:</strong> <code class="overflow-auto text-nowrap d-block user-select-all py-1">sha256:${escape_html(theme.hash)}</code></li> <li class="list-group-item"><strong>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-detail.installed-at"))}:</strong> `);
		Date_1($$renderer, {
			time: theme.createdAt,
			relativeFormat: true
		});
		$$renderer.push(`<!----></li> <li class="list-group-item"><strong>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-detail.updated-at"))}:</strong> `);
		Date_1($$renderer, {
			time: theme.updatedAt,
			relativeFormat: true
		});
		$$renderer.push(`<!----></li> <li class="list-group-item"><strong>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-detail.installed-by"))}:</strong> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-detail.installed-by-types." + theme.installedBy))}</li> <li class="list-group-item"><strong>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-detail.size"))}:</strong> ${escape_html(formatBytes(theme.size))}</li></ul></div></div></div></div></div> `);
		if (theme.premium) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<div class="mt-3">`);
			ThemeLicenseCard($$renderer, { theme });
			$$renderer.push(`<!----></div>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--> `);
		ConfirmRemoveThemeModal($$renderer);
		$$renderer.push(`<!----> `);
		ConfirmStopThemeModal($$renderer);
		$$renderer.push(`<!---->`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
		bind_props($$props, { data });
	});
}

export { ThemeDetail as T, load as l };
//# sourceMappingURL=ThemeDetail.js-WVt3KdOE.js.map
