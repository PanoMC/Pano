import { e as error } from './exports2.js-VkmSkXbz.js';
import { b as base } from './internal.js-BRN1McAa.js';
import { J as getContext, T as attr, Q as store_get, V as attr_class, Z as escape_html, P as ensure_array_like, U as stringify, X as html, S as unsubscribe_stores, O as bind_props } from './index-server.js-DdhL7Abu.js';
import { g as goto } from './stores.js-D5xmrOAP.js';
import './server.js-BlClO2ED.js';
import './internal2.js-CNe5OZUJ.js';
import './routing.js-N-OPb2ye.js';
import { e as buildQueryParams, b as ApiUtil } from './Store.js-DT3aZHRb.js';
import { $ as $format } from './runtime.js-BzHEw_ze.js';
import './ToastContainer.js-Bv1jJ2dr.js';
import { I as InstallResourceModal } from './InstallingResourceModal.js-CaKAxtGU.js';
import { N as NoContent } from './NoContent.js-Coj2fA9d.js';
import { S as SearchInput } from './SearchInput.js-DPW0WADK.js';
import { V as VerifiedStatus } from './VerifiedStatus.js-BWWM3WML.js';
import { L as LicenseStatusBadge } from './LicenseStatusBadge.js-C5qJr3_k.js';
import { C as CardHeader } from './CardHeader.js-XBureLRg.js';

//#region src/lib/components/FailedLoginPanoStoreAlert.svelte
function FailedLoginPanoStoreAlert($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		$$renderer.push(`<div><div class="alert alert-danger d-flex align-items-center mb-0" role="alert"><i class="fa-solid fa-triangle-exclamation me-2"></i> <span>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.failed-login-pano-store"))}</span></div></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
	});
}
//#endregion
//#region src/lib/pages/view/Themes.svelte
var PageTypes = Object.freeze({
	ALL: "ALL",
	ACTIVE: "ACTIVE",
	DISABLED: "DISABLED"
});
var DefaultPageType = PageTypes.ALL;
async function load(event) {
	const { parent, url: { searchParams } } = event;
	await parent();
	const status = searchParams.get("status") || DefaultPageType;
	const search = searchParams.get("search");
	const failedLogin = searchParams.has("failedLogin");
	if (!Object.values(PageTypes).includes(status)) throw error(404, "PAGE_NOT_FOUND");
	const queryParams = buildQueryParams({
		status,
		search
	});
	const body = await ApiUtil.get({
		path: `/api/panel/themes` + queryParams,
		request: event
	});
	if (body.error) throw error(500, body.error);
	return {
		pageType: status,
		themes: body.data,
		meta: body.meta,
		failedLogin
	};
}
var originalThemeMenuItems = [{
	href: "/view",
	text: "buttons.themes"
}, {
	href: "/view/theme-settings",
	text: "buttons.theme-settings"
}];
function Themes($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let sortedThemes;
		let data = $$props["data"];
		let search = "";
		let isSearching = false;
		function onSearchInput(event) {
			search = event.detail.value;
			refreshData();
		}
		async function refreshData() {
			isSearching = true;
			const queryParams = buildQueryParams({
				status: data.pageType,
				search: search || void 0
			});
			await goto(`${base}/view${queryParams}`, {
				});
			isSearching = false;
		}
		const pageTitle = getContext("pageTitle");
		let reloading;
		pageTitle.set("pages.themes.title");
		function getFirstScreenshotUrl(theme) {
			const keys = Object.keys(theme.screenshots);
			if (keys.length === 0) return null;
			const firstKey = keys[0];
			return `${firstKey}?hash=${theme.screenshots[firstKey]}`;
		}
		const slots = getContext("layout-slots");
		Object.assign(slots, { right });
		sortedThemes = data.themes;
		function right($$renderer) {
			$$renderer.push(`<button type="button"${attr("title", store_get($$store_subs ??= {}, "$_", $format)("buttons.reload"))}${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("buttons.reload"))}${attr_class("btn btn-link svelte-17iwqly", void 0, { "active": reloading })}><i${attr_class("fas fa-sync", void 0, { "fa-spin": reloading })}></i></button> <button type="button" class="btn btn-secondary svelte-17iwqly"><i class="fas fa-plus"></i> <span class="d-lg-inline d-none ms-2">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.install-theme"))}</span></button>`);
		}
		InstallResourceModal($$renderer);
		$$renderer.push(`<!----> `);
		if (data.failedLogin) {
			$$renderer.push("<!--[0-->");
			FailedLoginPanoStoreAlert($$renderer);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--> <div class="card">`);
		CardHeader($$renderer, { $$slots: {
			left: ($$renderer) => {
				$$renderer.push(`<div slot="left">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.themes.card-title", { values: { amount: data.themes.length } }))}</div>`);
			},
			right: ($$renderer) => {
				$$renderer.push(`<div slot="right" style="width: 250px;">`);
				SearchInput($$renderer, {
					initialValue: search,
					searching: isSearching,
					debounceMs: 500,
					onchange: onSearchInput
				});
				$$renderer.push(`<!----></div>`);
			}
		} });
		$$renderer.push(`<!----> <div class="card-body">`);
		if (data.themes.length === 0) {
			$$renderer.push("<!--[0-->");
			NoContent($$renderer, {});
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--> <div class="row row-cols-xl-2 row-cols-1 g-3"><!--[-->`);
		const each_array = ensure_array_like(sortedThemes);
		for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
			let theme = each_array[$$index];
			$$renderer.push(`<div class="col"><a${attr("href", `${stringify(base)}/view/detail/${stringify(theme.id)}`)} class="text-decoration-none"><div${attr_class(`card rounded-4 position-relative overflow-hidden theme-card `, "svelte-17iwqly")}><div class="ratio ratio-16x9"><img${attr("src", `/api/panel/themes/${stringify(theme.id)}/screenshots/${stringify(getFirstScreenshotUrl(theme) || "screenshot.png")}`)} class="card-img-top object-fit-cover svelte-17iwqly" style="background-color: #eee;"${attr("alt", theme.title)}/></div> <div class="card-img-overlay d-flex flex-column justify-content-end p-3 overlay-gradient svelte-17iwqly"><h5 class="card-title mb-1 text-truncate d-flex align-items-center gap-2"><span class="text-truncate">${escape_html(theme.title)}</span> `);
			VerifiedStatus($$renderer, { status: theme.verifyStatus });
			$$renderer.push(`<!----> `);
			LicenseStatusBadge($$renderer, { status: theme.licenseStatus });
			$$renderer.push(`<!----></h5> <small class="mb-2 text-truncate opacity-75">${html(store_get($$store_subs ??= {}, "$_", $format)("pages.themes.by", { values: { author: theme.author } }))}</small> <div class="d-flex justify-content-between align-items-center mt-2"><div class="d-flex gap-2"><small class="font-monospace user-select-all opacity-75"><i class="fa-solid fa-code fa-fw me-1"></i>${escape_html(theme.version)}</small></div> <div class="hstack gap-2">`);
			if (theme.active) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<span class="badge text-bg-success svelte-17iwqly">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.themes.active"))}</span>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--></div></div></div> `);
			if (theme.updateVersion) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<button type="button" class="position-absolute top-0 end-0 m-3 btn btn-sm btn-primary rounded-circle shadow-sm svelte-17iwqly"${attr("title", store_get($$store_subs ??= {}, "$_", $format)("pages.themes.update-available") + " (v" + theme.updateVersion + ")")}${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("pages.themes.update-available"))}><i class="fas fa-sync text-white"></i></button>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--></div></a></div>`);
		}
		$$renderer.push(`<!--]--></div></div></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
		bind_props($$props, { data });
	});
}

export { FailedLoginPanoStoreAlert as F, Themes as T, load as l, originalThemeMenuItems as o };
//# sourceMappingURL=Themes.js-B8ffV7iF.js.map
