import { e as error } from './exports2.js-VkmSkXbz.js';
import { b as base } from './internal.js-BRN1McAa.js';
import { J as getContext, Z as escape_html, Q as store_get, P as ensure_array_like, S as unsubscribe_stores, O as bind_props, V as attr_class, T as attr, U as stringify, F as writable } from './index-server.js-DdhL7Abu.js';
import './stores.js-D5xmrOAP.js';
import './server.js-BlClO2ED.js';
import './internal2.js-CNe5OZUJ.js';
import './routing.js-N-OPb2ye.js';
import { e as buildQueryParams, b as ApiUtil } from './Store.js-DT3aZHRb.js';
import { $ as $format } from './runtime.js-BzHEw_ze.js';
import './ToastContainer.js-Bv1jJ2dr.js';
import './tooltip.util.js-BeLZL-Tj.js';
import { N as NoContent } from './NoContent.js-Coj2fA9d.js';
import { S as SearchInput } from './SearchInput.js-DPW0WADK.js';
import { C as CardHeader } from './CardHeader.js-XBureLRg.js';
import { P as Pagination } from './Pagination.js-sd1xTcbW.js';
import { P as PageActions } from './PageActions.js-co-RIHDp.js';
import { P as PageNav, a as PageNavItem } from './PageNav.js-Bzzuwwjz.js';

var mode = writable("create");
var category$1 = writable({});
var errors = writable([]);
function AddEditTicketCategoryModal($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let buttonDisabled;
		buttonDisabled = !store_get($$store_subs ??= {}, "$category", category$1).title;
		$$renderer.push(`<div class="modal fade" role="dialog" tabindex="-1"><div class="modal-dialog modal-dialog-centered" role="dialog"><div class="modal-content"><div class="modal-header"><h5 class="modal-title">${escape_html(store_get($$store_subs ??= {}, "$mode", mode) === "edit" ? store_get($$store_subs ??= {}, "$_", $format)("components.modals.add-edit-ticket-category.edit-category") : store_get($$store_subs ??= {}, "$_", $format)("components.modals.add-edit-ticket-category.create-category"))}</h5> <button${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("buttons.close"))} type="button" class="btn-close" data-bs-dismiss="modal"></button></div> <form><div class="modal-body"><input${attr_class("form-control form-control-lg mb-3", void 0, { "border-danger": store_get($$store_subs ??= {}, "$errors", errors).title })}${attr("placeholder", store_get($$store_subs ??= {}, "$_", $format)("components.modals.add-edit-ticket-category.inputs.title.placeholder"))} id="category" type="text"${attr("value", store_get($$store_subs ??= {}, "$category", category$1).title)}/> <textarea${attr_class("form-control", void 0, { "border-danger": store_get($$store_subs ??= {}, "$errors", errors).description })}${attr("placeholder", store_get($$store_subs ??= {}, "$_", $format)("components.modals.add-edit-ticket-category.inputs.description.placeholder"))} id="categoryDescription" type="text" rows="5">`);
		const $$body = escape_html(store_get($$store_subs ??= {}, "$category", category$1).description);
		if ($$body) $$renderer.push(`${$$body}`);
		$$renderer.push(`</textarea></div> <div class="modal-footer"><button${attr_class("btn w-100", void 0, {
			"btn-secondary": store_get($$store_subs ??= {}, "$mode", mode) === "create",
			"btn-primary": store_get($$store_subs ??= {}, "$mode", mode) === "edit",
			"disabled": buttonDisabled
		})} type="submit">${escape_html(store_get($$store_subs ??= {}, "$mode", mode) === "edit" ? store_get($$store_subs ??= {}, "$_", $format)("buttons.save") : store_get($$store_subs ??= {}, "$_", $format)("buttons.create"))}</button></div></form></div></div></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
	});
}
var category = writable({ tickets: [] });
function ConfirmDeleteTicketCategoryModal($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let loading = false;
		$$renderer.push(`<div aria-hidden="true" class="modal fade" role="dialog" tabindex="-1"><div class="modal-dialog modal-dialog-centered" role="dialog"><div class="modal-content"><div class="modal-body text-center"><div class="pb-3"><i class="fas fa-question-circle fa-3x d-block m-auto text-gray"></i></div> `);
		if (store_get($$store_subs ??= {}, "$category", category).ticketCount !== 0) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.confirm-delete-ticket-category.title-permanent"))} <br/> <br/> <!--[-->`);
			const each_array = ensure_array_like(store_get($$store_subs ??= {}, "$category", category).tickets);
			for (let index = 0, $$length = each_array.length; index < $$length; index++) {
				let ticket = each_array[index];
				$$renderer.push(`<a${attr("href", `${stringify(base)}/tickets/detail/${stringify(ticket.id)}`)} target="_blank">${escape_html(ticket.title)}</a> <br/>`);
			}
			$$renderer.push(`<!--]--> `);
			if (store_get($$store_subs ??= {}, "$category", category).ticketCount > 5) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.confirm-delete-ticket-category.more-tickets", { values: { count: store_get($$store_subs ??= {}, "$category", category).ticketCount - 5 } }))}`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--> <br/>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.confirm-delete-ticket-category.title"))}</div> <div class="modal-footer flex-nowrap"><button${attr_class("btn btn-link col-6 m-0", void 0, { "disabled": loading })} type="button">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.cancel"))}</button> <button${attr_class("btn btn-danger col-6 m-0", void 0, { "disabled": loading })} type="button">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.yes"))}</button></div></div></div></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
	});
}
//#endregion
//#region src/lib/components/rows/TicketCategoryRow.svelte
function TicketCategoryRow($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let category = $$props["category"];
		let index = $$props["index"];
		$$renderer.push(`<tr${attr_class("", void 0, { "table-active": category.selected })}><th scope="row" class="align-middle text-center"><button type="button"${attr("title", store_get($$store_subs ??= {}, "$_", $format)("buttons.delete"))}${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("buttons.delete"))} class="btn btn-link"><i class="fas fa-trash"></i></button></th><td class="align-middle" style="max-width: 200px;"><div class="text-truncate"><button type="button" class="btn btn-link p-0 text-start text-decoration-none w-100 text-truncate"${attr("title", category.title)}>${escape_html(category.title)}</button></div></td><td class="align-middle" style="max-width: 300px;"><div class="text-truncate"${attr("title", category.description)}>${escape_html(category.description)}</div></td></tr>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
		bind_props($$props, {
			category,
			index
		});
	});
}
//#endregion
//#region src/lib/pages/tickets/TicketCategories.svelte
async function load(event) {
	const { parent, url: { searchParams } } = event;
	await parent();
	const page = searchParams.get("page") || 1;
	const search = searchParams.get("search");
	const queryParams = buildQueryParams({
		page,
		search
	});
	const body = await ApiUtil.get({
		path: `/api/panel/ticket/categories` + queryParams,
		request: event
	});
	if (body.error) {
		if (body.error === "NOT_EXISTS" || body.error === "PAGE_NOT_FOUND") throw error(404, body.error);
		throw error(500, body.error);
	}
	body.page = parseInt(page);
	body.search = search;
	return body;
}
function TicketCategories($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let data = $$props["data"];
		getContext("pageTitle").set("pages.ticket-categories.title");
		let search = data.search || "";
		let isSearching = false;
		$$renderer.push(`<article class="container vstack gap-3">`);
		PageActions($$renderer, { $$slots: {
			left: ($$renderer) => {
				PageNav($$renderer, {
					slot: "left",
					children: ($$renderer) => {
						PageNavItem($$renderer, {
							href: "/tickets",
							children: ($$renderer) => {
								$$renderer.push(`<!---->${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.ticket-categories.tickets"))}`);
							}});
						$$renderer.push(`<!----> `);
						PageNavItem($$renderer, {
							href: "/tickets/categories",
							children: ($$renderer) => {
								$$renderer.push(`<!---->${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.categories"))}`);
							}});
						$$renderer.push(`<!---->`);
					},
					$$slots: { default: true }
				});
			},
			right: ($$renderer) => {
				$$renderer.push(`<button class="btn btn-secondary" type="button" slot="right"><i class="fas fa-plus"></i> <span class="d-lg-inline d-none ms-2">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.ticket-categories.create-category-button"))}</span></button>`);
			}
		} });
		$$renderer.push(`<!----> <div class="card">`);
		CardHeader($$renderer, { $$slots: {
			left: ($$renderer) => {
				$$renderer.push(`<div slot="left">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.ticket-categories.card-title", { values: { count: data.categoryCount } }))}</div>`);
			},
			right: ($$renderer) => {
				$$renderer.push(`<div slot="right" style="width: 250px;">`);
				SearchInput($$renderer, {
					initialValue: search,
					searching: isSearching,
					debounceMs: 500
				});
				$$renderer.push(`<!----></div>`);
			}
		} });
		$$renderer.push(`<!----> `);
		if (data.categoryCount === 0) {
			$$renderer.push("<!--[0-->");
			NoContent($$renderer, {});
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--> `);
		if (data.categoryCount > 0) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<div class="table-responsive"><table class="table table-hover"><thead><tr><th scope="col"></th><th class="align-middle text-nowrap" scope="col">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.ticket-categories.category"))}</th><th scope="col" class="align-middle text-nowrap">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.ticket-categories.description"))}</th></tr></thead><tbody><!--[-->`);
			const each_array = ensure_array_like(data.categories);
			for (let index = 0, $$length = each_array.length; index < $$length; index++) {
				let category = each_array[index];
				TicketCategoryRow($$renderer, {
					category,
					index
				});
			}
			$$renderer.push(`<!--]--></tbody></table></div> <div class="card-footer">`);
			Pagination($$renderer, {
				page: data.page,
				totalPage: data.totalPage
			});
			$$renderer.push(`<!----></div>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--></div></article> `);
		AddEditTicketCategoryModal($$renderer);
		$$renderer.push(`<!----> `);
		ConfirmDeleteTicketCategoryModal($$renderer);
		$$renderer.push(`<!---->`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
		bind_props($$props, { data });
	});
}

export { TicketCategories as T, load as l };
//# sourceMappingURL=TicketCategories.js-BuqvJp76.js.map
