import { e as error } from './exports2.js-VkmSkXbz.js';
import { b as base } from './internal.js-BRN1McAa.js';
import { J as getContext, O as bind_props, T as attr, Q as store_get, Z as escape_html, U as stringify, X as html, V as attr_class, P as ensure_array_like, S as unsubscribe_stores } from './index-server.js-DdhL7Abu.js';
import './stores.js-D5xmrOAP.js';
import './server.js-BlClO2ED.js';
import './internal2.js-CNe5OZUJ.js';
import './routing.js-N-OPb2ye.js';
import { b as ApiUtil, f as avatarVersion } from './Store.js-DT3aZHRb.js';
import { $ as $format } from './runtime.js-BzHEw_ze.js';
import { D as Date_1 } from './Date.js-DCZp_jrB.js';
import './tooltip.util.js-BeLZL-Tj.js';
import { P as PageActions } from './PageActions.js-co-RIHDp.js';
import { E as Editor_1 } from './Editor.js-Cs5tQi--.js';
import { a as TicketStatuses, T as TicketStatusBadge } from './TicketStatusBadge.js-DtBYgr-f.js';
import './ToastContainer.js-Bv1jJ2dr.js';

//#region src/lib/pages/tickets/TicketDetail.svelte
async function load(event) {
	const { parent } = event;
	await parent();
	const id = event.params.id;
	const body = await ApiUtil.get({
		path: `/api/panel/tickets/${id}`,
		request: event
	});
	if (body.error) {
		if (body.error === "NOT_EXISTS" || body.error === "PAGE_NOT_FOUND") throw error(404, body.error);
		throw error(500, body.error);
	}
	body.ticket.id = parseInt(id);
	return body;
}
function TicketDetail($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let data = $$props["data"];
		getContext("pageTitle").set("#" + data.ticket.id + " " + limitTitle(data.ticket.title));
		let loadMoreLoading = false;
		let messageText = "";
		let isEditorEmpty = true;
		let sentMessageCount = 0;
		function limitTitle(text) {
			const limit = 32;
			if (text.length > limit) text = text.substring(0, limit) + "...";
			return text;
		}
		let $$settled = true;
		let $$inner_renderer;
		function $$render_inner($$renderer) {
			$$renderer.push(`<div class="container vstack gap-3">`);
			PageActions($$renderer, { $$slots: {
				left: ($$renderer) => {
					$$renderer.push(`<a class="btn btn-link"${attr("title", store_get($$store_subs ??= {}, "$_", $format)("pages.ticket-detail.tickets"))}${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("pages.ticket-detail.tickets"))} role="button"${attr("href", `${stringify(base)}/tickets`)} slot="left"><i class="fas fa-arrow-left"></i></a>`);
				},
				right: ($$renderer) => {
					$$renderer.push(`<div class="hstack gap-2" slot="right"><button${attr("title", store_get($$store_subs ??= {}, "$_", $format)("buttons.delete"))}${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("buttons.delete"))} class="btn btn-link" type="button"><i class="fas fa-trash"></i></button> `);
					if (data.ticket.status !== TicketStatuses.CLOSED) {
						$$renderer.push("<!--[0-->");
						$$renderer.push(`<button${attr("title", store_get($$store_subs ??= {}, "$_", $format)("buttons.close"))}${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("buttons.close"))} class="btn btn-secondary" type="button"><i class="fas fa-check me-2"></i> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.close"))}</button>`);
					} else $$renderer.push("<!--[-1-->");
					$$renderer.push(`<!--]--></div>`);
				}
			} });
			$$renderer.push(`<!----> <div class="card"><div class="card-header"><div class="row"><div class="col"><h5 class="card-title text-truncate mb-0"${attr("title", data.ticket.title)}>#${escape_html(data.ticket.id)}: ${escape_html(data.ticket.title)}</h5> <small class="mb-0">${html(store_get($$store_subs ??= {}, "$_", $format)("pages.ticket-detail.by-who", { values: { username: `<a class="rounded focus-ring" href="${base}/players/detail/${data.ticket.username}"
          >${data.ticket.username}</a>` } }))} `);
			Date_1($$renderer, { time: data.ticket.date });
			$$renderer.push(`<!---->, ${html(store_get($$store_subs ??= {}, "$_", $format)("pages.ticket-detail.opened-in-category", { values: { category: `<a href="${base}/tickets?categoryUrl=${data.ticket.category.url}"
          >${data.ticket.category.title === "-" ? store_get($$store_subs ??= {}, "$_", $format)("pages.ticket-detail.no-category") : data.ticket.category.title}</a>` } }))}</small></div> <div class="col-auto">`);
			TicketStatusBadge($$renderer, { status: data.ticket.status });
			$$renderer.push(`<!----></div></div></div> <div class="card-body" id="messageSection">`);
			if (data.ticket.messages.length < data.ticket.count && data.ticket.count > 5) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<div class="d-flex justify-content-center mb-3"><button${attr_class("btn btn-sm btn-secondary", void 0, { "disabled": loadMoreLoading })}><i class="fas fa-arrow-up me-2"></i> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.ticket-detail.previous-messages", { values: { count: data.ticket.count - (data.ticket.messages.length - sentMessageCount) } }))}</button></div>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--> <div class="vstack gap-2"><!--[-->`);
			const each_array = ensure_array_like(data.ticket.messages);
			for (let index = 0, $$length = each_array.length; index < $$length; index++) {
				let message = each_array[index];
				if (message.panel) {
					$$renderer.push("<!--[0-->");
					$$renderer.push(`<div class="row g-2 flex-nowrap"><div class="col vstack align-items-end"><div class="card rounded-5 bg-transparent border shadow-sm"><div class="card-body answer px-3">${html(message.message)}</div></div> <small class="text-body-secondary mt-1">`);
					Date_1($$renderer, {
						time: message.date,
						relativeFormat: true
					});
					$$renderer.push(`<!----></small></div> <div class="col-auto"><a${attr("href", `${stringify(base)}/players/detail/${stringify(message.username)}`)} class="rounded focus-ring"><img${attr("src", `/api/profile/picture/${stringify(message.username)}?${stringify(store_get($$store_subs ??= {}, "$avatarVersion", avatarVersion))}`)}${attr("alt", message.username)} class="rounded-circle" width="48" height="48" onload="this.__e=event" onerror="this.__e=event"/></a></div></div>`);
				} else {
					$$renderer.push("<!--[-1-->");
					$$renderer.push(`<div class="row g-2 flex-nowrap"><div class="col-auto"><a${attr("href", `${stringify(base)}/players/detail/${stringify(message.username)}`)}><img${attr("src", `/api/profile/picture/${stringify(message.username)}?${stringify(store_get($$store_subs ??= {}, "$avatarVersion", avatarVersion))}`)}${attr("alt", message.username)} class="rounded-circle" width="48" height="48" onload="this.__e=event" onerror="this.__e=event"/></a></div> <div class="col vstack align-items-start"><div class="card rounded-5 text-bg-primary border-0 shadow-sm"><div class="card-body px-3">${escape_html(message.message)}</div></div> <small class="text-body-secondary mt-1">`);
					Date_1($$renderer, {
						time: message.date,
						relativeFormat: true
					});
					$$renderer.push(`<!----></small></div></div>`);
				}
				$$renderer.push(`<!--]-->`);
			}
			$$renderer.push(`<!--]--></div></div> <div${attr_class("card-footer", void 0, { "d-none": data.ticket.status === TicketStatuses.CLOSED })}>`);
			Editor_1($$renderer, {
				get content() {
					return messageText;
				},
				set content($$value) {
					messageText = $$value;
					$$settled = false;
				},
				get isEmpty() {
					return isEditorEmpty;
				},
				set isEmpty($$value) {
					isEditorEmpty = $$value;
					$$settled = false;
				},
				children: ($$renderer) => {
					$$renderer.push(`<button${attr_class("btn btn-secondary", void 0, { "disabled": isEditorEmpty })}${attr("disabled", isEditorEmpty, true)}${attr("title", store_get($$store_subs ??= {}, "$_", $format)("pages.ticket-detail.send-button"))}${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("pages.ticket-detail.send-button"))}><i class="fas fa-paper-plane"></i></button>`);
				},
				$$slots: { default: true }
			});
			$$renderer.push(`<!----></div></div></div>`);
		}
		do {
			$$settled = true;
			$$inner_renderer = $$renderer.copy();
			$$render_inner($$inner_renderer);
		} while (!$$settled);
		$$renderer.subsume($$inner_renderer);
		if ($$store_subs) unsubscribe_stores($$store_subs);
		bind_props($$props, { data });
	});
}

export { TicketDetail as T, load as l };
//# sourceMappingURL=TicketDetail.js-CtG7WafG.js.map
