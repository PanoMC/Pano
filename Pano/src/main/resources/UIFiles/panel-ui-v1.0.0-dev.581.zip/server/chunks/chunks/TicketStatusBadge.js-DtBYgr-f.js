import { b as base } from './internal.js-BRN1McAa.js';
import { N as fallback, T as attr, Q as store_get, U as stringify, Z as escape_html, S as unsubscribe_stores, O as bind_props } from './index-server.js-DdhL7Abu.js';
import './server.js-BlClO2ED.js';
import './internal2.js-CNe5OZUJ.js';
import './routing.js-N-OPb2ye.js';
import { $ as $format } from './runtime.js-BzHEw_ze.js';

//#region src/lib/components/badges/TicketStatusBadge.svelte
var TicketStatuses = Object.freeze({
	NEW: "NEW",
	REPLIED: "REPLIED",
	CLOSED: "CLOSED"
});
function TicketStatusBadge($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let status = fallback($$props["status"], () => TicketStatuses.NEW, true);
		if (status === TicketStatuses.NEW) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<a class="badge rounded-pill text-bg-success focus-ring text-decoration-none"${attr("title", store_get($$store_subs ??= {}, "$_", $format)("components.ticket-status-badge.filter"))}${attr("href", `${stringify(base)}/tickets?pageType=WAITING_REPLY`)}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.ticket-status-badge.new"))}</a>`);
		} else if (status === TicketStatuses.REPLIED) {
			$$renderer.push("<!--[1-->");
			$$renderer.push(`<a class="badge rounded-pill text-bg-warning focus-ring text-decoration-none"${attr("title", store_get($$store_subs ??= {}, "$_", $format)("components.ticket-status-badge.filter"))}${attr("href", `${stringify(base)}/tickets`)}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.ticket-status-badge.replied"))}</a>`);
		} else if (status === TicketStatuses.CLOSED) {
			$$renderer.push("<!--[2-->");
			$$renderer.push(`<a class="badge rounded-pill text-bg-danger focus-ring text-decoration-none"${attr("title", store_get($$store_subs ??= {}, "$_", $format)("components.ticket-status-badge.filter"))}${attr("href", `${stringify(base)}/tickets?pageType=CLOSED`)}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.closed"))}</a>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]-->`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
		bind_props($$props, { status });
	});
}

export { TicketStatusBadge as T, TicketStatuses as a };
//# sourceMappingURL=TicketStatusBadge.js-DtBYgr-f.js.map
