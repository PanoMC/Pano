import { e as error } from './exports2.js-VkmSkXbz.js';
import { b as base } from './internal.js-BRN1McAa.js';
import { J as getContext, Q as store_get, T as attr, Z as escape_html, V as attr_class, P as ensure_array_like, S as unsubscribe_stores, O as bind_props, U as stringify, F as writable } from './index-server.js-DdhL7Abu.js';
import './stores.js-D5xmrOAP.js';
import './server.js-BlClO2ED.js';
import './internal2.js-CNe5OZUJ.js';
import './routing.js-N-OPb2ye.js';
import { e as buildQueryParams, b as ApiUtil, f as avatarVersion } from './Store.js-DT3aZHRb.js';
import { $ as $format } from './runtime.js-BzHEw_ze.js';
import { D as Date_1 } from './Date.js-DCZp_jrB.js';
import './tooltip.util.js-BeLZL-Tj.js';
import { N as NoContent } from './NoContent.js-Coj2fA9d.js';
import { S as SearchInput } from './SearchInput.js-DPW0WADK.js';
import { C as CardHeader } from './CardHeader.js-XBureLRg.js';
import { P as Pagination } from './Pagination.js-sd1xTcbW.js';
import { C as CategoryBadge } from './CategoryBadge.js-DjLui7ZD.js';
import { C as CardFilters, a as CardFiltersItem } from './CardFiltersItem.js-n0hSsrtm.js';
import { P as PageActions } from './PageActions.js-co-RIHDp.js';
import { P as PageNav, a as PageNavItem } from './PageNav.js-Bzzuwwjz.js';
import { T as TicketStatusBadge } from './TicketStatusBadge.js-DtBYgr-f.js';
import './ToastContainer.js-Bv1jJ2dr.js';

//#region src/lib/components/rows/TicketRow.svelte
function TicketRow($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let ticket = $$props["ticket"];
		let checkedList = $$props["checkedList"];
		$$renderer.push(`<tr${attr_class("", void 0, { "table-active": ticket.selected })}><th scope="row" class="align-middle"><div class="form-check d-flex justify-content-center align-items-center"><input class="form-check-input"${attr("id", `postCheck${stringify(ticket.id)}`)} type="checkbox"${attr("checked", store_get($$store_subs ??= {}, "$checkedList", checkedList)[ticket.id], true)}/></div></th><td class="align-middle text-nowrap"><code>#${escape_html(ticket.id)}</code></td><td class="align-middle" style="max-width: 250px;"><div class="text-truncate"><a${attr("href", `${stringify(base)}/tickets/detail/${stringify(ticket.id)}`)} class="rounded focus-ring text-decoration-none d-block text-truncate"${attr("title", ticket.title)}>${escape_html(ticket.title)}</a></div></td><td class="align-middle text-nowrap">`);
		CategoryBadge($$renderer, {
			category: ticket.category,
			pageType: "tickets",
			filterTitle: store_get($$store_subs ??= {}, "$_", $format)("components.ticket-row.filter"),
			noCategoryText: store_get($$store_subs ??= {}, "$_", $format)("components.ticket-row.no-category")
		});
		$$renderer.push(`<!----></td><td class="align-middle" style="max-width: 200px;"><div class="text-truncate d-flex align-items-center"><a${attr("href", `${stringify(base)}/players/detail/${stringify(ticket.writer.username)}`)}${attr("title", store_get($$store_subs ??= {}, "$_", $format)("buttons.view"))} class="rounded focus-ring text-decoration-none text-truncate d-flex align-items-center"><img${attr("src", `/api/profile/picture/${stringify(ticket.writer.username)}?${stringify(store_get($$store_subs ??= {}, "$avatarVersion", avatarVersion))}`)}${attr("alt", store_get($$store_subs ??= {}, "$_", $format)("components.ticket-row.player-name"))} class="rounded-circle me-2 flex-shrink-0" height="32" width="32"/> <span class="text-truncate">${escape_html(ticket.writer.username)}</span></a></div></td><td class="align-middle text-nowrap">`);
		TicketStatusBadge($$renderer, { status: ticket.status });
		$$renderer.push(`<!----></td><td class="align-middle text-nowrap">`);
		Date_1($$renderer, { time: ticket.lastUpdate });
		$$renderer.push(`<!----></td></tr>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
		bind_props($$props, {
			ticket,
			checkedList
		});
	});
}
//#endregion
//#region src/lib/pages/Tickets.svelte
var checkedList = writable([]);
var PageTypes = Object.freeze({
	ALL: "ALL",
	WAITING_REPLY: "WAITING_REPLY",
	CLOSED: "CLOSED"
});
var DefaultPageType = PageTypes.ALL;
async function load(event) {
	const { parent, url: { searchParams } } = event;
	await parent();
	const page = parseInt(searchParams.get("page")) || 1;
	const categoryUrl = searchParams.get("categoryUrl");
	const pageType = searchParams.get("pageType") || DefaultPageType;
	const search = searchParams.get("search");
	if (!Object.values(PageTypes).includes(pageType)) throw error(404, "PAGE_NOT_FOUND");
	const queryParams = buildQueryParams({
		page,
		pageType,
		categoryUrl,
		search
	});
	const body = await ApiUtil.get({
		path: `/api/panel/tickets` + queryParams,
		request: event
	});
	if (body.error) {
		if (body.error === "PAGE_NOT_FOUND") throw error(404, body.error);
		throw error(500, body.error);
	}
	body.page = page;
	body.pageType = pageType;
	body.categoryUrl = categoryUrl;
	body.search = search;
	return body;
}
function Tickets($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let checkedItems;
		let data = $$props["data"];
		const pageTitle = getContext("pageTitle");
		let firstLoad = true;
		let search = data.search || "";
		let isSearching = false;
		function getListOfChecked(list) {
			return Object.keys(list).filter((key) => list[key]);
		}
		function isAllTicketsSelected(ticketsList, selectedList) {
			let isAllSelected = true;
			ticketsList.forEach((ticket) => {
				if (!selectedList[ticket.id]) isAllSelected = false;
			});
			return isAllSelected;
		}
		pageTitle.set(data.categoryUrl ? store_get($$store_subs ??= {}, "$_", $format)("pages.tickets.category-tickets-title", { values: { category: (data.category?.title || "-") === "-" ? store_get($$store_subs ??= {}, "$_", $format)("pages.tickets.no-category") : data.category?.title || "-" } }) : store_get($$store_subs ??= {}, "$_", $format)("pages.tickets.title", { values: { pageType: data.pageType === PageTypes.WAITING_REPLY ? store_get($$store_subs ??= {}, "$_", $format)("pages.tickets.waiting-reply") + " " : data.pageType === PageTypes.CLOSED ? store_get($$store_subs ??= {}, "$_", $format)("pages.tickets.closed") + " " : "" } }));
		checkedItems = Object.keys(store_get($$store_subs ??= {}, "$checkedList", checkedList)).filter((key) => store_get($$store_subs ??= {}, "$checkedList", checkedList)[key]);
		if (checkedItems.length > 0) firstLoad = false;
		$$renderer.push(`<article class="container vstack gap-3">`);
		if (data.categoryUrl) {
			$$renderer.push("<!--[0-->");
			PageActions($$renderer, {
				middleClasses: "d-none",
				rightClasses: "d-none",
				$$slots: { left: ($$renderer) => {
					$$renderer.push(`<div slot="left"><a class="btn btn-link" role="button"${attr("href", `${stringify(base)}/tickets`)}><i class="fas fa-arrow-left me-2"></i> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.tickets"))}</a></div>`);
				} }
			});
		} else {
			$$renderer.push("<!--[-1-->");
			PageActions($$renderer, {
				rightClasses: checkedItems.length > 0 ? "" : null,
				$$slots: {
					left: ($$renderer) => {
						PageNav($$renderer, {
							slot: "left",
							children: ($$renderer) => {
								if (!data.categoryUrl) {
									$$renderer.push("<!--[0-->");
									PageNavItem($$renderer, {
										href: "/tickets",
										children: ($$renderer) => {
											$$renderer.push(`<!---->${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.ticket-categories.tickets"))}`);
										}});
									$$renderer.push(`<!----> `);
									PageNavItem($$renderer, {
										href: "/tickets/categories",
										children: ($$renderer) => {
											$$renderer.push(`<!---->${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.categories"))}`);
										}});
									$$renderer.push(`<!---->`);
								} else $$renderer.push("<!--[-1-->");
								$$renderer.push(`<!--]-->`);
							},
							$$slots: { default: true }
						});
					},
					right: ($$renderer) => {
						$$renderer.push(`<div slot="right">`);
						if (checkedItems.length > 0) {
							$$renderer.push("<!--[0-->");
							$$renderer.push(`<div${attr_class("hstack gap-2", void 0, { "d-none": firstLoad })}><button${attr("title", store_get($$store_subs ??= {}, "$_", $format)("buttons.delete"))}${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("buttons.delete"))}${attr_class("btn btn-link", void 0, { "disabled": getListOfChecked(store_get($$store_subs ??= {}, "$checkedList", checkedList)).length === 0 })} type="button"><i class="fas fa-trash"></i></button> <button${attr_class("btn btn-secondary", void 0, { "disabled": getListOfChecked(store_get($$store_subs ??= {}, "$checkedList", checkedList)).length === 0 })} type="button"><i class="fas fa-times me-2"></i>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.close"))}</button></div>`);
						} else $$renderer.push("<!--[-1-->");
						$$renderer.push(`<!--]--></div>`);
					}
				}
			});
		}
		$$renderer.push(`<!--]--> <div class="card">`);
		CardHeader($$renderer, { $$slots: {
			left: ($$renderer) => {
				$$renderer.push(`<div slot="left">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.tickets.table-title", { values: {
					ticketCount: data.ticketCount,
					pageType: data.pageType === PageTypes.WAITING_REPLY ? store_get($$store_subs ??= {}, "$_", $format)("pages.tickets.waiting-reply") : data.pageType === PageTypes.CLOSED ? store_get($$store_subs ??= {}, "$_", $format)("pages.tickets.closed") : ""
				} }) + (checkedItems.length > 0 ? ", " + store_get($$store_subs ??= {}, "$_", $format)("pages.tickets.amount-selected", { values: { amount: checkedItems.length } }) : ""))}</div>`);
			},
			middle: ($$renderer) => {
				$$renderer.push(`<div slot="middle" style="width: 250px;">`);
				SearchInput($$renderer, {
					initialValue: search,
					searching: isSearching,
					debounceMs: 500
				});
				$$renderer.push(`<!----></div>`);
			},
			right: ($$renderer) => {
				CardFilters($$renderer, {
					slot: "right",
					children: ($$renderer) => {
						if (!data.categoryUrl) {
							$$renderer.push("<!--[0-->");
							CardFiltersItem($$renderer, {
								href: "/tickets",
								active: data.pageType === PageTypes.ALL,
								children: ($$renderer) => {
									$$renderer.push(`<!---->${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.tickets.all"))}`);
								}});
							$$renderer.push(`<!----> `);
							CardFiltersItem($$renderer, {
								href: "/tickets?pageType=WAITING_REPLY",
								active: data.pageType === PageTypes.WAITING_REPLY,
								children: ($$renderer) => {
									$$renderer.push(`<!---->${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.tickets.waiting-reply"))}`);
								}});
							$$renderer.push(`<!----> `);
							CardFiltersItem($$renderer, {
								href: "/tickets?pageType=CLOSED",
								active: data.pageType === PageTypes.CLOSED,
								children: ($$renderer) => {
									$$renderer.push(`<!---->${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.tickets.closed"))}`);
								}});
							$$renderer.push(`<!---->`);
						} else $$renderer.push("<!--[-1-->");
						$$renderer.push(`<!--]-->`);
					},
					$$slots: { default: true }
				});
			}
		} });
		$$renderer.push(`<!----> `);
		if (data.ticketCount === 0) {
			$$renderer.push("<!--[0-->");
			NoContent($$renderer, {});
		} else {
			$$renderer.push("<!--[-1-->");
			$$renderer.push(`<div class="table-responsive"><table class="table table-hover"><thead><tr><th class="align-middle" scope="col"><div class="form-check d-flex justify-content-center align-items-center"><input class="form-check-input"${attr("checked", isAllTicketsSelected(data.tickets, store_get($$store_subs ??= {}, "$checkedList", checkedList)), true)} id="selectAll" type="checkbox"/></div></th><th class="align-middle text-nowrap" scope="col">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.tickets.table.id"))}</th><th class="align-middle text-nowrap" scope="col">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.tickets.table.title"))}</th><th${attr_class("align-middle", void 0, { "table-active": data.categoryUrl })} scope="col">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.tickets.table.category"))}</th><th class="align-middle text-nowrap" scope="col">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.tickets.table.player"))}</th><th class="align-middle text-nowrap" scope="col">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.tickets.table.status"))}</th><th class="align-middle text-nowrap" scope="col">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.tickets.table.last-reply"))}</th></tr></thead><tbody><!--[-->`);
			const each_array = ensure_array_like(data.tickets);
			for (let index = 0, $$length = each_array.length; index < $$length; index++) {
				let ticket = each_array[index];
				TicketRow($$renderer, {
					ticket,
					checkedList
				});
			}
			$$renderer.push(`<!--]--></tbody></table></div> <div class="card-footer">`);
			Pagination($$renderer, {
				page: data.page,
				totalPage: data.totalPage
			});
			$$renderer.push(`<!----></div>`);
		}
		$$renderer.push(`<!--]--></div></article>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
		bind_props($$props, { data });
	});
}

export { Tickets as T, load as l };
//# sourceMappingURL=Tickets.js-C0fcfvxv.js.map
