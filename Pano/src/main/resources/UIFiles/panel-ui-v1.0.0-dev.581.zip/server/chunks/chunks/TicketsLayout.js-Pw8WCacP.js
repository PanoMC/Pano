import { _ as __exportAll } from './rolldown-runtime.js-BMnQIuNT.js';
import { r as redirect } from './exports2.js-VkmSkXbz.js';
import { b as base } from './internal.js-BRN1McAa.js';
import { W as slot } from './index-server.js-DdhL7Abu.js';
import './server.js-BlClO2ED.js';
import './internal2.js-CNe5OZUJ.js';
import './routing.js-N-OPb2ye.js';
import { h as hasPermission, P as Permissions } from './auth.util.js-C77uoaNq.js';
import { C as ConfirmCloseTicketModal, a as ConfirmDeleteTicketModal } from './ConfirmDeleteTicketModal.js-BSTS91aX.js';

//#region src/lib/layouts/TicketsLayout.svelte
var TicketsLayout_exports = /* @__PURE__ */ __exportAll({
	default: () => TicketsLayout,
	load: () => load
});
async function load({ parent }) {
	const parentData = await parent();
	const { user } = parentData;
	if (!hasPermission(Permissions.MANAGE_TICKETS, user)) throw redirect(302, base);
	return parentData;
}
function TicketsLayout($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		$$renderer.push(`<!--[-->`);
		slot($$renderer, $$props, "default", {}, null);
		$$renderer.push(`<!--]--> `);
		ConfirmCloseTicketModal($$renderer);
		$$renderer.push(`<!----> `);
		ConfirmDeleteTicketModal($$renderer);
		$$renderer.push(`<!---->`);
	});
}

export { TicketsLayout_exports as T, TicketsLayout as a, load as l };
//# sourceMappingURL=TicketsLayout.js-Pw8WCacP.js.map
