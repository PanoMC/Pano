import { e as error } from './exports2.js-VkmSkXbz.js';
import { Y as get, J as getContext, a0 as onDestroy, M as tick, P as ensure_array_like, T as attr, U as stringify, Z as escape_html, O as bind_props, Q as store_get, S as unsubscribe_stores } from './index-server.js-DdhL7Abu.js';
import { b as beforeNavigate } from './stores.js-D5xmrOAP.js';
import './server.js-BlClO2ED.js';
import './internal2.js-CNe5OZUJ.js';
import './routing.js-N-OPb2ye.js';
import { b as ApiUtil, e as buildQueryParams } from './Store.js-DT3aZHRb.js';
import { $ as $format } from './runtime.js-BzHEw_ze.js';
import './ToastContainer.js-Bv1jJ2dr.js';
import { c as currentLanguage } from './language.util.js-ByanOnuS.js';
import { N as NoContent } from './NoContent.js-Coj2fA9d.js';
import { S as SearchInput } from './SearchInput.js-DPW0WADK.js';
import { C as CardHeader } from './CardHeader.js-XBureLRg.js';
import { C as CardFilters, a as CardFiltersItem } from './CardFiltersItem.js-n0hSsrtm.js';
import { P as PageActions } from './PageActions.js-co-RIHDp.js';
import { P as PageNav, a as PageNavItem } from './PageNav.js-Bzzuwwjz.js';

//#region src/lib/components/rows/TranslationRow.svelte
function TranslationRow($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let translation = $$props["translation"];
		let pluginId = $$props["pluginId"];
		$$renderer.push(`<div class="row mb-3 g-2"><div class="col-md"><div class="form-floating"><input type="text" class="form-control font-monospace" id="KeyTranslation" readonly=""${attr("value", pluginId ? translation.key.replace(`plugins.${pluginId}.`, "") : translation.key)}${attr("title", pluginId ? translation.key.replace(`plugins.${pluginId}.`, "") : translation.key)}/> <label for="KeyTranslation">Key</label></div></div> <div class="col-md"><div class="form-floating"><textarea rows="1" class="form-control" id="OriginalTranslation" readonly=""${attr("title", translation.original)}>`);
		const $$body = escape_html(translation.original);
		if ($$body) $$renderer.push(`${$$body}`);
		$$renderer.push(`</textarea> <label for="OriginalTranslation">Original</label></div></div> <div class="col-md"><div class="form-floating"><textarea rows="1" class="form-control" id="CustomTranslation"${attr("title", translation.custom)}>`);
		const $$body_1 = escape_html(translation.custom);
		if ($$body_1) $$renderer.push(`${$$body_1}`);
		$$renderer.push(`</textarea> <label for="CustomTranslation">Custom</label></div></div> `);
		if (translation.notExists) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<div class="col-auto"><button${attr("title", store_get($$store_subs ??= {}, "$_", $format)("buttons.delete"))}${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("buttons.delete"))} id="deleteButton" type="button" class="btn btn-link h-100"><i class="fa-solid fa-trash"></i></button></div>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
		bind_props($$props, {
			translation,
			pluginId
		});
	});
}
//#endregion
//#region src/lib/components/UnnecessaryTranslationsAlert.svelte
function UnnecessaryTranslationsAlert($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		let translations = $$props["translations"];
		let pluginId = $$props["pluginId"];
		let open = $$props["open"];
		$$renderer.push(`<div class="alert alert-warning" role="alert"><details${attr("open", open, true)}><summary>These translations are not used anymore, you can delete them:</summary> <!--[-->`);
		const each_array = ensure_array_like(translations);
		for (let index = 0, $$length = each_array.length; index < $$length; index++) {
			let translation = each_array[index];
			TranslationRow($$renderer, {
				translation,
				pluginId
			});
		}
		$$renderer.push(`<!--]--></details></div>`);
		bind_props($$props, {
			translations,
			pluginId,
			open
		});
	});
}
//#endregion
//#region src/lib/pages/Translations.svelte
var PageTypes = Object.freeze({
	PANEL: "PANEL",
	THEME: "THEME",
	PLUGIN: "PLUGIN",
	PLATFORM: "PLATFORM",
	MC_PLUGIN: "MC_PLUGIN"
});
var DefaultPageType = PageTypes.PANEL;
var FilterTypes = Object.freeze({
	ALL: "ALL",
	ORIGINAL: "ORIGINAL",
	CUSTOM: "CUSTOM",
	NOT_EXISTS: "NOT_EXISTS"
});
var DefaultFilter = FilterTypes.ALL;
function groupTranslationsByPluginId(translations, filter, filterResult) {
	return (filter === DefaultFilter ? translations : filterResult).reduce((acc, item) => {
		const match = item.key.match(/^plugins\.([^.]+)/);
		if (match) {
			const pluginId = match[1];
			if (!acc[pluginId]) acc[pluginId] = [];
			acc[pluginId].push(item);
		}
		return acc;
	}, {});
}
/**
* @type {import('@sveltejs/kit').PageLoad}
*/
async function load(event) {
	const { parent, url: { searchParams } } = event;
	await parent();
	const type = searchParams.get("type") || DefaultPageType;
	const locale = searchParams.get("locale") || get(currentLanguage).code;
	const filter = searchParams.get("filter") || DefaultFilter;
	if (!Object.values(PageTypes).includes(type)) throw error(404, "PAGE_NOT_FOUND");
	if (!Object.values(FilterTypes).includes(filter)) throw error(404, "PAGE_NOT_FOUND");
	const locales = (await ApiUtil.get({
		path: `/api/panel/locales`,
		request: event
	})).data;
	if (!locales.some((item) => item.code === locale)) throw error(404, "PAGE_NOT_FOUND");
	const localeId = locales.find((item) => item.code === locale).id;
	const queryParams = buildQueryParams({ filter: filter === FilterTypes.ALL ? null : filter });
	const translationsBody = await ApiUtil.get({
		path: `/api/panel/locales/${localeId}/types/${type}/translations${queryParams}`,
		request: event
	});
	let translations = translationsBody.data;
	const meta = translationsBody.meta;
	if (filter !== DefaultFilter && meta.filterResult) translations = meta.filterResult;
	const originalTranslations = translations.map((t) => ({ ...t }));
	const translationInputs = translations.map((t) => ({ ...t }));
	let translationsToReturn = translations;
	if (type === PageTypes.PLUGIN) translationsToReturn = groupTranslationsByPluginId(translations, filter, meta.filterResult);
	return {
		locale,
		localeId,
		locales,
		type,
		filter,
		translations: translationsToReturn,
		translationInputs,
		originalTranslations,
		meta
	};
}
function Translations($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let hasMore, saveDisabled;
		let data = $$props["data"];
		let saving;
		let filteredTranslations = [];
		let searching = false;
		let ready = false;
		let renderingLimit = 40;
		let pluginLimit = 15;
		let allGroupedByPlugin = {};
		let datasetToken = "";
		let splitByPlugin = {};
		let splitFlat = {
			notExists: [],
			existing: []
		};
		getContext("pageTitle").set("pages.translations.title");
		function extractPluginId(key) {
			const m = String(key || "").match(/^plugins\.([^.]+)/);
			return m ? m[1] : null;
		}
		function rebuildIndexes() {
			new Map((data.translationInputs || []).map((t) => [t.key, t]));
			if (data.type === PageTypes.PLUGIN) {
				const grouped = {};
				for (const t of data.translationInputs || []) {
					const pid = extractPluginId(t.key);
					if (!pid) continue;
					if (!grouped[pid]) grouped[pid] = [];
					grouped[pid].push(t);
				}
				allGroupedByPlugin = grouped;
				filteredTranslations = grouped;
			} else {
				allGroupedByPlugin = {};
				filteredTranslations = data.translationInputs || [];
			}
		}
		function splitList(list) {
			const notExists = [];
			const existing = [];
			for (const t of list || []) if (t?.notExists) notExists.push(t);
			else existing.push(t);
			return {
				notExists,
				existing
			};
		}
		function runSearchInBackground(query) {
			if (!String("").trim()) {
				searching = true;
				(/* @__PURE__ */ tick()).then(() => {
					filteredTranslations = data.type === PageTypes.PLUGIN ? allGroupedByPlugin : data.translationInputs || [];
					setTimeout(() => searching = false, 0);
				});
				return;
			}
		}
		function getQueryParams(type, locale, filter) {
			return buildQueryParams({
				locale: locale === store_get($$store_subs ??= {}, "$currentLanguage", currentLanguage).code ? null : locale,
				type: type === PageTypes.PANEL ? null : type,
				filter: type === data.type ? filter === DefaultFilter ? null : filter : null
			});
		}
		onDestroy(() => {});
		beforeNavigate((nav) => {});
		{
			const nextToken = `${data?.localeId ?? ""}|${data?.type ?? ""}|${data?.filter ?? ""}|${data?.meta?.totalCount ?? ""}`;
			if (nextToken && nextToken !== datasetToken) {
				ready = false;
				datasetToken = nextToken;
				renderingLimit = 40;
				pluginLimit = 15;
				rebuildIndexes();
				runSearchInBackground();
				(/* @__PURE__ */ tick()).then(() => {
					setTimeout(() => {
						ready = true;
					}, 100);
				});
			}
		}
		hasMore = data.type === PageTypes.PLUGIN ? pluginLimit < Object.keys(filteredTranslations).length || Object.values(filteredTranslations).slice(0, pluginLimit).some((list) => list.length > renderingLimit) : renderingLimit < filteredTranslations.length;
		if (datasetToken) runSearchInBackground();
		if (data.type === PageTypes.PLUGIN) {
			const out = {};
			for (const [pid, list] of Object.entries(filteredTranslations || {})) out[pid] = splitList(list);
			splitByPlugin = out;
			splitFlat = {
				notExists: [],
				existing: []
			};
		} else {
			splitByPlugin = {};
			splitFlat = splitList(filteredTranslations || []);
		}
		saveDisabled = JSON.stringify(data.translationInputs) === JSON.stringify(data.originalTranslations) || saving;
		$$renderer.push(`<div class="container vstack gap-3">`);
		PageActions($$renderer, {
			middleClasses: null,
			$$slots: {
				left: ($$renderer) => {
					PageNav($$renderer, {
						slot: "left",
						children: ($$renderer) => {
							PageNavItem($$renderer, {
								href: "/translations",
								children: ($$renderer) => {
									$$renderer.push(`<!---->${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.translations.title"))}`);
								}});
							$$renderer.push(`<!----> `);
							PageNavItem($$renderer, {
								href: "/translations/languages",
								children: ($$renderer) => {
									$$renderer.push(`<!---->${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.languages"))}`);
								}});
							$$renderer.push(`<!---->`);
						},
						$$slots: { default: true }
					});
				},
				right: ($$renderer) => {
					$$renderer.push(`<div slot="right" class="hstack gap-2">`);
					$$renderer.push("<!--[-1-->");
					$$renderer.push(`<!--]--> <div class="input-group">`);
					$$renderer.select({
						class: "form-select",
						name: "selectType",
						id: "selectType",
						value: data.type
					}, ($$renderer) => {
						$$renderer.push(`<!--[-->`);
						const each_array = ensure_array_like(Object.keys(PageTypes));
						for (let index = 0, $$length = each_array.length; index < $$length; index++) {
							let pageType = each_array[index];
							$$renderer.option({
								selected: true,
								value: pageType
							}, ($$renderer) => {
								$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons." + pageType.toLowerCase().replace("_", "-")))}`);
							});
						}
						$$renderer.push(`<!--]-->`);
					});
					$$renderer.push(` `);
					$$renderer.select({
						class: "form-select",
						name: "selectLanguage",
						id: "selectLanguage",
						value: data.locale
					}, ($$renderer) => {
						$$renderer.push(`<!--[-->`);
						const each_array_1 = ensure_array_like(data.locales);
						for (let index = 0, $$length = each_array_1.length; index < $$length; index++) {
							let locale = each_array_1[index];
							$$renderer.option({
								selected: true,
								value: locale.code
							}, ($$renderer) => {
								$$renderer.push(`${escape_html(locale.name)}`);
							});
						}
						$$renderer.push(`<!--]-->`);
					});
					$$renderer.push(`</div> <button type="button"${attr("title", store_get($$store_subs ??= {}, "$_", $format)("buttons.save"))}${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("buttons.save"))} class="btn btn-secondary"${attr("disabled", saveDisabled, true)}><i class="fa fa-save"></i></button></div>`);
				}
			}
		});
		$$renderer.push(`<!----> <div class="card">`);
		CardHeader($$renderer, { $$slots: {
			left: ($$renderer) => {
				$$renderer.push(`<div slot="left">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.translations.card-title", { values: { count: data.filter !== FilterTypes.ALL ? data.meta.filterCount : data.meta.totalCount } }))}</div>`);
			},
			middle: ($$renderer) => {
				$$renderer.push(`<div slot="middle">`);
				SearchInput($$renderer, { searching });
				$$renderer.push(`<!----></div>`);
			},
			right: ($$renderer) => {
				CardFilters($$renderer, {
					slot: "right",
					children: ($$renderer) => {
						CardFiltersItem($$renderer, {
							href: `/translations${stringify(getQueryParams(data.type, data.locale, FilterTypes.ALL))}`,
							active: data.filter === FilterTypes.ALL,
							children: ($$renderer) => {
								$$renderer.push(`<!---->${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.all"))}`);
							}});
						$$renderer.push(`<!----> `);
						CardFiltersItem($$renderer, {
							href: `/translations${stringify(getQueryParams(data.type, data.locale, FilterTypes.ORIGINAL))}`,
							active: data.filter === FilterTypes.ORIGINAL,
							children: ($$renderer) => {
								$$renderer.push(`<!---->${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.original"))}`);
							}});
						$$renderer.push(`<!----> `);
						CardFiltersItem($$renderer, {
							href: `/translations${stringify(getQueryParams(data.type, data.locale, FilterTypes.CUSTOM))}`,
							active: data.filter === FilterTypes.CUSTOM,
							children: ($$renderer) => {
								$$renderer.push(`<!---->${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.modified"))}`);
							}});
						$$renderer.push(`<!----> `);
						CardFiltersItem($$renderer, {
							href: `/translations${stringify(getQueryParams(data.type, data.locale, FilterTypes.NOT_EXISTS))}`,
							active: data.filter === FilterTypes.NOT_EXISTS,
							children: ($$renderer) => {
								$$renderer.push(`<!---->${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.not-exists"))}`);
							}});
						$$renderer.push(`<!---->`);
					},
					$$slots: { default: true }
				});
			}
		} });
		$$renderer.push(`<!----> <div class="vstack gap-3">`);
		if (data.type === PageTypes.PLUGIN) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<div class="accordion accordion-flush mb-2">`);
			const each_array_2 = ensure_array_like(Object.keys(filteredTranslations).slice(0, pluginLimit));
			if (each_array_2.length !== 0) {
				$$renderer.push("<!--[-->");
				for (let index = 0, $$length = each_array_2.length; index < $$length; index++) {
					let pluginId = each_array_2[index];
					$$renderer.push(`<div class="accordion-item"><h2 class="accordion-header"><button class="accordion-button" type="button" data-bs-toggle="collapse"${attr("data-bs-target", `#collapsePlugin${stringify(pluginId)}`)}>${escape_html(filteredTranslations[pluginId].length)}
                  ${escape_html(pluginId)}</button></h2> <div${attr("id", `collapsePlugin${stringify(pluginId)}`)} class="accordion-collapse collapse show"><div class="accordion-body">`);
					if (ready) {
						$$renderer.push("<!--[0-->");
						if ((splitByPlugin[pluginId]?.notExists || []).length > 0) {
							$$renderer.push("<!--[0-->");
							UnnecessaryTranslationsAlert($$renderer, {
								translations: splitByPlugin[pluginId].notExists,
								pluginId,
								open: data.filter === FilterTypes.NOT_EXISTS
							});
						} else $$renderer.push("<!--[-1-->");
						$$renderer.push(`<!--]--> `);
						if ((splitByPlugin[pluginId]?.existing || []).length > 0) {
							$$renderer.push("<!--[0-->");
							$$renderer.push(`<!--[-->`);
							const each_array_3 = ensure_array_like(splitByPlugin[pluginId].existing.slice(0, renderingLimit));
							for (let index = 0, $$length = each_array_3.length; index < $$length; index++) {
								let translation = each_array_3[index];
								TranslationRow($$renderer, {
									translation,
									pluginId
								});
							}
							$$renderer.push(`<!--]-->`);
						} else $$renderer.push("<!--[-1-->");
						$$renderer.push(`<!--]-->`);
					} else $$renderer.push("<!--[-1-->");
					$$renderer.push(`<!--]--></div></div></div>`);
				}
			} else {
				$$renderer.push("<!--[!-->");
				NoContent($$renderer, {});
			}
			$$renderer.push(`<!--]--></div>`);
		} else {
			$$renderer.push("<!--[-1-->");
			$$renderer.push(`<div class="p-3">`);
			if (ready) {
				$$renderer.push("<!--[0-->");
				if (splitFlat.notExists.length > 0) {
					$$renderer.push("<!--[0-->");
					UnnecessaryTranslationsAlert($$renderer, {
						translations: splitFlat.notExists,
						open: data.filter === FilterTypes.NOT_EXISTS
					});
				} else $$renderer.push("<!--[-1-->");
				$$renderer.push(`<!--]--> `);
				if (splitFlat.existing.length > 0) {
					$$renderer.push("<!--[0-->");
					$$renderer.push(`<!--[-->`);
					const each_array_4 = ensure_array_like(splitFlat.existing.slice(0, renderingLimit));
					for (let index = 0, $$length = each_array_4.length; index < $$length; index++) {
						let translation = each_array_4[index];
						TranslationRow($$renderer, { translation });
					}
					$$renderer.push(`<!--]-->`);
				} else if (splitFlat.notExists.length === 0) {
					$$renderer.push("<!--[1-->");
					NoContent($$renderer, {});
				} else $$renderer.push("<!--[-1-->");
				$$renderer.push(`<!--]-->`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--></div>`);
		}
		$$renderer.push(`<!--]--> `);
		if (ready && hasMore) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<div class="py-3 text-center small" style="min-height: 50px;">`);
			if (searching) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<i class="fas fa-circle-notch fa-spin me-2"></i> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.store-loading.loading"))}`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--></div>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--></div></div></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
		bind_props($$props, { data });
	});
}

export { Translations as T, load as l };
//# sourceMappingURL=Translations.js-CX_F4WYQ.js.map
