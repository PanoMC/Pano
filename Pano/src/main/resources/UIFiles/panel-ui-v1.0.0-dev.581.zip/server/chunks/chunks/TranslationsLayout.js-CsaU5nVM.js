import { _ as __exportAll } from './rolldown-runtime.js-BMnQIuNT.js';
import { r as redirect } from './exports2.js-VkmSkXbz.js';
import { b as base } from './internal.js-BRN1McAa.js';
import { W as slot } from './index-server.js-DdhL7Abu.js';
import './server.js-BlClO2ED.js';
import './internal2.js-CNe5OZUJ.js';
import './routing.js-N-OPb2ye.js';
import { h as hasPermission, P as Permissions } from './auth.util.js-C77uoaNq.js';

//#region src/lib/layouts/TranslationsLayout.svelte
var TranslationsLayout_exports = /* @__PURE__ */ __exportAll({
	default: () => TranslationsLayout,
	load: () => load
});
async function load({ parent }) {
	const parentData = await parent();
	const { user } = parentData;
	if (!hasPermission(Permissions.MANAGE_TRANSLATIONS, user)) throw redirect(302, base);
	return parentData;
}
function TranslationsLayout($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		$$renderer.push(`<!--[-->`);
		slot($$renderer, $$props, "default", {}, null);
		$$renderer.push(`<!--]-->`);
	});
}

export { TranslationsLayout_exports as T, TranslationsLayout as a, load as l };
//# sourceMappingURL=TranslationsLayout.js-CsaU5nVM.js.map
