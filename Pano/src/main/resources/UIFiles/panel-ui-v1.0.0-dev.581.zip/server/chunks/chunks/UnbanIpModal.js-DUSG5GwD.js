import { Z as escape_html, Q as store_get, T as attr, V as attr_class, S as unsubscribe_stores, F as writable } from './index-server.js-DdhL7Abu.js';
import 'node:module';
import './stores.js-D5xmrOAP.js';
import './server.js-BlClO2ED.js';
import './internal2.js-CNe5OZUJ.js';
import './routing.js-N-OPb2ye.js';
import './ToastContainer.js-Bv1jJ2dr.js';
import { $ as $format } from './runtime.js-BzHEw_ze.js';

var ipAddress = writable("");
var banMessage = writable("");
var banDuration = writable("permanent");
var customDuration = writable("");
var customDateTime = writable("");
function ConfirmBanIpModal($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let loading;
		$$renderer.push(`<div aria-hidden="true" class="modal fade" role="dialog" tabindex="-1"><div class="modal-dialog modal-dialog-centered" role="dialog"><div class="modal-content"><div class="modal-body text-center"><div class="pb-3"><i class="fas fa-network-wired fa-3x d-block m-auto text-gray"></i></div> <div class="pb-3">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.confirm-ban-ip.title"))}</div> <div class="form-group text-start mb-3"><div class="d-flex flex-wrap gap-2 align-items-end justify-content-between"><div class="flex-grow-1" style="min-width: 12rem"><label for="ipBanField" class="form-label">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.ip-bans.ip"))}</label> <input type="text" class="form-control" id="ipBanField" name="ipBanField" autocomplete="off"${attr("value", store_get($$store_subs ??= {}, "$ipAddress", ipAddress))}/></div> <div><button type="button" class="btn btn-outline-secondary">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.confirm-ban-ip.find-player"))}</button></div></div></div> <div class="form-group text-start mb-3"><label for="ipBanMessage" class="form-label">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.confirm-ban-player.ban-message"))}</label> <textarea class="form-control" id="ipBanMessage" name="ipBanMessage" rows="3" maxlength="255"${attr("placeholder", store_get($$store_subs ??= {}, "$_", $format)("components.modals.confirm-ban-ip.ban-message-placeholder"))}>`);
		const $$body = escape_html(store_get($$store_subs ??= {}, "$banMessage", banMessage));
		if ($$body) $$renderer.push(`${$$body}`);
		else $$renderer.push(`
          `);
		$$renderer.push(`</textarea> <small class="float-end">${escape_html(store_get($$store_subs ??= {}, "$banMessage", banMessage).length)}/255</small></div> <div class="form-group text-start mb-3"><h6 class="mb-2">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.confirm-ban-player.ban-duration"))}</h6> <div class="btn-group w-100" role="group" aria-label="IP ban duration options"><input type="radio" class="btn-check" value="permanent"${attr("checked", store_get($$store_subs ??= {}, "$banDuration", banDuration) === "permanent", true)} id="ipBanPermanent" name="ipBanDuration" autocomplete="off"/> <label class="btn btn-outline-primary" for="ipBanPermanent">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.confirm-ban-player.permanent-ban"))}</label> <input type="radio" class="btn-check" value="custom"${attr("checked", store_get($$store_subs ??= {}, "$banDuration", banDuration) === "custom", true)} id="ipBanCustom" name="ipBanDuration" autocomplete="off"/> <label class="btn btn-outline-primary" for="ipBanCustom">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.confirm-ban-player.custom-duration"))}</label> <input type="radio" class="btn-check" value="datetime"${attr("checked", store_get($$store_subs ??= {}, "$banDuration", banDuration) === "datetime", true)} id="ipBanDateTime" name="ipBanDuration" autocomplete="off"/> <label class="btn btn-outline-primary" for="ipBanDateTime">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.confirm-ban-player.custom-datetime"))}</label></div> `);
		if (store_get($$store_subs ??= {}, "$banDuration", banDuration) === "custom") {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<div class="mt-2">`);
			$$renderer.select({
				class: "form-select",
				value: store_get($$store_subs ??= {}, "$customDuration", customDuration)
			}, ($$renderer) => {
				$$renderer.option({ value: "" }, ($$renderer) => {
					$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.confirm-ban-player.select-duration"))}`);
				});
				$$renderer.option({ value: "15m" }, ($$renderer) => {
					$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.confirm-ban-player.15-minutes"))}`);
				});
				$$renderer.option({ value: "30m" }, ($$renderer) => {
					$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.confirm-ban-player.30-minutes"))}`);
				});
				$$renderer.option({ value: "1h" }, ($$renderer) => {
					$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.confirm-ban-player.1-hour"))}`);
				});
				$$renderer.option({ value: "3h" }, ($$renderer) => {
					$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.confirm-ban-player.3-hours"))}`);
				});
				$$renderer.option({ value: "6h" }, ($$renderer) => {
					$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.confirm-ban-player.6-hours"))}`);
				});
				$$renderer.option({ value: "12h" }, ($$renderer) => {
					$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.confirm-ban-player.12-hours"))}`);
				});
				$$renderer.option({ value: "1d" }, ($$renderer) => {
					$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.confirm-ban-player.1-day"))}`);
				});
				$$renderer.option({ value: "3d" }, ($$renderer) => {
					$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.confirm-ban-player.3-days"))}`);
				});
				$$renderer.option({ value: "7d" }, ($$renderer) => {
					$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.confirm-ban-player.1-week"))}`);
				});
				$$renderer.option({ value: "30d" }, ($$renderer) => {
					$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.confirm-ban-player.1-month"))}`);
				});
				$$renderer.option({ value: "180d" }, ($$renderer) => {
					$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.confirm-ban-player.6-months"))}`);
				});
				$$renderer.option({ value: "365d" }, ($$renderer) => {
					$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.confirm-ban-player.1-year"))}`);
				});
			});
			$$renderer.push(`</div>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--> `);
		if (store_get($$store_subs ??= {}, "$banDuration", banDuration) === "datetime") {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<div class="mt-2"><input type="datetime-local" class="form-control"${attr("value", store_get($$store_subs ??= {}, "$customDateTime", customDateTime))}${attr("min", (/* @__PURE__ */ new Date()).toISOString().slice(0, 16))} step="60"/></div>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--></div></div> <div class="modal-footer flex-nowrap"><button${attr_class("btn btn-link col-6 m-0", void 0, { "disabled": loading })} type="button">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.cancel"))}</button> <button${attr_class("btn btn-danger col-6 m-0", void 0, { "disabled": loading })} type="button">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.yes"))}</button></div></div></div></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
	});
}
var bannedIp = writable({
	id: 0,
	ip: ""
});
function UnbanIpModal($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let loading;
		$$renderer.push(`<div aria-hidden="true" class="modal fade" role="dialog" tabindex="-1"><div class="modal-dialog modal-dialog-centered" role="dialog"><div class="modal-content"><div class="modal-body text-center"><div class="pb-3"><i class="fas fa-question-circle fa-3x d-block m-auto text-gray"></i></div> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.unban-ip.title", { values: { ip: store_get($$store_subs ??= {}, "$bannedIp", bannedIp)?.ip ?? "" } }))}</div> <div class="modal-footer flex-nowrap"><button${attr_class("btn btn-link col-6 m-0", void 0, { "disabled": loading })} type="button">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.cancel"))}</button> <button${attr_class("btn btn-danger col-6 m-0", void 0, { "disabled": loading })} type="button">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.yes"))}</button></div></div></div></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
	});
}

export { ConfirmBanIpModal as C, UnbanIpModal as U };
//# sourceMappingURL=UnbanIpModal.js-DUSG5GwD.js.map
