import { J as getContext, Q as store_get, Z as escape_html, T as attr, P as ensure_array_like, V as attr_class, S as unsubscribe_stores, F as writable, R as spread_props } from './index-server.js-DdhL7Abu.js';
import { p as page } from './stores.js-D5xmrOAP.js';
import 'node:module';
import './server.js-BlClO2ED.js';
import './internal2.js-CNe5OZUJ.js';
import './routing.js-N-OPb2ye.js';
import './ToastContainer.js-Bv1jJ2dr.js';
import { $ as $format } from './runtime.js-BzHEw_ze.js';
import { h as hasPermission, P as Permissions } from './auth.util.js-C77uoaNq.js';
import { L as Languages } from './language.util.js-ByanOnuS.js';
import './tooltip.util.js-BeLZL-Tj.js';
import './SiteNavigationMenu.js-DeoPp7eK.js';

//#region src/lib/components/ViewComponent.svelte
function ViewComponent($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		let { component, $$slots, $$events, ...rest } = $$props;
		if (component && typeof component !== "function") {
			$$renderer.push("<!--[0-->");
			const Component = component.default || component;
			if (Component) {
				$$renderer.push("<!--[-->");
				Component($$renderer, spread_props([rest]));
				$$renderer.push("<!--]-->");
			} else {
				$$renderer.push("<!--[!-->");
				$$renderer.push("<!--]-->");
			}
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]-->`);
	});
}
var player$2 = writable({});
var playerBackup = writable({});
var errors = writable({
	"username": "",
	"email": "",
	"newPassword": "",
	"newPasswordRepeat": ""
});
var pluginHandlers = writable({});
var resolvedCardRowItems = writable([]);
function EditPlayerModal($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let playerDataForPlugins, pluginsDirty, saveDisabled;
		function registerPluginHandler(id, handler) {
			if (handler) pluginHandlers.update((h) => {
				h[id] = handler;
				return { ...h };
			});
		}
		const siteInfo = getContext("siteInfo");
		const user = getContext("user");
		playerDataForPlugins = (store_get($$store_subs ??= {}, "$player", player$2).username ?? "") !== (store_get($$store_subs ??= {}, "$playerBackup", playerBackup).username ?? "") ? {
			...store_get($$store_subs ??= {}, "$player", player$2),
			username: store_get($$store_subs ??= {}, "$playerBackup", playerBackup).username
		} : store_get($$store_subs ??= {}, "$player", player$2);
		pluginsDirty = Object.values(store_get($$store_subs ??= {}, "$pluginHandlers", pluginHandlers)).some((h) => h && h.isDirty);
		saveDisabled = !store_get($$store_subs ??= {}, "$player", player$2).username || !pluginsDirty && !store_get($$store_subs ??= {}, "$player", player$2).clearPassword && store_get($$store_subs ??= {}, "$player", player$2).username === store_get($$store_subs ??= {}, "$playerBackup", playerBackup).username && store_get($$store_subs ??= {}, "$player", player$2).email === store_get($$store_subs ??= {}, "$playerBackup", playerBackup).email && (!store_get($$store_subs ??= {}, "$player", player$2).newPassword || store_get($$store_subs ??= {}, "$player", player$2).newPassword && store_get($$store_subs ??= {}, "$player", player$2).newPassword !== store_get($$store_subs ??= {}, "$player", player$2).newPasswordRepeat) && store_get($$store_subs ??= {}, "$player", player$2).canCreateTicket === store_get($$store_subs ??= {}, "$playerBackup", playerBackup).canCreateTicket && store_get($$store_subs ??= {}, "$player", player$2).isEmailVerified === store_get($$store_subs ??= {}, "$playerBackup", playerBackup).isEmailVerified && store_get($$store_subs ??= {}, "$player", player$2).localeCode === store_get($$store_subs ??= {}, "$playerBackup", playerBackup).localeCode;
		$$renderer.push(`<div aria-hidden="true" class="modal fade" role="dialog" tabindex="-1"><div class="modal-dialog modal-dialog-centered" role="dialog"><div class="modal-content"><div class="modal-header"><h5 class="modal-title">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.edit-player.title"))}</h5> <button${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("buttons.close"))} type="button" class="btn-close" data-bs-dismiss="modal"></button></div> <form><div class="modal-body"><!--[-->`);
		const each_array = ensure_array_like(store_get($$store_subs ??= {}, "$resolvedCardRowItems", resolvedCardRowItems));
		for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
			let row = each_array[$$index];
			if (!row.permission || hasPermission(row.permission, store_get($$store_subs ??= {}, "$page", page).data.user)) {
				$$renderer.push("<!--[0-->");
				ViewComponent($$renderer, {
					component: row.component,
					playerData: playerDataForPlugins,
					onHookRegister: (handler) => registerPluginHandler(row.id, handler)
				});
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]-->`);
		}
		$$renderer.push(`<!--]--> <div class="row"><div class="col-12"><div class="form-floating mb-3"><input${attr_class("form-control", void 0, { "is-invalid": !!store_get($$store_subs ??= {}, "$errors", errors).username })} id="username"${attr("placeholder", store_get($$store_subs ??= {}, "$_", $format)("components.modals.edit-player.inputs.username.placeholder"))} type="text"${attr("value", store_get($$store_subs ??= {}, "$player", player$2).username)} aria-describedby="validationEditUsernameInModal"/> <label for="username">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.edit-player.inputs.username.placeholder"))}</label></div> <div id="validationEditUsernameInModal" class="invalid-feedback">`);
		if (!!store_get($$store_subs ??= {}, "$errors", errors)["username"]) {
			$$renderer.push("<!--[0-->");
			if (store_get($$store_subs ??= {}, "$errors", errors)["username"] === "INVALID") {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.edit-player.inputs.username.errors.invalid"))}`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--> `);
			if (store_get($$store_subs ??= {}, "$errors", errors)["username"] === "EXISTS") {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.edit-player.inputs.username.errors.exists"))}`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]-->`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--></div></div> <div class="col-12 mb-3"><div class="form-floating"><input${attr_class("form-control", void 0, { "is-invalid": !!store_get($$store_subs ??= {}, "$errors", errors).email })} id="email" type="text" placeholder="email@example.com"${attr("value", store_get($$store_subs ??= {}, "$player", player$2).email)}${attr("disabled", store_get($$store_subs ??= {}, "$player", player$2).clearPassword, true)} aria-describedby="validationEditEmailInModal"/> <label for="email">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.edit-player.inputs.email.title"))}</label></div> <div id="validationEditEmailInModal" class="invalid-feedback">`);
		if (!!store_get($$store_subs ??= {}, "$errors", errors)["email"]) {
			$$renderer.push("<!--[0-->");
			if (store_get($$store_subs ??= {}, "$errors", errors)["email"] === "INVALID") {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.edit-player.inputs.email.errors.invalid"))}`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--> `);
			if (store_get($$store_subs ??= {}, "$errors", errors)["email"] === "EXISTS") {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.edit-player.inputs.email.errors.exists"))}`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]-->`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--></div> `);
		if (!store_get($$store_subs ??= {}, "$player", player$2).clearPassword && !String(store_get($$store_subs ??= {}, "$player", player$2).email ?? "").trim()) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<div class="alert alert-info mt-2 mb-0 py-2 px-3" role="status"><i class="fa-solid fa-circle-info me-1"></i> <small>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.edit-player.inputs.email.empty-login-notice"))}</small></div>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--></div> <div class="col-12 mb-3"><div class="merged-grid w-100 svelte-1u2vj3d"><div class="form-floating svelte-1u2vj3d"><input${attr_class("form-control svelte-1u2vj3d", void 0, { "is-invalid": !!store_get($$store_subs ??= {}, "$errors", errors).newPassword })} id="newPassword" type="password" placeholder="••••••••"${attr("value", store_get($$store_subs ??= {}, "$player", player$2).newPassword)}${attr("disabled", store_get($$store_subs ??= {}, "$player", player$2).clearPassword, true)} aria-describedby="validationEditPasswordInModal"/> <label for="newPassword">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.edit-player.inputs.new-password.title"))}</label></div> <div class="form-floating svelte-1u2vj3d"><input${attr_class("form-control svelte-1u2vj3d", void 0, { "is-invalid": !!store_get($$store_subs ??= {}, "$errors", errors).newPasswordRepeat })} id="newPasswordRepeat" type="password" placeholder="••••••••"${attr("value", store_get($$store_subs ??= {}, "$player", player$2).newPasswordRepeat)}${attr("disabled", store_get($$store_subs ??= {}, "$player", player$2).clearPassword, true)} aria-describedby="validationEditNewPasswordInModal"/> <label for="newPasswordRepeat">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.edit-player.inputs.new-password-repeat.title"))}</label></div></div> `);
		if (hasPermission(Permissions.MANAGE_PLAYERS, store_get($$store_subs ??= {}, "$page", page).data.user)) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<div class="form-check form-switch mt-2"><input class="form-check-input" type="checkbox" role="switch" id="clearPasswordInEditPlayerModal"${attr("checked", store_get($$store_subs ??= {}, "$player", player$2).clearPassword, true)}/> <label class="form-check-label" for="clearPasswordInEditPlayerModal">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.edit-player.inputs.clear-password.label"))}</label></div> `);
			if (store_get($$store_subs ??= {}, "$player", player$2).clearPassword) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<div class="alert alert-warning mt-2 mb-0 py-2 px-3" role="status"><i class="fa-solid fa-triangle-exclamation me-1"></i> <small>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.edit-player.inputs.clear-password.help"))}</small></div>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]-->`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--> <div id="validationEditPasswordInModal" class="invalid-feedback">`);
		if (!!store_get($$store_subs ??= {}, "$errors", errors)["newPassword"]) {
			$$renderer.push("<!--[0-->");
			if (store_get($$store_subs ??= {}, "$errors", errors)["newPassword"] === "INVALID") {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.edit-player.inputs.new-password.errors.invalid"))}`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--> `);
			if (store_get($$store_subs ??= {}, "$errors", errors)["newPassword"] === "CONFLICT") {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.edit-player.inputs.new-password.errors.conflict-with-clear"))}`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]-->`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--></div> <div id="validationEditNewPasswordInModal" class="invalid-feedback">`);
		if (!!store_get($$store_subs ??= {}, "$errors", errors)["newPasswordRepeat"]) {
			$$renderer.push("<!--[0-->");
			if (store_get($$store_subs ??= {}, "$errors", errors)["newPasswordRepeat"] === "NOT_MATCH") {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.edit-player.inputs.new-password-repeat.errors.not-match"))}`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]-->`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--></div></div> <div class="col-12 mb-3"><div class="form-floating">`);
		$$renderer.select({
			class: "form-control form-select",
			id: "userLocaleCode",
			value: store_get($$store_subs ??= {}, "$player", player$2).localeCode
		}, ($$renderer) => {
			$$renderer.option({ value: null }, ($$renderer) => {
				$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.edit-player.inputs.locale.default", { values: { defaultLocaleName: store_get($$store_subs ??= {}, "$Languages", Languages)[store_get($$store_subs ??= {}, "$siteInfo", siteInfo).platformLocale].name } }))}`);
			});
			$$renderer.push(`<!--[-->`);
			const each_array_1 = ensure_array_like(Object.keys(store_get($$store_subs ??= {}, "$Languages", Languages)));
			for (let index = 0, $$length = each_array_1.length; index < $$length; index++) {
				let language = each_array_1[index];
				$$renderer.option({ value: store_get($$store_subs ??= {}, "$Languages", Languages)[language].code }, ($$renderer) => {
					$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$Languages", Languages)[language].name)}`);
				});
			}
			$$renderer.push(`<!--]-->`);
		});
		$$renderer.push(` <label for="userLocaleCode">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.edit-player.inputs.locale.label"))}</label></div> `);
		if (store_get($$store_subs ??= {}, "$player", player$2).localeCode && store_get($$store_subs ??= {}, "$player", player$2).localeCode !== store_get($$store_subs ??= {}, "$siteInfo", siteInfo).platformLocale) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<div class="alert alert-info mt-2 mb-0 py-2 px-3" role="alert"><i class="fa-solid fa-circle-info me-1"></i> <small>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.edit-player.inputs.locale.mismatch-warning"))}</small></div>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--></div> <div class="col-6"><div class="form-check form-switch"><input class="form-check-input" type="checkbox" aria-checked="true" role="switch" id="canCreateTicketCheckbox"${attr("checked", store_get($$store_subs ??= {}, "$player", player$2).canCreateTicket, true)}${attr("disabled", store_get($$store_subs ??= {}, "$playerBackup", playerBackup).username === store_get($$store_subs ??= {}, "$user", user).username, true)}/> <label class="form-check-label" for="canCreateTicketCheckbox">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.edit-player.inputs.can-open-ticket"))}</label></div></div> <div class="col-6"><div class="form-check form-switch"><input class="form-check-input" type="checkbox" role="switch" aria-checked="true" id="emailVerifiedCheckbox"${attr("checked", store_get($$store_subs ??= {}, "$player", player$2).isEmailVerified, true)}${attr("disabled", store_get($$store_subs ??= {}, "$playerBackup", playerBackup).username === store_get($$store_subs ??= {}, "$user", user).username, true)}/> <label class="form-check-label" for="emailVerifiedCheckbox">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.edit-player.inputs.email-verified"))}</label></div></div></div></div> <div class="modal-footer"><button${attr_class("btn btn-primary w-100", void 0, { "disabled": saveDisabled })} type="submit">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.save"))}</button></div></form></div></div></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
	});
}
var sendNotification = writable(true);
var banMessage = writable("");
var banDuration = writable("permanent");
var customDuration = writable("");
var customDateTime = writable("");
function ConfirmBanPlayerModal($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let loading;
		$$renderer.push(`<div aria-hidden="true" class="modal fade" role="dialog" tabindex="-1"><div class="modal-dialog modal-dialog-centered" role="dialog"><div class="modal-content"><div class="modal-body text-center"><div class="pb-3"><i class="fas fa-question-circle fa-3x d-block m-auto text-gray"></i></div> <div class="pb-3">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.confirm-ban-player.title"))}</div> <div class="form-group text-start mb-3"><label for="banMessage" class="form-label">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.confirm-ban-player.ban-message"))}</label> <textarea class="form-control" id="banMessage" rows="3" maxlength="255"${attr("placeholder", store_get($$store_subs ??= {}, "$_", $format)("components.modals.confirm-ban-player.ban-message-placeholder"))}>`);
		const $$body = escape_html(store_get($$store_subs ??= {}, "$banMessage", banMessage));
		if ($$body) $$renderer.push(`${$$body}`);
		else $$renderer.push(`
          `);
		$$renderer.push(`</textarea> <small class="float-end">${escape_html(store_get($$store_subs ??= {}, "$banMessage", banMessage).length)}/255</small></div> <div class="form-group text-start mb-3"><h6 class="mb-2">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.confirm-ban-player.ban-duration"))}</h6> <div class="btn-group w-100" role="group" aria-label="Ban duration options"><input type="radio" class="btn-check" value="permanent"${attr("checked", store_get($$store_subs ??= {}, "$banDuration", banDuration) === "permanent", true)} id="banPermanent" autocomplete="off"/> <label class="btn btn-outline-primary" for="banPermanent">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.confirm-ban-player.permanent-ban"))}</label> <input type="radio" class="btn-check" value="custom"${attr("checked", store_get($$store_subs ??= {}, "$banDuration", banDuration) === "custom", true)} id="banCustom" autocomplete="off"/> <label class="btn btn-outline-primary" for="banCustom">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.confirm-ban-player.custom-duration"))}</label> <input type="radio" class="btn-check" value="datetime"${attr("checked", store_get($$store_subs ??= {}, "$banDuration", banDuration) === "datetime", true)} id="banDateTime" autocomplete="off"/> <label class="btn btn-outline-primary" for="banDateTime">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.confirm-ban-player.custom-datetime"))}</label></div> `);
		if (store_get($$store_subs ??= {}, "$banDuration", banDuration) === "custom") {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<div class="mt-2">`);
			$$renderer.select({
				class: "form-select",
				value: store_get($$store_subs ??= {}, "$customDuration", customDuration)
			}, ($$renderer) => {
				$$renderer.option({ value: "" }, ($$renderer) => {
					$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.confirm-ban-player.select-duration"))}`);
				});
				$$renderer.option({ value: "15m" }, ($$renderer) => {
					$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.confirm-ban-player.15-minutes"))}`);
				});
				$$renderer.option({ value: "30m" }, ($$renderer) => {
					$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.confirm-ban-player.30-minutes"))}`);
				});
				$$renderer.option({ value: "1h" }, ($$renderer) => {
					$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.confirm-ban-player.1-hour"))}`);
				});
				$$renderer.option({ value: "3h" }, ($$renderer) => {
					$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.confirm-ban-player.3-hours"))}`);
				});
				$$renderer.option({ value: "6h" }, ($$renderer) => {
					$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.confirm-ban-player.6-hours"))}`);
				});
				$$renderer.option({ value: "12h" }, ($$renderer) => {
					$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.confirm-ban-player.12-hours"))}`);
				});
				$$renderer.option({ value: "1d" }, ($$renderer) => {
					$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.confirm-ban-player.1-day"))}`);
				});
				$$renderer.option({ value: "3d" }, ($$renderer) => {
					$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.confirm-ban-player.3-days"))}`);
				});
				$$renderer.option({ value: "7d" }, ($$renderer) => {
					$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.confirm-ban-player.1-week"))}`);
				});
				$$renderer.option({ value: "30d" }, ($$renderer) => {
					$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.confirm-ban-player.1-month"))}`);
				});
				$$renderer.option({ value: "180d" }, ($$renderer) => {
					$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.confirm-ban-player.6-months"))}`);
				});
				$$renderer.option({ value: "365d" }, ($$renderer) => {
					$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.confirm-ban-player.1-year"))}`);
				});
			});
			$$renderer.push(`</div>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--> `);
		if (store_get($$store_subs ??= {}, "$banDuration", banDuration) === "datetime") {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<div class="mt-2"><input type="datetime-local" class="form-control"${attr("value", store_get($$store_subs ??= {}, "$customDateTime", customDateTime))}${attr("min", (/* @__PURE__ */ new Date()).toISOString().slice(0, 16))} step="60"/></div>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--></div> <div class="form-check d-inline-block text-center"><input class="form-check-input" type="checkbox" value=""${attr("checked", store_get($$store_subs ??= {}, "$sendNotification", sendNotification), true)} id="notifyBanEmail"/> <label class="form-check-label" for="notifyBanEmail">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.confirm-ban-player.notify-with-email"))}</label></div></div> <div class="modal-footer flex-nowrap"><button${attr_class("btn btn-link col-6 m-0", void 0, { "disabled": loading })} type="button">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.cancel"))}</button> <button${attr_class("btn btn-danger col-6 m-0", void 0, { "disabled": loading })} type="button">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.yes"))}</button></div></div></div></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
	});
}
function UnbanPlayerModal($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let loading;
		$$renderer.push(`<div aria-hidden="true" class="modal fade" role="dialog" tabindex="-1"><div class="modal-dialog modal-dialog-centered" role="dialog"><div class="modal-content"><div class="modal-body text-center"><div class="pb-3"><i class="fas fa-question-circle fa-3x d-block m-auto text-gray"></i></div> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.unban-player.title"))}</div> <div class="modal-footer flex-nowrap"><button${attr_class("btn btn-link col-6 m-0", void 0, { "disabled": loading })} type="button">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.cancel"))}</button> <button${attr_class("btn btn-danger col-6 m-0", void 0, { "disabled": loading })} type="button">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.yes"))}</button></div></div></div></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
	});
}

export { ConfirmBanPlayerModal as C, EditPlayerModal as E, UnbanPlayerModal as U };
//# sourceMappingURL=UnbanPlayerModal.js-BlpULLWg.js.map
