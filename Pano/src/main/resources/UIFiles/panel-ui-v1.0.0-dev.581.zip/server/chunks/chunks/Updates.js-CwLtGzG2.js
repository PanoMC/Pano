import 'node:module';
import { b as base } from './internal.js-BRN1McAa.js';
import { J as getContext, a0 as onDestroy, Z as escape_html, Q as store_get, V as attr_class, T as attr, $ as attr_style, U as stringify, P as ensure_array_like, S as unsubscribe_stores, O as bind_props, N as fallback, a4 as store_set, F as writable } from './index-server.js-DdhL7Abu.js';
import { b as beforeNavigate } from './stores.js-D5xmrOAP.js';
import './server.js-BlClO2ED.js';
import './internal2.js-CNe5OZUJ.js';
import './routing.js-N-OPb2ye.js';
import { e as buildQueryParams, b as ApiUtil, P as PANO_WEBSITE_URL } from './Store.js-DT3aZHRb.js';
import { $ as $format } from './runtime.js-BzHEw_ze.js';
import './ToastContainer.js-Bv1jJ2dr.js';
import { D as Date_1 } from './Date.js-DCZp_jrB.js';
import './tooltip.util.js-BeLZL-Tj.js';
import { N as NoContent } from './NoContent.js-Coj2fA9d.js';
import { V as VerifiedStatus } from './VerifiedStatus.js-BWWM3WML.js';
import { C as CardHeader } from './CardHeader.js-XBureLRg.js';
import { r as require_copy_to_clipboard } from './copy-to-clipboard.js-Doa_mbw4.js';
import { P as PageActions } from './PageActions.js-co-RIHDp.js';
import { f as formatBytes } from './string.util.js-Pwbw6tDM.js';
import './MarkdownRenderer.js-CF3Vvdqz.js';
import { C as ChangelogModal } from './ChangelogModal.js-Bs6ZUEs3.js';

require_copy_to_clipboard();
var background = writable(false);
function ConfirmUpdatePlatformModal($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let showBackgroundOption, confirmDisabled;
		let runMode = fallback($$props["runMode"], void 0);
		let loading = false;
		showBackgroundOption = runMode != null && !runMode.background;
		if (showBackgroundOption) store_set(background, true);
		else store_set(background, false);
		confirmDisabled = showBackgroundOption && !store_get($$store_subs ??= {}, "$background", background);
		$$renderer.push(`<div aria-hidden="true" class="modal fade" role="dialog" tabindex="-1"><div class="modal-dialog modal-dialog-centered" role="dialog"><div class="modal-content"><div class="modal-body text-center"><div class="pb-3"><i class="fas fa-download fa-3x d-block m-auto text-gray"></i></div> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.confirm-update-platform.title"))} `);
		if (showBackgroundOption) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<div class="alert alert-warning small text-start mt-3 mb-0"><i class="fas fa-triangle-exclamation me-2"></i> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.confirm-update-platform.terminal-mode-warning"))}</div> <div class="form-check form-switch text-start mt-2"><input id="updateInBackgroundSwitch" class="form-check-input" type="checkbox"${attr("checked", store_get($$store_subs ??= {}, "$background", background), true)}${attr("disabled", loading, true)}/> <label class="form-check-label" for="updateInBackgroundSwitch">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.confirm-update-platform.restart-in-background"))}</label></div>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--></div> <div class="modal-footer flex-nowrap"><button${attr_class("btn btn-link col-6 m-0", void 0, { "disabled": loading })} type="button">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.cancel"))}</button> <button${attr_class("btn btn-secondary col-6 m-0", void 0, { "disabled": confirmDisabled })} type="button"${attr("disabled", confirmDisabled, true)}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.yes"))}</button></div></div></div></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
		bind_props($$props, { runMode });
	});
}
function ConfirmUpdateResourceModal($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let loading = false;
		$$renderer.push(`<div aria-hidden="true" class="modal fade" role="dialog" tabindex="-1"><div class="modal-dialog modal-dialog-centered" role="dialog"><div class="modal-content"><div class="modal-body text-center"><div class="pb-3"><i class="fas fa-download fa-3x d-block m-auto text-gray"></i></div> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.confirm-update-resource.title"))}</div> <div class="modal-footer flex-nowrap"><button${attr_class("btn btn-link col-6 m-0", void 0, { "disabled": loading })} type="button">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.cancel"))}</button> <button${attr_class("btn btn-secondary col-6 m-0", void 0, { "disabled": loading })} type="button">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.yes"))}</button></div></div></div></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
	});
}
function ConfirmUpdateResourcesModal($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let loading = false;
		$$renderer.push(`<div aria-hidden="true" class="modal fade" role="dialog" tabindex="-1"><div class="modal-dialog modal-dialog-centered" role="dialog"><div class="modal-content"><div class="modal-body text-center"><div class="pb-3"><i class="fas fa-download fa-3x d-block m-auto text-gray"></i></div> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.confirm-update-resources.title"))}</div> <div class="modal-footer flex-nowrap"><button${attr_class("btn btn-link col-6 m-0", void 0, { "disabled": loading })} type="button">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.cancel"))}</button> <button${attr_class("btn btn-secondary col-6 m-0", void 0, { "disabled": loading })} type="button">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.yes"))}</button></div></div></div></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
	});
}
//#endregion
//#region src/lib/pages/settings/Updates.svelte
async function load(event) {
	const { parent } = event;
	await parent();
	const queryParams = buildQueryParams({ type: "UPDATES" });
	return await ApiUtil.get({
		path: "/api/panel/settings" + queryParams,
		request: event
	});
}
function Updates($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let data = $$props["data"];
		getContext("pageTitle").set("pages.settings.updates.title");
		let loading;
		let platformUpdateError;
		let platformUpdatingStep = 1;
		let inProgressResource;
		let resourceUpdateStep = 1;
		let updatingAll;
		(/* @__PURE__ */ new Date()).toISOString(), (/* @__PURE__ */ new Date()).toISOString();
		const platformUpdating = getContext("platformUpdating");
		getContext("platformRestarting");
		const platformUpdateProcesses = [
			"getting-platform-update-info",
			"downloading-update",
			"verifying-hash",
			"extracting-updater",
			"installing-new-update"
		];
		const resourceUpdateProcesses = [
			"getting-version-info",
			"downloading-update",
			"preparing",
			"installing-new-update"
		];
		function isPlatformUpdateFinished(installingStep) {
			return installingStep === platformUpdateProcesses.length + 1;
		}
		function isResourceUpdateFinished(installingStep) {
			return installingStep === resourceUpdateProcesses.length + 1;
		}
		String.prototype.capitalize = function() {
			return this.charAt(0).toUpperCase() + this.slice(1);
		};
		function getVerifiedStatus(status) {
			if (typeof status === "undefined") return "UNKNOWN";
			else if (status) return "VERIFIED";
			else return "NOT_VERIFIED";
		}
		onDestroy(() => {});
		beforeNavigate((nav) => {});
		PageActions($$renderer, {
			middleClasses: "d-lg-flex d-none",
			$$slots: {
				left: ($$renderer) => {
					$$renderer.push(`<div slot="left"><span class="small"><i class="fa-regular fa-clock me-2"></i> `);
					if (data.lastCheckedAt) {
						$$renderer.push("<!--[0-->");
						Date_1($$renderer, {
							time: data.lastCheckedAt.value,
							relativeFormat: true,
							tooltip: false
						});
					} else {
						$$renderer.push("<!--[-1-->");
						$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.updates.never"))}`);
					}
					$$renderer.push(`<!--]--></span></div>`);
				},
				right: ($$renderer) => {
					$$renderer.push(`<div class="hstack gap-2" slot="right"><button${attr_class("btn btn-secondary", void 0, { "disabled": store_get($$store_subs ??= {}, "$platformUpdating", platformUpdating) || inProgressResource })}><i${attr_class("fa-regular fa-arrows-rotate", void 0, { "fa-spin": loading })}></i> <span class="d-lg-inline d-none ms-2">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.check-updates"))}</span></button></div>`);
				}
			}
		});
		$$renderer.push(`<!----> <div class="card"><div class="card-header">`);
		if (data.platformUpdate) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.updates.platform-updates-count", { values: { count: 1 } }))}`);
		} else {
			$$renderer.push("<!--[-1-->");
			$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.updates.platform-updates"))}`);
		}
		$$renderer.push(`<!--]--></div> `);
		if (!data.platformUpdate) {
			$$renderer.push("<!--[0-->");
			NoContent($$renderer, {
				icon: "fas fa-check fa-3x",
				text: store_get($$store_subs ??= {}, "$_", $format)("pages.settings.updates.using-latest-pano")
			});
		} else {
			$$renderer.push("<!--[-1-->");
			$$renderer.push(`<div class="card-body"><ul class="list-group"><li class="list-group-item"><div class="d-flex gap-3 flex-wrap position-relative"><div class="flex-shrink-0"><div class="d-inline-flex rounded justify-content-center align-items-center bg-primary" style="width: 64px; height: 64px;"><i class="fas fa-box fa-2x text-white" title="Pano"></i></div></div> <div class="flex-grow-1 min-w-0 mobile-info-padding svelte-usmvh6"><div class="d-flex justify-content-between align-items-start gap-3"><div class="vstack gap-2"><div class="d-flex align-items-center gap-2 flex-wrap"><h5 class="mb-0">Pano</h5> <i class="fa-regular fa-circle-check text-success"></i> <span class="badge text-bg-secondary">${escape_html(data.platformUpdate.channel.capitalize())}</span> <span class="badge text-bg-primary">${escape_html(data.platformUpdate.oldVersion)} <i class="fas fa-arrow-right fa-xs"></i> ${escape_html(data.platformUpdate.version)}</span></div> <div class="d-flex flex-wrap gap-2 small mb-0"><div><i class="fas fa-database me-1"></i> ${escape_html(formatBytes(data.platformUpdate.size))}</div> <div><i class="fas fa-calendar me-1"></i> `);
			Date_1($$renderer, { time: data.platformUpdate.releaseDate });
			$$renderer.push(`<!----></div></div></div> <div class="d-flex align-items-center gap-1 flex-shrink-0 mobile-absolute-actions svelte-usmvh6"><button${attr_class("btn btn-sm btn-link", void 0, { "disabled": store_get($$store_subs ??= {}, "$platformUpdating", platformUpdating) || updatingAll })}${attr("title", store_get($$store_subs ??= {}, "$_", $format)("pages.settings.updates.changelog"))}${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("pages.settings.updates.changelog"))}><i class="fa-regular fa-file-lines fa-lg"></i></button> <button${attr_class("btn btn-sm btn-link", void 0, { "disabled": store_get($$store_subs ??= {}, "$platformUpdating", platformUpdating) || updatingAll })}${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("pages.settings.updates.copy-hash"))}${attr("title", store_get($$store_subs ??= {}, "$_", $format)("pages.settings.updates.copy-hash"))}><i class="fa-solid fa-hashtag fa-lg"></i></button> <button${attr_class("btn btn-sm btn-secondary d-flex align-items-center gap-2", void 0, { "disabled": store_get($$store_subs ??= {}, "$platformUpdating", platformUpdating) || updatingAll })}>`);
			if (store_get($$store_subs ??= {}, "$platformUpdating", platformUpdating)) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<i class="fas fa-circle-notch fa-spin"></i>`);
			} else {
				$$renderer.push("<!--[-1-->");
				$$renderer.push(`<i class="fas fa-download"></i>`);
			}
			$$renderer.push(`<!--]--></button></div></div> `);
			if (store_get($$store_subs ??= {}, "$platformUpdating", platformUpdating) || platformUpdateError) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<div class="progress my-3" role="progressbar"${attr("aria-valuenow", platformUpdatingStep)} aria-valuemin="0"${attr("aria-valuemax", platformUpdateProcesses.length + 1)} style="height: 5px;"><div${attr_class(`progress-bar bg-secondary progress-bar-striped ${!isPlatformUpdateFinished(platformUpdatingStep) ? "progress-bar-animated bg-primary" : "bg-success"}`)}${attr_style(`width: ${stringify(Math.min(0, platformUpdateProcesses.length - 1) / (platformUpdateProcesses.length - 1) * 100)}%`)}></div></div> <p class="small mb-0">`);
				if (!isPlatformUpdateFinished(platformUpdatingStep)) {
					$$renderer.push("<!--[1-->");
					$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.updates.platform-update-steps." + platformUpdateProcesses[0]))}`);
				} else {
					$$renderer.push("<!--[-1-->");
					$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.updates.install-complete-restarting"))} <i class="me-2 fas fa-arrows-rotate fa-spin"></i>`);
				}
				$$renderer.push(`<!--]--></p>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--></div></div></li></ul></div>`);
		}
		$$renderer.push(`<!--]--></div> <div class="card">`);
		CardHeader($$renderer, {
			showRight: data.resourceUpdates.length > 1,
			$$slots: {
				left: ($$renderer) => {
					$$renderer.push(`<div slot="left">`);
					if (data.resourceUpdates.length > 0) {
						$$renderer.push("<!--[0-->");
						$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.updates.resource-updates-count", { values: { count: data.resourceUpdates.length } }))}`);
					} else {
						$$renderer.push("<!--[-1-->");
						$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.updates.resource-updates"))}`);
					}
					$$renderer.push(`<!--]--></div>`);
				},
				right: ($$renderer) => {
					$$renderer.push(`<div slot="right"><button${attr_class("btn btn-sm btn-secondary", void 0, { "disabled": store_get($$store_subs ??= {}, "$platformUpdating", platformUpdating) || data.resourceUpdates.length === 0 })}><i class="fas fa-download me-2"></i> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.update-all"))}</button></div>`);
				}
			}
		});
		$$renderer.push(`<!----> <div class="card-body">`);
		if (!data.panoAccount) {
			$$renderer.push("<!--[0-->");
			NoContent($$renderer, {
				icon: "fas fa-sync fa-3x",
				text: store_get($$store_subs ??= {}, "$_", $format)("pages.settings.updates.connect-pano-account"),
				dark: false,
				children: ($$renderer) => {
					$$renderer.push(`<div class="text-center"><a class="btn btn-primary"${attr("href", `${stringify(base)}/settings/platform`)}><i class="fa-solid fa-link me-2" aria-hidden="true"></i> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.connect-pano-account"))}</a></div>`);
				},
				$$slots: { default: true }
			});
		} else if (data.resourceUpdates.length === 0) {
			$$renderer.push("<!--[1-->");
			NoContent($$renderer, {
				icon: "fas fa-sync fa-3x",
				text: store_get($$store_subs ??= {}, "$_", $format)("pages.settings.updates.no-update-found"),
				dark: false
			});
		} else {
			$$renderer.push("<!--[-1-->");
			$$renderer.push(`<ul class="list-group"><!--[-->`);
			const each_array = ensure_array_like(data.resourceUpdates);
			for (let index = 0, $$length = each_array.length; index < $$length; index++) {
				let update = each_array[index];
				$$renderer.push(`<li class="list-group-item"><div class="d-flex gap-3 flex-wrap position-relative"><div class="flex-shrink-0"><a${attr("href", `${PANO_WEBSITE_URL}/${update.type === "PLUGIN" ? "addons" : "themes"}/${update.id}`)} target="_blank">`);
				if (update.iconFileName) {
					$$renderer.push("<!--[0-->");
					$$renderer.push(`<img${attr("width", update.type === "THEME" ? 114 : 64)} height="64" class="rounded"${attr("src", `/api/panel/updates/icon/${update.iconFileName}?type=${update.type}`)}${attr("alt", update.name || update.id)}/>`);
				} else {
					$$renderer.push("<!--[-1-->");
					$$renderer.push(`<div class="rounded text-body overflow-hidden position-relative"${attr_style(`width: ${stringify(update.type === "THEME" ? 114 : 64)}px; height: 64px;`)}><i${attr_class(`fas fa-${update.type === "THEME" ? "palette" : "puzzle-piece"} position-absolute`)} style="font-size: 100px; bottom: -35px; right: -30px; opacity: 0.15;"></i></div>`);
				}
				$$renderer.push(`<!--]--></a></div> <div class="flex-grow-1 min-w-0 mobile-info-padding svelte-usmvh6"><div class="d-flex justify-content-between align-items-start gap-3"><div class="vstack gap-1 min-w-0"><div class="d-flex flex-wrap align-items-center gap-2"><a${attr("href", `${PANO_WEBSITE_URL}/${update.type === "PLUGIN" ? "addons" : "themes"}/${update.id}`)} target="_blank" class="text-decoration-none focus-ring rounded d-inline-flex align-items-center gap-2"><h5 class="text-truncate mb-0">${escape_html(update.resourceTitle || update.name || update.id)} <i class="fas fa-external-link-alt fa-xs ms-1"></i></h5> `);
				VerifiedStatus($$renderer, { status: getVerifiedStatus(update.verified) });
				$$renderer.push(`<!----></a> <span class="badge text-bg-primary">${escape_html(update.oldVersion)} <i class="fas fa-arrow-right fa-xs"></i> ${escape_html(update.version)}</span></div> <div class="small font-monospace d-flex align-items-center gap-2">${escape_html(update.id)} `);
				if (update.incompatible) {
					$$renderer.push("<!--[0-->");
					$$renderer.push(`<span class="text-danger small hstack gap-1"><i class="fas fa-triangle-exclamation"></i> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.updates.incompatible-version", { default: "Pano version incompatible" }))} `);
					if (update.requiredPanoVersion) {
						$$renderer.push("<!--[0-->");
						$$renderer.push(`(${escape_html(update.requiredPanoVersion)}+)`);
					} else $$renderer.push("<!--[-1-->");
					$$renderer.push(`<!--]--></span>`);
				} else $$renderer.push("<!--[-1-->");
				$$renderer.push(`<!--]--></div> <div class="hstack gap-3 small flex-wrap"><span>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.updates.by"))} <a${attr("href", `${PANO_WEBSITE_URL}/users/${update.developer}`)} target="_blank" class="text-decoration-none">${escape_html(update.developer)}</a></span> <span><i class="fas fa-database me-2"></i>${escape_html(formatBytes(update.size))}</span> <span><i class="fa-regular fa-calendar me-2"></i>`);
				Date_1($$renderer, { time: update.createdAt });
				$$renderer.push(`<!----></span></div></div> <div class="d-flex align-items-center gap-1 flex-shrink-0 mobile-absolute-actions svelte-usmvh6"><button${attr_class("btn btn-sm btn-link", void 0, { "disabled": store_get($$store_subs ??= {}, "$platformUpdating", platformUpdating) || updatingAll })}${attr("title", store_get($$store_subs ??= {}, "$_", $format)("pages.settings.updates.changelog"))}${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("pages.settings.updates.changelog"))}><i class="fa-regular fa-file-lines fa-lg"></i></button> <button${attr_class("btn btn-sm btn-link", void 0, { "disabled": store_get($$store_subs ??= {}, "$platformUpdating", platformUpdating) || updatingAll })}${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("pages.settings.updates.copy-hash"))}${attr("title", store_get($$store_subs ??= {}, "$_", $format)("pages.settings.updates.copy-hash"))}><i class="fa-solid fa-hashtag fa-lg"></i></button> <button${attr("title", store_get($$store_subs ??= {}, "$_", $format)("buttons.install"))}${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("buttons.install"))}${attr_class("btn btn-sm btn-secondary d-flex align-items-center gap-2", void 0, { "disabled": store_get($$store_subs ??= {}, "$platformUpdating", platformUpdating) || update.incompatible })}><i class="fas fa-download"></i></button></div></div> `);
				if (void 0 === update.id || void 0 === update.id) {
					$$renderer.push("<!--[0-->");
					$$renderer.push(`<div class="progress mt-3" role="progressbar"${attr("aria-valuenow", resourceUpdateStep)} aria-valuemin="0"${attr("aria-valuemax", resourceUpdateProcesses.length + 1)} style="height: 5px;"><div${attr_class(`progress-bar progress-bar-striped ${!isResourceUpdateFinished(resourceUpdateStep) ? "progress-bar-animated bg-primary" : "bg-success"}`)}${attr_style(`width: ${stringify(Math.min(0, resourceUpdateProcesses.length - 1) / (resourceUpdateProcesses.length - 1) * 100)}%`)}></div></div> <p class="small mb-0 mt-2">`);
					if (!isResourceUpdateFinished(resourceUpdateStep)) {
						$$renderer.push("<!--[1-->");
						$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.updates.resource-update-steps." + resourceUpdateProcesses[0]))}`);
					} else {
						$$renderer.push("<!--[-1-->");
						$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.updates.install-complete"))}`);
					}
					$$renderer.push(`<!--]--></p>`);
				} else $$renderer.push("<!--[-1-->");
				$$renderer.push(`<!--]--></div></div></li>`);
			}
			$$renderer.push(`<!--]--></ul>`);
		}
		$$renderer.push(`<!--]--></div></div> `);
		ConfirmUpdatePlatformModal($$renderer, { runMode: data.runMode });
		$$renderer.push(`<!----> `);
		ConfirmUpdateResourceModal($$renderer);
		$$renderer.push(`<!----> `);
		ConfirmUpdateResourcesModal($$renderer);
		$$renderer.push(`<!----> `);
		ChangelogModal($$renderer);
		$$renderer.push(`<!---->`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
		bind_props($$props, { data });
	});
}

export { Updates as U, load as l };
//# sourceMappingURL=Updates.js-CwLtGzG2.js.map
