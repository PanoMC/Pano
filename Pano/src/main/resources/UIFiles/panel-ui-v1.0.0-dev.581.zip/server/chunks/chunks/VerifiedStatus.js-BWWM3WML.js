import { O as bind_props } from './index-server.js-DdhL7Abu.js';
import './runtime.js-BzHEw_ze.js';
import './tooltip.util.js-BeLZL-Tj.js';

//#region src/lib/components/VerifiedStatus.svelte
function VerifiedStatus($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		let status = $$props["status"];
		if (status !== "UNKNOWN") $$renderer.push("<!--[0-->");
		else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--> `);
		if (status === "VERIFIED") {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<span class="text-success"><i class="fa-regular fa-circle-check"></i></span>`);
		} else if (status === "NOT_VERIFIED") {
			$$renderer.push("<!--[1-->");
			$$renderer.push(`<span class="text-warning"><i class="fa-solid fa-circle-exclamation"></i></span>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]-->`);
		bind_props($$props, { status });
	});
}

export { VerifiedStatus as V };
//# sourceMappingURL=VerifiedStatus.js-BWWM3WML.js.map
