import { Q as store_get, V as attr_class, T as attr, S as unsubscribe_stores, O as bind_props, Z as escape_html, F as writable } from './index-server.js-DdhL7Abu.js';
import { $ as $format } from './runtime.js-BzHEw_ze.js';
import { D as Date_1 } from './Date.js-DCZp_jrB.js';
import './tooltip.util.js-BeLZL-Tj.js';
import { M as MarkdownRenderer } from './MarkdownRenderer.js-CF3Vvdqz.js';

//#region src/lib/activity-log.util.js
function getActivityLogTranslation(log, translate) {
	if (!log) return "";
	const globalKey = "activity-logs." + log.type;
	const globalTranslation = translate(globalKey, { values: log.details });
	if (globalTranslation !== globalKey) return globalTranslation;
	if (log.pluginId) {
		const pluginKey = `plugins.${log.pluginId}.activity-logs.${log.type}`;
		const pluginTranslation = translate(pluginKey, { values: log.details });
		if (pluginTranslation !== pluginKey) return pluginTranslation;
	}
	return globalTranslation;
}
function stripHtmlTags(value) {
	return String(value ?? "").replace(/<[^>]*>?/gm, "");
}
//#endregion
//#region src/lib/components/rows/ActivityLogRow.svelte
function ActivityLogRow($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let translation;
		let log = $$props["log"];
		translation = getActivityLogTranslation(log, store_get($$store_subs ??= {}, "$_", $format));
		$$renderer.push(`<button type="button"${attr_class("list-group-item list-group-item-action focus-ring", void 0, { "bg-secondary-subtle": log.selected })}${attr("title", store_get($$store_subs ??= {}, "$_", $format)("buttons.view"))}><span class="fw-normal d-block text-truncate markdown-renderer"${attr("title", stripHtmlTags(translation))}>`);
		MarkdownRenderer($$renderer, { content: translation });
		$$renderer.push(`<!----></span> `);
		Date_1($$renderer, { time: log.createdAt });
		$$renderer.push(`<!----></button>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
		bind_props($$props, { log });
	});
}
var activityLog = writable({});
function ViewActivityLogModal($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		$$renderer.push(`<div aria-hidden="true" class="modal fade" role="dialog" tabindex="-1"><div class="modal-dialog modal-dialog-centered" role="dialog"><div class="modal-content"><div class="modal-header"><h5 class="modal-title">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.view-activity-log.title"))}</h5> <button type="button" class="btn-close"${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("buttons.close"))}></button></div> <div class="modal-body"><label for="activityLogJson" class="form-label">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.view-activity-log.json"))}</label> <textarea id="activityLogJson" name="activityLogJson" class="form-control" rows="10" readonly="">`);
		const $$body = escape_html(JSON.stringify(store_get($$store_subs ??= {}, "$activityLog", activityLog).details, null, 2));
		if ($$body) $$renderer.push(`${$$body}`);
		$$renderer.push(`</textarea></div></div></div></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
	});
}

export { ActivityLogRow as A, ViewActivityLogModal as V };
//# sourceMappingURL=ViewActivityLogModal.js-BQcvB1fM.js.map
