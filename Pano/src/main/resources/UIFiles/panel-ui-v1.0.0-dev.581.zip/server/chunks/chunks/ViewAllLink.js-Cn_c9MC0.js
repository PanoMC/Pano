import { N as fallback, T as attr, V as attr_class, U as stringify, Q as store_get, W as slot, S as unsubscribe_stores, O as bind_props } from './index-server.js-DdhL7Abu.js';
import { $ as $format } from './runtime.js-BzHEw_ze.js';

//#region src/lib/components/ViewAllLink.svelte
function ViewAllLink($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let href = fallback($$props["href"], "");
		let classes = fallback($$props["classes"], "");
		let targetBlank = fallback($$props["targetBlank"], false);
		$$renderer.push(`<a${attr("href", href || "javascript:void(0)")}${attr("target", targetBlank ? "_blank" : void 0)}${attr("rel", targetBlank ? "noopener noreferrer" : void 0)}${attr_class(`btn-link text-decoration-none focus-ring rounded ${stringify(classes)}`)}${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("buttons.view-all"))}${attr("title", store_get($$store_subs ??= {}, "$_", $format)("buttons.view-all"))}><!--[-->`);
		slot($$renderer, $$props, "default", {}, () => {
			$$renderer.push(`<i class="fa-solid fa-arrow-right"></i>`);
		});
		$$renderer.push(`<!--]--></a>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
		bind_props($$props, {
			href,
			classes,
			targetBlank
		});
	});
}

export { ViewAllLink as V };
//# sourceMappingURL=ViewAllLink.js-Cn_c9MC0.js.map
