import { _ as __exportAll } from './rolldown-runtime.js-BMnQIuNT.js';
import { r as redirect } from './exports2.js-VkmSkXbz.js';
import { b as base } from './internal.js-BRN1McAa.js';
import { Q as store_get, S as unsubscribe_stores, x as setContext, P as ensure_array_like, Z as escape_html } from './index-server.js-DdhL7Abu.js';
import { b as beforeNavigate, p as page } from './stores.js-D5xmrOAP.js';
import './server.js-BlClO2ED.js';
import './internal2.js-CNe5OZUJ.js';
import './routing.js-N-OPb2ye.js';
import { $ as $format } from './runtime.js-BzHEw_ze.js';
import { h as hasPermission, P as Permissions } from './auth.util.js-C77uoaNq.js';
import { t as themeMenuItems } from './SiteNavigationMenu.js-DeoPp7eK.js';
import { P as PageActions } from './PageActions.js-co-RIHDp.js';
import { P as PageNav, a as PageNavItem } from './PageNav.js-Bzzuwwjz.js';

//#region src/lib/layouts/ViewLayout.svelte
var ViewLayout_exports = /* @__PURE__ */ __exportAll({
	default: () => ViewLayout,
	initSlots: () => initSlots,
	load: () => load
});
var key = "layout-slots";
async function load({ parent }) {
	const parentData = await parent();
	const { user } = parentData;
	if (!hasPermission(Permissions.MANAGE_VIEW, user)) throw redirect(302, base);
	return parentData;
}
function initSlots() {
	const slots = {};
	setContext(key, slots);
	return slots;
}
function ViewLayout($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		const { children } = $$props;
		const slots = initSlots();
		beforeNavigate(({ from, to }) => {
			if (from?.route.id !== to?.route.id) Object.assign(slots, {
				right: null,
				left: null
			});
		});
		if (store_get($$store_subs ??= {}, "$page", page).url.pathname === `${base}/view/store`) {
			$$renderer.push("<!--[0-->");
			children($$renderer);
			$$renderer.push(`<!---->`);
		} else {
			$$renderer.push("<!--[-1-->");
			$$renderer.push(`<div class="container vstack gap-3">`);
			PageActions($$renderer, { $$slots: {
				left: ($$renderer) => {
					$$renderer.push(`<div slot="left">`);
					if (slots.left) {
						$$renderer.push("<!--[0-->");
						slots.left($$renderer);
						$$renderer.push(`<!---->`);
					} else {
						$$renderer.push("<!--[-1-->");
						PageNav($$renderer, {
							children: ($$renderer) => {
								$$renderer.push(`<!--[-->`);
								const each_array = ensure_array_like(store_get($$store_subs ??= {}, "$themeMenuItems", themeMenuItems));
								for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
									let item = each_array[$$index];
									if (!item.permission || hasPermission(item.permission)) {
										$$renderer.push("<!--[0-->");
										PageNavItem($$renderer, {
											href: item.href,
											children: ($$renderer) => {
												$$renderer.push(`<!---->${escape_html(store_get($$store_subs ??= {}, "$_", $format)(item.text))}`);
											}});
									} else $$renderer.push("<!--[-1-->");
									$$renderer.push(`<!--]-->`);
								}
								$$renderer.push(`<!--]-->`);
							},
							$$slots: { default: true }
						});
					}
					$$renderer.push(`<!--]--></div>`);
				},
				right: ($$renderer) => {
					$$renderer.push(`<div slot="right" class="hstack gap-2" data-layout-actions="right">`);
					if (slots.right) {
						$$renderer.push("<!--[0-->");
						slots.right($$renderer);
						$$renderer.push(`<!---->`);
					} else $$renderer.push("<!--[-1-->");
					$$renderer.push(`<!--]--></div>`);
				}
			} });
			$$renderer.push(`<!----> `);
			children($$renderer);
			$$renderer.push(`<!----></div>`);
		}
		$$renderer.push(`<!--]-->`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
	});
}

export { ViewLayout_exports as V, ViewLayout as a, load as l };
//# sourceMappingURL=ViewLayout.js-B-QXZLWA.js.map
