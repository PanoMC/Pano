import { J as getContext, Z as escape_html, Q as store_get, T as attr, V as attr_class, U as stringify, P as ensure_array_like, S as unsubscribe_stores, O as bind_props, F as writable, a4 as store_set } from './index-server.js-DdhL7Abu.js';
import { e as buildQueryParams, b as ApiUtil } from './Store.js-DT3aZHRb.js';
import { $ as $format } from './runtime.js-BzHEw_ze.js';
import './ToastContainer.js-Bv1jJ2dr.js';
import './tooltip.util.js-BeLZL-Tj.js';
import { D as DragAndDropZone } from './DragAndDropZone.js-DkRk4oSS.js';
import { E as Editor_1 } from './Editor.js-Cs5tQi--.js';
import { C as ConfirmRestartPanoModal, a as ConfirmSaveCriticalSettingsModal } from './ConfirmSaveCriticalSettingsModal.js-Coj5M9TO.js';

//#region src/lib/register-agreement.util.js
/**
* TipTap may produce an empty document `<p></p>`; for consistency with the API and `isNotBlank`, it counts as an empty string when there is no text.
* @param {unknown} html
* @returns {string}
*/
function normalizeRegisterAgreement(html) {
	if (html == null || typeof html !== "string") return "";
	const trimmed = html.trim();
	if (!trimmed) return "";
	if (typeof document === "undefined") return trimmed.replace(/<[^>]*>/g, " ").replace(/&nbsp;/gi, " ").replace(/\s+/g, " ").trim() ? trimmed : "";
	try {
		return (new DOMParser().parseFromString(trimmed, "text/html").body.textContent || "").replace(/\u00a0/g, " ").trim() ? trimmed : "";
	} catch {
		return trimmed;
	}
}
var draft = writable("");
var agreementOff = writable(false);
function EditRegisterAgreementModal($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let $$settled = true;
		let $$inner_renderer;
		function $$render_inner($$renderer) {
			$$renderer.push(`<div aria-hidden="true" class="modal fade" role="dialog" tabindex="-1"><div class="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable" role="dialog"><div class="modal-content"><div class="modal-header"><h5 class="modal-title">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.site-settings.inputs.register-agreement.label"))}</h5> <button${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("buttons.close"))} type="button" class="btn-close" data-bs-dismiss="modal"></button></div> <div class="modal-body"><div class="form-check"><input class="form-check-input" type="checkbox" id="requireRegisterAgreement"${attr("checked", !store_get($$store_subs ??= {}, "$agreementOff", agreementOff), true)}/> <label class="form-check-label" for="requireRegisterAgreement">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.site-settings.inputs.register-agreement.require-label"))}</label></div> `);
			if (!store_get($$store_subs ??= {}, "$agreementOff", agreementOff)) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<div class="register-agreement-editor-wrap mt-3 svelte-1qamnbv"><!---->`);
				Editor_1($$renderer, {
					showHtml: true,
					showPreview: true,
					contentStyles: "min-height: 240px; height: 360px;",
					get content() {
						return store_get($$store_subs ??= {}, "$draft", draft);
					},
					set content($$value) {
						store_set(draft, $$value);
						$$settled = false;
					}
				});
				$$renderer.push(`<!----></div>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--></div> <div class="modal-footer"><button class="btn btn-secondary w-100" type="button">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.save"))}</button></div></div></div></div>`);
		}
		do {
			$$settled = true;
			$$inner_renderer = $$renderer.copy();
			$$render_inner($$inner_renderer);
		} while (!$$settled);
		$$renderer.subsume($$inner_renderer);
		if ($$store_subs) unsubscribe_stores($$store_subs);
	});
}
//#endregion
//#region src/lib/pages/settings/WebsiteSettings.svelte
async function load(event) {
	const { parent } = event;
	await parent();
	const queryParams = buildQueryParams({ type: "WEBSITE" });
	const body = await ApiUtil.get({
		path: "/api/panel/settings" + queryParams,
		request: event
	});
	body.oldSettings = { ...body };
	body.oldSettings.keywords = [...body.keywords];
	return body;
}
function WebsiteSettings($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let domainFromUrl, isDomainValidForLE, isPortValidForLE, isHttpsPortValidForLE, isCurrentDomainMatched, isLetsEncryptInvalid, isManualInvalid, isSaveButtonDisabled, portFromUrl, isHostMismatch, hasExplicitPort, isPortMismatch;
		let data = $$props["data"];
		const pageTitle = getContext("pageTitle");
		getContext("website");
		pageTitle.set("pages.settings.site-settings.title");
		let selectedFaviconFiles = [];
		let selectedWebsiteLogoFiles = [];
		let keyword;
		let keywordInputError = false;
		let favicon = "/api/favicon?_=" + Date.now();
		let websiteLogo = "/api/websiteLogo?_=" + Date.now();
		Array.prototype.equals = function(array) {
			if (!array) return false;
			if (this.length != array.length) return false;
			for (let i = 0, l = this.length; i < l; i++) if (this[i] instanceof Array && array[i] instanceof Array) {
				if (!this[i].equals(array[i])) return false;
			} else if (this[i] != array[i]) return false;
			return true;
		};
		Object.defineProperty(Array.prototype, "equals", { enumerable: false });
		domainFromUrl = (() => {
			try {
				if (!data.websiteUrl) return "";
				const url = data.websiteUrl.startsWith("http") ? data.websiteUrl : "http://" + data.websiteUrl;
				return new URL(url).hostname;
			} catch (e) {
				return data.websiteUrl.replace("http://", "").replace("https://", "").split("/")[0].split(":")[0];
			}
		})();
		isDomainValidForLE = domainFromUrl && domainFromUrl !== "localhost" && domainFromUrl !== "127.0.0.1" && domainFromUrl.includes(".");
		isPortValidForLE = data.httpPort === 80;
		isHttpsPortValidForLE = data.httpsPort === 443;
		isCurrentDomainMatched = typeof window !== "undefined" && domainFromUrl === window.location.hostname;
		isLetsEncryptInvalid = data.sslMode === "LETS_ENCRYPT" && (!isDomainValidForLE || !isPortValidForLE || !isHttpsPortValidForLE || !isCurrentDomainMatched);
		isManualInvalid = data.sslMode === "MANUAL" && (!data.sslCert || !data.sslKey);
		isSaveButtonDisabled = data.oldSettings.websiteName === data.websiteName && data.oldSettings.websiteDescription === data.websiteDescription && data.oldSettings.websiteUrl === data.websiteUrl && normalizeRegisterAgreement(data.oldSettings.registerAgreement) === normalizeRegisterAgreement(data.registerAgreement) && data.oldSettings.supportEmail === data.supportEmail && data.oldSettings.serverIpAddress === data.serverIpAddress && data.oldSettings.serverGameVersion === data.serverGameVersion && JSON.stringify(data.oldSettings.keywords) === JSON.stringify(data.keywords) && data.oldSettings.httpPort === data.httpPort && data.oldSettings.httpsPort === data.httpsPort && data.oldSettings.sslMode === data.sslMode && data.oldSettings.sslCert === data.sslCert && data.oldSettings.sslKey === data.sslKey && data.oldSettings.redirectHttps === data.redirectHttps && selectedFaviconFiles.length === 0 && selectedWebsiteLogoFiles.length === 0 || isLetsEncryptInvalid || isManualInvalid;
		portFromUrl = (() => {
			try {
				if (!data.websiteUrl) return "";
				const url = data.websiteUrl.includes("://") ? data.websiteUrl : "https://" + data.websiteUrl;
				return new URL(url).port;
			} catch (e) {
				return "";
			}
		})();
		isHostMismatch = typeof window !== "undefined" && !!data.websiteUrl && !!domainFromUrl && domainFromUrl.toLowerCase() !== window.location.hostname.toLowerCase();
		hasExplicitPort = portFromUrl !== "";
		isPortMismatch = typeof window !== "undefined" && hasExplicitPort && portFromUrl !== window.location.port;
		$$renderer.push(`<div class="card"><div class="card-header">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.site-settings.preferences"))}</div> <div class="card-body">`);
		$$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--> <div class="row mb-3"><label class="col-md-6 col-form-label" for="siteTitle">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.site-settings.inputs.website-name.label"))}</label> <div class="col-md-6"><input${attr("value", data.websiteName)} aria-describedby="siteTitle" class="form-control"${attr("placeholder", store_get($$store_subs ??= {}, "$_", $format)("pages.settings.site-settings.inputs.website-name.placeholder"))} id="siteTitle" type="text"/></div></div> <div class="row mb-3"><label class="col-md-6 col-form-label" for="siteDesc">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.site-settings.inputs.website-description.label"))}</label> <div class="col-md-6"><textarea aria-describedby="siteDesc" class="form-control" id="siteDesc" rows="2">`);
		const $$body = escape_html(data.websiteDescription);
		if ($$body) $$renderer.push(`${$$body}`);
		$$renderer.push(`</textarea></div></div> <div class="row mb-3"><label class="col-md-6 col-form-label" for="websiteUrl"><span class="d-inline-block position-relative">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.site-settings.inputs.website-url.label"))} <i class="fas fa-circle-info label-restart-info text-secondary svelte-j38pr4"></i></span></label> <div class="col-md-6"><input${attr("value", data.websiteUrl)} aria-describedby="websiteUrl"${attr_class("form-control", void 0, { "is-invalid": data.sslMode === "LETS_ENCRYPT" && !isDomainValidForLE })}${attr("placeholder", store_get($$store_subs ??= {}, "$_", $format)("pages.settings.site-settings.inputs.website-url.placeholder"))} id="websiteUrl" type="text"/> `);
		if (isHostMismatch) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<div class="alert alert-warning d-flex align-items-start mt-2 mb-0"><i class="fas fa-triangle-exclamation me-2 mt-1"></i> <div>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.site-settings.inputs.website-url.host-mismatch"))}</div></div>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--> `);
		if (isPortMismatch) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<div class="alert alert-warning d-flex align-items-start mt-2 mb-0"><i class="fas fa-triangle-exclamation me-2 mt-1"></i> <div>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.site-settings.inputs.website-url.port-mismatch", { values: {
				port: portFromUrl,
				current: window.location.port || "80/443"
			} }))}</div></div>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--> `);
		if (hasExplicitPort) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<div class="alert alert-warning d-flex align-items-start mt-2 mb-0"><i class="fas fa-triangle-exclamation me-2 mt-1"></i> <div>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.site-settings.inputs.website-url.explicit-port", { values: { port: portFromUrl } }))}</div></div>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--></div></div> <div class="row mb-3"><label class="col-md-6 col-form-label" for="registerAgreementEditBtn">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.site-settings.inputs.register-agreement.label"))}</label> <div class="col-md-6 d-flex align-items-center">`);
		if (normalizeRegisterAgreement(data.registerAgreement)) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<button type="button" id="registerAgreementEditBtn" class="btn btn-link p-0 text-decoration-none"><i class="fas fa-pencil me-1"></i> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.edit"))}</button>`);
		} else {
			$$renderer.push("<!--[-1-->");
			$$renderer.push(`<button type="button" id="registerAgreementEditBtn" class="btn btn-link p-0 text-decoration-none text-body-secondary"><i class="fas fa-pencil me-1"></i> Belirlenmedi</button>`);
		}
		$$renderer.push(`<!--]--></div></div> <div class="row mb-3"><label class="col-md-6 col-form-label" for="ipAddress">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.site-settings.inputs.game-server-ip-address.label"))}</label> <div class="col-md-6"><input id="ipAddress" class="form-control" placeholder="play.server.com" type="text" name="ipAddress"${attr("value", data.serverIpAddress)}/></div></div> <div class="row mb-3"><label class="col-md-6 col-form-label" for="serverGameVersion">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.site-settings.inputs.game-server-version.label"))}</label> <div class="col-md-6"><input id="serverGameVersion" class="form-control" placeholder="1.8.x" type="text" name="serverGameVersion"${attr("value", data.serverGameVersion)}/></div></div> <div class="row mb-3"><label class="col-md-6 col-form-label" for="supportEmailAddress">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.site-settings.inputs.support-email-address.label"))}</label> <div class="col-md-6"><input id="supportEmailAddress" class="form-control"${attr("placeholder", `support@${stringify(data.websiteName)}.com`)} type="email" name="supportEmailAddress"${attr("value", data.supportEmail)}/></div></div> <div class="row mb-3"><label class="col-md-6 col-form-label" for="siteKeywords">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.site-settings.inputs.keywords.label"))}</label> <div class="col-md-6"><form><input id="siteKeywords"${attr_class("form-control mb-2", void 0, { "border-danger": keywordInputError })}${attr("placeholder", store_get($$store_subs ??= {}, "$_", $format)("pages.settings.site-settings.inputs.keywords.placeholder"))} type="text" name="keyword"${attr("value", keyword)}/></form> <div class="mb-3"><!--[-->`);
		const each_array = ensure_array_like(data.keywords);
		for (let index = 0, $$length = each_array.length; index < $$length; index++) {
			let keyword = each_array[index];
			$$renderer.push(`<button type="button" class="btn btn-link btn-sm"${attr("title", store_get($$store_subs ??= {}, "$_", $format)("buttons.remove"))}>${escape_html(keyword)}</button>`);
		}
		$$renderer.push(`<!--]--></div></div></div> <div class="row mb-3"><label class="col-md-6 col-form-label" for="siteFavicon">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.site-settings.inputs.favicon.label"))}</label> <div class="col-md-6"><div class="position-relative d-inline-block" style="width: 64px; height: 64px;">`);
		DragAndDropZone($$renderer, {
			class: "p-0",
			accept: [
				"image/png",
				"image/jpeg",
				"image/gif",
				"image/x-icon",
				"image/vnd.microsoft.icon"
			],
			maxFileSize: 1048576,
			children: ($$renderer) => {
				$$renderer.push(`<img${attr("alt", store_get($$store_subs ??= {}, "$_", $format)("pages.settings.site-settings.inputs.favicon.select"))}${attr("src", favicon)} class="w-100 h-100" style="object-fit: contain;"/>`);
			},
			$$slots: { default: true }
		});
		$$renderer.push(`<!----> <button type="button" class="btn btn-sm btn-secondary position-absolute top-0 start-100 translate-middle"${attr("title", store_get($$store_subs ??= {}, "$_", $format)("buttons.change"))}${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("buttons.change"))}><i class="fas fa-pen"></i></button></div> <small class="d-block mt-2">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.site-settings.inputs.favicon.helper"))}</small></div></div> <div class="row mb-3"><label class="col-md-6 col-form-label" for="siteLogo">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.site-settings.inputs.website-logo.label"))}</label> <div class="col-md-6"><div class="position-relative w-100" style="max-width: 300px;"><div class="ratio ratio-16x9">`);
		DragAndDropZone($$renderer, {
			class: "p-0 position-absolute start-0 top-0",
			accept: [
				"image/png",
				"image/jpeg",
				"image/gif"
			],
			maxFileSize: 2097152,
			children: ($$renderer) => {
				$$renderer.push(`<img${attr("src", websiteLogo)} class="object-fit-contain w-100 h-100"${attr("alt", store_get($$store_subs ??= {}, "$_", $format)("pages.settings.site-settings.inputs.website-logo.server-icon"))}/>`);
			},
			$$slots: { default: true }
		});
		$$renderer.push(`<!----></div> <button type="button" class="btn btn-sm btn-secondary position-absolute top-0 start-100 translate-middle"${attr("title", store_get($$store_subs ??= {}, "$_", $format)("buttons.change"))}${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("buttons.change"))}><i class="fas fa-pencil"></i></button></div> <small class="d-block mt-2">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.site-settings.inputs.website-logo.helper"))}</small></div></div> <hr/> <h5 class="mb-3">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.site-settings.ssl.title"))}</h5> <div class="row mb-3"><label class="col-md-6 col-form-label" for="httpPort"><span class="d-inline-block position-relative">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.site-settings.inputs.http-port.label"))} <i class="fas fa-circle-info label-restart-info text-secondary svelte-j38pr4"></i></span></label> <div class="col-md-6"><input id="httpPort"${attr_class("form-control", void 0, { "is-invalid": data.sslMode === "LETS_ENCRYPT" && !isPortValidForLE })} type="number"${attr("value", data.httpPort)}/></div></div> <div class="row mb-3"><label class="col-md-6 col-form-label" for="httpsPort"><span class="d-inline-block position-relative">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.site-settings.inputs.https-port.label"))} <i class="fas fa-circle-info label-restart-info text-secondary svelte-j38pr4"></i></span></label> <div class="col-md-6"><input id="httpsPort"${attr_class("form-control", void 0, { "is-invalid": data.sslMode === "LETS_ENCRYPT" && !isHttpsPortValidForLE })} type="number"${attr("disabled", data.sslMode === "DISABLED", true)}${attr("value", data.httpsPort)}/></div></div> <div class="row mb-3"><label class="col-md-6 col-form-label" for="redirectHttps">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.site-settings.inputs.redirect-https.label"))}</label> <div class="col-md-6 d-flex align-items-center"><div class="form-check form-switch"><input class="form-check-input" type="checkbox" id="redirectHttps"${attr("disabled", data.sslMode === "DISABLED", true)}${attr("checked", data.redirectHttps, true)}/></div></div></div> <div class="row mb-3"><label class="col-md-6 col-form-label" for="sslMode"><span class="d-inline-block position-relative">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.site-settings.inputs.ssl-mode.label"))} <i class="fas fa-circle-info label-restart-info text-secondary svelte-j38pr4"></i></span></label> <div class="col-md-6">`);
		$$renderer.select({
			id: "sslMode",
			class: "form-select",
			value: data.sslMode
		}, ($$renderer) => {
			$$renderer.option({ value: "DISABLED" }, ($$renderer) => {
				$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.site-settings.ssl.modes.disabled"))}`);
			});
			$$renderer.option({ value: "LETS_ENCRYPT" }, ($$renderer) => {
				$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.site-settings.ssl.modes.lets-encrypt"))}`);
			});
			$$renderer.option({ value: "MANUAL" }, ($$renderer) => {
				$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.site-settings.ssl.modes.manual"))}`);
			});
		});
		$$renderer.push(` `);
		if (isLetsEncryptInvalid) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<div class="alert alert-danger mt-2 mb-0"><i class="fas fa-circle-exclamation me-2"></i> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.site-settings.ssl.lets-encrypt-invalid-config"))}</div>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--></div></div> `);
		if (data.sslMode === "MANUAL") {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<div class="row mb-3"><label class="col-md-6 col-form-label" for="sslCert"><span class="d-inline-block position-relative">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.site-settings.inputs.ssl-cert.label"))} <i class="fas fa-circle-info label-restart-info text-secondary svelte-j38pr4"></i></span></label> <div class="col-md-6"><div class="position-relative"><textarea${attr("disabled", data.sslCert === "****************", true)}${attr_class("form-control font-monospace", void 0, { "is-invalid": data.sslMode === "MANUAL" && !data.sslCert })} id="sslCert" rows="5" placeholder="-----BEGIN CERTIFICATE-----">`);
			const $$body_1 = escape_html(data.sslCert);
			if ($$body_1) $$renderer.push(`${$$body_1}`);
			$$renderer.push(`</textarea> `);
			if (data.sslCert === "****************") {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<button class="btn btn-sm btn-secondary position-absolute top-50 start-50 translate-middle"><i class="fas fa-eye me-1"></i> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.reveal"))}</button>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--></div></div></div> <div class="row mb-3"><label class="col-md-6 col-form-label" for="sslKey"><span class="d-inline-block position-relative">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.site-settings.inputs.ssl-key.label"))} <i class="fas fa-circle-info label-restart-info text-secondary svelte-j38pr4"></i></span></label> <div class="col-md-6"><div class="position-relative"><textarea${attr("disabled", data.sslKey === "****************", true)}${attr_class("form-control font-monospace", void 0, { "is-invalid": data.sslMode === "MANUAL" && !data.sslKey })} id="sslKey" rows="5" placeholder="-----BEGIN PRIVATE KEY-----">`);
			const $$body_2 = escape_html(data.sslKey);
			if ($$body_2) $$renderer.push(`${$$body_2}`);
			$$renderer.push(`</textarea> `);
			if (data.sslKey === "****************") {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<button class="btn btn-sm btn-secondary position-absolute top-50 start-50 translate-middle"><i class="fas fa-eye me-1"></i> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.reveal"))}</button>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--></div></div></div>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--> <button${attr_class("btn btn-secondary", void 0, { "disabled": isSaveButtonDisabled })}${attr("aria-disabled", isSaveButtonDisabled)}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.save"))}</button></div></div> `);
		ConfirmRestartPanoModal($$renderer, { runMode: data.runMode });
		$$renderer.push(`<!----> `);
		ConfirmSaveCriticalSettingsModal($$renderer);
		$$renderer.push(`<!----> `);
		EditRegisterAgreementModal($$renderer);
		$$renderer.push(`<!---->`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
		bind_props($$props, { data });
	});
}

export { WebsiteSettings as W, load as l };
//# sourceMappingURL=WebsiteSettings.js-B14c2Skl.js.map
