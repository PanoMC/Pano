import { b as base } from './internal.js-BRN1McAa.js';
import { Y as get, F as writable, T as attr, U as stringify, Z as escape_html, Q as store_get, S as unsubscribe_stores } from './index-server.js-DdhL7Abu.js';
import './server.js-BlClO2ED.js';
import './internal2.js-CNe5OZUJ.js';
import './routing.js-N-OPb2ye.js';
import 'node:module';
import './stores.js-D5xmrOAP.js';
import './ToastContainer.js-Bv1jJ2dr.js';
import { $ as $format } from './runtime.js-BzHEw_ze.js';

//#region src/lib/components/modals/WhatsNewModal.svelte
var dontShowAgain = writable(false);
var modalElement = writable();
var modal;
var showDonotShowAgain = writable(true);
async function show(requestedShowDonotShowAgain = true) {
	showDonotShowAgain.set(requestedShowDonotShowAgain);
	dontShowAgain.set(false);
	if (!modal) modal = new window.bootstrap.Modal(get(modalElement), {
		backdrop: true,
		keyboard: true
	});
	modal.show();
}
function WhatsNewModal($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		$$renderer.push(`<div aria-hidden="true" class="modal fade" role="dialog" tabindex="-1"><div class="modal-dialog modal-lg modal-dialog-centered" role="dialog"><div class="modal-content overflow-hidden"><div class="modal-header text-bg-primary d-block text-center border-bottom-0 py-5 position-relative blocks svelte-c6nf4r"><button type="button" class="btn-close btn-close-white position-absolute top-0 end-0 m-3" aria-label="Close"></button> <img${attr("src", `${stringify(base)}/assets/img/pano-logo-heorizontal.png`)} alt="Pano" class="my-3" style="height: 3rem;"/> <p class="lead mb-0 px-lg-5">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.whats-new.description"))}</p></div> <div class="modal-body px-lg-5 py-5"><div class="row g-4 mb-4 text-start"><div class="col-md-6"><div class="d-flex align-items-start"><div class="feature-icon-small bg-primary bg-gradient text-white rounded-3 p-2 me-3 svelte-c6nf4r"><i class="fas fa-file-alt"></i></div> <div><h5 class="fw-bold mb-1">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.whats-new.features.cms"))}</h5> <p class="mb-0">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.whats-new.features.cms-description"))}</p></div></div></div> <div class="col-md-6"><div class="d-flex align-items-start"><div class="feature-icon-small bg-primary bg-gradient text-white rounded-3 p-2 me-3 svelte-c6nf4r"><i class="fas fa-server"></i></div> <div><h5 class="fw-bold mb-1">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.whats-new.features.management"))}</h5> <p class="mb-0">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.whats-new.features.management-description"))}</p></div></div></div> <div class="col-md-6"><div class="d-flex align-items-start"><div class="feature-icon-small bg-primary bg-gradient text-white rounded-3 p-2 me-3 svelte-c6nf4r"><i class="fas fa-gamepad"></i></div> <div><h5 class="fw-bold mb-1">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.whats-new.features.integration"))}</h5> <p class="mb-0">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.whats-new.features.integration-description"))}</p></div></div></div> <div class="col-md-6"><div class="d-flex align-items-start"><div class="feature-icon-small bg-primary bg-gradient text-white rounded-3 p-2 me-3 svelte-c6nf4r"><i class="fas fa-shield-alt"></i></div> <div><h5 class="fw-bold mb-1">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.whats-new.features.e2ee"))}</h5> <p class="mb-0">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.whats-new.features.e2ee-description"))}</p></div></div></div></div></div> `);
		if (store_get($$store_subs ??= {}, "$showDonotShowAgain", showDonotShowAgain)) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<div class="modal-footer d-flex justify-content-center align-items-center"><div class="form-check form-switch mb-0"><input class="form-check-input" type="checkbox" id="dontShowAgain" autocomplete="off"${attr("checked", store_get($$store_subs ??= {}, "$dontShowAgain", dontShowAgain), true)}/> <label class="form-check-label small" for="dontShowAgain">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.whats-new.dont-show-again"))}</label></div></div>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--></div></div></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
	});
}

export { WhatsNewModal as W, show as s };
//# sourceMappingURL=WhatsNewModal.js-DYlgNmt1.js.map
