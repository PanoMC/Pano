import { e as error } from './exports2.js-VkmSkXbz.js';
import { b as base } from './internal.js-BRN1McAa.js';
import { a7 as getAllContexts, $ as attr_style, W as slot } from './index-server.js-DdhL7Abu.js';
import './server.js-BlClO2ED.js';
import './internal2.js-CNe5OZUJ.js';
import './routing.js-N-OPb2ye.js';
import { M as MainLayout_exports, A as AppLayout_exports } from './AppLayout.js-DQpVQODo.js';
import { h as hasPermission } from './auth.util.js-C77uoaNq.js';
import { g as findMatch, r as registeredPages } from './SiteNavigationMenu.js-DeoPp7eK.js';
import { A as AddonsLayout_exports } from './AddonsLayout.js-D51u-QW6.js';
import { A as AddonDetailLayout_exports } from './AddonDetailLayout.js-Dsuoa7y-.js';
import { M as MigrationLayout_exports } from './MigrationLayout.js-BQMl41SU.js';
import { P as PermissionsLayout_exports } from './PermissionsLayout.js-C2reeQRx.js';
import { P as PlayersLayout_exports } from './PlayersLayout.js-DaYRyCVT.js';
import { P as PlayerDetailLayout_exports } from './PlayerDetailLayout.js-DxKEQet7.js';
import { P as PostsLayout_exports } from './PostsLayout.js-BRwPIU94.js';
import { S as ServerLayout_exports } from './ServerLayout.js-CrkamJnH.js';
import { S as ServerSettingsLayout_exports } from './ServerSettingsLayout.js-DUjy1RdU.js';
import { S as SettingsLayout_exports } from './SettingsLayout.js-DDNsZN_1.js';
import { T as TicketsLayout_exports } from './TicketsLayout.js-Pw8WCacP.js';
import { T as TranslationsLayout_exports } from './TranslationsLayout.js-CsaU5nVM.js';
import { V as ViewLayout_exports } from './ViewLayout.js-B-QXZLWA.js';

//#region src/routes/(plugin-ui)/[...path]/+layout.svelte
var layouts = /* #__PURE__ */ Object.assign({
	"/src/lib/layouts/AddonDetailLayout.svelte": AddonDetailLayout_exports,
	"/src/lib/layouts/AddonsLayout.svelte": AddonsLayout_exports,
	"/src/lib/layouts/AppLayout.svelte": AppLayout_exports,
	"/src/lib/layouts/MainLayout.svelte": MainLayout_exports,
	"/src/lib/layouts/MigrationLayout.svelte": MigrationLayout_exports,
	"/src/lib/layouts/PermissionsLayout.svelte": PermissionsLayout_exports,
	"/src/lib/layouts/PlayerDetailLayout.svelte": PlayerDetailLayout_exports,
	"/src/lib/layouts/PlayersLayout.svelte": PlayersLayout_exports,
	"/src/lib/layouts/PostsLayout.svelte": PostsLayout_exports,
	"/src/lib/layouts/ServerLayout.svelte": ServerLayout_exports,
	"/src/lib/layouts/ServerSettingsLayout.svelte": ServerSettingsLayout_exports,
	"/src/lib/layouts/SettingsLayout.svelte": SettingsLayout_exports,
	"/src/lib/layouts/TicketsLayout.svelte": TicketsLayout_exports,
	"/src/lib/layouts/TranslationsLayout.svelte": TranslationsLayout_exports,
	"/src/lib/layouts/ViewLayout.svelte": ViewLayout_exports
});
var layoutMap = Object.keys(layouts).reduce((acc, path) => {
	const name = path.split("/").pop().replace(".svelte", "");
	acc[name] = layouts[path];
	return acc;
}, {});
function removePrefix(str, prefix) {
	return str.startsWith(prefix) ? str.slice(prefix.length) : str;
}
/**
* @type {import('@sveltejs/kit').PageLoad}
*/
async function load(event) {
	const { url: { pathname }, parent } = event;
	const { resetLayout, user } = await parent();
	const registeredPage = findMatch(registeredPages, removePrefix(pathname, base));
	if (!registeredPage) throw error(404);
	if (registeredPage.permission && !hasPermission(registeredPage.permission, user)) throw error(404);
	resetLayout.set(registeredPage.resetLayout || false);
	let systemLayout = null;
	let systemLayoutOutput = {};
	if (registeredPage.systemLayout) {
		const module = layoutMap[registeredPage.systemLayout];
		if (module) {
			systemLayout = module.default;
			if (typeof module.load === "function") systemLayoutOutput = await module.load(event);
		}
	}
	let layout = null;
	let layoutOutput = {};
	if (registeredPage.layout) {
		layout = typeof registeredPage.layout === "function" ? await registeredPage.layout() : registeredPage.layout;
		if (layout.load) layoutOutput = await layout.load(event);
	}
	return {
		registeredPage,
		layout,
		systemLayout,
		props: layoutOutput,
		params: registeredPage.params,
		...systemLayoutOutput
	};
}
function _layout($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		let { data } = $$props;
		getAllContexts();
		if (data.systemLayout) {
			$$renderer.push("<!--[0-->");
			if (data.systemLayout) {
				$$renderer.push("<!--[-->");
				data.systemLayout($$renderer, {
					data,
					children: ($$renderer) => {
						$$renderer.push(`<div class="plugin-layout-container svelte-1t52p2b"${attr_style(data.layout ? "" : "display: none;")}></div> <div class="plugin-content-wrapper"${attr_style(data.layout ? "display: none;" : "")}><!---->`);
						$$renderer.push(`<!--[-->`);
						slot($$renderer, $$props, "default", {}, null);
						$$renderer.push(`<!--]-->`);
						$$renderer.push(`<!----></div>`);
					},
					$$slots: { default: true }
				});
				$$renderer.push("<!--]-->");
			} else {
				$$renderer.push("<!--[!-->");
				$$renderer.push("<!--]-->");
			}
		} else {
			$$renderer.push("<!--[-1-->");
			$$renderer.push(`<div class="plugin-layout-container svelte-1t52p2b"${attr_style(data.layout ? "" : "display: none;")}></div> <div class="plugin-content-wrapper"${attr_style(data.layout ? "display: none;" : "")}><!---->`);
			$$renderer.push(`<!--[-->`);
			slot($$renderer, $$props, "default", {}, null);
			$$renderer.push(`<!--]-->`);
			$$renderer.push(`<!----></div>`);
		}
		$$renderer.push(`<!--]-->`);
	});
}

export { _layout as _, load as l };
//# sourceMappingURL=_layout.js-taxmsIXc.js.map
