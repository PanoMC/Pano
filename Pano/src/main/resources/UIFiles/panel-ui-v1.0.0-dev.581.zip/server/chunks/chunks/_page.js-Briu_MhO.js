import { a7 as getAllContexts, R as spread_props, O as bind_props } from './index-server.js-DdhL7Abu.js';

//#region src/routes/(plugin-ui)/[...path]/+page.svelte
async function load(event) {
	const { parent } = event;
	const { registeredPage } = await parent();
	let componentOutput = {};
	const component = await registeredPage.component();
	if (registeredPage.params) event.params = {
		...event.params,
		...registeredPage.params
	};
	if (component.load !== void 0) componentOutput = await component.load(event);
	return {
		registeredPage,
		component,
		props: componentOutput
	};
}
function _page($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		let data = $$props["data"];
		getAllContexts();
		$$renderer.push("<!--[0-->");
		if (data.component.default) {
			$$renderer.push("<!--[-->");
			data.component.default($$renderer, spread_props([data.props || {}]));
			$$renderer.push("<!--]-->");
		} else {
			$$renderer.push("<!--[!-->");
			$$renderer.push("<!--]-->");
		}
		$$renderer.push(`<!--]-->`);
		bind_props($$props, { data });
	});
}

export { _page as _, load as l };
//# sourceMappingURL=_page.js-Briu_MhO.js.map
