import 'node:module';
import { Z as escape_html, Q as store_get, T as attr, S as unsubscribe_stores, F as writable } from './index-server.js-DdhL7Abu.js';
import { $ as $format } from './runtime.js-BzHEw_ze.js';
import { r as require_copy_to_clipboard } from './copy-to-clipboard.js-Doa_mbw4.js';

require_copy_to_clipboard();
var errorContent = writable("");
function AddonStartupErrorModal($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		$$renderer.push(`<div aria-hidden="true" class="modal fade" role="dialog" tabindex="-1"><div class="modal-dialog modal-dialog-centered modal-lg" role="dialog"><div class="modal-content border-0 shadow-lg"><div class="modal-header bg-dark text-white border-bottom-0 rounded-top"><h5 class="modal-title font-monospace small"><i class="fa-solid fa-terminal me-2 text-primary"></i> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.error-log"))}</h5> <button type="button" class="btn-close btn-close-white"${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("buttons.close"))}></button></div> <div class="modal-body bg-dark text-white p-0 overflow-hidden"><div class="bg-black p-3 font-monospace overflow-auto custom-scrollbar svelte-614rxf" style="max-height: 500px; white-space: pre-wrap; font-size: 0.875rem; color: #dcdccc; border: 1px solid #333;">${escape_html(store_get($$store_subs ??= {}, "$errorContent", errorContent))}</div></div> <div class="modal-footer bg-dark border-top-0 rounded-bottom justify-content-between p-2"><div class="hstack gap-2"><button type="button" class="btn btn-sm btn-outline-primary">`);
		$$renderer.push("<!--[-1-->");
		$$renderer.push(`<i class="fa-solid fa-copy me-1"></i> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.copy"))}`);
		$$renderer.push(`<!--]--></button></div> <button type="button" class="btn btn-sm btn-secondary">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.close"))}</button></div></div></div></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
	});
}
//#endregion
//#region src/lib/addon-license-issue.util.js
/**
* Premium addon license outcomes exposed as `licenseStatus` by the panel API.
* Keep in sync with `com.panomc.platform.license.LicenseStatus` (excluding NOT_PREMIUM / LICENSED).
*/
var ADDON_LICENSE_ISSUE_STATUSES = /* @__PURE__ */ new Set([
	"MISSING",
	"NO_PURCHASE",
	"EXPIRED",
	"NETWORK_ERROR",
	"NOT_CONNECTED",
	"NEEDS_REFRESH",
	"JAR_TAMPERED",
	"SIGNATURE_INVALID",
	"VERSION_MISMATCH",
	"AUDIENCE_MISMATCH",
	"PLATFORM_MISMATCH",
	"UNKNOWN"
]);
/**
* True when FAILED state is due to DRM / license gate — not a generic plugin crash.
* Prefer host-provided `startupBlockedByLicense` (derived from LicenseRequiredException chain).
*/
function isAddonLicenseStartupBlocked(addon) {
	if (!addon) return false;
	if (addon.startupBlockedByLicense === true) return true;
	if (!addon.premium) return false;
	return ADDON_LICENSE_ISSUE_STATUSES.has(addon.licenseStatus);
}
/**
* Do not hard-block most premium enable attempts in UI.
*
* License state can be stale (e.g. purchase/account link happened after startup), and backend
* start flow should be the source of truth. We only block when host is clearly disconnected.
*/
function isPremiumAddonEnableBlockedByLicense(addon) {
	if (!addon?.premium) return false;
	return addon.licenseStatus === "NOT_CONNECTED";
}

export { AddonStartupErrorModal as A, isPremiumAddonEnableBlockedByLicense as a, ADDON_LICENSE_ISSUE_STATUSES as b, isAddonLicenseStartupBlocked as i };
//# sourceMappingURL=addon-license-issue.util.js-C_l-lxBM.js.map
