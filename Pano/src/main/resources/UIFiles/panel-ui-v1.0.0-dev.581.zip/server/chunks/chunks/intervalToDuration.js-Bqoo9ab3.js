import { n as normalizeDates } from './en-US.js-Qz-txlMm.js';
import { t as toDate, c as constructFrom } from './toDate.js-DvNQTMH_.js';
import { d as differenceInYears, a as differenceInDays, b as differenceInHours, c as differenceInMinutes, e as addMonths, f as addDays } from './differenceInYears.js-BVSYOnW_.js';
import { d as differenceInMonths } from './differenceInMonths.js-dJH89BLU.js';
import { d as differenceInSeconds } from './differenceInSeconds.js-DEJPF-lp.js';

//#region node_modules/date-fns/add.js
/**
* The {@link add} function options.
*/
/**
* @name add
* @category Common Helpers
* @summary Add the specified years, months, weeks, days, hours, minutes, and seconds to the given date.
*
* @description
* Add the specified years, months, weeks, days, hours, minutes, and seconds to the given date.
*
* **You don't need date-fns\***:
*
* Temporal has a built-in `add` method on all its classes:
*
* - [`Temporal.Instant.prototype.add()`](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Temporal/Instant/add)
* - [`Temporal.PlainDate.prototype.add()`](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Temporal/PlainDate/add)
* - [`Temporal.PlainDateTime.prototype.add()`](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Temporal/PlainDateTime/add)
* - [`Temporal.PlainTime.prototype.add()`](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Temporal/PlainTime/add)
* - [`Temporal.PlainYearMonth.prototype.add()`](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Temporal/PlainYearMonth/add)
* - [`Temporal.ZonedDateTime.prototype.add()`](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Temporal/ZonedDateTime/add)
*
* \* **Not really**, see: https://date-fns.org/you-dont-need-date-fns
*
* @typeParam DateType - The `Date` type the function operates on. Gets inferred from passed arguments. Allows using extensions like [`UTCDate`](https://github.com/date-fns/utc).
* @typeParam ResultDate - The result `Date` type, it is the type returned from the context function if it is passed, or inferred from the arguments.
*
* @param date - The date to be changed
* @param duration - The object with years, months, weeks, days, hours, minutes, and seconds to be added.
* @param options - An object with options
*
* @returns The new date with the seconds added
*
* @example
* // Add the following duration to 1 September 2014, 10:19:50
* const result = add(new Date(2014, 8, 1, 10, 19, 50), {
*   years: 2,
*   months: 9,
*   weeks: 1,
*   days: 7,
*   hours: 5,
*   minutes: 9,
*   seconds: 30,
* })
* //=> Thu Jun 15 2017 15:29:20
*
* @example
* // Using Temporal:
* // Add the following duration to 1 September 2014, 10:19:50
* Temporal.PlainDateTime.from("2014-09-01T10:19:50")
*   .add({
*     years: 2,
*     months: 9,
*     weeks: 1,
*     days: 7,
*     hours: 5,
*     minutes: 9,
*     seconds: 30,
*   })
*   .toString();
* //=> "2017-06-15T15:29:20"
*/
function add(date, duration, options) {
	const { years = 0, months = 0, weeks = 0, days = 0, hours = 0, minutes = 0, seconds = 0 } = duration;
	const _date = toDate(date, options?.in);
	const dateWithMonths = months || years ? addMonths(_date, months + years * 12) : _date;
	const dateWithDays = days || weeks ? addDays(dateWithMonths, days + weeks * 7) : dateWithMonths;
	const msToAdd = (seconds + (minutes + hours * 60) * 60) * 1e3;
	return constructFrom(date, +dateWithDays + msToAdd);
}
//#endregion
//#region node_modules/date-fns/_lib/normalizeInterval.js
function normalizeInterval(context, interval) {
	const [start, end] = normalizeDates(context, interval.start, interval.end);
	return {
		start,
		end
	};
}
//#endregion
//#region node_modules/date-fns/intervalToDuration.js
/**
* The {@link intervalToDuration} function options.
*/
/**
* @name intervalToDuration
* @category Common Helpers
* @summary Convert interval to duration
*
* @description
* Convert an interval object to a duration object.
*
* @param interval - The interval to convert to duration
* @param options - The context options
*
* @returns The duration object
*
* @example
* // Get the duration between January 15, 1929 and April 4, 1968.
* intervalToDuration({
*   start: new Date(1929, 0, 15, 12, 0, 0),
*   end: new Date(1968, 3, 4, 19, 5, 0)
* });
* //=> { years: 39, months: 2, days: 20, hours: 7, minutes: 5, seconds: 0 }
*/
function intervalToDuration(interval, options) {
	const { start, end } = normalizeInterval(options?.in, interval);
	const duration = {};
	const years = differenceInYears(end, start);
	if (years) duration.years = years;
	const remainingMonths = add(start, { years: duration.years });
	const months = differenceInMonths(end, remainingMonths);
	if (months) duration.months = months;
	const remainingDays = add(remainingMonths, { months: duration.months });
	const days = differenceInDays(end, remainingDays);
	if (days) duration.days = days;
	const remainingHours = add(remainingDays, { days: duration.days });
	const hours = differenceInHours(end, remainingHours);
	if (hours) duration.hours = hours;
	const remainingMinutes = add(remainingHours, { hours: duration.hours });
	const minutes = differenceInMinutes(end, remainingMinutes);
	if (minutes) duration.minutes = minutes;
	const remainingSeconds = add(remainingMinutes, { minutes: duration.minutes });
	const seconds = differenceInSeconds(end, remainingSeconds);
	if (seconds) duration.seconds = seconds;
	return duration;
}

export { intervalToDuration as i };
//# sourceMappingURL=intervalToDuration.js-Bqoo9ab3.js.map
