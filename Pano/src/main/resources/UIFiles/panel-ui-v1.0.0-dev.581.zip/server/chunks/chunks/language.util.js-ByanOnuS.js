import { _ as __exportAll } from './rolldown-runtime.js-BMnQIuNT.js';
import { b as base } from './internal.js-BRN1McAa.js';
import { F as writable, Y as get } from './index-server.js-DdhL7Abu.js';
import './server.js-BlClO2ED.js';
import './internal2.js-CNe5OZUJ.js';
import './routing.js-N-OPb2ye.js';
import { b as ApiUtil } from './Store.js-DT3aZHRb.js';
import { a as registerLocaleLoader, w as waitLocale, i as init$1, b as $locale } from './runtime.js-BzHEw_ze.js';

//#region src/lib/language.util.js
var language_util_exports = /* @__PURE__ */ __exportAll({
	Languages: () => Languages,
	changeLanguage: () => changeLanguage,
	currentLanguage: () => currentLanguage,
	getAcceptedLanguage: () => getAcceptedLanguage,
	getLanguageByLocale: () => getLanguageByLocale,
	init: () => init,
	languageLoading: () => languageLoading,
	loadLanguage: () => loadLanguage
});
var languageLoading = writable(false);
var currentLanguage = writable(null);
var Languages = writable({});
async function fetchLanguages(event) {
	const locales = (await ApiUtil.get({
		path: `/api/locales`,
		request: event
	})).data;
	Languages.set(Object.fromEntries(locales.map((item) => [item.code, item])));
}
async function init(initialLocale, event) {
	await fetchLanguages(event);
	const languageToLoad = getLanguageByLocale(initialLocale) || get(Languages)["en-US"];
	await loadLanguage(get(Languages)["en-US"], event);
	await loadLanguage(languageToLoad, event);
	currentLanguage.set(languageToLoad);
	await waitLocale();
	init$1({
		fallbackLocale: "en-US",
		initialLocale: languageToLoad.code
	});
}
function getAcceptedLanguage(headers) {
	if (typeof headers.get("accept-language") === "undefined" || headers.get("accept-language") == null) return "";
	return headers.get("accept-language").split(",")[0];
}
async function loadLanguage(language, event) {
	const useFetch = event ? event.fetch : fetch;
	const [localTranslationsResponse, translationsResponse] = await Promise.all([useFetch(base + `/panel-api/languages/${language.code}.json`), ApiUtil.get({
		path: `/api/locales/${language.code}/translations/types/PANEL`,
		request: event
	})]);
	const languageFile = await localTranslationsResponse.json();
	const customTranslations = translationsResponse.result !== "ok" ? {} : translationsResponse.data;
	const translations = unflattenObject({
		...flattenObject(languageFile),
		...flattenObject(customTranslations)
	});
	registerLocaleLoader(language.code, async () => translations);
	await waitLocale(language.code);
	if (language.derivatives) for (const derivative of language.derivatives) {
		registerLocaleLoader(derivative, async () => translations);
		await waitLocale(language.code);
	}
}
async function changeLanguage(language) {
	if (get(currentLanguage) === language) return;
	languageLoading.set(true);
	await loadLanguage(language);
	$locale.set(language.code);
	currentLanguage.set(language);
	languageLoading.set(false);
}
function getLanguageByLocale(locale) {
	let foundLanguage = null;
	const languages = get(Languages);
	Object.keys(languages).forEach((key) => {
		const language = languages[key];
		if (language.code === locale) foundLanguage = language;
	});
	return foundLanguage;
}
function flattenObject(obj, prefix = "", result = {}) {
	for (const key in obj) {
		const value = obj[key];
		const newKey = prefix ? `${prefix}.${key}` : key;
		if (typeof value === "object" && value !== null && !Array.isArray(value)) flattenObject(value, newKey, result);
		else result[newKey] = value;
	}
	return result;
}
function unflattenObject(flatObj) {
	const result = {};
	for (const flatKey in flatObj) {
		const keys = flatKey.split(".");
		keys.reduce((acc, key, idx) => {
			if (idx === keys.length - 1) acc[key] = flatObj[flatKey];
			else acc[key] = acc[key] || {};
			return acc[key];
		}, result);
	}
	return result;
}

export { Languages as L, currentLanguage as c, init as i, language_util_exports as l };
//# sourceMappingURL=language.util.js-ByanOnuS.js.map
