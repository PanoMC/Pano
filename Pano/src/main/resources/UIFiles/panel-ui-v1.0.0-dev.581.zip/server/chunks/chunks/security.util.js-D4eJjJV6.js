//#region src/lib/security.util.js
/**
* Security utilities for sanitizing user-provided content.
* Prevents XSS attacks via malicious image URLs, SVG data URLs, etc.
*/
/**
* Whitelist of allowed image MIME types in data URLs.
* SVG is intentionally excluded because it can contain embedded JavaScript.
*/
var ALLOWED_IMAGE_MIME_TYPES = /* @__PURE__ */ new Set([
	"image/png",
	"image/jpeg",
	"image/webp",
	"image/gif",
	"image/x-icon",
	"image/vnd.microsoft.icon"
]);
/**
* Validates an image source URL for safe rendering.
* - Allows relative URLs (e.g. /api/server/icon/default)
* - Allows HTTPS URLs
* - Allows data: URLs only if MIME type is in the whitelist
* - Rejects javascript: URLs
* - Rejects SVG data URLs
*
* @param {string} src - The image source to validate
* @param {string} fallback - Fallback URL if the source is not safe
* @returns {string} The safe image URL or fallback
*/
function sanitizeImageSrc(src, fallback = "") {
	if (!src || typeof src !== "string") return fallback;
	if (src.startsWith("/")) return src;
	if (src.startsWith("https://")) return src;
	if (src.startsWith("http://")) return src;
	if (src.startsWith("data:")) {
		const semicolonIndex = src.indexOf(";");
		if (semicolonIndex === -1) return fallback;
		const mimeType = src.substring(5, semicolonIndex).toLowerCase();
		if (ALLOWED_IMAGE_MIME_TYPES.has(mimeType)) return src;
		return fallback;
	}
	return fallback;
}

export { sanitizeImageSrc as s };
//# sourceMappingURL=security.util.js-D4eJjJV6.js.map
