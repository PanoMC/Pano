//#region src/lib/string.util.js
function formatBytes(bytes, decimals = 2) {
	if (bytes === 0) return "0 B";
	const k = 1024;
	const sizes = [
		"B",
		"KB",
		"MB",
		"GB",
		"TB"
	];
	const i = Math.floor(Math.log(bytes) / Math.log(k));
	return parseFloat((bytes / Math.pow(k, i)).toFixed(decimals)) + " " + sizes[i];
}
function parseUserAgent(userAgent) {
	if (!userAgent || userAgent === "-") return "Unknown";
	const ua = userAgent.toLowerCase();
	let browser = "Unknown Browser";
	if (ua.includes("firefox")) browser = "Firefox";
	else if (ua.includes("edg")) browser = "Edge";
	else if (ua.includes("chrome")) browser = "Chrome";
	else if (ua.includes("safari")) browser = "Safari";
	else if (ua.includes("opera") || ua.includes("opr")) browser = "Opera";
	let os = "Unknown OS";
	if (ua.includes("win")) os = "Windows";
	else if (ua.includes("mac")) os = "macOS";
	else if (ua.includes("linux")) os = "Linux";
	else if (ua.includes("android")) os = "Android";
	else if (ua.includes("iphone") || ua.includes("ipad")) os = "iOS";
	return `${browser} (${os})`;
}

export { formatBytes as f, parseUserAgent as p };
//# sourceMappingURL=string.util.js-Pwbw6tDM.js.map
