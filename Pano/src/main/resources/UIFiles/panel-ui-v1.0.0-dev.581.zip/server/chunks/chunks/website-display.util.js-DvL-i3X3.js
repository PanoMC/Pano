import { P as PANO_WEBSITE_URL } from './Store.js-DT3aZHRb.js';

//#region src/lib/website-display.util.js
/** Hostname from configured website URL (e.g. panomc.com) for translation placeholders. */
function websiteDisplayHost(url = PANO_WEBSITE_URL) {
	if (!url || typeof url !== "string") return "";
	try {
		const normalized = /^https?:\/\//i.test(url) ? url : `https://${url}`;
		return new URL(normalized).hostname;
	} catch {
		return url.replace(/^https?:\/\//i, "").replace(/\/.*$/, "") || url;
	}
}

export { websiteDisplayHost as w };
//# sourceMappingURL=website-display.util.js-DvL-i3X3.js.map
