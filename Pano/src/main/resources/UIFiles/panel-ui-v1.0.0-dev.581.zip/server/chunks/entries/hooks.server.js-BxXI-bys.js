import { R as RUNTIME_SPECIFIERS } from '../chunks/specifiers.js-DAH8di1Y.js';
import { A as API_URL, u as updateApiUrl, C as COOKIE_PREFIX, a as CSRF_TOKEN_COOKIE_NAME, J as JWT_COOKIE_NAME, b as ApiUtil, n as networkErrorBody, c as updatePanoWebsiteUrl, d as updatePanoWebsiteApiUrl } from '../chunks/Store.js-DT3aZHRb.js';
import { createVerify, createPublicKey, createHash } from 'node:crypto';
import { existsSync, readFileSync, readdirSync } from 'node:fs';
import path from 'node:path';
import '../chunks/rolldown-runtime.js-BMnQIuNT.js';
import 'node:module';
import '../chunks/index-server.js-DdhL7Abu.js';
import '../chunks/uneval.js-BAGiwb_L.js';
import '../chunks/stores.js-D5xmrOAP.js';
import '../chunks/shared.js-B3c7sR3F.js';
import '../chunks/exports.js-BxqLZ-Bq.js';
import '../chunks/routing.js-N-OPb2ye.js';
import '../chunks/server.js-BlClO2ED.js';
import '../chunks/internal2.js-CNe5OZUJ.js';
import '../chunks/ToastContainer.js-Bv1jJ2dr.js';
import '../chunks/runtime.js-BzHEw_ze.js';

//#region node_modules/@panomc/theme-core/src/lib/services/auth.js
var getCredentialsServerSide = async (token) => {
	return ApiUtil.get({
		path: "/api/auth/credentials",
		token
	}).then((response) => {
		if (response.result !== "ok") return null;
		return Object.keys(response).filter((key) => !["result"].includes(key)).reduce((object, key) => {
			object[key] = response[key];
			return object;
		}, {});
	});
};
//#endregion
//#region node_modules/@panomc/theme-core/src/kit/license-runtime.js
/**
* Runtime license check for premium Pano themes.
*
* Mirrors the plugin-side {@link com.panomc.plugins.license.PluginLicenseClient} in shape:
*   - load the panomc.com public key embedded at build time
*   - read the RS256 JWT from the PANO_LICENSE_JWT env var the Pano host sets when it
*     spawns the theme bun process
*   - verify the signature locally and assert the claims (audience = theme id, version,
*     issuer, expiry)
*
* The host has ALREADY verified those claims by the time it hands us the JWT (see
* com.panomc.platform.license.LicenseManager.fetchAndCacheThemeLicense), but a forked /
* patched host could feed back a forged token. Re-verifying with our own embedded
* public key is the theme's actual security boundary; a cracker has to either tamper with
* THIS theme version's bundle (which only breaks one version, the next release resets
* everything because the public key, theme version and constants are embedded fresh) OR
* forge a JWT (impossible without panomc.com's RSA private key).
*
* Free builds (PANO_LICENSE_REQUIRED=false) make every export here a no-op so the same
* code path stays valid for development and free distribution.
*/
/** Stable strings mirrored from com.panomc.platform.license.LicenseDeniedReason. */
var LICENSE_REASONS = Object.freeze({
	NOT_CONNECTED: "not-connected",
	KEY_NOT_AVAILABLE: "key-not-available",
	SIGNATURE_INVALID: "signature-invalid",
	EXPIRED: "expired",
	AUDIENCE_MISMATCH: "audience-mismatch",
	VERSION_MISMATCH: "version-mismatch",
	MALFORMED_JWT: "malformed-jwt",
	FILE_TAMPERED: "file-tampered",
	UNKNOWN: "unknown"
});
var LicenseError = class extends Error {
	constructor(reason, message) {
		super(`license-check-failed: ${reason}${message ? ` (${message})` : ""}`);
		this.reason = reason;
	}
};
function createLicenseRuntime(licenseConstants) {
	const { PANO_LICENSE_PUBLIC_KEY_BASE64 = "", PANO_LICENSE_THEME_ID = "", PANO_LICENSE_THEME_VERSION = "", PANO_LICENSE_REQUIRED = false, PANO_LICENSE_ISSUER_HINT = "" } = licenseConstants || {};
	let cachedPublicKey = null;
	function loadPublicKey() {
		if (cachedPublicKey !== null) return cachedPublicKey;
		if (!PANO_LICENSE_PUBLIC_KEY_BASE64) return null;
		const pem = "-----BEGIN PUBLIC KEY-----\n" + (PANO_LICENSE_PUBLIC_KEY_BASE64.match(/.{1,64}/g) || []).join("\n") + "\n-----END PUBLIC KEY-----\n";
		cachedPublicKey = createPublicKey(pem);
		return cachedPublicKey;
	}
	function base64UrlDecode(str) {
		const b64 = (str + "=".repeat((4 - str.length % 4) % 4)).replace(/-/g, "+").replace(/_/g, "/");
		return Buffer.from(b64, "base64");
	}
	function decodeJwt(jwt) {
		const parts = jwt.split(".");
		if (parts.length !== 3) throw new LicenseError(LICENSE_REASONS.MALFORMED_JWT, "JWT does not have 3 segments");
		let header;
		let payload;
		try {
			header = JSON.parse(base64UrlDecode(parts[0]).toString("utf-8"));
			payload = JSON.parse(base64UrlDecode(parts[1]).toString("utf-8"));
		} catch (e) {
			throw new LicenseError(LICENSE_REASONS.MALFORMED_JWT, e.message);
		}
		const signature = base64UrlDecode(parts[2]);
		const signedData = Buffer.from(`${parts[0]}.${parts[1]}`, "utf-8");
		return {
			header,
			payload,
			signature,
			signedData
		};
	}
	/** Cached snapshot of the last successful verification; refreshed lazily on expiry. */
	let snapshot = null;
	/** True when this build was configured as premium AND a public key was embedded. */
	function isPremiumBuild() {
		return PANO_LICENSE_REQUIRED && !!PANO_LICENSE_PUBLIC_KEY_BASE64;
	}
	/** Theme identity baked in at build time. */
	function getEmbeddedThemeIdentity() {
		return {
			id: PANO_LICENSE_THEME_ID,
			version: PANO_LICENSE_THEME_VERSION,
			premium: PANO_LICENSE_REQUIRED
		};
	}
	/**
	* Verifies the JWT in PANO_LICENSE_JWT (RS256 + claim checks) and caches the snapshot.
	* Throws [LicenseError] on any failure. No-op for free builds.
	*/
	function verifyLicenseFromEnv() {
		if (!isPremiumBuild()) {
			snapshot = null;
			return null;
		}
		const publicKey = loadPublicKey();
		if (!publicKey) throw new LicenseError(LICENSE_REASONS.KEY_NOT_AVAILABLE, "embedded panomc.com public key is missing or malformed");
		const jwt = readCurrentJwt(locateThemeRoot());
		if (!jwt) throw new LicenseError(LICENSE_REASONS.NOT_CONNECTED, "Pano host did not pass PANO_LICENSE_JWT (premium themes require a connected panomc.com account)");
		const { header, payload, signature, signedData } = decodeJwt(jwt);
		if (header.alg !== "RS256") throw new LicenseError(LICENSE_REASONS.SIGNATURE_INVALID, `unexpected JWT algorithm: ${header.alg}`);
		let signatureOk = false;
		try {
			signatureOk = createVerify("RSA-SHA256").update(signedData).verify(publicKey, signature);
		} catch (e) {
			throw new LicenseError(LICENSE_REASONS.SIGNATURE_INVALID, e.message);
		}
		if (!signatureOk) throw new LicenseError(LICENSE_REASONS.SIGNATURE_INVALID, "JWT signature failed verification (host may be tampered)");
		const expectedIssuer = (process.env.PANO_LICENSE_ISSUER || PANO_LICENSE_ISSUER_HINT || "panomc.com").trim();
		if (expectedIssuer && payload.iss !== expectedIssuer) throw new LicenseError(LICENSE_REASONS.AUDIENCE_MISMATCH, `iss=${payload.iss}, expected ${expectedIssuer}`);
		const audience = Array.isArray(payload.aud) ? payload.aud[0] : payload.aud;
		if (!audience || String(audience).toLowerCase() !== String(PANO_LICENSE_THEME_ID).toLowerCase()) throw new LicenseError(LICENSE_REASONS.AUDIENCE_MISMATCH, `aud=${audience}, expected ${PANO_LICENSE_THEME_ID}`);
		if (payload.ver !== PANO_LICENSE_THEME_VERSION) throw new LicenseError(LICENSE_REASONS.VERSION_MISMATCH, `ver=${payload.ver}, expected ${PANO_LICENSE_THEME_VERSION}`);
		const nowSec = Math.floor(Date.now() / 1e3);
		if (typeof payload.exp !== "number" || payload.exp <= nowSec) throw new LicenseError(LICENSE_REASONS.EXPIRED, `exp=${payload.exp} now=${nowSec}`);
		try {
			verifyFileFingerprint();
		} catch (e) {
			if (e instanceof LicenseError) throw e;
			throw new LicenseError(LICENSE_REASONS.FILE_TAMPERED, e?.message || String(e));
		}
		snapshot = {
			payload,
			expiresAtMs: payload.exp * 1e3,
			audience,
			version: payload.ver
		};
		return snapshot;
	}
	const DEFAULT_FINGERPRINT_EXCLUDE = /* @__PURE__ */ new Set(["manifest.json", ".pano-license.jwt"]);
	const LICENSE_JWT_FILENAME = ".pano-license.jwt";
	/**
	* Reads the freshest JWT for this theme. Priority:
	*   1. <themeRoot>/.pano-license.jwt — host writes this on every renewal sweep so the bun
	*      process can pick up new tokens without restarting.
	*   2. process.env.PANO_LICENSE_JWT — the launch-time value, used as a fallback when the
	*      disk file is missing (e.g. first start of a theme installed by an older host).
	*/
	function readCurrentJwt(themeRoot) {
		if (themeRoot) try {
			const p = path.join(themeRoot, LICENSE_JWT_FILENAME);
			if (existsSync(p)) {
				const fromDisk = readFileSync(p, "utf8").trim();
				if (fromDisk) return fromDisk;
			}
		} catch {}
		return (process.env.PANO_LICENSE_JWT || "").trim();
	}
	function sha256Hex(buffer) {
		return createHash("sha256").update(buffer).digest("hex");
	}
	function listFilesRecursive(dir) {
		const out = [];
		function walk(d) {
			let entries;
			try {
				entries = readdirSync(d, { withFileTypes: true });
			} catch {
				return;
			}
			for (const entry of entries) {
				const full = path.join(d, entry.name);
				if (entry.isDirectory()) walk(full);
				else if (entry.isFile()) out.push(full);
			}
		}
		walk(dir);
		return out;
	}
	/**
	* Reimplementation of file-fingerprint.js#computeStableFileFingerprint. Kept inline here
	* so the runtime guard works without depending on any extra source files that an attacker
	* could trivially remove from the build output.
	*/
	function computeFileFingerprintOf(dir) {
		return sha256Hex(listFilesRecursive(dir).map((full) => ({
			rel: path.relative(dir, full).split(path.sep).join("/"),
			full
		})).filter((it) => !DEFAULT_FINGERPRINT_EXCLUDE.has(it.rel)).sort((a, b) => a.rel < b.rel ? -1 : a.rel > b.rel ? 1 : 0).map((it) => `${it.rel}:${sha256Hex(readFileSync(it.full))}`).join("\n"));
	}
	/**
	* Locate the theme root by walking up from the running script until we find a
	* `manifest.json` with our theme id. We can't trust process.cwd() blindly because the
	* Pano host spawns bun from inside the theme folder but operators could run it via
	* arbitrary working directories during local debugging.
	*/
	function locateThemeRoot() {
		const candidates = [process.cwd()];
		try {
			const here = new URL(import.meta.url).pathname;
			let dir = path.dirname(here);
			for (let i = 0; i < 8; i++) {
				candidates.push(dir);
				dir = path.dirname(dir);
				if (dir === "/" || dir === ".") break;
			}
		} catch {}
		for (const c of candidates) {
			const mf = path.join(c, "manifest.json");
			if (!existsSync(mf)) continue;
			try {
				const parsed = JSON.parse(readFileSync(mf, "utf-8"));
				if (parsed && parsed.id === PANO_LICENSE_THEME_ID) return c;
			} catch {}
		}
		return null;
	}
	function verifyFileFingerprint() {
		const themeRoot = locateThemeRoot();
		if (!themeRoot) throw new LicenseError(LICENSE_REASONS.FILE_TAMPERED, `could not locate theme root containing manifest.json for "${PANO_LICENSE_THEME_ID}"`);
		const expected = JSON.parse(readFileSync(path.join(themeRoot, "manifest.json"), "utf-8")).fileFingerprint;
		if (typeof expected !== "string" || expected.length !== 64) throw new LicenseError(LICENSE_REASONS.FILE_TAMPERED, "manifest.json is missing or has malformed fileFingerprint (run a fresh build of the theme)");
		const actual = computeFileFingerprintOf(themeRoot);
		if (actual !== expected) throw new LicenseError(LICENSE_REASONS.FILE_TAMPERED, `theme files have been modified after install: expected ${expected.slice(0, 12)}…, got ${actual.slice(0, 12)}…`);
	}
	/** Re-verify proactively when the cached snapshot has less than this much time left. */
	const PRE_EXPIRY_REFRESH_MARGIN_MS = 3e5;
	/**
	* Cheap runtime check intended for sprinkling across request handlers. Re-verifies a
	* few minutes BEFORE the cached snapshot expires so we pick up the JWT that the host
	* just wrote to <themeRoot>/.pano-license.jwt (the host's half-life renewal lands
	* roughly at expiresAt - 30 minutes for a 1h TTL, so 5 min before expiry the disk
	* file is always already refreshed).
	*/
	function assertStillLicensed() {
		if (!isPremiumBuild()) return;
		if (!snapshot || snapshot.expiresAtMs <= Date.now() + PRE_EXPIRY_REFRESH_MARGIN_MS) verifyLicenseFromEnv();
	}
	/** Returns the current verified license snapshot or null. */
	function getLicenseSnapshot() {
		return snapshot;
	}
	return {
		LICENSE_REASONS,
		LicenseError,
		isPremiumBuild,
		getEmbeddedThemeIdentity,
		verifyLicenseFromEnv,
		assertStillLicensed,
		getLicenseSnapshot
	};
}
//#endregion
//#region node_modules/@panomc/theme-core/src/kit/hooks-server.js
/**
* Factory for the theme's server hooks. A theme's src/hooks.server.js becomes:
*
*   import { createThemeHooks } from "$pano/kit/hooks-server.js";
*   import { internalLibsHash } from "$lib/internalLibs.js";
*   import { runtimeShimsHash } from "$lib/runtimeShims.js";
*   import * as licenseConstants from "$lib/server/license-constants.generated.js";
*   export const { handle, handleError, handleFetch } = createThemeHooks({
*     internalLibsHash,
*     runtimeShimsHash,
*     licenseConstants,
*   });
*
* The generated per-theme artifacts (internalLibsHash, runtimeShimsHash, license
* constants) are parameters because they are produced inside the theme repo at
* build time; everything else lives here so a hooks fix ships to every theme as
* a core version bump instead of a hand-applied patch.
*/
function stripModulePreload(linkHeader) {
	const kept = linkHeader.split(",").map((p) => p.trim()).filter(Boolean).filter((p) => !/;\s*rel="?modulepreload"?/i.test(p));
	return kept.length ? kept.join(", ") : null;
}
function getCookieWithHttpFallback(cookies, baseName) {
	return cookies.get(baseName) ?? cookies.get(`${baseName}_http`);
}
/** In production, skip logging common client/bot noise (wrong method, stray POST to non-action routes). */
function shouldSuppressServerErrorLog(error) {
	if (process.env.NODE_ENV !== "production") return false;
	if (error?.status === 405) return true;
	if (String(error?.message ?? "").includes("No form actions exist")) return true;
	return false;
}
function escapeHtml(s) {
	return String(s).replace(/[&<>"']/g, (c) => ({
		"&": "&amp;",
		"<": "&lt;",
		">": "&gt;",
		"\"": "&quot;",
		"'": "&#39;"
	})[c]);
}
function renderLicenseBlocked(reason, message) {
	const body = `<!doctype html><html lang="en"><head><meta charset="utf-8"><title>License required</title><meta name="robots" content="noindex"><style>html,body{height:100%;margin:0;font-family:system-ui,sans-serif;color:#222;background:#f7f7f9}main{display:flex;align-items:center;justify-content:center;height:100%;padding:2rem;text-align:center}section{max-width:540px}h1{margin:.2em 0 .6em}code{background:#eee;padding:.1em .3em;border-radius:.2em}.reason{color:#a00;font-weight:600}</style></head><body><main><section><h1>This premium theme is not licensed on this server.</h1><p>The Pano host did not provide a valid license token.</p><p>Reason: <span class="reason">${escapeHtml(reason)}</span>${message ? ` — ${escapeHtml(message)}` : ""}</p><p>Open the Pano panel and reconnect your panomc.com account, then re-activate this theme.</p></section></main></body></html>`;
	return new Response(body, {
		status: 503,
		headers: {
			"content-type": "text/html; charset=utf-8",
			"cache-control": "no-store"
		}
	});
}
var IMPORT_MAP_PLACEHOLDER = "%pano_lib_import%";
var IMPORT_MAP_PLACEHOLDER_LEN = 17;
/**
* @param {object} opts
* @param {string} opts.internalLibsHash  content hash from the generated $lib/internalLibs.js
* @param {string} opts.runtimeShimsHash  content hash from the generated $lib/runtimeShims.js
* @param {object} [opts.licenseConstants]  the generated license constants module (premium builds);
*   pass the whole module namespace — free builds no-op automatically. Panel profile: omit.
* @param {(html: string) => string} [opts.transformHtml]  optional extra page-chunk transform
* @param {string} [opts.base]  URL prefix for /lib and /runtime shim URLs ("" for themes,
*   "/panel" for panel-ui — must match kit.paths.base)
* @param {(ctx: {event: any, locals: object, jwt: string|undefined, csrfToken: string|undefined,
*   pathname: string}) => Promise<void>} [opts.resolveLocals]  profile-specific locals resolution.
*   Default (theme profile): locals.user via getCredentialsServerSide guarded against /api and
*   /auth paths. Panel passes its basicData-based resolver instead.
* @param {(locals: object) => void} [opts.applyExtraEnv]  hook for profile-specific env vars
*   (panel: PANO_WEBSITE_API_URL → updatePanoWebsiteApiUrl)
* @param {boolean} [opts.suppressNoisyErrors]  prod-suppress 405/no-form-action logs (theme default)
*/
function createThemeHooks({ internalLibsHash, runtimeShimsHash, licenseConstants = null, transformHtml = null, base = "", resolveLocals = null, applyExtraEnv = null, suppressNoisyErrors = true }) {
	const license = createLicenseRuntime(licenseConstants);
	const libBase = `${base}/lib/${internalLibsHash}`;
	const runtimeShim = (file) => `${base}/runtime/${file}?v=${runtimeShimsHash}`;
	const importMap = `
  <script type="importmap" crossorigin="anonymous">
  {
    "imports": {
${Object.entries(RUNTIME_SPECIFIERS).map(([specifier, file]) => `      "${specifier}": "${runtimeShim(file)}"`).join(",\n")}
    }
  }
  <\/script>
  <script defer src="${libBase}/bootstrap/bootstrap.bundle.min.js"><\/script>`;
	const licenseEnforced = license.isPremiumBuild() && true;
	let bootLicenseError = null;
	if (licenseEnforced) try {
		license.verifyLicenseFromEnv();
		console.log("[pano-license] startup verification passed");
	} catch (e) {
		bootLicenseError = e instanceof license.LicenseError ? e : new license.LicenseError("unknown", String(e?.message ?? e));
		console.error("[pano-license] startup verification FAILED:", bootLicenseError.message);
	}
	/** @type {import('@sveltejs/kit').Handle} */
	async function handle({ event, event: { cookies, url: { pathname } }, resolve }) {
		if (licenseEnforced) {
			if (bootLicenseError) return renderLicenseBlocked(bootLicenseError.reason ?? "unknown", bootLicenseError.message);
			try {
				license.assertStillLicensed();
			} catch (e) {
				return renderLicenseBlocked(e instanceof license.LicenseError ? e.reason : "unknown", e?.message);
			}
		}
		const locals = {};
		const apiUrlEnv = process.env.API_URL;
		const panoWebsiteUrlEnv = process.env.PANO_WEBSITE_URL;
		if (apiUrlEnv) {
			updateApiUrl(apiUrlEnv);
			locals.apiUrlEnv = apiUrlEnv;
		}
		if (panoWebsiteUrlEnv) {
			updatePanoWebsiteUrl(panoWebsiteUrlEnv);
			locals.panoWebsiteUrlEnv = panoWebsiteUrlEnv;
		}
		if (applyExtraEnv) applyExtraEnv(locals);
		const jwt = getCookieWithHttpFallback(cookies, COOKIE_PREFIX + JWT_COOKIE_NAME);
		const csrfToken = getCookieWithHttpFallback(cookies, COOKIE_PREFIX + CSRF_TOKEN_COOKIE_NAME);
		if (resolveLocals) await resolveLocals({
			event,
			locals,
			jwt,
			csrfToken,
			pathname
		});
		else locals.user = jwt && csrfToken && !pathname.startsWith("/api/") && !pathname.startsWith("/auth/") && await getCredentialsServerSide(jwt);
		locals.csrfToken = csrfToken;
		event.locals = locals;
		const response = await resolve(event, { transformPageChunk: ({ html }) => {
			const index = html.indexOf(IMPORT_MAP_PLACEHOLDER);
			let out = html;
			if (index !== -1) out = html.substring(0, index) + importMap + html.substring(index + IMPORT_MAP_PLACEHOLDER_LEN);
			return transformHtml ? transformHtml(out) : out;
		} });
		if ((response.headers.get("content-type") || "").includes("text/html")) {
			const link = response.headers.get("link");
			if (link) {
				const filtered = stripModulePreload(link);
				if (filtered) response.headers.set("link", filtered);
				else response.headers.delete("link");
			}
		}
		return response;
	}
	/** @type {import('@sveltejs/kit').HandleServerError} */
	function handleError({ error, event }) {
		if (!suppressNoisyErrors || !shouldSuppressServerErrorLog(error)) {
			console.log("!!! [GLOBAL ERROR EVENT]:", event.url.href);
			console.error("!!! [GLOBAL ERROR CONTENT]:", error);
		}
		return {
			message: "Internal Error",
			code: error?.code
		};
	}
	/** @type {import("@sveltejs/kit").HandleFetch} */
	async function handleFetch({ event, request, fetch }) {
		if (request.url.startsWith(event.url.origin + "/api/")) {
			const apiPath = new URL(request.url).pathname + new URL(request.url).search;
			const backendUrl = API_URL.replace(/\/api\/?$/, "") + apiPath;
			request = new Request(backendUrl, request);
			request.headers.set("cookie", event.request.headers.get("cookie") || "");
			request.headers.set("Origin", API_URL);
		} else if (request.url.startsWith(API_URL)) {
			request.headers.set("cookie", event.request.headers.get("cookie") || "");
			request.headers.set("Origin", API_URL);
		}
		return fetch(request);
	}
	return {
		handle,
		handleError,
		handleFetch
	};
}
//#endregion
//#region src/lib/internalLibs.js
var internalLibsHash = "be8641ae3b66de78";
//#endregion
//#region src/lib/runtimeShims.js
var runtimeShimsHash = "3571f7d37c0fce28";
//#endregion
//#region src/hooks.server.js
async function fetchBasicData(token, csrfToken) {
	return ApiUtil.get({
		path: "/api/panel/basicData",
		token,
		csrfToken
	}).catch(() => networkErrorBody);
}
var { handle, handleError } = createThemeHooks({
	internalLibsHash,
	runtimeShimsHash,
	base: "/panel",
	suppressNoisyErrors: false,
	applyExtraEnv: (locals) => {
		const panoWebsiteApiUrlEnv = process.env.PANO_WEBSITE_API_URL;
		if (panoWebsiteApiUrlEnv) {
			updatePanoWebsiteApiUrl(panoWebsiteApiUrlEnv);
			locals.panoWebsiteApiUrlEnv = panoWebsiteApiUrlEnv;
		}
	},
	resolveLocals: async ({ locals, jwt, csrfToken }) => {
		locals.basicData = await fetchBasicData(jwt, csrfToken);
		locals.jwt = jwt;
	}
});
/** @type {import('@sveltejs/kit').HandleFetch} */
async function handleFetch({ event, request, fetch }) {
	if (request.url.startsWith(event.url.origin + "/api/")) {
		const apiPath = new URL(request.url).pathname + new URL(request.url).search;
		const backendUrl = new URL(API_URL).origin + apiPath;
		request = new Request(backendUrl, request);
		request.headers.set("cookie", event.request.headers.get("cookie") || "");
		request.headers.set("Origin", API_URL);
	} else if (request.url.startsWith(API_URL)) {
		request.headers.set("cookie", event.request.headers.get("cookie") || "");
		request.headers.set("Origin", API_URL);
	}
	return fetch(request);
}

export { handle, handleError, handleFetch };
//# sourceMappingURL=hooks.server.js-BxXI-bys.js.map
