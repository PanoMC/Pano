import { l as load } from '../../../chunks/Dashboard.js-DYKZYuXG.js';

var _page = /*#__PURE__*/Object.freeze({
	__proto__: null,
	load: load
});

export { _page as _ };
//# sourceMappingURL=_page.js-D4e3Kb00.js.map
