import { l as load } from '../../../../chunks/AddonsLayout.js-D51u-QW6.js';

var _layout = /*#__PURE__*/Object.freeze({
	__proto__: null,
	load: load
});

export { _layout as _ };
//# sourceMappingURL=_layout.js-BI-u0VqJ.js.map
