import { l as load } from '../../../../chunks/Addons.js-DTwhgMdd.js';

var _page = /*#__PURE__*/Object.freeze({
	__proto__: null,
	load: load
});

export { _page as _ };
//# sourceMappingURL=_page.js-C9yEMut-.js.map
