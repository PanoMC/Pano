import { l as load } from '../../../../../../chunks/AddonDetailLayout.js-Dsuoa7y-.js';

var _layout = /*#__PURE__*/Object.freeze({
	__proto__: null,
	load: load
});

export { _layout as _ };
//# sourceMappingURL=_layout.js-CbHGJ8j1.js.map
