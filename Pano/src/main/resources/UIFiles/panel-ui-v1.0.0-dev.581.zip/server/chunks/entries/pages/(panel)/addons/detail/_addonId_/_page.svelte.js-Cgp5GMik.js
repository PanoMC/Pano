import { b as base } from '../../../../../../chunks/internal.js-BRN1McAa.js';
import { O as bind_props, Z as escape_html, Q as store_get, T as attr, X as html, S as unsubscribe_stores, U as stringify, J as getContext, y as derived } from '../../../../../../chunks/index-server.js-DdhL7Abu.js';
import '../../../../../../chunks/server.js-BlClO2ED.js';
import '../../../../../../chunks/internal2.js-CNe5OZUJ.js';
import '../../../../../../chunks/routing.js-N-OPb2ye.js';
import '../../../../../../chunks/stores.js-D5xmrOAP.js';
import 'node:module';
import '../../../../../../chunks/ToastContainer.js-Bv1jJ2dr.js';
import { $ as $format } from '../../../../../../chunks/runtime.js-BzHEw_ze.js';
import { w as websiteDisplayHost } from '../../../../../../chunks/website-display.util.js-DvL-i3X3.js';
import { L as LicenseStatusBadge } from '../../../../../../chunks/LicenseStatusBadge.js-C5qJr3_k.js';
import { f as formatBytes } from '../../../../../../chunks/string.util.js-Pwbw6tDM.js';
import '../../../../../../chunks/rolldown-runtime.js-BMnQIuNT.js';
import '../../../../../../chunks/uneval.js-BAGiwb_L.js';
import '../../../../../../chunks/shared.js-B3c7sR3F.js';
import '../../../../../../chunks/exports.js-BxqLZ-Bq.js';
import '../../../../../../chunks/Store.js-DT3aZHRb.js';
import '../../../../../../chunks/tooltip.util.js-BeLZL-Tj.js';

//#region src/lib/components/AddonLicenseCard.svelte
function AddonLicenseCard($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let { addon } = $$props;
		let refreshing = false;
		const websiteI18n = derived(() => ({ values: { website: websiteDisplayHost() } }));
		if (addon.premium) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<div class="card"><div class="card-header d-flex align-items-center justify-content-between"><div class="d-flex align-items-center gap-2"><strong>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.addon-detail.license-section"))}</strong> `);
			LicenseStatusBadge($$renderer, {
				status: addon.licenseStatus,
				labeled: false
			});
			$$renderer.push(`<!----></div> `);
			if (addon.licenseStatus !== "LICENSED") {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<button type="button" class="btn btn-sm btn-link"${attr("disabled", refreshing, true)}${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("buttons.refresh"))}>`);
				$$renderer.push("<!--[-1-->");
				$$renderer.push(`<i class="fa-solid fa-rotate me-1"></i>`);
				$$renderer.push(`<!--]--> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.refresh"))}</button>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--></div> <div class="card-body">`);
			if (addon.licenseStatus === "LICENSED") {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<p class="mb-0 text-body-secondary">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.addon-detail.license.active"))}</p>`);
			} else {
				$$renderer.push("<!--[-1-->");
				if (addon.licenseStatus === "NO_PURCHASE" || addon.licenseStatus === "MISSING" || addon.licenseStatus === "NEEDS_REFRESH" || addon.licenseStatus === "JAR_TAMPERED" || addon.licenseStatus === "SIGNATURE_INVALID") {
					$$renderer.push("<!--[0-->");
					$$renderer.push(`<p class="mb-3">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.addon-detail.license.no-purchase", websiteI18n()))}</p> `);
					if (addon.purchaseUrl) {
						$$renderer.push("<!--[0-->");
						$$renderer.push(`<a class="btn btn-warning"${attr("href", addon.purchaseUrl)} target="_blank" rel="noopener"><i class="fa-solid fa-store me-2"></i> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.buy-addon-on-market", websiteI18n()))}</a>`);
					} else $$renderer.push("<!--[-1-->");
					$$renderer.push(`<!--]-->`);
				} else if (addon.licenseStatus === "NOT_CONNECTED") {
					$$renderer.push("<!--[1-->");
					$$renderer.push(`<p class="mb-3">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.addon-detail.license.not-connected", websiteI18n()))}</p> <a class="btn btn-primary"${attr("href", `${stringify(base)}/settings/platform`)}><i class="fa-solid fa-link me-2"></i> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.connect-pano-account"))}</a>`);
				} else if (addon.licenseStatus === "EXPIRED") {
					$$renderer.push("<!--[2-->");
					$$renderer.push(`<p class="mb-3">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.addon-detail.license.expired"))}</p>`);
				} else if (addon.licenseStatus === "NETWORK_ERROR") {
					$$renderer.push("<!--[3-->");
					$$renderer.push(`<p class="mb-0">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.addon-detail.license.network-error", websiteI18n()))}</p>`);
				} else if (addon.licenseStatus === "VERSION_MISMATCH") {
					$$renderer.push("<!--[4-->");
					$$renderer.push(`<p class="mb-0">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.addon-detail.license.version-mismatch", websiteI18n()))}</p>`);
				} else {
					$$renderer.push("<!--[-1-->");
					$$renderer.push(`<p class="mb-0">${escape_html(addon.licenseFailureMessage || store_get($$store_subs ??= {}, "$_", $format)("components.license-status.UNKNOWN-tooltip", {
						...websiteI18n(),
						default: "Unknown license issue"
					}))}</p>`);
				}
				$$renderer.push(`<!--]-->`);
			}
			$$renderer.push(`<!--]--></div></div>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]-->`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
	});
}
//#endregion
//#region src/lib/components/AddonLicenseEmbed.svelte
function AddonLicenseEmbed($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let { addon } = $$props;
		getContext("panelTheme");
		let notConnected = false;
		if (addon.freemium) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<div class="card"><div class="card-header d-flex align-items-center justify-content-between gap-2"><strong>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.license-embed.title"))}</strong> <button type="button" class="btn btn-sm btn-link"${attr("disabled", notConnected, true)}${attr("title", store_get($$store_subs ??= {}, "$_", $format)("components.license-embed.refresh-hint"))}${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("buttons.refresh"))}>`);
			$$renderer.push("<!--[-1-->");
			$$renderer.push(`<i class="fa-solid fa-rotate me-1"></i>`);
			$$renderer.push(`<!--]--> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.refresh"))}</button></div> <div class="card-body">`);
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<div class="text-body-secondary small"><i class="fa-solid fa-spinner fa-spin me-2"></i> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.license-embed.loading"))}</div>`);
			$$renderer.push(`<!--]--></div></div>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]-->`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
	});
}
//#endregion
//#region src/lib/pages/addons/AddonDetail.svelte
function AddonDetail($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let { data } = $$props;
		function isBlank(value) {
			return value === null || value === void 0 || value.toString().trim() === "";
		}
		function getDependencyText(dependency) {
			let text = dependency.pluginId;
			if (dependency.pluginVersionSupport !== "*") text += `@<span class="font-monospace">${dependency.pluginVersionSupport}</span>`;
			if (dependency.optional) text = `[${text}]`;
			return text;
		}
		$$renderer.push(`<div class="vstack gap-3">`);
		AddonLicenseCard($$renderer, { addon: data.addon });
		$$renderer.push(`<!----> `);
		AddonLicenseEmbed($$renderer, { addon: data.addon });
		$$renderer.push(`<!----> <div class="card"><div class="card-header">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.toggle-details"))}</div> <div class="card-body p-0"><ul class="list-group list-group-flush"><li class="list-group-item"><strong>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.addon-detail.developer"))}:</strong> <span class="text-break">${escape_html(data.addon.developer)}</span></li> <li class="list-group-item"><strong>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.addon-detail.open-source-license"))}:</strong> <span class="text-break">${escape_html(data.addon.openSourceLicense || data.addon.license || store_get($$store_subs ??= {}, "$_", $format)("pages.addon-detail.unknown"))}</span></li> <li class="list-group-item"><strong>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.addon-detail.source"))}:</strong> <a${attr("href", data.addon.sourceUrl)} target="_blank" class="text-break">${escape_html(data.addon.sourceUrl || store_get($$store_subs ??= {}, "$_", $format)("pages.addon-detail.unknown"))} <i class="fa-solid fa-arrow-up-right-from-square ms-2"></i></a></li> <li class="list-group-item"><strong>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.addon-detail.dependencies"))}:</strong> <span class="text-break">${html(isBlank(data.addon.dependencies) ? "-" : data.addon.dependencies.map((dependency) => getDependencyText(dependency)).join(", "))}</span></li> <li class="list-group-item"><strong>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.addon-detail.requires"))}:</strong> <span class="text-break">${escape_html(isBlank(data.addon.requires) ? "-" : data.addon.requires)}</span></li> <li class="list-group-item"><strong>Hash:</strong> <code class="overflow-auto text-break user-select-all">sha256:${escape_html(data.addon.hash)}</code></li> <li class="list-group-item rounded-bottom"><strong>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.addon-detail.size"))}:</strong> <span class="text-break">${escape_html(formatBytes(data.addon.size))}</span></li></ul></div></div></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
	});
}
//#endregion
//#region src/routes/(panel)/addons/detail/[addonId]/+page.svelte
function _page($$renderer, $$props) {
	let data = $$props["data"];
	AddonDetail($$renderer, { data });
	bind_props($$props, { data });
}

export { _page as default };
//# sourceMappingURL=_page.svelte.js-Cgp5GMik.js.map
