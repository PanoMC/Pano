import { a0 as onDestroy, Q as store_get, S as unsubscribe_stores } from '../../../../../../../chunks/index-server.js-DdhL7Abu.js';
import { $ as $format } from '../../../../../../../chunks/runtime.js-BzHEw_ze.js';
import { h as panoApiClient, H as Hook } from '../../../../../../../chunks/SiteNavigationMenu.js-DeoPp7eK.js';
import { N as NoContent } from '../../../../../../../chunks/NoContent.js-Coj2fA9d.js';
import '../../../../../../../chunks/rolldown-runtime.js-BMnQIuNT.js';
import 'node:module';
import '../../../../../../../chunks/uneval.js-BAGiwb_L.js';
import '../../../../../../../chunks/exports2.js-VkmSkXbz.js';
import '../../../../../../../chunks/shared.js-B3c7sR3F.js';
import '../../../../../../../chunks/internal.js-BRN1McAa.js';
import '../../../../../../../chunks/stores.js-D5xmrOAP.js';
import '../../../../../../../chunks/exports.js-BxqLZ-Bq.js';
import '../../../../../../../chunks/routing.js-N-OPb2ye.js';
import '../../../../../../../chunks/server.js-BlClO2ED.js';
import '../../../../../../../chunks/internal2.js-CNe5OZUJ.js';
import '../../../../../../../chunks/Store.js-DT3aZHRb.js';
import '../../../../../../../chunks/ToastContainer.js-Bv1jJ2dr.js';
import '../../../../../../../chunks/auth.util.js-C77uoaNq.js';
import '../../../../../../../chunks/Date.js-DCZp_jrB.js';
import '../../../../../../../chunks/locale.js-DgLiJnqO.js';
import '../../../../../../../chunks/en-US.js-Qz-txlMm.js';
import '../../../../../../../chunks/toDate.js-DvNQTMH_.js';
import '../../../../../../../chunks/parseISO.js-Cr7JVAUm.js';
import '../../../../../../../chunks/getTimezoneOffsetInMilliseconds.js-B7thhdAL.js';
import '../../../../../../../chunks/language.util.js-ByanOnuS.js';
import '../../../../../../../chunks/tooltip.util.js-BeLZL-Tj.js';
import '../../../../../../../chunks/SearchInput.js-DPW0WADK.js';
import '../../../../../../../chunks/CardHeader.js-XBureLRg.js';
import '../../../../../../../chunks/Themes.js-B8ffV7iF.js';
import '../../../../../../../chunks/InstallingResourceModal.js-CaKAxtGU.js';
import '../../../../../../../chunks/website-display.util.js-DvL-i3X3.js';
import '../../../../../../../chunks/DragAndDropZone.js-DkRk4oSS.js';
import '../../../../../../../chunks/VerifiedStatus.js-BWWM3WML.js';
import '../../../../../../../chunks/LicenseStatusBadge.js-C5qJr3_k.js';
import '../../../../../../../chunks/Pagination.js-sd1xTcbW.js';
import '../../../../../../../chunks/CategoryBadge.js-DjLui7ZD.js';
import '../../../../../../../chunks/CardFiltersItem.js-n0hSsrtm.js';
import 'fs';

//#region src/lib/pages/addons/AddonSettings.svelte
function AddonSettings($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let { data } = $$props;
		const hookStore = panoApiClient.ui.hook.get("panel:plugin-detail:content");
		let specificHooks = [];
		onDestroy(() => {});
		if (store_get($$store_subs ??= {}, "$hookStore", hookStore).length > 0 || specificHooks.length > 0) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<div class="d-flex flex-column gap-3">`);
			Hook($$renderer, {
				name: "panel:plugin-detail:content",
				addon: data.addon
			});
			$$renderer.push(`<!----> `);
			Hook($$renderer, {
				name: `panel:plugin-detail:content:${data.addon.id}`,
				addon: data.addon
			});
			$$renderer.push(`<!----></div>`);
		} else {
			$$renderer.push("<!--[-1-->");
			NoContent($$renderer, {
				title: store_get($$store_subs ??= {}, "$_", $format)("pages.addon-detail.no-settings", { default: "No Settings" }),
				description: store_get($$store_subs ??= {}, "$_", $format)("pages.addon-detail.no-settings-desc", { default: "This addon has no configurable settings." }),
				icon: "fas fa-cog"
			});
		}
		$$renderer.push(`<!--]-->`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
	});
}
//#endregion
//#region src/routes/(panel)/addons/detail/[addonId]/settings/+page.svelte
function _page($$renderer, $$props) {
	let { data } = $$props;
	AddonSettings($$renderer, { data });
}

export { _page as default };
//# sourceMappingURL=_page.svelte.js-h1Pefkn7.js.map
