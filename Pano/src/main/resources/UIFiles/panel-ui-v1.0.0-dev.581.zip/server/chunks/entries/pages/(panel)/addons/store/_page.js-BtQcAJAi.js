import { l as load$1, P as PageTypes } from '../../../../../chunks/StoreLoading.js-DX8sKhLL.js';

//#region src/routes/(panel)/addons/store/+page.js
/**
* @type {import('@sveltejs/kit').PageLoad}
*/
async function load(params) {
	return load$1(params, PageTypes.ADDON);
}

var _page = /*#__PURE__*/Object.freeze({
	__proto__: null,
	load: load
});

export { _page as _ };
//# sourceMappingURL=_page.js-BtQcAJAi.js.map
