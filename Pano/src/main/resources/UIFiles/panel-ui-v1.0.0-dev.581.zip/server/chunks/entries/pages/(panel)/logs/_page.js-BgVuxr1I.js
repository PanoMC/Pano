import { l as load } from '../../../../chunks/ActivityLogs.js-CgEdvaRe.js';

var _page = /*#__PURE__*/Object.freeze({
	__proto__: null,
	load: load
});

export { _page as _ };
//# sourceMappingURL=_page.js-BgVuxr1I.js.map
