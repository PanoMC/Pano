import { l as load } from '../../../../chunks/MigrationLayout.js-BQMl41SU.js';

var _layout = /*#__PURE__*/Object.freeze({
	__proto__: null,
	load: load
});

export { _layout as _ };
//# sourceMappingURL=_layout.js-B52FAgzH.js.map
