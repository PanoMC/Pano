import { O as bind_props, W as slot } from '../../../../chunks/index-server.js-DdhL7Abu.js';
import { a as MigrationLayout } from '../../../../chunks/MigrationLayout.js-BQMl41SU.js';
import '../../../../chunks/rolldown-runtime.js-BMnQIuNT.js';
import 'node:module';
import '../../../../chunks/uneval.js-BAGiwb_L.js';
import '../../../../chunks/exports2.js-VkmSkXbz.js';
import '../../../../chunks/shared.js-B3c7sR3F.js';
import '../../../../chunks/internal.js-BRN1McAa.js';
import '../../../../chunks/server.js-BlClO2ED.js';
import '../../../../chunks/internal2.js-CNe5OZUJ.js';
import '../../../../chunks/routing.js-N-OPb2ye.js';
import '../../../../chunks/runtime.js-BzHEw_ze.js';
import '../../../../chunks/auth.util.js-C77uoaNq.js';
import '../../../../chunks/stores.js-D5xmrOAP.js';
import '../../../../chunks/exports.js-BxqLZ-Bq.js';
import '../../../../chunks/PageActions.js-co-RIHDp.js';
import '../../../../chunks/PageNav.js-Bzzuwwjz.js';

//#region src/routes/(panel)/migration/+layout.svelte
function _layout($$renderer, $$props) {
	let data = $$props["data"];
	MigrationLayout($$renderer, {
		data,
		children: ($$renderer) => {
			$$renderer.push(`<!--[-->`);
			slot($$renderer, $$props, "default", {}, null);
			$$renderer.push(`<!--]-->`);
		},
		$$slots: { default: true }
	});
	bind_props($$props, { data });
}

export { _layout as default };
//# sourceMappingURL=_layout.svelte.js-l4xWiLIB.js.map
