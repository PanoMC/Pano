import 'node:module';
import { M as MigrationServer } from '../../../../chunks/MigrationServer.js-Bt-7XZeK.js';
import '../../../../chunks/index-server.js-DdhL7Abu.js';
import '../../../../chunks/rolldown-runtime.js-BMnQIuNT.js';
import '../../../../chunks/uneval.js-BAGiwb_L.js';
import '../../../../chunks/Store.js-DT3aZHRb.js';
import '../../../../chunks/stores.js-D5xmrOAP.js';
import '../../../../chunks/shared.js-B3c7sR3F.js';
import '../../../../chunks/exports.js-BxqLZ-Bq.js';
import '../../../../chunks/routing.js-N-OPb2ye.js';
import '../../../../chunks/server.js-BlClO2ED.js';
import '../../../../chunks/internal2.js-CNe5OZUJ.js';
import '../../../../chunks/ToastContainer.js-Bv1jJ2dr.js';
import '../../../../chunks/runtime.js-BzHEw_ze.js';
import '../../../../chunks/DragAndDropZone.js-DkRk4oSS.js';
import '../../../../chunks/NoContent.js-Coj2fA9d.js';
import '../../../../chunks/SearchInput.js-DPW0WADK.js';
import '../../../../chunks/CardHeader.js-XBureLRg.js';
import '../../../../chunks/Pagination.js-sd1xTcbW.js';

//#region src/routes/(panel)/migration/+page.svelte
function _page($$renderer) {
	MigrationServer($$renderer);
}

export { _page as default };
//# sourceMappingURL=_page.svelte.js-B2FxICG7.js.map
