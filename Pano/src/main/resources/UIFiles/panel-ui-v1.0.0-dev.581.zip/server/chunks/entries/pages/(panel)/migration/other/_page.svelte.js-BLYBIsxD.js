import { O as bind_props } from '../../../../../chunks/index-server.js-DdhL7Abu.js';
import { M as MigrationPlatforms } from '../../../../../chunks/MigrationPlatforms.js-QRgB5C5G.js';
import '../../../../../chunks/rolldown-runtime.js-BMnQIuNT.js';
import 'node:module';
import '../../../../../chunks/uneval.js-BAGiwb_L.js';
import '../../../../../chunks/runtime.js-BzHEw_ze.js';
import '../../../../../chunks/NoContent.js-Coj2fA9d.js';

//#region src/routes/(panel)/migration/other/+page.svelte
function _page($$renderer, $$props) {
	let data = $$props["data"];
	MigrationPlatforms($$renderer);
	bind_props($$props, { data });
}

export { _page as default };
//# sourceMappingURL=_page.svelte.js-BLYBIsxD.js.map
