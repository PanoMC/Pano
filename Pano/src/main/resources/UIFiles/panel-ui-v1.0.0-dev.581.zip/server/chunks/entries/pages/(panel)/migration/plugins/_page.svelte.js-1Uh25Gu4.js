import { O as bind_props, J as getContext, Z as escape_html, Q as store_get, N as fallback, U as stringify, T as attr, $ as attr_style, P as ensure_array_like, S as unsubscribe_stores, V as attr_class, a1 as clsx } from '../../../../../chunks/index-server.js-DdhL7Abu.js';
import { b as ApiUtil } from '../../../../../chunks/Store.js-DT3aZHRb.js';
import { $ as $format } from '../../../../../chunks/runtime.js-BzHEw_ze.js';
import '../../../../../chunks/tooltip.util.js-BeLZL-Tj.js';
import { D as DragAndDropZone } from '../../../../../chunks/DragAndDropZone.js-DkRk4oSS.js';
import { N as NoContent } from '../../../../../chunks/NoContent.js-Coj2fA9d.js';
import { S as SearchInput } from '../../../../../chunks/SearchInput.js-DPW0WADK.js';
import { C as CardHeader } from '../../../../../chunks/CardHeader.js-XBureLRg.js';
import { P as Pagination } from '../../../../../chunks/Pagination.js-sd1xTcbW.js';
import { P as PageActions } from '../../../../../chunks/PageActions.js-co-RIHDp.js';
import '../../../../../chunks/rolldown-runtime.js-BMnQIuNT.js';
import 'node:module';
import '../../../../../chunks/uneval.js-BAGiwb_L.js';
import '../../../../../chunks/stores.js-D5xmrOAP.js';
import '../../../../../chunks/shared.js-B3c7sR3F.js';
import '../../../../../chunks/exports.js-BxqLZ-Bq.js';
import '../../../../../chunks/routing.js-N-OPb2ye.js';
import '../../../../../chunks/server.js-BlClO2ED.js';
import '../../../../../chunks/internal2.js-CNe5OZUJ.js';
import '../../../../../chunks/ToastContainer.js-Bv1jJ2dr.js';

//#region src/lib/pages/settings/migration/AuthMeMigration.svelte
function AuthMeMigration($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let filteredUsers, paginatedUsers, totalPages, filteredPanoOnlyUsers;
		const mockConfigFile = new File(["backend: SQLITE\n"], "config.yml", { type: "application/x-yaml" });
		Object.defineProperty(mockConfigFile, "size", { value: 2457 });
		const mockDbFile = new File([""], "authme.db", { type: "application/x-sqlite3" });
		Object.defineProperty(mockDbFile, "size", { value: 51200 });
		let configFile = fallback($$props["configFile"], null);
		let dbFile = fallback($$props["dbFile"], null);
		let showDatabaseUpload = fallback($$props["showDatabaseUpload"], false);
		let detectedBackend = fallback($$props["detectedBackend"], "");
		let dbConnectionInfo = fallback($$props["dbConnectionInfo"], null);
		let isProcessing = fallback($$props["isProcessing"], false);
		let uploadProgress = fallback($$props["uploadProgress"], 0);
		let currentStep = fallback($$props["currentStep"], "upload");
		let previewData = fallback($$props["previewData"], null);
		let selectedUsers = fallback($$props["selectedUsers"], () => /* @__PURE__ */ new Set(), true);
		let deleteUsers = fallback($$props["deleteUsers"], () => /* @__PURE__ */ new Set(), true);
		let passwordStrategy = fallback($$props["passwordStrategy"], "hash");
		let existingUserUpdates = fallback($$props["existingUserUpdates"], () => ({
			password: false,
			username: false,
			email: false
		}), true);
		let isImporting = fallback($$props["isImporting"], false);
		let importProgress = fallback($$props["importProgress"], 0);
		let importResult = fallback($$props["importResult"], null);
		let uploadError = fallback($$props["uploadError"], null);
		let importSearchQuery = fallback($$props["importSearchQuery"], "");
		let deleteSearchQuery = fallback($$props["deleteSearchQuery"], "");
		let currentPage = 1;
		let itemsPerPage = 10;
		async function uploadAndPreview() {
			isProcessing = true;
			uploadProgress = 0;
			uploadError = null;
			try {
				const formData = new FormData();
				formData.append("config", configFile);
				if (dbFile) formData.append("database", dbFile);
				if (dbConnectionInfo) {
					formData.append("dbHost", dbConnectionInfo.host);
					formData.append("dbPort", dbConnectionInfo.port);
					formData.append("dbName", dbConnectionInfo.database);
					formData.append("dbTable", dbConnectionInfo.table);
					formData.append("dbUser", dbConnectionInfo.username);
					formData.append("dbPassword", dbConnectionInfo.password);
				}
				const result = await ApiUtil.post({
					path: "/api/panel/migration/authme/upload",
					body: formData,
					onUploadProgress: (progress) => {
						uploadProgress = progress;
					}
				});
				if (result?.result === "error") {
					uploadError = result.message || result.error || store_get($$store_subs ??= {}, "$_", $format)("pages.migration.authme.error-upload-failed");
					return;
				}
				if (result) {
					previewData = result;
					selectedUsers = /* @__PURE__ */ new Set();
					result.users.forEach((user) => {
						if (user.status === "new") selectedUsers.add(user.username);
					});
					selectedUsers = selectedUsers;
					currentStep = "review";
				}
			} catch (error) {
				uploadError = error.message || store_get($$store_subs ??= {}, "$_", $format)("pages.migration.authme.error-upload-failed");
			} finally {
				isProcessing = false;
			}
		}
		async function importUsers() {
			isImporting = true;
			importProgress = 0;
			const totalActions = selectedUsers.size + deleteUsers.size;
			const progressInterval = setInterval(() => {
				if (importProgress < .9) importProgress += .05;
			}, Math.max(100, totalActions * 10));
			try {
				const result = await ApiUtil.post({
					path: "/api/panel/migration/authme/import",
					body: {
						usernames: Array.from(selectedUsers),
						deleteUsernames: Array.from(deleteUsers),
						passwordStrategy,
						existingUserUpdates
					}
				});
				clearInterval(progressInterval);
				importProgress = 1;
				if (result?.result === "error") {
					uploadError = result.message || result.error || store_get($$store_subs ??= {}, "$_", $format)("pages.migration.authme.error-import-failed");
					return;
				}
				if (result) {
					importResult = result;
					currentStep = "result";
				}
			} catch (error) {
				clearInterval(progressInterval);
				uploadError = error.message || store_get($$store_subs ??= {}, "$_", $format)("pages.migration.authme.error-import-failed");
			} finally {
				isImporting = false;
			}
		}
		function resetForm() {
			configFile = null;
			dbFile = null;
			showDatabaseUpload = false;
			detectedBackend = "";
			dbConnectionInfo = null;
			isProcessing = false;
			uploadProgress = 0;
			currentStep = "upload";
			previewData = null;
			selectedUsers = /* @__PURE__ */ new Set();
			deleteUsers = /* @__PURE__ */ new Set();
			passwordStrategy = "hash";
			existingUserUpdates = {
				password: false,
				username: false,
				email: false
			};
			isImporting = false;
			importProgress = 0;
			importResult = null;
			uploadError = null;
			importSearchQuery = "";
			deleteSearchQuery = "";
		}
		if (importSearchQuery) currentPage = 1;
		filteredUsers = previewData?.users?.filter((u) => {
			if (!importSearchQuery.trim()) return true;
			const q = importSearchQuery.toLowerCase();
			return (u.username || "").toLowerCase().includes(q) || (u.realName || "").toLowerCase().includes(q) || (u.email || "").toLowerCase().includes(q);
		}) ?? [];
		paginatedUsers = filteredUsers.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);
		totalPages = Math.ceil(filteredUsers.length / itemsPerPage);
		filteredPanoOnlyUsers = previewData?.panoOnlyUsers?.filter((u) => {
			if (!deleteSearchQuery.trim()) return true;
			const q = deleteSearchQuery.toLowerCase();
			return (u.username || "").toLowerCase().includes(q) || (u.email || "").toLowerCase().includes(q);
		}) ?? [];
		if (currentStep === "upload") {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<div class="alert alert-info mb-3"><i class="fas fa-info-circle me-1"></i> <strong>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.authme.supported-info-title"))}</strong> <ul class="mb-0 mt-1"><li>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.authme.supported-backends"))}</li> <li>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.authme.supported-hashes"))}</li> <li>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.authme.unsupported-note"))}</li></ul></div> <label class="form-label" for="uploadConfig">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.authme.upload-config"))}</label> `);
			if (configFile) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<div class="position-relative">`);
				DragAndDropZone($$renderer, {
					id: "uploadConfig",
					accept: [".yml", ".yaml"],
					icon: "fas fa-file-alt fs-1",
					title: configFile.name,
					subtitle: `${stringify((configFile.size / 1024).toFixed(2))} KB`
				});
				$$renderer.push(`<!----> <button class="btn-close position-absolute top-0 end-0 m-2"${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("buttons.remove"))}${attr("title", store_get($$store_subs ??= {}, "$_", $format)("buttons.remove"))}></button></div>`);
			} else {
				$$renderer.push("<!--[-1-->");
				DragAndDropZone($$renderer, {
					id: "uploadConfig",
					accept: [".yml", ".yaml"],
					title: store_get($$store_subs ??= {}, "$_", $format)("pages.migration.authme.drag-drop-file"),
					subtitle: store_get($$store_subs ??= {}, "$_", $format)("pages.migration.authme.click-to-browse")
				});
			}
			$$renderer.push(`<!--]--> `);
			if (showDatabaseUpload) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<div class="mt-3"><label class="form-label" for="uploadDb">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.authme.upload-db"))}</label> <div class="alert alert-warning"><i class="fas fa-info-circle me-1"></i> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.authme.sqlite-detected-note"))}</div> `);
				if (dbFile) {
					$$renderer.push("<!--[0-->");
					$$renderer.push(`<div class="position-relative">`);
					DragAndDropZone($$renderer, {
						id: "uploadDb",
						accept: [
							".db",
							".sqlite",
							".sqlite3"
						],
						icon: "fas fa-database fa-lg",
						title: dbFile.name,
						subtitle: `${stringify((dbFile.size / 1024).toFixed(2))} KB`
					});
					$$renderer.push(`<!----> <button class="btn-close position-absolute top-0 end-0 m-2"${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("buttons.remove"))}${attr("title", store_get($$store_subs ??= {}, "$_", $format)("buttons.remove"))}></button></div>`);
				} else {
					$$renderer.push("<!--[-1-->");
					DragAndDropZone($$renderer, {
						id: "uploadDb",
						accept: [
							".db",
							".sqlite",
							".sqlite3"
						],
						title: store_get($$store_subs ??= {}, "$_", $format)("pages.migration.authme.drag-drop-file"),
						subtitle: store_get($$store_subs ??= {}, "$_", $format)("pages.migration.authme.click-to-browse")
					});
				}
				$$renderer.push(`<!--]--></div>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--> `);
			if (configFile && dbConnectionInfo) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<div class="card mb-3 border-warning"><div class="card-header bg-warning"><strong>${escape_html(detectedBackend)}</strong> — ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.authme.db-connect-info"))}</div> <div class="card-body py-3"><div class="row g-2 mb-2"><div class="col-12 col-sm-8"><label class="form-label small mb-1" for="dbHost">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.authme.host"))}</label> <input type="text" class="form-control form-control-sm" id="dbHost"${attr("value", dbConnectionInfo.host)}/></div> <div class="col-12 col-sm-4"><label class="form-label small mb-1" for="dbPort">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.authme.port"))}</label> <input type="text" class="form-control form-control-sm" id="dbPort"${attr("value", dbConnectionInfo.port)}/></div></div> <div class="row g-2 mb-2"><div class="col-12 col-sm-6"><label class="form-label small mb-1" for="dbName">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.authme.database"))}</label> <input type="text" class="form-control form-control-sm" id="dbName"${attr("value", dbConnectionInfo.database)}/></div> <div class="col-12 col-sm-6"><label class="form-label small mb-1" for="dbTable">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.authme.table"))}</label> <input type="text" class="form-control form-control-sm" id="dbTable"${attr("value", dbConnectionInfo.table)}/></div></div> <div class="row g-2"><div class="col-12 col-sm-6"><label class="form-label small mb-1" for="dbUser">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.authme.username"))}</label> <input type="text" class="form-control form-control-sm" id="dbUser"${attr("value", dbConnectionInfo.username)}/></div> <div class="col-12 col-sm-6"><label class="form-label small mb-1" for="dbPass">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.authme.password"))}</label> <input type="password" class="form-control form-control-sm" id="dbPass"${attr("value", dbConnectionInfo.password)}/></div></div></div></div>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--> `);
			if (isProcessing) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<div class="mt-3"><div class="d-flex justify-content-between mb-1"><small>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.authme.uploading-processing"))}</small> <small>${escape_html(Math.round(uploadProgress * 100))}%</small></div> <div class="progress" style="height: 6px;"><div class="progress-bar progress-bar-striped progress-bar-animated" role="progressbar"${attr_style(`width: ${stringify(uploadProgress * 100)}%`)}${attr("aria-valuenow", Math.round(uploadProgress * 100))} aria-valuemin="0" aria-valuemax="100"></div></div></div>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--> `);
			if (uploadError) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<div class="alert alert-danger mt-3" role="alert"><i class="fas fa-exclamation-triangle me-2"></i> ${escape_html(uploadError)}</div>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]-->`);
		} else if (currentStep === "review") {
			$$renderer.push("<!--[1-->");
			if (previewData.users.some((u) => u.passwordType === "PLAINTEXT" || u.passwordType === "UNKNOWN")) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<div class="row align-items-center mb-3"><div class="col-9"><label class="fw-bold mb-0" for="strategyHash">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.authme.strategy-hash"))} <span class="badge text-bg-success ms-1">${escape_html(previewData.defaultHashAlgorithm)}</span></label> <small class="d-block text-muted">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.authme.strategy-hash-desc"))}</small></div> <div class="col-3 text-end"><div class="form-check form-check-inline me-0"><input class="form-check-input" type="radio" name="passwordStrategy" id="strategyHash" value="hash"${attr("checked", passwordStrategy === "hash", true)}/></div></div></div> <div class="row align-items-center"><div class="col-9"><label class="fw-bold mb-0" for="strategyReset">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.authme.strategy-reset"))}</label> <small class="d-block text-muted">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.authme.strategy-reset-desc"))}</small></div> <div class="col-3 text-end"><div class="form-check form-check-inline me-0"><input class="form-check-input" type="radio" name="passwordStrategy" id="strategyReset" value="reset"${attr("checked", passwordStrategy === "reset", true)}/></div></div></div> <hr/>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--> `);
			if (previewData.existingCount > 0) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<div class="row align-items-center mb-3"><div class="col-9"><label class="fw-bold mb-0" for="updatePassword">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.authme.update-password"))}</label> <small class="d-block text-muted">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.authme.update-password-desc"))}</small></div> <div class="col-3 text-end"><div class="form-check form-switch d-inline-block"><input class="form-check-input" type="checkbox" role="switch" id="updatePassword"${attr("checked", existingUserUpdates.password, true)}/></div></div></div> <div class="row align-items-center mb-3"><div class="col-9"><label class="fw-bold mb-0" for="updateUsername">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.authme.update-username"))}</label> <small class="d-block text-muted">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.authme.update-username-desc"))}</small></div> <div class="col-3 text-end"><div class="form-check form-switch d-inline-block"><input class="form-check-input" type="checkbox" role="switch" id="updateUsername"${attr("checked", existingUserUpdates.username, true)}/></div></div></div> <div class="row align-items-center"><div class="col-9"><label class="fw-bold mb-0" for="updateEmail">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.authme.update-email"))}</label> <small class="d-block text-muted">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.authme.update-email-desc"))}</small></div> <div class="col-3 text-end"><div class="form-check form-switch d-inline-block"><input class="form-check-input" type="checkbox" role="switch" id="updateEmail"${attr("checked", existingUserUpdates.email, true)}/></div></div></div> <hr/>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--> <div class="alert alert-info mt-3 mb-3"><i class="fas fa-info-circle me-2"></i> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.authme.password-info"))}</div> `);
			if (previewData.users.some((u) => (!u.hasPassword || u.passwordType === "UNKNOWN" || u.passwordType === "PLAINTEXT") && selectedUsers.has(u.username))) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<div class="alert alert-warning mt-2 mb-3"><i class="fas fa-exclamation-triangle me-2"></i> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.authme.no-password-warning"))}</div>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--> <div class="card mb-3">`);
			CardHeader($$renderer, { $$slots: {
				left: ($$renderer) => {
					$$renderer.push(`<div slot="left"><span class="me-3"><strong>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.authme.total-data", { values: { count: previewData.totalCount } }))}</strong></span> <span class="badge text-bg-success me-2">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.authme.new", { values: { count: previewData.newCount } }))}</span> <span class="badge text-bg-warning">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.authme.existing", { values: { count: previewData.existingCount } }))}</span></div>`);
				},
				middle: ($$renderer) => {
					$$renderer.push(`<div slot="middle" style="width: 250px;">`);
					SearchInput($$renderer, {
						placeholderKey: "buttons.find",
						showSpinner: false
					});
					$$renderer.push(`<!----></div>`);
				},
				right: ($$renderer) => {
					$$renderer.push(`<div slot="right" class="d-flex flex-wrap gap-2"><button class="btn btn-link text-decoration-none px-0 px-md-2">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.authme.select-all-new"))}</button></div>`);
				}
			} });
			$$renderer.push(`<!----> <div class="card-body p-0"><div class="table-responsive"><table class="table table-hover mb-0"><thead><tr><th class="align-middle text-nowrap" scope="col" style="width: 40px;"><input type="checkbox" class="form-check-input"${attr("checked", selectedUsers.size === previewData.users.length, true)}/></th><th class="align-middle text-nowrap" scope="col">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.players.table.name"))}</th><th class="align-middle text-nowrap" scope="col">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.authme.email"))}</th><th class="align-middle text-nowrap" scope="col">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.authme.ip"))}</th><th class="align-middle text-nowrap" scope="col">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.authme.status"))}</th><th class="align-middle text-nowrap" scope="col">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.authme.password"))}</th></tr></thead><tbody><!--[-->`);
			const each_array = ensure_array_like(paginatedUsers);
			for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
				let user = each_array[$$index];
				$$renderer.push(`<tr><td><input type="checkbox" class="form-check-input"${attr("checked", selectedUsers.has(user.username), true)}/></td><td class="fw-semibold">${escape_html(user.realName || user.username)}</td><td><span class="user-select-all">${escape_html(user.email || "-")}</span></td><td><code class="user-select-all">${escape_html(user.ip || "-")}</code></td><td>`);
				if (user.status === "new") {
					$$renderer.push("<!--[0-->");
					$$renderer.push(`<span class="badge text-bg-success">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.authme.status-new"))}</span>`);
				} else {
					$$renderer.push("<!--[-1-->");
					$$renderer.push(`<span class="badge text-bg-warning">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.authme.status-existing"))}</span>`);
				}
				$$renderer.push(`<!--]--></td><td>`);
				if (user.hasPassword && user.passwordType) {
					$$renderer.push("<!--[0-->");
					$$renderer.push(`<span class="fw-bold fs-7">${escape_html(user.passwordType)}</span>`);
				} else if (user.hasPassword) {
					$$renderer.push("<!--[1-->");
					$$renderer.push(`<i class="fas fa-check text-success"></i>`);
				} else {
					$$renderer.push("<!--[-1-->");
					$$renderer.push(`<span class="badge text-bg-danger">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.authme.none"))}</span>`);
				}
				$$renderer.push(`<!--]--></td></tr>`);
			}
			$$renderer.push(`<!--]--></tbody></table></div></div> <div class="card-footer">`);
			Pagination($$renderer, {
				page: currentPage,
				totalPage: totalPages
			});
			$$renderer.push(`<!----></div></div> `);
			if (previewData.panoOnlyUsers && previewData.panoOnlyUsers.length > 0) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<div class="card mt-3">`);
				CardHeader($$renderer, { $$slots: {
					left: ($$renderer) => {
						$$renderer.push(`<div slot="left"><strong>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.authme.pano-only-title", { values: { count: previewData.panoOnlyUsers.length } }))}</strong></div>`);
					},
					middle: ($$renderer) => {
						$$renderer.push(`<div slot="middle" style="width: 250px;">`);
						SearchInput($$renderer, {
							placeholderKey: "buttons.find",
							showSpinner: false
						});
						$$renderer.push(`<!----></div>`);
					},
					right: ($$renderer) => {
						$$renderer.push(`<div slot="right"></div>`);
					}
				} });
				$$renderer.push(`<!----> <div class="card-body p-0"><div class="table-responsive"><table class="table table-hover mb-0"><thead><tr><th class="align-middle text-nowrap" scope="col" style="width: 40px;"><input type="checkbox" class="form-check-input"${attr("checked", deleteUsers.size === previewData.panoOnlyUsers.length, true)}/></th><th class="align-middle text-nowrap" scope="col">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.players.table.name"))}</th><th class="align-middle text-nowrap" scope="col">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.authme.email"))}</th></tr></thead><tbody><!--[-->`);
				const each_array_1 = ensure_array_like(filteredPanoOnlyUsers);
				for (let $$index_1 = 0, $$length = each_array_1.length; $$index_1 < $$length; $$index_1++) {
					let user = each_array_1[$$index_1];
					$$renderer.push(`<tr><td><input type="checkbox" class="form-check-input"${attr("checked", deleteUsers.has(user.username), true)}/></td><td>${escape_html(user.username)}</td><td>${escape_html(user.email || "-")}</td></tr>`);
				}
				$$renderer.push(`<!--]--></tbody></table></div></div> <div class="card-footer"><small class="text-danger"><i class="fas fa-exclamation-triangle me-1"></i> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.authme.pano-only-warning"))}</small></div></div>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--> `);
			if (isImporting) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<div class="mt-3"><div class="d-flex justify-content-between mb-1"><small>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.authme.importing-status", { values: { count: selectedUsers.size } }))} `);
				if (deleteUsers.size > 0) {
					$$renderer.push("<!--[0-->");
					$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.authme.deleting-status", { values: { count: deleteUsers.size } }))}`);
				} else $$renderer.push("<!--[-1-->");
				$$renderer.push(`<!--]-->...</small> <small>${escape_html(Math.round(importProgress * 100))}%</small></div> <div class="progress" style="height: 6px;"><div class="progress-bar progress-bar-striped progress-bar-animated bg-success" role="progressbar"${attr_style(`width: ${stringify(importProgress * 100)}%`)}${attr("aria-valuenow", Math.round(importProgress * 100))} aria-valuemin="0" aria-valuemax="100"></div></div></div>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--> <div class="mt-4 d-flex gap-2"><button class="btn btn-secondary"${attr("disabled", selectedUsers.size === 0 && deleteUsers.size === 0 || isImporting, true)}>`);
			if (isImporting) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<span class="spinner-border spinner-border-sm me-2" role="status"></span>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.import"))}</button> <button class="btn btn-link text-decoration-none"${attr("disabled", isImporting, true)}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.cancel"))}</button></div>`);
		} else if (currentStep === "result" && importResult) {
			$$renderer.push("<!--[2-->");
			$$renderer.push(`<div class="alert alert-success d-flex align-items-center" role="alert"><i class="fas fa-check-circle fs-4 me-3"></i> <div><h6 class="alert-heading mb-1">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.authme.result-title"))}</h6> <p class="mb-0 small"><strong>${escape_html(importResult.importedCount)}</strong> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.authme.result-imported"))}`);
			if (importResult.updatedCount > 0) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`, <strong>${escape_html(importResult.updatedCount)}</strong> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.authme.result-updated"))}`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]-->`);
			if (importResult.deletedCount > 0) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`, <strong>${escape_html(importResult.deletedCount)}</strong> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.authme.result-deleted"))}`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]-->.</p></div></div> `);
			if (importResult?.errors && importResult.errors.length > 0) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<div class="alert alert-warning mt-3"><h6 class="alert-heading mb-2"><i class="fas fa-exclamation-triangle me-1"></i> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.authme.some-issues-occurred"))}</h6> <ul class="mb-0 small"><!--[-->`);
				const each_array_2 = ensure_array_like(importResult.errors);
				for (let $$index_2 = 0, $$length = each_array_2.length; $$index_2 < $$length; $$index_2++) {
					let err = each_array_2[$$index_2];
					$$renderer.push(`<li><strong>${escape_html(err.item)}</strong>: ${escape_html(err.error)}</li>`);
				}
				$$renderer.push(`<!--]--></ul></div>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--> <button class="btn btn-primary"><i class="fas fa-redo me-2"></i> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.authme.start-new-migration"))}</button>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]-->`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
		bind_props($$props, {
			configFile,
			dbFile,
			showDatabaseUpload,
			detectedBackend,
			dbConnectionInfo,
			isProcessing,
			uploadProgress,
			currentStep,
			previewData,
			selectedUsers,
			deleteUsers,
			passwordStrategy,
			existingUserUpdates,
			isImporting,
			importProgress,
			importResult,
			uploadError,
			importSearchQuery,
			deleteSearchQuery,
			resetForm,
			importUsers,
			uploadAndPreview
		});
	});
}
//#endregion
//#region src/lib/pages/settings/migration/LuckPermsNodeTable.svelte
function LuckPermsNodeTable($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let totalPages, pagedNodes;
		let nodes = fallback($$props["nodes"], () => [], true);
		let mergeStrategy = fallback($$props["mergeStrategy"], "merge");
		let nodesPerPage = 10;
		let page = 1;
		function isValidContext(contexts) {
			if (!contexts || !contexts.trim()) return true;
			try {
				const parsed = JSON.parse(contexts);
				return parsed !== null && typeof parsed === "object" && !Array.isArray(parsed);
			} catch {
				return false;
			}
		}
		function baseline(node) {
			return node._incomingSnapshot ?? node._before;
		}
		function isEdited(node) {
			const before = baseline(node);
			if (!before) return false;
			return before.permission !== node.permission || before.value !== node.value || before.server !== node.server || before.world !== node.world || String(before.contexts) !== String(node.contexts);
		}
		function nodeEffect(node) {
			if (node._origin === "added") return "added";
			if (isEdited(node)) return "edited";
			if (mergeStrategy === "replace" && node._panoNodeId != null && !node._incoming) return "deleted";
			if (node._implied && node.value) return "implied";
			if (!node._incoming) return "unchanged";
			return node._before ? "overwrite" : "new";
		}
		function effectBadgeClass(effect) {
			switch (effect) {
				case "new": return "text-bg-success";
				case "overwrite": return "text-bg-warning";
				case "deleted": return "text-bg-danger";
				case "added":
				case "edited": return "lp-badge-edited";
				default: return "text-bg-secondary";
			}
		}
		const pageSizeOptions = [
			10,
			20,
			50,
			100,
			1e3
		];
		totalPages = Math.max(1, Math.ceil(nodes.length / nodesPerPage));
		if (page > totalPages) page = totalPages;
		pagedNodes = nodes.slice((page - 1) * nodesPerPage, page * nodesPerPage);
		$$renderer.push(`<table class="table table-sm mb-0 small align-middle"><thead><tr class="opacity-75"><th>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.luckperms.header-permission"))}</th><th style="width: 70px;">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.luckperms.header-value"))}</th><th style="width: 110px;">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.luckperms.header-server"))}</th><th style="width: 110px;">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.luckperms.header-world"))}</th><th style="width: 140px;">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.luckperms.header-context"))}</th><th style="width: 130px;">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.luckperms.header-effect"))}</th><th style="width: 40px;"></th></tr></thead><tbody><!--[-->`);
		const each_array = ensure_array_like(pagedNodes);
		for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
			let node = each_array[$$index];
			const effect = nodeEffect(node);
			$$renderer.push(`<tr${attr_class("svelte-pd3713", void 0, {
				"lp-row-new": effect === "new",
				"lp-row-overwrite": effect === "overwrite",
				"lp-row-edited": effect === "added" || effect === "edited",
				"lp-row-deleted": effect === "deleted"
			})}><td><input${attr_class("form-control form-control-sm font-monospace", void 0, { "is-invalid": !node.permission?.trim() })}${attr("placeholder", store_get($$store_subs ??= {}, "$_", $format)("pages.migration.luckperms.node-permission-placeholder"))}${attr("value", node.permission)}/> `);
			if (node._before && node._before.permission !== node.permission) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<div class="opacity-75 mt-1"><i class="fas fa-arrow-right-arrow-left me-1"></i> <code>${escape_html(node._before.permission)}</code></div>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--></td><td><div class="form-check form-switch mb-0"><input class="form-check-input" type="checkbox" role="switch"${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("pages.migration.luckperms.header-value"))}${attr("checked", node.value, true)}/></div> `);
			if (node._before && node._before.value !== node.value) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<div class="opacity-75 mt-1">${escape_html(node._before.value ? store_get($$store_subs ??= {}, "$_", $format)("buttons.yes") : store_get($$store_subs ??= {}, "$_", $format)("buttons.no"))} <i class="fas fa-arrow-right ms-1"></i></div>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--></td><td><input class="form-control form-control-sm"${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("pages.migration.luckperms.header-server"))}${attr("value", node.server)}/></td><td><input class="form-control form-control-sm"${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("pages.migration.luckperms.header-world"))}${attr("value", node.world)}/></td><td><input${attr_class("form-control form-control-sm font-monospace", void 0, { "is-invalid": !isValidContext(node.contexts) })}${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("pages.migration.luckperms.header-context"))} placeholder="{}"${attr("value", node.contexts)}/></td><td><span${attr_class(`badge ${effectBadgeClass(effect)}`, "svelte-pd3713")}${attr("title", effect === "implied" ? store_get($$store_subs ??= {}, "$_", $format)("pages.migration.luckperms.node-implied-hint") : "")}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)(`pages.migration.luckperms.node-${effect}`))}</span> `);
			if (node._fromPrimaryGroup) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<span class="d-block small opacity-75 mt-1">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.luckperms.node-from-primary-group"))}</span>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--></td><td class="text-end"><button class="btn btn-link text-danger p-0 border-0"${attr("title", store_get($$store_subs ??= {}, "$_", $format)("buttons.remove"))}${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("buttons.remove"))}><i class="fas fa-trash"></i></button></td></tr>`);
		}
		$$renderer.push(`<!--]-->`);
		if (nodes.length === 0) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<tr><td colspan="7" class="text-center opacity-75 py-3">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.luckperms.no-nodes"))}</td></tr>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--></tbody></table> <div class="d-flex flex-wrap align-items-center justify-content-between gap-2 mt-2"><button class="btn btn-link text-decoration-none px-0"><i class="fas fa-plus me-1"></i>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.luckperms.add-node"))}</button> <div class="d-flex align-items-center gap-2">`);
		if (nodes.length > pageSizeOptions[0]) {
			$$renderer.push("<!--[0-->");
			$$renderer.select({
				class: "form-select form-select-sm w-auto",
				value: nodesPerPage,
				"aria-label": store_get($$store_subs ??= {}, "$_", $format)("pages.migration.luckperms.per-page")
			}, ($$renderer) => {
				$$renderer.push(`<!--[-->`);
				const each_array_1 = ensure_array_like(pageSizeOptions);
				for (let $$index_1 = 0, $$length = each_array_1.length; $$index_1 < $$length; $$index_1++) {
					let size = each_array_1[$$index_1];
					$$renderer.option({ value: size }, ($$renderer) => {
						$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.luckperms.per-page-option", { values: { count: size } }))}`);
					});
				}
				$$renderer.push(`<!--]-->`);
			});
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--> `);
		if (totalPages > 1) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<button class="btn btn-sm btn-outline-secondary"${attr("disabled", page <= 1, true)}${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("buttons.previous"))}><i class="fas fa-chevron-left"></i></button> <small class="opacity-75">${escape_html(page)} / ${escape_html(totalPages)}</small> <button class="btn btn-sm btn-outline-secondary"${attr("disabled", page >= totalPages, true)}${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("buttons.next"))}><i class="fas fa-chevron-right"></i></button>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--></div></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
		bind_props($$props, {
			nodes,
			mergeStrategy
		});
	});
}
//#endregion
//#region src/lib/pages/settings/migration/LuckPermsMigration.svelte
function LuckPermsMigration($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let filteredGroups, totalGroupPages, paginatedGroups, filteredPlayers, totalPlayerPages, paginatedPlayers, filteredTracks, totalTrackPages, paginatedTracks, missingPlayers, creatablePlayers, incompleteNodeCount, invalidUsernameCount;
		let configFile = fallback($$props["configFile"], null);
		let dbFile = fallback($$props["dbFile"], null);
		let showDatabaseUpload = fallback($$props["showDatabaseUpload"], false);
		let detectedBackend = fallback($$props["detectedBackend"], "");
		let dbConnectionInfo = fallback($$props["dbConnectionInfo"], null);
		let isProcessing = fallback($$props["isProcessing"], false);
		let uploadProgress = fallback($$props["uploadProgress"], 0);
		let currentStep = fallback($$props["currentStep"], "upload");
		let previewData = fallback($$props["previewData"], null);
		let selectedGroups = fallback($$props["selectedGroups"], () => /* @__PURE__ */ new Set(), true);
		let selectedTracks = fallback($$props["selectedTracks"], () => /* @__PURE__ */ new Set(), true);
		let mergeStrategy = fallback($$props["mergeStrategy"], "merge");
		let importUserPermissions = fallback($$props["importUserPermissions"], true);
		let createMissingPlayers = fallback($$props["createMissingPlayers"], true);
		let isImporting = fallback($$props["isImporting"], false);
		let importProgress = fallback($$props["importProgress"], 0);
		let importResult = fallback($$props["importResult"], null);
		let uploadError = fallback($$props["uploadError"], null);
		let expandedGroups = fallback($$props["expandedGroups"], () => /* @__PURE__ */ new Set(), true);
		let expandedPlayers = fallback($$props["expandedPlayers"], () => /* @__PURE__ */ new Set(), true);
		let expandedTracks = fallback($$props["expandedTracks"], () => /* @__PURE__ */ new Set(), true);
		let trackChains = {};
		let trackDescriptions = {};
		let trackGroupToAdd = "";
		let groupNodes = {};
		let userNodes = {};
		let removedEdits = [];
		let existingNodeDeletions = [];
		let playerUsernames = {};
		let skippedPlayers = /* @__PURE__ */ new Set();
		let nodeSeq = 0;
		let groupSearchQuery = fallback($$props["groupSearchQuery"], "");
		let groupPage = 1;
		const pageSizeOptions = [
			10,
			20,
			50,
			100,
			1e3
		];
		let groupsPerPage = 10;
		let tracksPerPage = 10;
		let playersPerPage = 10;
		let playerSearchQuery = fallback($$props["playerSearchQuery"], "");
		let playerPage = 1;
		let trackSearchQuery = fallback($$props["trackSearchQuery"], "");
		let trackPage = 1;
		async function uploadAndPreview() {
			isProcessing = true;
			uploadProgress = 0;
			uploadError = null;
			try {
				const formData = new FormData();
				formData.append("config", configFile);
				if (dbFile) formData.append("database", dbFile);
				if (dbConnectionInfo) {
					formData.append("dbHost", dbConnectionInfo.host);
					formData.append("dbPort", dbConnectionInfo.port);
					formData.append("dbName", dbConnectionInfo.database);
					formData.append("dbUser", dbConnectionInfo.username);
					formData.append("dbPassword", dbConnectionInfo.password);
					formData.append("dbTablePrefix", dbConnectionInfo.tablePrefix);
				}
				const result = await ApiUtil.post({
					path: "/api/panel/migration/luckperms/upload",
					body: formData,
					onUploadProgress: (progress) => {
						uploadProgress = progress;
					}
				});
				if (result?.result === "error") {
					uploadError = result.message || result.error || store_get($$store_subs ??= {}, "$_", $format)("pages.migration.authme.error-upload-failed");
					return;
				}
				if (result) {
					previewData = result;
					buildEditableNodes(result);
					selectedGroups = new Set(result.groups.map((g) => g.name));
					if (result.tracks) selectedTracks = new Set(result.tracks.map((t) => t.name));
					currentStep = "review";
				}
			} catch (error) {
				uploadError = error.message || store_get($$store_subs ??= {}, "$_", $format)("pages.migration.authme.error-upload-failed");
			} finally {
				isProcessing = false;
			}
		}
		function snapshotOf(node) {
			return {
				permission: node.permission,
				value: node.value,
				server: node.server,
				world: node.world,
				contexts: node.contexts
			};
		}
		function normalise(perm) {
			return {
				permission: perm.permission,
				value: perm.value !== false,
				server: perm.server ?? "global",
				world: perm.world ?? "global",
				expiry: perm.expiry ?? 0,
				contexts: perm.contexts ?? "{}"
			};
		}
		function toPanoRow(node) {
			const row = {
				_id: ++nodeSeq,
				_origin: "pano",
				_panoNodeId: node.id,
				_match: null,
				_incoming: false,
				_implied: false,
				_fromPrimaryGroup: false,
				...normalise(node)
			};
			row._before = snapshotOf(row);
			row._incomingSnapshot = null;
			return row;
		}
		function toIncomingRow(perm) {
			const row = {
				_id: ++nodeSeq,
				_origin: "luckperms",
				_panoNodeId: null,
				_incoming: true,
				_implied: perm.implied === true,
				_fromPrimaryGroup: perm.fromPrimaryGroup === true,
				...normalise(perm)
			};
			row._match = {
				permission: row.permission,
				server: row.server,
				world: row.world,
				expiry: row.expiry,
				contexts: row.contexts
			};
			row._before = null;
			row._incomingSnapshot = snapshotOf(row);
			return row;
		}
		function mergeIncoming(rows, perm) {
			const target = rows.find((row) => row._origin === "pano" && !row._incoming && row.permission === perm.permission);
			if (!target) {
				rows.push(toIncomingRow(perm));
				return;
			}
			Object.assign(target, normalise(perm), {
				_incoming: true,
				_implied: perm.implied === true,
				_fromPrimaryGroup: perm.fromPrimaryGroup === true
			});
			target._match = {
				permission: target.permission,
				server: target.server,
				world: target.world,
				expiry: target.expiry,
				contexts: target.contexts
			};
			target._incomingSnapshot = snapshotOf(target);
		}
		function buildEditableNodes(result) {
			const groups = {};
			const users = {};
			Object.entries(result.existingGroupNodes ?? {}).forEach(([name, nodes]) => {
				groups[name] = nodes.map(toPanoRow);
			});
			(result.groups ?? []).forEach((group) => {
				groups[group.name] ??= [];
			});
			(result.players ?? []).forEach((player) => {
				const existing = result.existingUserNodes?.[player.username.toLowerCase()] ?? [];
				users[player.uuid] = existing.map(toPanoRow);
			});
			(result.groupPermissions ?? []).forEach((perm) => {
				if (!perm.groupName) return;
				groups[perm.groupName] ??= [];
				mergeIncoming(groups[perm.groupName], perm);
			});
			(result.userPermissions ?? []).forEach((perm) => {
				if (!perm.uuid) return;
				users[perm.uuid] ??= [];
				mergeIncoming(users[perm.uuid], perm);
			});
			groupNodes = groups;
			userNodes = users;
			removedEdits = [];
			existingNodeDeletions = [];
			playerUsernames = {};
			skippedPlayers = /* @__PURE__ */ new Set();
			trackChains = {};
			trackDescriptions = {};
		}
		function isNodeEdited(node) {
			const before = node._incomingSnapshot ?? node._before;
			if (!before) return false;
			return before.permission !== node.permission || before.value !== node.value || before.server !== node.server || before.world !== node.world || String(before.contexts) !== String(node.contexts);
		}
		function collectNodeEdits() {
			const edits = removedEdits.map((removed) => ({
				...removed,
				action: "remove"
			}));
			const collect = (holderType, bucket) => {
				Object.entries(bucket).forEach(([holderKey, nodes]) => {
					if (holderType === "USER" && skippedPlayers.has(holderKey)) return;
					nodes.forEach((node) => {
						const permission = node.permission?.trim();
						if (!permission) return;
						const payload = {
							permission,
							value: node.value,
							server: node.server?.trim() || "global",
							world: node.world?.trim() || "global",
							expiry: Number(node.expiry) || 0,
							contexts: node.contexts?.trim() || "{}"
						};
						if (node._origin === "added") {
							edits.push({
								holderType,
								holderKey,
								action: "add",
								node: payload
							});
							return;
						}
						if (!isNodeEdited(node)) return;
						if (node._fromPrimaryGroup) edits.push({
							holderType,
							holderKey,
							action: "add",
							node: payload
						});
						else if (node._match) edits.push({
							holderType,
							holderKey,
							action: "update",
							match: node._match,
							node: payload
						});
						else {
							edits.push({
								holderType,
								holderKey,
								action: "add",
								node: payload
							});
							if (node._panoNodeId != null && !existingNodeDeletions.includes(node._panoNodeId)) existingNodeDeletions = [...existingNodeDeletions, node._panoNodeId];
						}
					});
				});
			};
			collect("GROUP", groupNodes);
			collect("USER", userNodes);
			return edits;
		}
		function playerUsername(player) {
			return playerUsernames[player.uuid] ?? player.username;
		}
		function isPanoOnly(player) {
			return player.inLuckPerms === false;
		}
		function nodeSurvivesImport(node) {
			if (mergeStrategy === "replace" && node._panoNodeId != null && !node._incoming) return false;
			return true;
		}
		function resultingGroup(player) {
			if (skippedPlayers.has(player.uuid)) return player.primaryGroup;
			const node = (userNodes[player.uuid] ?? []).find((n) => n.value && n.permission?.startsWith("group.") && n.permission.length > 6 && nodeSurvivesImport(n));
			return node ? node.permission.slice(6) : "default";
		}
		function playerLosesNodes(player) {
			if (mergeStrategy !== "replace") return false;
			return (userNodes[player.uuid] ?? []).some((n) => !nodeSurvivesImport(n));
		}
		function playerStatus(player) {
			if (!player.existsInPano) return "new";
			const nodes = userNodes[player.uuid] ?? [];
			const changed = nodes.some((node) => node._origin === "added" || node._incoming && node._before || isNodeEdited(node));
			if (playerLosesNodes(player) && !nodes.some((n) => n._incoming)) return "deleted";
			if (isPanoOnly(player)) return changed ? "changed" : "existing";
			return playerUsername(player) !== player.username || changed || playerLosesNodes(player) ? "changed" : "existing";
		}
		function playerBadgeClass(status) {
			switch (status) {
				case "new": return "text-bg-success";
				case "changed": return "text-bg-warning";
				case "deleted": return "text-bg-danger";
				default: return "text-bg-secondary";
			}
		}
		function collectPlayerEdits() {
			return (previewData?.players ?? []).filter((player) => !skippedPlayers.has(player.uuid)).filter((player) => playerUsername(player).trim() !== player.username).map((player) => ({
				uuid: player.uuid,
				username: playerUsername(player).trim()
			}));
		}
		function importableGroups() {
			return (previewData?.groups ?? []).filter((g) => g.inLuckPerms !== false);
		}
		function groupStatus(group) {
			if (group.inLuckPerms === false) return mergeStrategy === "replace" ? "deleted" : "kept";
			if (!selectedGroups.has(group.name)) return "skipped";
			return group.status === "new" ? "new" : "update";
		}
		function importableTracks() {
			return (previewData?.tracks ?? []).filter((t) => t.inLuckPerms !== false);
		}
		function trackStatus(track) {
			if (track.inLuckPerms === false) return mergeStrategy === "replace" ? "deleted" : "kept";
			if (!selectedTracks.has(track.name)) return "skipped";
			return track.status === "new" ? "new" : "update";
		}
		function trackBadgeClass(status) {
			switch (status) {
				case "new": return "text-bg-success";
				case "update": return "text-bg-warning";
				case "deleted": return "text-bg-danger";
				default: return "text-bg-secondary";
			}
		}
		function trackChain(track) {
			return trackChains[track.name] ?? track.groups ?? [];
		}
		function trackDescription(track) {
			return trackDescriptions[track.name] ?? track.existingDescription ?? "";
		}
		function isGroupImportable(name) {
			return (previewData?.groups ?? []).some((g) => g.name === name);
		}
		function collectTrackEdits() {
			return (previewData?.tracks ?? []).filter((track) => selectedTracks.has(track.name)).map((track) => ({
				name: track.name,
				groups: trackChain(track),
				description: trackDescription(track)
			}));
		}
		async function importData() {
			isImporting = true;
			importProgress = 0;
			uploadError = null;
			const totalActions = selectedGroups.size + selectedTracks.size;
			const progressInterval = setInterval(() => {
				if (importProgress < .9) importProgress += .05;
			}, Math.max(100, totalActions * 10));
			try {
				const nodeEdits = collectNodeEdits();
				const result = await ApiUtil.post({
					path: "/api/panel/migration/luckperms/import",
					body: {
						selectedGroups: Array.from(selectedGroups),
						selectedTracks: Array.from(selectedTracks),
						importUserPermissions,
						createMissingPlayers,
						mergeStrategy,
						nodeEdits,
						playerEdits: collectPlayerEdits(),
						skippedPlayers: Array.from(skippedPlayers),
						deletedExistingNodes: existingNodeDeletions,
						trackEdits: collectTrackEdits()
					}
				});
				clearInterval(progressInterval);
				importProgress = 1;
				if (result?.result === "error") {
					uploadError = result.message || result.error || store_get($$store_subs ??= {}, "$_", $format)("pages.migration.authme.error-import-failed");
					return;
				}
				if (result) {
					importResult = result;
					currentStep = "result";
				}
			} catch (error) {
				clearInterval(progressInterval);
				uploadError = error.message || store_get($$store_subs ??= {}, "$_", $format)("pages.migration.authme.error-import-failed");
			} finally {
				isImporting = false;
			}
		}
		function resetForm() {
			configFile = null;
			dbFile = null;
			showDatabaseUpload = false;
			detectedBackend = "";
			dbConnectionInfo = null;
			isProcessing = false;
			uploadProgress = 0;
			currentStep = "upload";
			previewData = null;
			selectedGroups = /* @__PURE__ */ new Set();
			selectedTracks = /* @__PURE__ */ new Set();
			mergeStrategy = "merge";
			importUserPermissions = true;
			createMissingPlayers = true;
			isImporting = false;
			importProgress = 0;
			importResult = null;
			uploadError = null;
			expandedGroups = /* @__PURE__ */ new Set();
			expandedPlayers = /* @__PURE__ */ new Set();
			expandedTracks = /* @__PURE__ */ new Set();
			trackChains = {};
			trackDescriptions = {};
			trackGroupToAdd = "";
			trackSearchQuery = "";
			trackPage = 1;
			groupNodes = {};
			userNodes = {};
			removedEdits = [];
			existingNodeDeletions = [];
			playerUsernames = {};
			skippedPlayers = /* @__PURE__ */ new Set();
			groupSearchQuery = "";
			playerSearchQuery = "";
			groupPage = 1;
			playerPage = 1;
		}
		if (groupSearchQuery) groupPage = 1;
		if (playerSearchQuery) playerPage = 1;
		if (trackSearchQuery) trackPage = 1;
		filteredGroups = previewData?.groups?.filter((g) => {
			if (!groupSearchQuery.trim()) return true;
			return g.name.toLowerCase().includes(groupSearchQuery.toLowerCase());
		}) ?? [];
		totalGroupPages = Math.max(1, Math.ceil(filteredGroups.length / groupsPerPage));
		if (groupPage > totalGroupPages) groupPage = totalGroupPages;
		paginatedGroups = filteredGroups.slice((groupPage - 1) * groupsPerPage, groupPage * groupsPerPage);
		filteredPlayers = previewData?.players?.filter((p) => {
			if (!playerSearchQuery.trim()) return true;
			const query = playerSearchQuery.toLowerCase();
			return p.username.toLowerCase().includes(query) || (p.uuid ?? "").toLowerCase().includes(query);
		}) ?? [];
		totalPlayerPages = Math.max(1, Math.ceil(filteredPlayers.length / playersPerPage));
		if (playerPage > totalPlayerPages) playerPage = totalPlayerPages;
		paginatedPlayers = filteredPlayers.slice((playerPage - 1) * playersPerPage, playerPage * playersPerPage);
		filteredTracks = previewData?.tracks?.filter((t) => {
			if (!trackSearchQuery.trim()) return true;
			return t.name.toLowerCase().includes(trackSearchQuery.toLowerCase());
		}) ?? [];
		totalTrackPages = Math.max(1, Math.ceil(filteredTracks.length / tracksPerPage));
		if (trackPage > totalTrackPages) trackPage = totalTrackPages;
		paginatedTracks = filteredTracks.slice((trackPage - 1) * tracksPerPage, trackPage * tracksPerPage);
		missingPlayers = previewData?.players?.filter((p) => !p.existsInPano) ?? [];
		creatablePlayers = missingPlayers.filter((p) => p.hasImportableData);
		incompleteNodeCount = [...Object.values(groupNodes).flat(), ...Object.values(userNodes).flat()].filter((node) => !node.permission?.trim()).length;
		invalidUsernameCount = previewData?.players?.filter((player) => !skippedPlayers.has(player.uuid) && !playerUsername(player).trim()).length ?? 0;
		if (currentStep === "upload") {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<div class="alert alert-info mb-3"><i class="fas fa-info-circle me-1"></i> <strong>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.luckperms.supported-info-title"))}</strong> <ul class="mb-0 mt-1"><li>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.luckperms.supported-backends"))}</li> <li>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.luckperms.supported-data"))}</li> <li>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.luckperms.merge-note"))}</li></ul></div> <label class="form-label" for="lpUploadConfig">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.authme.upload-config"))}</label> `);
			if (configFile) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<div class="position-relative">`);
				DragAndDropZone($$renderer, {
					id: "lpUploadConfig",
					accept: [".yml", ".yaml"],
					icon: "fas fa-file-alt fs-1",
					title: configFile?.name || "config.yml",
					subtitle: `${stringify((configFile.size / 1024).toFixed(2))} KB`
				});
				$$renderer.push(`<!----> <button class="btn-close position-absolute top-0 end-0 m-2"${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("buttons.remove"))}${attr("title", store_get($$store_subs ??= {}, "$_", $format)("buttons.remove"))}></button></div>`);
			} else {
				$$renderer.push("<!--[-1-->");
				DragAndDropZone($$renderer, {
					id: "lpUploadConfig",
					accept: [".yml", ".yaml"],
					title: store_get($$store_subs ??= {}, "$_", $format)("pages.migration.authme.drag-drop-file"),
					subtitle: store_get($$store_subs ??= {}, "$_", $format)("pages.migration.authme.click-to-browse")
				});
			}
			$$renderer.push(`<!--]--> `);
			if (showDatabaseUpload) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<div class="mt-3"><label class="form-label" for="lpUploadDb">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.luckperms.h2-database-label"))}</label> <div class="alert alert-warning"><i class="fas fa-info-circle me-1"></i> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.luckperms.h2-detected-note"))}</div> `);
				if (dbFile) {
					$$renderer.push("<!--[0-->");
					$$renderer.push(`<div class="position-relative">`);
					DragAndDropZone($$renderer, {
						id: "lpUploadDb",
						accept: [".db", ".mv.db"],
						icon: "fas fa-database fa-lg",
						title: dbFile?.name || "database.db",
						subtitle: `${stringify((dbFile.size / 1024).toFixed(2))} KB`
					});
					$$renderer.push(`<!----> <button class="btn-close position-absolute top-0 end-0 m-2"${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("buttons.remove"))}${attr("title", store_get($$store_subs ??= {}, "$_", $format)("buttons.remove"))}></button></div>`);
				} else {
					$$renderer.push("<!--[-1-->");
					DragAndDropZone($$renderer, {
						id: "lpUploadDb",
						accept: [".db", ".mv.db"],
						title: store_get($$store_subs ??= {}, "$_", $format)("pages.migration.authme.drag-drop-file"),
						subtitle: store_get($$store_subs ??= {}, "$_", $format)("pages.migration.authme.click-to-browse")
					});
				}
				$$renderer.push(`<!--]--></div>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--> `);
			if (configFile && dbConnectionInfo) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<div class="card border-warning"><div class="card-header bg-warning"><strong>${escape_html(detectedBackend)}</strong> — ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.luckperms.db-connect-info"))}</div> <div class="card-body py-3"><div class="row g-2 mb-2"><div class="col-12 col-sm-8"><label class="form-label small mb-1" for="dbHost">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.authme.host"))}</label> <input type="text" class="form-control form-control-sm" id="dbHost"${attr("value", dbConnectionInfo.host)}/></div> <div class="col-12 col-sm-4"><label class="form-label small mb-1" for="dbPort">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.authme.port"))}</label> <input type="text" class="form-control form-control-sm" id="dbPort"${attr("value", dbConnectionInfo.port)}/></div></div> <div class="row g-2 mb-2"><div class="col-12 col-sm-6"><label class="form-label small mb-1" for="dbName">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.authme.database"))}</label> <input type="text" class="form-control form-control-sm" id="dbName"${attr("value", dbConnectionInfo.database)}/></div> <div class="col-12 col-sm-6"><label class="form-label small mb-1" for="dbPrefix">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.luckperms.table-prefix"))}</label> <input type="text" class="form-control form-control-sm" id="dbPrefix"${attr("value", dbConnectionInfo.tablePrefix)}/></div></div> <div class="row g-2"><div class="col-12 col-sm-6"><label class="form-label small mb-1" for="dbUser">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.authme.username"))}</label> <input type="text" class="form-control form-control-sm" id="dbUser"${attr("value", dbConnectionInfo.username)}/></div> <div class="col-12 col-sm-6"><label class="form-label small mb-1" for="dbPass">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.authme.password"))}</label> <input type="password" class="form-control form-control-sm" id="dbPass"${attr("value", dbConnectionInfo.password)}/></div></div></div></div>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--> `);
			if (configFile && !showDatabaseUpload) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<div class="mt-3"><button class="btn btn-primary"${attr("disabled", isProcessing, true)}>`);
				if (isProcessing) {
					$$renderer.push("<!--[0-->");
					$$renderer.push(`<span class="spinner-border spinner-border-sm me-2" role="status"></span>`);
				} else $$renderer.push("<!--[-1-->");
				$$renderer.push(`<!--]--> `);
				if (dbConnectionInfo) {
					$$renderer.push("<!--[0-->");
					$$renderer.push(`<i class="fas fa-plug me-1"></i> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.luckperms.connect-preview"))}`);
				} else {
					$$renderer.push("<!--[-1-->");
					$$renderer.push(`<i class="fas fa-upload me-1"></i> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.luckperms.upload-preview"))}`);
				}
				$$renderer.push(`<!--]--></button></div>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--> `);
			if (isProcessing) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<div class="mt-3"><div class="d-flex justify-content-between mb-1"><small>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.authme.uploading-processing"))}</small> <small>${escape_html(Math.round(uploadProgress * 100))}%</small></div> <div class="progress" style="height: 6px;"><div class="progress-bar progress-bar-striped progress-bar-animated" role="progressbar"${attr_style(`width: ${stringify(uploadProgress * 100)}%`)}${attr("aria-valuenow", Math.round(uploadProgress * 100))} aria-valuemin="0" aria-valuemax="100"></div></div></div>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--> `);
			if (uploadError) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<div class="alert alert-danger mt-3" role="alert"><i class="fas fa-exclamation-triangle me-2"></i> ${escape_html(uploadError)}</div>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]-->`);
		} else if (currentStep === "review" && previewData) {
			$$renderer.push("<!--[1-->");
			$$renderer.push(`<fieldset class="mb-4"><legend class="fs-6 fw-bold mb-2">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.luckperms.merge-strategy-title"))}</legend> <small class="d-block opacity-75 mb-3">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.luckperms.merge-strategy-desc"))}</small> <div class="row g-3"><div class="col-12 col-md-6"><input class="btn-check svelte-17ndxmn" type="radio" name="mergeStrategy" id="strategyMerge" value="merge"${attr("checked", mergeStrategy === "merge", true)}/> <label class="lp-strategy card h-100 mb-0 svelte-17ndxmn" for="strategyMerge"><div class="card-body d-flex gap-3"><i class="fas fa-code-merge fs-4 lp-strategy-icon svelte-17ndxmn"></i> <span><span class="d-block fw-bold">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.luckperms.strategy-merge"))} `);
			if (mergeStrategy === "merge") {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<i class="fas fa-circle-check ms-1 lp-strategy-check svelte-17ndxmn"></i>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--></span> <small class="d-block opacity-75">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.luckperms.strategy-merge-desc"))}</small></span></div></label></div> <div class="col-12 col-md-6"><input class="btn-check svelte-17ndxmn" type="radio" name="mergeStrategy" id="strategyReplace" value="replace"${attr("checked", mergeStrategy === "replace", true)}/> <label class="lp-strategy lp-strategy-danger card h-100 mb-0 svelte-17ndxmn" for="strategyReplace"><div class="card-body d-flex gap-3"><i class="fas fa-triangle-exclamation fs-4 lp-strategy-icon svelte-17ndxmn"></i> <span><span class="d-block fw-bold">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.luckperms.strategy-replace"))} `);
			if (mergeStrategy === "replace") {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<i class="fas fa-circle-check ms-1 lp-strategy-check svelte-17ndxmn"></i>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--></span> <small class="d-block opacity-75">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.luckperms.strategy-replace-desc"))}</small></span></div></label></div></div></fieldset> `);
			if (previewData.existingPanoNodeCount > 0) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<div${attr_class(`alert ${mergeStrategy === "replace" ? "alert-danger" : "alert-warning"} mb-3`)}><i class="fas fa-exclamation-triangle me-1"></i> `);
				if (mergeStrategy === "replace") {
					$$renderer.push("<!--[0-->");
					$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.luckperms.existing-data-replace-warning", { values: {
						groupCount: previewData.existingPanoGroupCount,
						nodeCount: previewData.existingPanoNodeCount
					} }))}`);
				} else {
					$$renderer.push("<!--[-1-->");
					$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.luckperms.existing-data-warning", { values: {
						groupCount: previewData.existingPanoGroupCount,
						nodeCount: previewData.existingPanoNodeCount
					} }))}`);
				}
				$$renderer.push(`<!--]--></div>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--> <div class="alert alert-secondary d-flex flex-wrap gap-3 mb-3"><span><span class="lp-legend-swatch lp-legend-new me-1 svelte-17ndxmn"></span> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.luckperms.legend-new"))}</span> <span><span class="lp-legend-swatch lp-legend-overwrite me-1 svelte-17ndxmn"></span> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.luckperms.legend-overwrite"))}</span> <span><span class="lp-legend-swatch lp-legend-edited me-1 svelte-17ndxmn"></span> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.luckperms.legend-edited"))}</span> `);
			if (mergeStrategy === "replace") {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<span><span class="lp-legend-swatch lp-legend-deleted me-1 svelte-17ndxmn"></span> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.luckperms.legend-deleted"))}</span>`);
			} else {
				$$renderer.push("<!--[-1-->");
				$$renderer.push(`<span><span class="lp-legend-swatch lp-legend-unchanged me-1 svelte-17ndxmn"></span> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.luckperms.legend-unchanged"))}</span>`);
			}
			$$renderer.push(`<!--]--></div> <hr/> <div class="card mb-3">`);
			CardHeader($$renderer, { $$slots: {
				left: ($$renderer) => {
					$$renderer.push(`<div slot="left"><span class="me-3"><strong>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.luckperms.groups-title"))}</strong></span> <span class="badge text-bg-success me-2">${escape_html(previewData.newGroupCount)} ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.authme.status-new"))}</span> <span class="badge text-bg-warning">${escape_html(previewData.existingGroupCount)} ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.authme.status-existing"))}</span> `);
					if (previewData.panoOnlyGroupCount > 0) {
						$$renderer.push("<!--[0-->");
						$$renderer.push(`<span class="badge text-bg-secondary ms-2">${escape_html(previewData.panoOnlyGroupCount)} ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.luckperms.pano-only"))}</span>`);
					} else $$renderer.push("<!--[-1-->");
					$$renderer.push(`<!--]--></div>`);
				},
				middle: ($$renderer) => {
					$$renderer.push(`<div slot="middle" style="width: 250px;">`);
					SearchInput($$renderer, {
						placeholderKey: "buttons.find",
						showSpinner: false
					});
					$$renderer.push(`<!----></div>`);
				},
				right: ($$renderer) => {
					$$renderer.push(`<div slot="right" class="d-flex flex-wrap gap-2"><button class="btn btn-link text-decoration-none px-0 px-md-2">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.select-all"))}</button></div>`);
				}
			} });
			$$renderer.push(`<!----> <div class="card-body p-0"><div class="table-responsive"><table class="table table-hover mb-0"><thead><tr><th class="align-middle text-nowrap" scope="col" style="width: 40px;"><input type="checkbox" class="form-check-input"${attr("checked", selectedGroups.size === importableGroups().length && selectedGroups.size > 0, true)}/></th><th class="align-middle text-nowrap" scope="col">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.luckperms.header-group"))}</th><th class="align-middle text-nowrap" scope="col">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.luckperms.header-status"))}</th><th class="align-middle text-nowrap" scope="col">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.luckperms.header-permissions"))}</th><th class="align-middle text-nowrap" scope="col" style="width: 40px;"></th></tr></thead><tbody><!--[-->`);
			const each_array = ensure_array_like(paginatedGroups);
			for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
				let group = each_array[$$index];
				const groupState = groupStatus(group);
				$$renderer.push(`<tr${attr_class("svelte-17ndxmn", void 0, {
					"lp-row-new": groupState === "new",
					"lp-row-overwrite": groupState === "update",
					"lp-row-deleted": groupState === "deleted"
				})}><td>`);
				if (group.inLuckPerms !== false) {
					$$renderer.push("<!--[0-->");
					$$renderer.push(`<input type="checkbox" class="form-check-input"${attr("checked", selectedGroups.has(group.name), true)}/>`);
				} else $$renderer.push("<!--[-1-->");
				$$renderer.push(`<!--]--></td><td class="fw-semibold">${escape_html(group.name)} `);
				if (group.inLuckPerms === false) {
					$$renderer.push("<!--[0-->");
					$$renderer.push(`<div class="small opacity-75 fw-normal mt-1"><i class="fas fa-database me-1"></i>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.luckperms.player-pano-only"))}</div>`);
				} else $$renderer.push("<!--[-1-->");
				$$renderer.push(`<!--]--></td><td><span${attr_class(`badge ${trackBadgeClass(groupState)}`, "svelte-17ndxmn")}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)(`pages.migration.luckperms.track-${groupState}`))}</span></td><td><span class="badge text-bg-primary">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.luckperms.nodes-count", { values: { count: (groupNodes[group.name] ?? []).length } }))}</span></td><td class="text-end"><button class="btn btn-link text-body p-0 border-0"${attr("title", expandedGroups.has(group.name) ? store_get($$store_subs ??= {}, "$_", $format)("buttons.show-less-details") : store_get($$store_subs ??= {}, "$_", $format)("buttons.show-more-details"))}${attr("aria-label", expandedGroups.has(group.name) ? store_get($$store_subs ??= {}, "$_", $format)("buttons.show-less-details") : store_get($$store_subs ??= {}, "$_", $format)("buttons.show-more-details"))}><i${attr_class(`fas fa-chevron-${expandedGroups.has(group.name) ? "up" : "down"}`)}></i></button></td></tr> `);
				if (expandedGroups.has(group.name)) {
					$$renderer.push("<!--[0-->");
					$$renderer.push(`<tr><td colspan="5" class="p-0"><div class="bg-body-tertiary p-3 border-top">`);
					LuckPermsNodeTable($$renderer, {
						mergeStrategy,
						nodes: groupNodes[group.name] ?? []
					});
					$$renderer.push(`<!----></div></td></tr>`);
				} else $$renderer.push("<!--[-1-->");
				$$renderer.push(`<!--]-->`);
			}
			$$renderer.push(`<!--]-->`);
			if (filteredGroups.length === 0) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<tr><td colspan="5" class="text-center opacity-75 py-4">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.luckperms.no-groups"))}</td></tr>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--></tbody></table></div></div> <div class="card-footer d-flex flex-wrap align-items-center gap-2">`);
			$$renderer.select({
				class: "form-select form-select-sm w-auto",
				value: groupsPerPage,
				"aria-label": store_get($$store_subs ??= {}, "$_", $format)("pages.migration.luckperms.per-page")
			}, ($$renderer) => {
				$$renderer.push(`<!--[-->`);
				const each_array_1 = ensure_array_like(pageSizeOptions);
				for (let $$index_1 = 0, $$length = each_array_1.length; $$index_1 < $$length; $$index_1++) {
					let size = each_array_1[$$index_1];
					$$renderer.option({ value: size }, ($$renderer) => {
						$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.luckperms.per-page-option", { values: { count: size } }))}`);
					});
				}
				$$renderer.push(`<!--]-->`);
			});
			$$renderer.push(` <small class="opacity-75">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.luckperms.total-count", { values: { count: filteredGroups.length } }))}</small> <div class="ms-auto">`);
			Pagination($$renderer, {
				page: groupPage,
				totalPage: totalGroupPages
			});
			$$renderer.push(`<!----></div></div></div> `);
			if (previewData.tracks) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<div class="card mb-3">`);
				CardHeader($$renderer, { $$slots: {
					left: ($$renderer) => {
						$$renderer.push(`<div slot="left"><span class="me-3"><strong>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.luckperms.tracks-title"))}</strong></span> <span class="badge text-bg-primary">${escape_html(previewData.tracks.length)}</span> `);
						if (previewData.panoOnlyTrackCount > 0) {
							$$renderer.push("<!--[0-->");
							$$renderer.push(`<span class="badge text-bg-secondary ms-2">${escape_html(previewData.panoOnlyTrackCount)} ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.luckperms.pano-only"))}</span>`);
						} else $$renderer.push("<!--[-1-->");
						$$renderer.push(`<!--]--></div>`);
					},
					middle: ($$renderer) => {
						$$renderer.push(`<div slot="middle" style="width: 250px;">`);
						SearchInput($$renderer, {
							placeholderKey: "buttons.find",
							showSpinner: false
						});
						$$renderer.push(`<!----></div>`);
					},
					right: ($$renderer) => {
						$$renderer.push(`<div slot="right" class="d-flex flex-wrap gap-2"><button class="btn btn-link text-decoration-none px-0 px-md-2">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.select-all"))}</button></div>`);
					}
				} });
				$$renderer.push(`<!----> <div class="card-body p-0"><div class="table-responsive"><table class="table table-hover mb-0"><thead><tr><th class="align-middle text-nowrap" scope="col" style="width: 40px;"><input type="checkbox" class="form-check-input"${attr("checked", selectedTracks.size === importableTracks().length && selectedTracks.size > 0, true)}/></th><th class="align-middle text-nowrap" scope="col">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.luckperms.header-track"))}</th><th class="align-middle text-nowrap" scope="col">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.luckperms.header-status"))}</th><th class="align-middle text-nowrap" scope="col">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.luckperms.header-groups"))}</th><th class="align-middle text-nowrap" scope="col" style="width: 40px;"></th></tr></thead><tbody><!--[-->`);
				const each_array_2 = ensure_array_like(paginatedTracks);
				for (let $$index_6 = 0, $$length = each_array_2.length; $$index_6 < $$length; $$index_6++) {
					let track = each_array_2[$$index_6];
					const chain = trackChain(track);
					const trackState = trackStatus(track);
					$$renderer.push(`<tr${attr_class("svelte-17ndxmn", void 0, {
						"lp-row-new": trackState === "new",
						"lp-row-overwrite": trackState === "update",
						"lp-row-deleted": trackState === "deleted"
					})}><td>`);
					if (track.inLuckPerms !== false) {
						$$renderer.push("<!--[0-->");
						$$renderer.push(`<input type="checkbox" class="form-check-input"${attr("checked", selectedTracks.has(track.name), true)}/>`);
					} else $$renderer.push("<!--[-1-->");
					$$renderer.push(`<!--]--></td><td class="fw-semibold">${escape_html(track.name)} `);
					if (track.inLuckPerms === false) {
						$$renderer.push("<!--[0-->");
						$$renderer.push(`<div class="small opacity-75 fw-normal mt-1"><i class="fas fa-database me-1"></i>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.luckperms.player-pano-only"))}</div>`);
					} else $$renderer.push("<!--[-1-->");
					$$renderer.push(`<!--]--></td><td><span${attr_class(`badge ${trackBadgeClass(trackState)}`, "svelte-17ndxmn")}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)(`pages.migration.luckperms.track-${trackState}`))}</span></td><td><!--[-->`);
					const each_array_3 = ensure_array_like(chain);
					for (let i = 0, $$length = each_array_3.length; i < $$length; i++) {
						let g = each_array_3[i];
						$$renderer.push(`<span${attr_class(`badge me-1 ${isGroupImportable(g) ? "text-bg-secondary" : "text-bg-danger"}`)}${attr("title", isGroupImportable(g) ? "" : store_get($$store_subs ??= {}, "$_", $format)("pages.migration.luckperms.track-group-dropped"))}>${escape_html(i + 1)}. ${escape_html(g)}</span>`);
					}
					$$renderer.push(`<!--]--> `);
					if (chain.length === 0) {
						$$renderer.push("<!--[0-->");
						$$renderer.push(`<span class="opacity-75">—</span>`);
					} else $$renderer.push("<!--[-1-->");
					$$renderer.push(`<!--]--></td><td class="text-end"><button class="btn btn-link text-body p-0 border-0"${attr("title", expandedTracks.has(track.name) ? store_get($$store_subs ??= {}, "$_", $format)("buttons.show-less-details") : store_get($$store_subs ??= {}, "$_", $format)("buttons.show-more-details"))}${attr("aria-label", expandedTracks.has(track.name) ? store_get($$store_subs ??= {}, "$_", $format)("buttons.show-less-details") : store_get($$store_subs ??= {}, "$_", $format)("buttons.show-more-details"))}><i${attr_class(`fas fa-chevron-${expandedTracks.has(track.name) ? "up" : "down"}`)}></i></button></td></tr> `);
					if (expandedTracks.has(track.name)) {
						$$renderer.push("<!--[0-->");
						$$renderer.push(`<tr><td colspan="5" class="p-0"><div class="bg-body-tertiary p-3 border-top">`);
						if (track.status !== "new" && track.existingGroups?.length) {
							$$renderer.push("<!--[0-->");
							$$renderer.push(`<div class="mb-3 small"><span class="opacity-75 me-2">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.luckperms.track-current-chain"))}</span> <!--[-->`);
							const each_array_4 = ensure_array_like(track.existingGroups);
							for (let i = 0, $$length = each_array_4.length; i < $$length; i++) {
								let g = each_array_4[i];
								$$renderer.push(`<span class="badge text-bg-secondary me-1">${escape_html(i + 1)}. ${escape_html(g)}</span>`);
							}
							$$renderer.push(`<!--]--></div>`);
						} else $$renderer.push("<!--[-1-->");
						$$renderer.push(`<!--]--> `);
						if (chain.some((g) => !isGroupImportable(g))) {
							$$renderer.push("<!--[0-->");
							$$renderer.push(`<div class="alert alert-danger py-2 small"><i class="fas fa-exclamation-triangle me-1"></i> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.luckperms.track-unknown-groups", { values: { groups: chain.filter((g) => !isGroupImportable(g)).join(", ") } }))}</div>`);
						} else $$renderer.push("<!--[-1-->");
						$$renderer.push(`<!--]--> <label class="form-label small mb-1"${attr("for", `trackDesc-${stringify(track.name)}`)}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.luckperms.track-description"))}</label> <input${attr("id", `trackDesc-${stringify(track.name)}`)} class="form-control form-control-sm mb-3"${attr("value", trackDescription(track))}/> <div class="small opacity-75 mb-2">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.luckperms.track-order-hint"))}</div> <ol class="list-group list-group-numbered mb-2"><!--[-->`);
						const each_array_5 = ensure_array_like(chain);
						for (let i = 0, $$length = each_array_5.length; i < $$length; i++) {
							let g = each_array_5[i];
							$$renderer.push(`<li class="list-group-item d-flex align-items-center justify-content-between py-1"><span${attr_class(clsx(isGroupImportable(g) ? "" : "text-danger"))}>${escape_html(g)}</span> <span class="d-flex gap-1"><button class="btn btn-sm btn-outline-secondary py-0"${attr("disabled", i === 0, true)}${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("buttons.move-up"))}${attr("title", store_get($$store_subs ??= {}, "$_", $format)("buttons.move-up"))}><i class="fas fa-arrow-up"></i></button> <button class="btn btn-sm btn-outline-secondary py-0"${attr("disabled", i === chain.length - 1, true)}${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("buttons.move-down"))}${attr("title", store_get($$store_subs ??= {}, "$_", $format)("buttons.move-down"))}><i class="fas fa-arrow-down"></i></button> <button class="btn btn-sm btn-outline-danger py-0"${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("buttons.remove"))}${attr("title", store_get($$store_subs ??= {}, "$_", $format)("buttons.remove"))}><i class="fas fa-trash"></i></button></span></li>`);
						}
						$$renderer.push(`<!--]--></ol> <div class="d-flex gap-2">`);
						$$renderer.select({
							class: "form-select form-select-sm",
							style: "max-width: 260px;",
							value: trackGroupToAdd,
							"aria-label": store_get($$store_subs ??= {}, "$_", $format)("pages.migration.luckperms.track-add-group")
						}, ($$renderer) => {
							$$renderer.option({ value: "" }, ($$renderer) => {
								$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.luckperms.track-add-group"))}`);
							});
							$$renderer.push(`<!--[-->`);
							const each_array_6 = ensure_array_like(previewData.groups.filter((g) => !chain.includes(g.name)));
							for (let $$index_5 = 0, $$length = each_array_6.length; $$index_5 < $$length; $$index_5++) {
								let g = each_array_6[$$index_5];
								$$renderer.option({ value: g.name }, ($$renderer) => {
									$$renderer.push(`${escape_html(g.name)}`);
								});
							}
							$$renderer.push(`<!--]-->`);
						});
						$$renderer.push(` <button class="btn btn-sm btn-outline-secondary"${attr("disabled", !trackGroupToAdd, true)}><i class="fas fa-plus me-1"></i>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.add"))}</button></div></div></td></tr>`);
					} else $$renderer.push("<!--[-1-->");
					$$renderer.push(`<!--]-->`);
				}
				$$renderer.push(`<!--]-->`);
				if (filteredTracks.length === 0) {
					$$renderer.push("<!--[0-->");
					$$renderer.push(`<tr><td colspan="5" class="text-center opacity-75 py-4">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.luckperms.no-tracks"))}</td></tr>`);
				} else $$renderer.push("<!--[-1-->");
				$$renderer.push(`<!--]--></tbody></table></div></div> <div class="card-footer d-flex flex-wrap align-items-center gap-2">`);
				$$renderer.select({
					class: "form-select form-select-sm w-auto",
					value: tracksPerPage,
					"aria-label": store_get($$store_subs ??= {}, "$_", $format)("pages.migration.luckperms.per-page")
				}, ($$renderer) => {
					$$renderer.push(`<!--[-->`);
					const each_array_7 = ensure_array_like(pageSizeOptions);
					for (let $$index_7 = 0, $$length = each_array_7.length; $$index_7 < $$length; $$index_7++) {
						let size = each_array_7[$$index_7];
						$$renderer.option({ value: size }, ($$renderer) => {
							$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.luckperms.per-page-option", { values: { count: size } }))}`);
						});
					}
					$$renderer.push(`<!--]-->`);
				});
				$$renderer.push(` <small class="opacity-75">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.luckperms.total-count", { values: { count: filteredTracks.length } }))}</small> <div class="ms-auto">`);
				Pagination($$renderer, {
					page: trackPage,
					totalPage: totalTrackPages
				});
				$$renderer.push(`<!----></div></div></div>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--> `);
			if (previewData.players) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<div class="card mb-3">`);
				CardHeader($$renderer, { $$slots: {
					left: ($$renderer) => {
						$$renderer.push(`<div slot="left"><span class="me-3"><strong>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.luckperms.user-perms-title"))}</strong></span> <span class="badge text-bg-success me-2">${escape_html(previewData.panoPlayerCount)} ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.luckperms.in-pano"))}</span> `);
						if (missingPlayers.length > 0) {
							$$renderer.push("<!--[0-->");
							$$renderer.push(`<span class="badge text-bg-danger">${escape_html(missingPlayers.length)} ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.luckperms.not-in-pano"))}</span>`);
						} else $$renderer.push("<!--[-1-->");
						$$renderer.push(`<!--]--> `);
						if (previewData.panoOnlyPlayerCount > 0) {
							$$renderer.push("<!--[0-->");
							$$renderer.push(`<span class="badge text-bg-secondary ms-2">${escape_html(previewData.panoOnlyPlayerCount)} ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.luckperms.pano-only"))}</span>`);
						} else $$renderer.push("<!--[-1-->");
						$$renderer.push(`<!--]--></div>`);
					},
					middle: ($$renderer) => {
						$$renderer.push(`<div slot="middle" style="width: 250px;">`);
						SearchInput($$renderer, {
							placeholderKey: "buttons.find",
							showSpinner: false
						});
						$$renderer.push(`<!----></div>`);
					}
				} });
				$$renderer.push(`<!----> <div class="card-body pb-3"><div class="row align-items-center"><div class="col-9"><label class="fw-bold mb-0" for="importUserPerms">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.luckperms.import-user-perms"))}</label> <small class="d-block opacity-75">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.luckperms.import-user-perms-desc"))}</small></div> <div class="col-3 text-end"><div class="form-check form-switch d-inline-block"><input class="form-check-input" type="checkbox" role="switch" id="importUserPerms"${attr("checked", importUserPermissions, true)}/></div></div></div> `);
				if (importUserPermissions) {
					$$renderer.push("<!--[0-->");
					$$renderer.push(`<div class="row align-items-center mt-3"><div class="col-9"><label class="fw-bold mb-0" for="createMissingPlayers">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.luckperms.create-missing-players"))}</label> <small class="d-block opacity-75">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.luckperms.create-missing-players-desc"))}</small></div> <div class="col-3 text-end"><div class="form-check form-switch d-inline-block"><input class="form-check-input" type="checkbox" role="switch" id="createMissingPlayers"${attr("checked", createMissingPlayers, true)}/></div></div></div>`);
				} else $$renderer.push("<!--[-1-->");
				$$renderer.push(`<!--]--> `);
				if (importUserPermissions && creatablePlayers.length > 0) {
					$$renderer.push("<!--[0-->");
					$$renderer.push(`<div${attr_class(`alert ${createMissingPlayers ? "alert-success" : "alert-warning"} mb-0 mt-3`)}><i${attr_class(`fas ${createMissingPlayers ? "fa-user-plus" : "fa-exclamation-triangle"} me-1`)}></i> `);
					if (createMissingPlayers) {
						$$renderer.push("<!--[0-->");
						$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.luckperms.players-will-be-created", { values: {
							count: creatablePlayers.length,
							total: previewData.players.length
						} }))}`);
					} else {
						$$renderer.push("<!--[-1-->");
						$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.luckperms.players-will-be-skipped", { values: {
							count: creatablePlayers.length,
							total: previewData.players.length
						} }))}`);
					}
					$$renderer.push(`<!--]--></div>`);
				} else $$renderer.push("<!--[-1-->");
				$$renderer.push(`<!--]--></div> `);
				if (importUserPermissions) {
					$$renderer.push("<!--[0-->");
					$$renderer.push(`<div class="table-responsive border-top"><table class="table table-hover mb-0"><thead><tr><th style="width: 40px;"></th><th style="width: 40px;"></th><th>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.luckperms.header-player"))}</th><th>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.luckperms.header-primary-group"))}</th><th class="text-center">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.luckperms.header-nodes"))}</th><th class="text-center">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.luckperms.header-status"))}</th></tr></thead><tbody><!--[-->`);
					const each_array_8 = ensure_array_like(paginatedPlayers);
					for (let $$index_8 = 0, $$length = each_array_8.length; $$index_8 < $$length; $$index_8++) {
						let player = each_array_8[$$index_8];
						const status = playerStatus(player);
						const resulting = resultingGroup(player);
						$$renderer.push(`<tr${attr_class("svelte-17ndxmn", void 0, {
							"opacity-50": skippedPlayers.has(player.uuid),
							"lp-row-new": !skippedPlayers.has(player.uuid) && status === "new",
							"lp-row-overwrite": !skippedPlayers.has(player.uuid) && status === "changed",
							"lp-row-deleted": !skippedPlayers.has(player.uuid) && status === "deleted"
						})}><td>`);
						if (!isPanoOnly(player)) {
							$$renderer.push("<!--[0-->");
							$$renderer.push(`<input type="checkbox" class="form-check-input"${attr("title", store_get($$store_subs ??= {}, "$_", $format)("pages.migration.luckperms.include-player"))}${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("pages.migration.luckperms.include-player"))}${attr("checked", !skippedPlayers.has(player.uuid), true)}/>`);
						} else $$renderer.push("<!--[-1-->");
						$$renderer.push(`<!--]--></td><td><button class="btn btn-link text-body p-0 border-0"${attr("title", expandedPlayers.has(player.uuid) ? store_get($$store_subs ??= {}, "$_", $format)("buttons.show-less-details") : store_get($$store_subs ??= {}, "$_", $format)("buttons.show-more-details"))}${attr("aria-label", expandedPlayers.has(player.uuid) ? store_get($$store_subs ??= {}, "$_", $format)("buttons.show-less-details") : store_get($$store_subs ??= {}, "$_", $format)("buttons.show-more-details"))}><i${attr_class(`fas fa-chevron-${expandedPlayers.has(player.uuid) ? "up" : "down"} fs-7`, "svelte-17ndxmn")}></i></button></td><td><input${attr_class("form-control form-control-sm", void 0, { "is-invalid": !playerUsername(player).trim() })}${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("pages.migration.luckperms.header-username"))}${attr("value", playerUsername(player))}${attr("readonly", isPanoOnly(player), true)}/> `);
						if (isPanoOnly(player)) {
							$$renderer.push("<!--[0-->");
							$$renderer.push(`<div class="small opacity-75 fw-normal mt-1"><i class="fas fa-database me-1"></i>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.luckperms.player-pano-only"))}</div>`);
						} else {
							$$renderer.push("<!--[-1-->");
							$$renderer.push(`<div class="small opacity-75 fw-normal mt-1">${escape_html(player.uuid)}</div> `);
							if (player.panoUsername && player.panoUsername !== playerUsername(player)) {
								$$renderer.push("<!--[0-->");
								$$renderer.push(`<div class="small opacity-75 fw-normal"><i class="fas fa-link me-1"></i>${escape_html(player.panoUsername)}</div>`);
							} else $$renderer.push("<!--[-1-->");
							$$renderer.push(`<!--]-->`);
						}
						$$renderer.push(`<!--]--></td><td><span class="badge text-bg-secondary">${escape_html(player.primaryGroup)}</span> `);
						if (resulting !== player.primaryGroup) {
							$$renderer.push("<!--[0-->");
							$$renderer.push(`<i class="fas fa-arrow-right mx-1 opacity-75 fs-7 svelte-17ndxmn"></i> <span${attr_class(`badge ${resulting === "default" ? "text-bg-danger" : "text-bg-success"}`)}${attr("title", resulting === "default" ? store_get($$store_subs ??= {}, "$_", $format)("pages.migration.luckperms.group-falls-back-to-default") : "")}>${escape_html(resulting)}</span>`);
						} else $$renderer.push("<!--[-1-->");
						$$renderer.push(`<!--]--></td><td class="text-center"><span class="badge text-bg-primary">${escape_html((userNodes[player.uuid] ?? []).length)}</span></td><td class="text-center"><span${attr_class(`badge ${playerBadgeClass(status)}`, "svelte-17ndxmn")}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)(`pages.migration.luckperms.player-${status}`))}</span></td></tr> `);
						if (expandedPlayers.has(player.uuid)) {
							$$renderer.push("<!--[0-->");
							$$renderer.push(`<tr><td colspan="6" class="p-0"><div class="bg-body-tertiary p-3 border-top">`);
							LuckPermsNodeTable($$renderer, {
								mergeStrategy,
								nodes: userNodes[player.uuid] ?? []
							});
							$$renderer.push(`<!----></div></td></tr>`);
						} else $$renderer.push("<!--[-1-->");
						$$renderer.push(`<!--]-->`);
					}
					$$renderer.push(`<!--]-->`);
					if (filteredPlayers.length === 0) {
						$$renderer.push("<!--[0-->");
						$$renderer.push(`<tr><td colspan="6" class="text-center opacity-75 py-4">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.luckperms.no-players"))}</td></tr>`);
					} else $$renderer.push("<!--[-1-->");
					$$renderer.push(`<!--]--></tbody></table></div> <div class="card-footer d-flex flex-wrap align-items-center gap-2">`);
					$$renderer.select({
						class: "form-select form-select-sm w-auto",
						value: playersPerPage,
						"aria-label": store_get($$store_subs ??= {}, "$_", $format)("pages.migration.luckperms.per-page")
					}, ($$renderer) => {
						$$renderer.push(`<!--[-->`);
						const each_array_9 = ensure_array_like(pageSizeOptions);
						for (let $$index_9 = 0, $$length = each_array_9.length; $$index_9 < $$length; $$index_9++) {
							let size = each_array_9[$$index_9];
							$$renderer.option({ value: size }, ($$renderer) => {
								$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.luckperms.per-page-option", { values: { count: size } }))}`);
							});
						}
						$$renderer.push(`<!--]-->`);
					});
					$$renderer.push(` <small class="opacity-75">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.luckperms.total-count", { values: { count: filteredPlayers.length } }))}</small> <div class="ms-auto">`);
					Pagination($$renderer, {
						page: playerPage,
						totalPage: totalPlayerPages
					});
					$$renderer.push(`<!----></div></div>`);
				} else $$renderer.push("<!--[-1-->");
				$$renderer.push(`<!--]--></div>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--> `);
			if (incompleteNodeCount > 0) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<div class="alert alert-danger"><i class="fas fa-exclamation-triangle me-1"></i> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.luckperms.incomplete-nodes-warning", { values: { count: incompleteNodeCount } }))}</div>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--> `);
			if (invalidUsernameCount > 0) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<div class="alert alert-danger"><i class="fas fa-exclamation-triangle me-1"></i> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.luckperms.invalid-usernames-warning", { values: { count: invalidUsernameCount } }))}</div>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--> `);
			if (isImporting) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<div class="mt-3"><div class="d-flex justify-content-between mb-1"><small>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.luckperms.importing-permissions"))}</small> <small>${escape_html(Math.round(importProgress * 100))}%</small></div> <div class="progress" style="height: 6px;"><div class="progress-bar progress-bar-striped progress-bar-animated bg-success" role="progressbar"${attr_style(`width: ${stringify(importProgress * 100)}%`)}${attr("aria-valuenow", Math.round(importProgress * 100))} aria-valuemin="0" aria-valuemax="100"></div></div></div>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--> `);
			if (uploadError) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<div class="alert alert-danger mt-3" role="alert"><i class="fas fa-exclamation-triangle me-2"></i> ${escape_html(uploadError)}</div>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--> <div class="mt-4 d-flex gap-2"><button class="btn btn-secondary"${attr("disabled", selectedGroups.size === 0 && selectedTracks.size === 0 || isImporting || incompleteNodeCount > 0 || invalidUsernameCount > 0, true)}>`);
			if (isImporting) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<span class="spinner-border spinner-border-sm me-2" role="status"></span>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.import"))}</button> <button class="btn btn-link text-decoration-none"${attr("disabled", isImporting, true)}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.cancel"))}</button></div>`);
		} else if (currentStep === "result" && importResult) {
			$$renderer.push("<!--[2-->");
			$$renderer.push(`<div class="alert alert-success d-flex align-items-center" role="alert"><i class="fas fa-check-circle fs-4 me-3"></i> <div><h6 class="alert-heading mb-1">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.luckperms.result-title"))}</h6> <p class="mb-0 small"><strong>${escape_html(importResult.importedGroups)}</strong> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.luckperms.import-summary-groups"))}`);
			if (importResult.updatedGroups > 0) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`, <strong>${escape_html(importResult.updatedGroups)}</strong> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.luckperms.import-summary-updated"))}`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]-->, <strong>${escape_html(importResult.importedGroupNodes)}</strong> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.luckperms.import-summary-group-nodes"))}, <strong>${escape_html(importResult.importedUserNodes)}</strong> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.luckperms.import-summary-user-nodes"))} `);
			if (importResult.importedTracks > 0) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`, <strong>${escape_html(importResult.importedTracks)}</strong> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.luckperms.import-summary-tracks"))}`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--> `);
			if (importResult.updatedTracks > 0) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`, <strong>${escape_html(importResult.updatedTracks)}</strong> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.luckperms.import-summary-updated-tracks"))}`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--> `);
			if (importResult.createdUsers > 0) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`, <strong>${escape_html(importResult.createdUsers)}</strong> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.luckperms.import-summary-created-users"))}`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--> `);
			if (importResult.overwrittenNodes > 0) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`, <strong>${escape_html(importResult.overwrittenNodes)}</strong> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.luckperms.import-summary-overwritten"))}`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--> `);
			if (importResult.skippedNodes > 0) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`, <strong>${escape_html(importResult.skippedNodes)}</strong> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.luckperms.import-summary-skipped"))}`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--> `);
			if (importResult.skippedUsers > 0) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`, <strong>${escape_html(importResult.skippedUsers)}</strong> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.luckperms.import-summary-skipped-users"))}`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]-->.</p></div></div> `);
			if (importResult?.errors && importResult.errors.length > 0) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<div class="alert alert-warning mt-3"><h6 class="alert-heading mb-2"><i class="fas fa-exclamation-triangle me-1"></i> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.authme.some-issues-occurred"))}</h6> <ul class="mb-0 small"><!--[-->`);
				const each_array_10 = ensure_array_like(importResult.errors);
				for (let $$index_10 = 0, $$length = each_array_10.length; $$index_10 < $$length; $$index_10++) {
					let err = each_array_10[$$index_10];
					$$renderer.push(`<li><strong>${escape_html(err.item)}</strong>: ${escape_html(err.error)}</li>`);
				}
				$$renderer.push(`<!--]--></ul></div>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--> <button class="btn btn-primary"><i class="fas fa-redo me-2"></i> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.authme.start-new-migration"))}</button>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]-->`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
		bind_props($$props, {
			configFile,
			dbFile,
			showDatabaseUpload,
			detectedBackend,
			dbConnectionInfo,
			isProcessing,
			uploadProgress,
			currentStep,
			previewData,
			selectedGroups,
			selectedTracks,
			mergeStrategy,
			importUserPermissions,
			createMissingPlayers,
			isImporting,
			importProgress,
			importResult,
			uploadError,
			expandedGroups,
			expandedPlayers,
			expandedTracks,
			groupSearchQuery,
			playerSearchQuery,
			trackSearchQuery,
			resetForm,
			importData,
			uploadAndPreview
		});
	});
}
//#endregion
//#region src/lib/pages/settings/MigrationPlugins.svelte
function MigrationPlugins($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		const pageTitle = getContext("pageTitle");
		if (pageTitle) pageTitle.set("components.settings-layout.migration");
		let authMeStep;
		let authMeSelected = /* @__PURE__ */ new Set();
		let authMeDelete = /* @__PURE__ */ new Set();
		let authMeImporting;
		let authMeProcessing;
		let authMeConfigFile;
		let authMeDbUpload;
		let authMeDbInfo;
		let authMeResetForm;
		let authMeImportUsers;
		let authMeUploadAndPreview;
		let $$settled = true;
		let $$inner_renderer;
		function $$render_inner($$renderer) {
			PageActions($$renderer, { $$slots: { right: ($$renderer) => {
				$$renderer.push(`<div slot="right" class="d-flex align-items-center gap-2">`);
				if (authMeStep === "upload" && authMeConfigFile && !authMeDbUpload) {
					$$renderer.push("<!--[0-->");
					$$renderer.push(`<button class="btn btn-primary"${attr("disabled", authMeProcessing, true)}>`);
					if (authMeProcessing) {
						$$renderer.push("<!--[0-->");
						$$renderer.push(`<span class="spinner-border spinner-border-sm me-2" role="status"></span>`);
					} else $$renderer.push("<!--[-1-->");
					$$renderer.push(`<!--]--> `);
					if (authMeDbInfo) {
						$$renderer.push("<!--[0-->");
						$$renderer.push(`<i class="fas fa-plug me-1"></i> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.connect"))} &amp; ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.view"))}`);
					} else {
						$$renderer.push("<!--[-1-->");
						$$renderer.push(`<i class="fas fa-upload me-1"></i> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.upload"))} &amp; ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.view"))}`);
					}
					$$renderer.push(`<!--]--></button>`);
				} else $$renderer.push("<!--[-1-->");
				$$renderer.push(`<!--]--></div>`);
			} } });
			$$renderer.push(`<!----> <div class="card"><div class="card-header pb-0 vstack gap-2"><ul class="nav nav-tabs border-bottom-0" id="pluginMigrateTabs" role="tablist"><li class="nav-item" role="presentation"><button class="nav-link active" id="authme-tab" data-bs-toggle="tab" data-bs-target="#authme" type="button" role="tab" aria-controls="authme" aria-selected="true">AuthMe Reloaded</button></li> <li class="nav-item" role="presentation"><button class="nav-link" id="luckperms-tab" data-bs-toggle="tab" data-bs-target="#luckperms" type="button" role="tab" aria-controls="luckperms" aria-selected="false">LuckPerms</button></li> <li class="nav-item" role="presentation"><button class="nav-link" id="other-tab" data-bs-toggle="tab" data-bs-target="#other" type="button" role="tab" aria-controls="other" aria-selected="false" disabled="">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.migration.other-addons"))}</button></li></ul></div> <div class="card-body"><div class="tab-content"><div class="tab-pane active" id="authme" role="tabpanel" aria-labelledby="authme-tab">`);
			AuthMeMigration($$renderer, {
				get currentStep() {
					return authMeStep;
				},
				set currentStep($$value) {
					authMeStep = $$value;
					$$settled = false;
				},
				get selectedUsers() {
					return authMeSelected;
				},
				set selectedUsers($$value) {
					authMeSelected = $$value;
					$$settled = false;
				},
				get deleteUsers() {
					return authMeDelete;
				},
				set deleteUsers($$value) {
					authMeDelete = $$value;
					$$settled = false;
				},
				get isImporting() {
					return authMeImporting;
				},
				set isImporting($$value) {
					authMeImporting = $$value;
					$$settled = false;
				},
				get isProcessing() {
					return authMeProcessing;
				},
				set isProcessing($$value) {
					authMeProcessing = $$value;
					$$settled = false;
				},
				get configFile() {
					return authMeConfigFile;
				},
				set configFile($$value) {
					authMeConfigFile = $$value;
					$$settled = false;
				},
				get showDatabaseUpload() {
					return authMeDbUpload;
				},
				set showDatabaseUpload($$value) {
					authMeDbUpload = $$value;
					$$settled = false;
				},
				get dbConnectionInfo() {
					return authMeDbInfo;
				},
				set dbConnectionInfo($$value) {
					authMeDbInfo = $$value;
					$$settled = false;
				},
				get resetForm() {
					return authMeResetForm;
				},
				set resetForm($$value) {
					authMeResetForm = $$value;
					$$settled = false;
				},
				get importUsers() {
					return authMeImportUsers;
				},
				set importUsers($$value) {
					authMeImportUsers = $$value;
					$$settled = false;
				},
				get uploadAndPreview() {
					return authMeUploadAndPreview;
				},
				set uploadAndPreview($$value) {
					authMeUploadAndPreview = $$value;
					$$settled = false;
				}
			});
			$$renderer.push(`<!----></div> <div class="tab-pane" id="luckperms" role="tabpanel" aria-labelledby="luckperms-tab">`);
			LuckPermsMigration($$renderer, {});
			$$renderer.push(`<!----></div> <div class="tab-pane" id="other" role="tabpanel" aria-labelledby="other-tab">`);
			NoContent($$renderer, { text: "Not available yet." });
			$$renderer.push(`<!----></div></div></div></div>`);
		}
		do {
			$$settled = true;
			$$inner_renderer = $$renderer.copy();
			$$render_inner($$inner_renderer);
		} while (!$$settled);
		$$renderer.subsume($$inner_renderer);
		if ($$store_subs) unsubscribe_stores($$store_subs);
	});
}
//#endregion
//#region src/routes/(panel)/migration/plugins/+page.svelte
function _page($$renderer, $$props) {
	let data = $$props["data"];
	MigrationPlugins($$renderer);
	bind_props($$props, { data });
}

export { _page as default };
//# sourceMappingURL=_page.svelte.js-1Uh25Gu4.js.map
