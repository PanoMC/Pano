import { l as load } from '../../../../chunks/Notifications.js-Cqhgap6A.js';

var _page = /*#__PURE__*/Object.freeze({
	__proto__: null,
	load: load
});

export { _page as _ };
//# sourceMappingURL=_page.js-f0K7fXPU.js.map
