import { l as load } from '../../../../chunks/PermissionsLayout.js-C2reeQRx.js';

var _layout = /*#__PURE__*/Object.freeze({
	__proto__: null,
	load: load
});

export { _layout as _ };
//# sourceMappingURL=_layout.js-Dve4LQBQ.js.map
