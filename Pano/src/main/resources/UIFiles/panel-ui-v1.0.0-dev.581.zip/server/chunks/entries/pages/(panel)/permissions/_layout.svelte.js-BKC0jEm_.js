import { W as slot } from '../../../../chunks/index-server.js-DdhL7Abu.js';
import { a as PermissionsLayout } from '../../../../chunks/PermissionsLayout.js-C2reeQRx.js';
import '../../../../chunks/rolldown-runtime.js-BMnQIuNT.js';
import 'node:module';
import '../../../../chunks/uneval.js-BAGiwb_L.js';
import '../../../../chunks/exports2.js-VkmSkXbz.js';
import '../../../../chunks/shared.js-B3c7sR3F.js';
import '../../../../chunks/internal.js-BRN1McAa.js';
import '../../../../chunks/server.js-BlClO2ED.js';
import '../../../../chunks/internal2.js-CNe5OZUJ.js';
import '../../../../chunks/routing.js-N-OPb2ye.js';
import '../../../../chunks/auth.util.js-C77uoaNq.js';
import '../../../../chunks/stores.js-D5xmrOAP.js';
import '../../../../chunks/exports.js-BxqLZ-Bq.js';

//#region src/routes/(panel)/permissions/+layout.svelte
function _layout($$renderer, $$props) {
	PermissionsLayout($$renderer, {
		children: ($$renderer) => {
			$$renderer.push(`<!--[-->`);
			slot($$renderer, $$props, "default", {}, null);
			$$renderer.push(`<!--]-->`);
		},
		$$slots: { default: true }
	});
}

export { _layout as default };
//# sourceMappingURL=_layout.svelte.js-BKC0jEm_.js.map
