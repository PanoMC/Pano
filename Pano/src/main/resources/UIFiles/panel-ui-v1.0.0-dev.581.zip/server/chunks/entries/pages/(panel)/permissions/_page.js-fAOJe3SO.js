import { l as load } from '../../../../chunks/Permissions.js-B84fdrLw.js';

var _page = /*#__PURE__*/Object.freeze({
	__proto__: null,
	load: load
});

export { _page as _ };
//# sourceMappingURL=_page.js-fAOJe3SO.js.map
