import { O as bind_props } from '../../../../chunks/index-server.js-DdhL7Abu.js';
import { P as Permissions } from '../../../../chunks/Permissions.js-B84fdrLw.js';
import '../../../../chunks/rolldown-runtime.js-BMnQIuNT.js';
import 'node:module';
import '../../../../chunks/uneval.js-BAGiwb_L.js';
import '../../../../chunks/exports2.js-VkmSkXbz.js';
import '../../../../chunks/shared.js-B3c7sR3F.js';
import '../../../../chunks/stores.js-D5xmrOAP.js';
import '../../../../chunks/exports.js-BxqLZ-Bq.js';
import '../../../../chunks/routing.js-N-OPb2ye.js';
import '../../../../chunks/server.js-BlClO2ED.js';
import '../../../../chunks/internal2.js-CNe5OZUJ.js';
import '../../../../chunks/Store.js-DT3aZHRb.js';
import '../../../../chunks/ToastContainer.js-Bv1jJ2dr.js';
import '../../../../chunks/runtime.js-BzHEw_ze.js';
import '../../../../chunks/language.util.js-ByanOnuS.js';
import '../../../../chunks/internal.js-BRN1McAa.js';
import '../../../../chunks/NoContent.js-Coj2fA9d.js';
import '../../../../chunks/SearchInput.js-DPW0WADK.js';
import '../../../../chunks/PageActions.js-co-RIHDp.js';
import '../../../../chunks/SearchPlayerModal.js-BcRLy3K7.js';

//#region src/routes/(panel)/permissions/+page.svelte
function _page($$renderer, $$props) {
	let data = $$props["data"];
	Permissions($$renderer, { data });
	bind_props($$props, { data });
}

export { _page as default };
//# sourceMappingURL=_page.svelte.js-CCYXRHV7.js.map
