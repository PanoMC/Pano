import { l as load } from '../../../../chunks/PlayersLayout.js-DaYRyCVT.js';

var _layout = /*#__PURE__*/Object.freeze({
	__proto__: null,
	load: load
});

export { _layout as _ };
//# sourceMappingURL=_layout.js-DwsftpCD.js.map
