import { l as load } from '../../../../chunks/Players.js-CYdV8DQH.js';

var _page = /*#__PURE__*/Object.freeze({
	__proto__: null,
	load: load
});

export { _page as _ };
//# sourceMappingURL=_page.js-CaXDicyv.js.map
