import { l as load } from '../../../../../../chunks/PlayerDetailLayout.js-DxKEQet7.js';

var _layout = /*#__PURE__*/Object.freeze({
	__proto__: null,
	load: load
});

export { _layout as _ };
//# sourceMappingURL=_layout.js-BAY72RFd.js.map
