import { b as base } from '../../../../../../chunks/internal.js-BRN1McAa.js';
import { O as bind_props, Z as escape_html, Q as store_get, P as ensure_array_like, T as attr, U as stringify, S as unsubscribe_stores } from '../../../../../../chunks/index-server.js-DdhL7Abu.js';
import '../../../../../../chunks/server.js-BlClO2ED.js';
import '../../../../../../chunks/internal2.js-CNe5OZUJ.js';
import '../../../../../../chunks/routing.js-N-OPb2ye.js';
import '../../../../../../chunks/stores.js-D5xmrOAP.js';
import 'node:module';
import '../../../../../../chunks/ToastContainer.js-Bv1jJ2dr.js';
import { $ as $format } from '../../../../../../chunks/runtime.js-BzHEw_ze.js';
import { h as hasPermission, P as Permissions } from '../../../../../../chunks/auth.util.js-C77uoaNq.js';
import { B as BanHistoryRow } from '../../../../../../chunks/BanHistoryRow.js-5e9qraff.js';
import { D as Date_1 } from '../../../../../../chunks/Date.js-DCZp_jrB.js';
import { H as Hook } from '../../../../../../chunks/SiteNavigationMenu.js-DeoPp7eK.js';
import { N as NoContent } from '../../../../../../chunks/NoContent.js-Coj2fA9d.js';
import { P as Pagination } from '../../../../../../chunks/Pagination.js-sd1xTcbW.js';
import { T as TicketStatusBadge } from '../../../../../../chunks/TicketStatusBadge.js-DtBYgr-f.js';
import '../../../../../../chunks/rolldown-runtime.js-BMnQIuNT.js';
import '../../../../../../chunks/uneval.js-BAGiwb_L.js';
import '../../../../../../chunks/shared.js-B3c7sR3F.js';
import '../../../../../../chunks/exports.js-BxqLZ-Bq.js';
import '../../../../../../chunks/Store.js-DT3aZHRb.js';
import '../../../../../../chunks/locale.js-DgLiJnqO.js';
import '../../../../../../chunks/en-US.js-Qz-txlMm.js';
import '../../../../../../chunks/toDate.js-DvNQTMH_.js';
import '../../../../../../chunks/intervalToDuration.js-Bqoo9ab3.js';
import '../../../../../../chunks/differenceInYears.js-BVSYOnW_.js';
import '../../../../../../chunks/parseISO.js-Cr7JVAUm.js';
import '../../../../../../chunks/getTimezoneOffsetInMilliseconds.js-B7thhdAL.js';
import '../../../../../../chunks/differenceInMonths.js-dJH89BLU.js';
import '../../../../../../chunks/differenceInSeconds.js-DEJPF-lp.js';
import '../../../../../../chunks/language.util.js-ByanOnuS.js';
import '../../../../../../chunks/tooltip.util.js-BeLZL-Tj.js';
import '../../../../../../chunks/exports2.js-VkmSkXbz.js';
import '../../../../../../chunks/SearchInput.js-DPW0WADK.js';
import '../../../../../../chunks/CardHeader.js-XBureLRg.js';
import '../../../../../../chunks/Themes.js-B8ffV7iF.js';
import '../../../../../../chunks/InstallingResourceModal.js-CaKAxtGU.js';
import '../../../../../../chunks/website-display.util.js-DvL-i3X3.js';
import '../../../../../../chunks/DragAndDropZone.js-DkRk4oSS.js';
import '../../../../../../chunks/VerifiedStatus.js-BWWM3WML.js';
import '../../../../../../chunks/LicenseStatusBadge.js-C5qJr3_k.js';
import '../../../../../../chunks/CategoryBadge.js-DjLui7ZD.js';
import '../../../../../../chunks/CardFiltersItem.js-n0hSsrtm.js';
import 'fs';

//#region src/lib/pages/players/PlayerDetail.svelte
function PlayerDetail($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let { data = void 0 } = $$props;
		if (hasPermission(Permissions.MANAGE_TICKETS)) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<div class="card"><div class="card-header">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.player-detail.last-tickets"))}</div> `);
			if (data.ticketCount === 0) {
				$$renderer.push("<!--[0-->");
				NoContent($$renderer, {});
			} else {
				$$renderer.push("<!--[-1-->");
				$$renderer.push(`<div class="table-responsive"><table class="table table-hover"><!--[-->`);
				const each_array = ensure_array_like(data.tickets);
				for (let index = 0, $$length = each_array.length; index < $$length; index++) {
					let ticket = each_array[index];
					$$renderer.push(`<tbody><tr><td class="align-middle text-nowrap"><code>#${escape_html(ticket.id)}</code></td><td class="align-middle text-nowrap"><a${attr("href", `${stringify(base)}/tickets/detail/${stringify(ticket.id)}`)}${attr("title", store_get($$store_subs ??= {}, "$_", $format)("buttons.view"))}>${escape_html(ticket.title)}</a></td><td class="align-middle text-nowrap"><a${attr("title", store_get($$store_subs ??= {}, "$_", $format)("pages.player-detail.filter"))}${attr("href", `${stringify(base)}/tickets?categoryUrl=${stringify(ticket.category.url)}`)}>${escape_html(ticket.category.title === "-" ? store_get($$store_subs ??= {}, "$_", $format)("pages.player-detail.no-category") : ticket.category.title)}</a></td><td class="align-middle text-nowrap">`);
					TicketStatusBadge($$renderer, { status: ticket.status });
					$$renderer.push(`<!----></td><td class="align-middle text-nowrap"><span>`);
					Date_1($$renderer, { time: ticket.lastUpdate });
					$$renderer.push(`<!----></span></td></tr></tbody>`);
				}
				$$renderer.push(`<!--]--></table></div> <div class="card-footer">`);
				Pagination($$renderer, {
					page: data.ticketsPage,
					totalPage: data.ticketTotalPage
				});
				$$renderer.push(`<!----></div>`);
			}
			$$renderer.push(`<!--]--></div>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--> <div class="card"><div class="card-header">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.player-detail.ban-history"))}</div> `);
		if (data.banHistoryCount === 0) {
			$$renderer.push("<!--[0-->");
			NoContent($$renderer, {});
		} else {
			$$renderer.push("<!--[-1-->");
			$$renderer.push(`<div class="table-responsive"><table class="table table-hover"><thead><tr><th class="align-middle">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.player-detail.ban-duration"))}</th><th class="align-middle">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.player-detail.ban-reason"))}</th><th class="align-middle text-center">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.player-detail.email-notification"))}</th><th class="align-middle">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.player-detail.banned-by"))}</th><th class="align-middle">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.player-detail.ban-source"))}</th><th class="align-middle">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.player-detail.banned-at"))}</th></tr></thead><tbody><!--[-->`);
			const each_array_1 = ensure_array_like(data.banHistory);
			for (let index = 0, $$length = each_array_1.length; index < $$length; index++) {
				let banHistory = each_array_1[index];
				BanHistoryRow($$renderer, { banHistory });
			}
			$$renderer.push(`<!--]--></tbody></table></div> <div class="card-footer">`);
			Pagination($$renderer, {
				page: data.banHistoryPage,
				totalPage: data.banHistoryTotalPage
			});
			$$renderer.push(`<!----></div>`);
		}
		$$renderer.push(`<!--]--></div> `);
		Hook($$renderer, {
			name: "panel:player-detail:bottom",
			playerData: data
		});
		$$renderer.push(`<!---->`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
		bind_props($$props, { data });
	});
}
//#endregion
//#region src/routes/(panel)/players/detail/[username]/+page.svelte
function _page($$renderer, $$props) {
	let data = $$props["data"];
	PlayerDetail($$renderer, { data });
	bind_props($$props, { data });
}

export { _page as default };
//# sourceMappingURL=_page.svelte.js-DhZBNiWu.js.map
