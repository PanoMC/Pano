import { l as load } from '../../../../chunks/PostsLayout.js-BRwPIU94.js';

var _layout = /*#__PURE__*/Object.freeze({
	__proto__: null,
	load: load
});

export { _layout as _ };
//# sourceMappingURL=_layout.js-m5pYq37J.js.map
