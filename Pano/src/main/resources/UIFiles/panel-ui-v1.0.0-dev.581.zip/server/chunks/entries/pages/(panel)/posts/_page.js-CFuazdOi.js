import { l as load } from '../../../../chunks/SiteNavigationMenu.js-DeoPp7eK.js';

var _page = /*#__PURE__*/Object.freeze({
	__proto__: null,
	load: load
});

export { _page as _ };
//# sourceMappingURL=_page.js-CFuazdOi.js.map
