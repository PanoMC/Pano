import { O as bind_props } from '../../../../chunks/index-server.js-DdhL7Abu.js';
import { P as Posts } from '../../../../chunks/SiteNavigationMenu.js-DeoPp7eK.js';
import '../../../../chunks/rolldown-runtime.js-BMnQIuNT.js';
import 'node:module';
import '../../../../chunks/uneval.js-BAGiwb_L.js';
import '../../../../chunks/exports2.js-VkmSkXbz.js';
import '../../../../chunks/shared.js-B3c7sR3F.js';
import '../../../../chunks/internal.js-BRN1McAa.js';
import '../../../../chunks/stores.js-D5xmrOAP.js';
import '../../../../chunks/exports.js-BxqLZ-Bq.js';
import '../../../../chunks/routing.js-N-OPb2ye.js';
import '../../../../chunks/server.js-BlClO2ED.js';
import '../../../../chunks/internal2.js-CNe5OZUJ.js';
import '../../../../chunks/Store.js-DT3aZHRb.js';
import '../../../../chunks/ToastContainer.js-Bv1jJ2dr.js';
import '../../../../chunks/runtime.js-BzHEw_ze.js';
import '../../../../chunks/auth.util.js-C77uoaNq.js';
import '../../../../chunks/Date.js-DCZp_jrB.js';
import '../../../../chunks/locale.js-DgLiJnqO.js';
import '../../../../chunks/en-US.js-Qz-txlMm.js';
import '../../../../chunks/toDate.js-DvNQTMH_.js';
import '../../../../chunks/parseISO.js-Cr7JVAUm.js';
import '../../../../chunks/getTimezoneOffsetInMilliseconds.js-B7thhdAL.js';
import '../../../../chunks/language.util.js-ByanOnuS.js';
import '../../../../chunks/tooltip.util.js-BeLZL-Tj.js';
import '../../../../chunks/NoContent.js-Coj2fA9d.js';
import '../../../../chunks/SearchInput.js-DPW0WADK.js';
import '../../../../chunks/CardHeader.js-XBureLRg.js';
import '../../../../chunks/Themes.js-B8ffV7iF.js';
import '../../../../chunks/InstallingResourceModal.js-CaKAxtGU.js';
import '../../../../chunks/website-display.util.js-DvL-i3X3.js';
import '../../../../chunks/DragAndDropZone.js-DkRk4oSS.js';
import '../../../../chunks/VerifiedStatus.js-BWWM3WML.js';
import '../../../../chunks/LicenseStatusBadge.js-C5qJr3_k.js';
import '../../../../chunks/Pagination.js-sd1xTcbW.js';
import '../../../../chunks/CategoryBadge.js-DjLui7ZD.js';
import '../../../../chunks/CardFiltersItem.js-n0hSsrtm.js';
import 'fs';

//#region src/routes/(panel)/posts/+page.svelte
function _page($$renderer, $$props) {
	let data = $$props["data"];
	Posts($$renderer, { data });
	bind_props($$props, { data });
}

export { _page as default };
//# sourceMappingURL=_page.svelte.js-Yyc3V7tr.js.map
