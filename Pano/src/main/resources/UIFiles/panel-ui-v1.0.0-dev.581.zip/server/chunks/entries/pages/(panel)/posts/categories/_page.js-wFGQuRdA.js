import { l as load } from '../../../../../chunks/PostCategories.js-Cuw0p5PW.js';

var _page = /*#__PURE__*/Object.freeze({
	__proto__: null,
	load: load
});

export { _page as _ };
//# sourceMappingURL=_page.js-wFGQuRdA.js.map
