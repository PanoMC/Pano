import { l as load$1, M as Modes } from '../../../../../../chunks/PostEditor.js-C5JBkC7I.js';

//#region src/routes/(panel)/posts/detail/[id]/+page.js
/**
* @type {import('@sveltejs/kit').PageLoad}
*/
async function load(params) {
	return load$1(params, Modes.EDIT);
}

var _page = /*#__PURE__*/Object.freeze({
	__proto__: null,
	load: load
});

export { _page as _ };
//# sourceMappingURL=_page.js-BLdasQ02.js.map
