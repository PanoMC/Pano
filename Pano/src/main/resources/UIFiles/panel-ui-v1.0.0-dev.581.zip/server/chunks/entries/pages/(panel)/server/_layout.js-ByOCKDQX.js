import { l as load } from '../../../../chunks/ServerLayout.js-CrkamJnH.js';

var _layout = /*#__PURE__*/Object.freeze({
	__proto__: null,
	load: load
});

export { _layout as _ };
//# sourceMappingURL=_layout.js-ByOCKDQX.js.map
