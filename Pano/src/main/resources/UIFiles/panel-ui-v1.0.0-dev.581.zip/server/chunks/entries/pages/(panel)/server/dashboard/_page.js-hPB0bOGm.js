import { l as load } from '../../../../../chunks/ServerPanel.js-CVWvVoM7.js';

var _page = /*#__PURE__*/Object.freeze({
	__proto__: null,
	load: load
});

export { _page as _ };
//# sourceMappingURL=_page.js-hPB0bOGm.js.map
