import { O as bind_props } from '../../../../../chunks/index-server.js-DdhL7Abu.js';
import { S as ServerPanel } from '../../../../../chunks/ServerPanel.js-CVWvVoM7.js';
import '../../../../../chunks/rolldown-runtime.js-BMnQIuNT.js';
import 'node:module';
import '../../../../../chunks/uneval.js-BAGiwb_L.js';
import '../../../../../chunks/internal.js-BRN1McAa.js';
import '../../../../../chunks/server.js-BlClO2ED.js';
import '../../../../../chunks/internal2.js-CNe5OZUJ.js';
import '../../../../../chunks/routing.js-N-OPb2ye.js';
import '../../../../../chunks/runtime.js-BzHEw_ze.js';
import '../../../../../chunks/security.util.js-D4eJjJV6.js';
import '../../../../../chunks/tooltip.util.js-BeLZL-Tj.js';
import '../../../../../chunks/stores.js-D5xmrOAP.js';
import '../../../../../chunks/shared.js-B3c7sR3F.js';
import '../../../../../chunks/exports.js-BxqLZ-Bq.js';
import '../../../../../chunks/NoContent.js-Coj2fA9d.js';
import '../../../../../chunks/CardHeader.js-XBureLRg.js';
import '../../../../../chunks/copy-to-clipboard.js-Doa_mbw4.js';
import '../../../../../chunks/ServersModal.js-BMcMWCMK.js';
import '../../../../../chunks/Store.js-DT3aZHRb.js';
import '../../../../../chunks/ToastContainer.js-Bv1jJ2dr.js';
import '../../../../../chunks/SearchInput.js-DPW0WADK.js';
import '../../../../../chunks/ViewAllLink.js-Cn_c9MC0.js';

//#region src/routes/(panel)/server/dashboard/+page.svelte
function _page($$renderer, $$props) {
	let data = $$props["data"];
	ServerPanel($$renderer);
	bind_props($$props, { data });
}

export { _page as default };
//# sourceMappingURL=_page.svelte.js-C6AJMo_a.js.map
