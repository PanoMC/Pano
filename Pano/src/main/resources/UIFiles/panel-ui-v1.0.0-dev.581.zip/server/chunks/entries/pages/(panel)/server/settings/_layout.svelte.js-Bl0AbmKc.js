import { W as slot } from '../../../../../chunks/index-server.js-DdhL7Abu.js';
import { a as ServerSettingsLayout } from '../../../../../chunks/ServerSettingsLayout.js-DUjy1RdU.js';
import '../../../../../chunks/rolldown-runtime.js-BMnQIuNT.js';
import 'node:module';
import '../../../../../chunks/uneval.js-BAGiwb_L.js';
import '../../../../../chunks/runtime.js-BzHEw_ze.js';
import '../../../../../chunks/PageActions.js-co-RIHDp.js';
import '../../../../../chunks/PageNav.js-Bzzuwwjz.js';
import '../../../../../chunks/internal.js-BRN1McAa.js';
import '../../../../../chunks/stores.js-D5xmrOAP.js';
import '../../../../../chunks/shared.js-B3c7sR3F.js';
import '../../../../../chunks/exports.js-BxqLZ-Bq.js';
import '../../../../../chunks/routing.js-N-OPb2ye.js';
import '../../../../../chunks/server.js-BlClO2ED.js';
import '../../../../../chunks/internal2.js-CNe5OZUJ.js';

//#region src/routes/(panel)/server/settings/+layout.svelte
function _layout($$renderer, $$props) {
	ServerSettingsLayout($$renderer, {
		children: ($$renderer) => {
			$$renderer.push(`<!--[-->`);
			slot($$renderer, $$props, "default", {}, null);
			$$renderer.push(`<!--]-->`);
		},
		$$slots: { default: true }
	});
}

export { _layout as default };
//# sourceMappingURL=_layout.svelte.js-Bl0AbmKc.js.map
