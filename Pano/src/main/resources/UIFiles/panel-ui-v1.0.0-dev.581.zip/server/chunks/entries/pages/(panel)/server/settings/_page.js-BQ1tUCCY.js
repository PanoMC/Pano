import { l as load } from '../../../../../chunks/ServerSettings.js-CLFQ3oIR.js';

var _page = /*#__PURE__*/Object.freeze({
	__proto__: null,
	load: load
});

export { _page as _ };
//# sourceMappingURL=_page.js-BQ1tUCCY.js.map
