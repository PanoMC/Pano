import { O as bind_props } from '../../../../../chunks/index-server.js-DdhL7Abu.js';
import { S as ServerSettings } from '../../../../../chunks/ServerSettings.js-CLFQ3oIR.js';
import '../../../../../chunks/rolldown-runtime.js-BMnQIuNT.js';
import 'node:module';
import '../../../../../chunks/uneval.js-BAGiwb_L.js';
import '../../../../../chunks/exports2.js-VkmSkXbz.js';
import '../../../../../chunks/shared.js-B3c7sR3F.js';
import '../../../../../chunks/internal.js-BRN1McAa.js';
import '../../../../../chunks/server.js-BlClO2ED.js';
import '../../../../../chunks/internal2.js-CNe5OZUJ.js';
import '../../../../../chunks/routing.js-N-OPb2ye.js';
import '../../../../../chunks/stores.js-D5xmrOAP.js';
import '../../../../../chunks/exports.js-BxqLZ-Bq.js';
import '../../../../../chunks/Store.js-DT3aZHRb.js';
import '../../../../../chunks/ToastContainer.js-Bv1jJ2dr.js';
import '../../../../../chunks/runtime.js-BzHEw_ze.js';
import '../../../../../chunks/PageLoading.js-BAdCAKhL.js';

//#region src/routes/(panel)/server/settings/+page.svelte
function _page($$renderer, $$props) {
	let data = $$props["data"];
	ServerSettings($$renderer, { data });
	bind_props($$props, { data });
}

export { _page as default };
//# sourceMappingURL=_page.svelte.js-DvOX3h1p.js.map
