import { l as load } from '../../../../../../chunks/GameIntegrationSettings.js-iZg-15oy.js';

var _page = /*#__PURE__*/Object.freeze({
	__proto__: null,
	load: load
});

export { _page as _ };
//# sourceMappingURL=_page.js-DlxroNlF.js.map
