import { l as load } from '../../../../../chunks/ServerDashboard.js-B6BHUVPr.js';

var _page = /*#__PURE__*/Object.freeze({
	__proto__: null,
	load: load
});

export { _page as _ };
//# sourceMappingURL=_page.js-CjUBwPzA.js.map
