import { O as bind_props } from '../../../../../chunks/index-server.js-DdhL7Abu.js';
import { S as ServerDashboard } from '../../../../../chunks/ServerDashboard.js-B6BHUVPr.js';
import '../../../../../chunks/rolldown-runtime.js-BMnQIuNT.js';
import 'node:module';
import '../../../../../chunks/uneval.js-BAGiwb_L.js';
import '../../../../../chunks/exports2.js-VkmSkXbz.js';
import '../../../../../chunks/shared.js-B3c7sR3F.js';
import '../../../../../chunks/internal.js-BRN1McAa.js';
import '../../../../../chunks/server.js-BlClO2ED.js';
import '../../../../../chunks/internal2.js-CNe5OZUJ.js';
import '../../../../../chunks/routing.js-N-OPb2ye.js';
import '../../../../../chunks/Store.js-DT3aZHRb.js';
import '../../../../../chunks/stores.js-D5xmrOAP.js';
import '../../../../../chunks/exports.js-BxqLZ-Bq.js';
import '../../../../../chunks/ToastContainer.js-Bv1jJ2dr.js';
import '../../../../../chunks/runtime.js-BzHEw_ze.js';
import '../../../../../chunks/intervalToDuration.js-Bqoo9ab3.js';
import '../../../../../chunks/en-US.js-Qz-txlMm.js';
import '../../../../../chunks/toDate.js-DvNQTMH_.js';
import '../../../../../chunks/differenceInYears.js-BVSYOnW_.js';
import '../../../../../chunks/parseISO.js-Cr7JVAUm.js';
import '../../../../../chunks/getTimezoneOffsetInMilliseconds.js-B7thhdAL.js';
import '../../../../../chunks/differenceInMonths.js-dJH89BLU.js';
import '../../../../../chunks/differenceInSeconds.js-DEJPF-lp.js';
import '../../../../../chunks/chartjs-adapter-date-fns.esm.js-D4KsVK21.js';
import '../../../../../chunks/Date.js-DCZp_jrB.js';
import '../../../../../chunks/locale.js-DgLiJnqO.js';
import '../../../../../chunks/language.util.js-ByanOnuS.js';
import '../../../../../chunks/tooltip.util.js-BeLZL-Tj.js';
import '../../../../../chunks/CardHeader.js-XBureLRg.js';
import '../../../../../chunks/PageLoading.js-BAdCAKhL.js';

//#region src/routes/(panel)/server/statistics/+page.svelte
function _page($$renderer, $$props) {
	let data = $$props["data"];
	ServerDashboard($$renderer, { data });
	bind_props($$props, { data });
}

export { _page as default };
//# sourceMappingURL=_page.svelte.js-CtAdirsO.js.map
