import { l as load } from '../../../../chunks/SettingsLayout.js-DDNsZN_1.js';

var _layout = /*#__PURE__*/Object.freeze({
	__proto__: null,
	load: load
});

export { _layout as _ };
//# sourceMappingURL=_layout.js-CrXMoTkY.js.map
