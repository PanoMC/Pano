import { l as load } from '../../../../chunks/WebsiteSettings.js-B14c2Skl.js';

var _page = /*#__PURE__*/Object.freeze({
	__proto__: null,
	load: load
});

export { _page as _ };
//# sourceMappingURL=_page.js-Cwo8DPZQ.js.map
