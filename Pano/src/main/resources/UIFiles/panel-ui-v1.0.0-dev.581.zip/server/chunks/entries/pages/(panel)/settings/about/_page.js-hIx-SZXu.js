import { l as load } from '../../../../../chunks/About.js-Dht8EU7j.js';

var _page = /*#__PURE__*/Object.freeze({
	__proto__: null,
	load: load
});

export { _page as _ };
//# sourceMappingURL=_page.js-hIx-SZXu.js.map
