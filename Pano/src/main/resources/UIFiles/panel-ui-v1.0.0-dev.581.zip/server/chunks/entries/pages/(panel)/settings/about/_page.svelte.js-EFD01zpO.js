import { O as bind_props } from '../../../../../chunks/index-server.js-DdhL7Abu.js';
import { A as About } from '../../../../../chunks/About.js-Dht8EU7j.js';
import '../../../../../chunks/rolldown-runtime.js-BMnQIuNT.js';
import 'node:module';
import '../../../../../chunks/uneval.js-BAGiwb_L.js';
import '../../../../../chunks/Store.js-DT3aZHRb.js';
import '../../../../../chunks/stores.js-D5xmrOAP.js';
import '../../../../../chunks/shared.js-B3c7sR3F.js';
import '../../../../../chunks/exports.js-BxqLZ-Bq.js';
import '../../../../../chunks/routing.js-N-OPb2ye.js';
import '../../../../../chunks/server.js-BlClO2ED.js';
import '../../../../../chunks/internal2.js-CNe5OZUJ.js';
import '../../../../../chunks/ToastContainer.js-Bv1jJ2dr.js';
import '../../../../../chunks/runtime.js-BzHEw_ze.js';

//#region src/routes/(panel)/settings/about/+page.svelte
function _page($$renderer, $$props) {
	let data = $$props["data"];
	About($$renderer, { data });
	bind_props($$props, { data });
}

export { _page as default };
//# sourceMappingURL=_page.svelte.js-EFD01zpO.js.map
