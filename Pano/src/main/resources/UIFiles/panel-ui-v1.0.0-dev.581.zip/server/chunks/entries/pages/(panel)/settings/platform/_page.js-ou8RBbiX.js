import { l as load } from '../../../../../chunks/PlatformSettings.js-BOHofOJp.js';

var _page = /*#__PURE__*/Object.freeze({
	__proto__: null,
	load: load
});

export { _page as _ };
//# sourceMappingURL=_page.js-ou8RBbiX.js.map
