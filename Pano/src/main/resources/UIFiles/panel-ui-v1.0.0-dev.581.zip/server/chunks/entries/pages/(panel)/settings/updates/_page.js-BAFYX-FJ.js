import { l as load } from '../../../../../chunks/Updates.js-CwLtGzG2.js';

var _page = /*#__PURE__*/Object.freeze({
	__proto__: null,
	load: load
});

export { _page as _ };
//# sourceMappingURL=_page.js-BAFYX-FJ.js.map
