import { l as load } from '../../../../chunks/Statistics.js-CfbBG1U0.js';

var _page = /*#__PURE__*/Object.freeze({
	__proto__: null,
	load: load
});

export { _page as _ };
//# sourceMappingURL=_page.js-6dSf5NHT.js.map
