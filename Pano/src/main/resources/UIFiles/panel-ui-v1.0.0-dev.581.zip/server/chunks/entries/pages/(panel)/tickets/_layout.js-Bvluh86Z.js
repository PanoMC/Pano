import { l as load } from '../../../../chunks/TicketsLayout.js-Pw8WCacP.js';

var _layout = /*#__PURE__*/Object.freeze({
	__proto__: null,
	load: load
});

export { _layout as _ };
//# sourceMappingURL=_layout.js-Bvluh86Z.js.map
