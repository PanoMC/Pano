import { l as load } from '../../../../chunks/Tickets.js-C0fcfvxv.js';

var _page = /*#__PURE__*/Object.freeze({
	__proto__: null,
	load: load
});

export { _page as _ };
//# sourceMappingURL=_page.js-Dc-haA56.js.map
