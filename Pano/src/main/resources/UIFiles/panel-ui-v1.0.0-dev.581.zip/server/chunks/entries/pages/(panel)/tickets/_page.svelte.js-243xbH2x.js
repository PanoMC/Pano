import { O as bind_props } from '../../../../chunks/index-server.js-DdhL7Abu.js';
import { T as Tickets } from '../../../../chunks/Tickets.js-C0fcfvxv.js';
import '../../../../chunks/rolldown-runtime.js-BMnQIuNT.js';
import 'node:module';
import '../../../../chunks/uneval.js-BAGiwb_L.js';
import '../../../../chunks/exports2.js-VkmSkXbz.js';
import '../../../../chunks/shared.js-B3c7sR3F.js';
import '../../../../chunks/internal.js-BRN1McAa.js';
import '../../../../chunks/stores.js-D5xmrOAP.js';
import '../../../../chunks/exports.js-BxqLZ-Bq.js';
import '../../../../chunks/routing.js-N-OPb2ye.js';
import '../../../../chunks/server.js-BlClO2ED.js';
import '../../../../chunks/internal2.js-CNe5OZUJ.js';
import '../../../../chunks/Store.js-DT3aZHRb.js';
import '../../../../chunks/ToastContainer.js-Bv1jJ2dr.js';
import '../../../../chunks/runtime.js-BzHEw_ze.js';
import '../../../../chunks/Date.js-DCZp_jrB.js';
import '../../../../chunks/locale.js-DgLiJnqO.js';
import '../../../../chunks/en-US.js-Qz-txlMm.js';
import '../../../../chunks/toDate.js-DvNQTMH_.js';
import '../../../../chunks/parseISO.js-Cr7JVAUm.js';
import '../../../../chunks/getTimezoneOffsetInMilliseconds.js-B7thhdAL.js';
import '../../../../chunks/language.util.js-ByanOnuS.js';
import '../../../../chunks/tooltip.util.js-BeLZL-Tj.js';
import '../../../../chunks/NoContent.js-Coj2fA9d.js';
import '../../../../chunks/SearchInput.js-DPW0WADK.js';
import '../../../../chunks/CardHeader.js-XBureLRg.js';
import '../../../../chunks/Pagination.js-sd1xTcbW.js';
import '../../../../chunks/CategoryBadge.js-DjLui7ZD.js';
import '../../../../chunks/CardFiltersItem.js-n0hSsrtm.js';
import '../../../../chunks/PageActions.js-co-RIHDp.js';
import '../../../../chunks/PageNav.js-Bzzuwwjz.js';
import '../../../../chunks/TicketStatusBadge.js-DtBYgr-f.js';

//#region src/routes/(panel)/tickets/+page.svelte
function _page($$renderer, $$props) {
	let data = $$props["data"];
	Tickets($$renderer, { data });
	bind_props($$props, { data });
}

export { _page as default };
//# sourceMappingURL=_page.svelte.js-243xbH2x.js.map
