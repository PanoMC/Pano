import { l as load } from '../../../../../../chunks/TicketDetail.js-CtG7WafG.js';

var _page = /*#__PURE__*/Object.freeze({
	__proto__: null,
	load: load
});

export { _page as _ };
//# sourceMappingURL=_page.js-DUfr0WVN.js.map
