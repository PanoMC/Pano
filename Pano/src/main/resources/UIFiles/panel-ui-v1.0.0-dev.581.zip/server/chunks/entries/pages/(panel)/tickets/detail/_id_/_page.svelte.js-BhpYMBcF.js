import { O as bind_props } from '../../../../../../chunks/index-server.js-DdhL7Abu.js';
import { T as TicketDetail } from '../../../../../../chunks/TicketDetail.js-CtG7WafG.js';
import '../../../../../../chunks/rolldown-runtime.js-BMnQIuNT.js';
import 'node:module';
import '../../../../../../chunks/uneval.js-BAGiwb_L.js';
import '../../../../../../chunks/exports2.js-VkmSkXbz.js';
import '../../../../../../chunks/shared.js-B3c7sR3F.js';
import '../../../../../../chunks/internal.js-BRN1McAa.js';
import '../../../../../../chunks/stores.js-D5xmrOAP.js';
import '../../../../../../chunks/exports.js-BxqLZ-Bq.js';
import '../../../../../../chunks/routing.js-N-OPb2ye.js';
import '../../../../../../chunks/server.js-BlClO2ED.js';
import '../../../../../../chunks/internal2.js-CNe5OZUJ.js';
import '../../../../../../chunks/Store.js-DT3aZHRb.js';
import '../../../../../../chunks/ToastContainer.js-Bv1jJ2dr.js';
import '../../../../../../chunks/runtime.js-BzHEw_ze.js';
import '../../../../../../chunks/Date.js-DCZp_jrB.js';
import '../../../../../../chunks/locale.js-DgLiJnqO.js';
import '../../../../../../chunks/en-US.js-Qz-txlMm.js';
import '../../../../../../chunks/toDate.js-DvNQTMH_.js';
import '../../../../../../chunks/parseISO.js-Cr7JVAUm.js';
import '../../../../../../chunks/getTimezoneOffsetInMilliseconds.js-B7thhdAL.js';
import '../../../../../../chunks/language.util.js-ByanOnuS.js';
import '../../../../../../chunks/tooltip.util.js-BeLZL-Tj.js';
import '../../../../../../chunks/PageActions.js-co-RIHDp.js';
import '../../../../../../chunks/Editor.js-Cs5tQi--.js';
import '../../../../../../chunks/TicketStatusBadge.js-DtBYgr-f.js';

//#region src/routes/(panel)/tickets/detail/[id]/+page.svelte
function _page($$renderer, $$props) {
	let data = $$props["data"];
	TicketDetail($$renderer, { data });
	bind_props($$props, { data });
}

export { _page as default };
//# sourceMappingURL=_page.svelte.js-BhpYMBcF.js.map
