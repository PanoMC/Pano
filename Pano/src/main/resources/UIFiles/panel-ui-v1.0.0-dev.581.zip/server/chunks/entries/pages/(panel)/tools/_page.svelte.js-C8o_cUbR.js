import { J as getContext } from '../../../../chunks/index-server.js-DdhL7Abu.js';
import '../../../../chunks/rolldown-runtime.js-BMnQIuNT.js';
import 'node:module';
import '../../../../chunks/uneval.js-BAGiwb_L.js';

//#region src/lib/pages/Tools.svelte
function Tools($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		getContext("pageTitle").set("Araçlar");
		$$renderer.push(`<div class="container">Tools page!</div>`);
	});
}
//#endregion
//#region src/routes/(panel)/tools/+page.svelte
function _page($$renderer) {
	Tools($$renderer);
}

export { _page as default };
//# sourceMappingURL=_page.svelte.js-C8o_cUbR.js.map
