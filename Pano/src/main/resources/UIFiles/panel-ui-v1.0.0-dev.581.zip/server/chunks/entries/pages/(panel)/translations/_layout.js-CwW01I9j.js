import { l as load } from '../../../../chunks/TranslationsLayout.js-CsaU5nVM.js';

var _layout = /*#__PURE__*/Object.freeze({
	__proto__: null,
	load: load
});

export { _layout as _ };
//# sourceMappingURL=_layout.js-CwW01I9j.js.map
