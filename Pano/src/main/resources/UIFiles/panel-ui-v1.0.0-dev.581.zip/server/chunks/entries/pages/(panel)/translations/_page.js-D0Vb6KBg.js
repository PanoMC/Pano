import { l as load } from '../../../../chunks/Translations.js-CX_F4WYQ.js';

var _page = /*#__PURE__*/Object.freeze({
	__proto__: null,
	load: load
});

export { _page as _ };
//# sourceMappingURL=_page.js-D0Vb6KBg.js.map
