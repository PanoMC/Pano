import { l as load } from '../../../../../chunks/Languages.js-R6xXh1u-.js';

var _page = /*#__PURE__*/Object.freeze({
	__proto__: null,
	load: load
});

export { _page as _ };
//# sourceMappingURL=_page.js-HEwolcdw.js.map
