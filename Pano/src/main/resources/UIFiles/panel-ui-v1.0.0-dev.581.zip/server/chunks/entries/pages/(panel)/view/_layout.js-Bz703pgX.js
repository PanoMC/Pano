import { l as load } from '../../../../chunks/ViewLayout.js-B-QXZLWA.js';

var _layout = /*#__PURE__*/Object.freeze({
	__proto__: null,
	load: load
});

export { _layout as _ };
//# sourceMappingURL=_layout.js-Bz703pgX.js.map
