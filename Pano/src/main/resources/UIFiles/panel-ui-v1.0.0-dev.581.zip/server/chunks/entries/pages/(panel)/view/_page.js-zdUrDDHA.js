import { l as load } from '../../../../chunks/Themes.js-B8ffV7iF.js';

var _page = /*#__PURE__*/Object.freeze({
	__proto__: null,
	load: load
});

export { _page as _ };
//# sourceMappingURL=_page.js-zdUrDDHA.js.map
