import { l as load } from '../../../../../../chunks/ThemeDetail.js-WVt3KdOE.js';

var _page = /*#__PURE__*/Object.freeze({
	__proto__: null,
	load: load
});

export { _page as _ };
//# sourceMappingURL=_page.js-ChnBbvQ_.js.map
