import { l as load$1, P as PageTypes } from '../../../../../chunks/StoreLoading.js-DX8sKhLL.js';

//#region src/routes/(panel)/view/store/+page.js
/**
* @type {import('@sveltejs/kit').PageLoad}
*/
async function load(params) {
	return load$1(params, PageTypes.THEME);
}

var _page = /*#__PURE__*/Object.freeze({
	__proto__: null,
	load: load
});

export { _page as _ };
//# sourceMappingURL=_page.js-BpBpAvMD.js.map
