import { J as getContext, a0 as onDestroy, T as attr, Q as store_get, S as unsubscribe_stores } from '../../../../../chunks/index-server.js-DdhL7Abu.js';
import '../../../../../chunks/server.js-BlClO2ED.js';
import '../../../../../chunks/internal2.js-CNe5OZUJ.js';
import '../../../../../chunks/routing.js-N-OPb2ye.js';
import { $ as $format } from '../../../../../chunks/runtime.js-BzHEw_ze.js';
import '../../../../../chunks/ToastContainer.js-Bv1jJ2dr.js';
import '../../../../../chunks/rolldown-runtime.js-BMnQIuNT.js';
import 'node:module';
import '../../../../../chunks/uneval.js-BAGiwb_L.js';

//#region src/lib/pages/view/ThemeSettings.svelte
function ThemeSettings($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		const pageTitle = getContext("pageTitle");
		getContext("panelTheme");
		pageTitle.set("pages.theme-settings.title");
		let src;
		let loading = true;
		onDestroy(() => {});
		$$renderer.push("<!--[0-->");
		$$renderer.push(`<div class="d-flex align-items-center justify-content-center" style="height: 500px;"><div class="spinner-border text-primary" role="status" aria-label="Loading"></div></div>`);
		$$renderer.push(`<!--]--> `);
		$$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--> `);
		$$renderer.push("<!--[0-->");
		$$renderer.push(`<div${attr("hidden", loading)}><iframe${attr("src", src)}${attr("title", store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.title"))} style="width:100%; border:0; display:block; background:transparent; bg-dark" scrolling="no" allowtransparency="true" sandbox="allow-same-origin allow-scripts allow-forms"></iframe></div>`);
		$$renderer.push(`<!--]-->`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
	});
}
//#endregion
//#region src/routes/(panel)/view/theme-settings/+page.svelte
function _page($$renderer) {
	ThemeSettings($$renderer);
}

export { _page as default };
//# sourceMappingURL=_page.svelte.js-DPyZwxkp.js.map
