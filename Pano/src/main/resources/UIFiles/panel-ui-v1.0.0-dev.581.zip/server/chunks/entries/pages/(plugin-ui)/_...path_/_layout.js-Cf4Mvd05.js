import { l as load$1 } from '../../../../chunks/_layout.js-taxmsIXc.js';

//#region src/routes/(plugin-ui)/[...path]/+layout.js
/**
* @type {import('@sveltejs/kit').PageLoad}
*/
async function load(event) {
	return load$1(event);
}

var _layout = /*#__PURE__*/Object.freeze({
	__proto__: null,
	load: load
});

export { _layout as _ };
//# sourceMappingURL=_layout.js-Cf4Mvd05.js.map
