import { l as load$1 } from '../../../../chunks/_page.js-Briu_MhO.js';

//#region src/routes/(plugin-ui)/[...path]/+page.js
/**
* @type {import('@sveltejs/kit').PageLoad}
*/
async function load(event) {
	return load$1(event);
}

var _page = /*#__PURE__*/Object.freeze({
	__proto__: null,
	load: load
});

export { _page as _ };
//# sourceMappingURL=_page.js-Clgeo1o4.js.map
