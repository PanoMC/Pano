import { b as base } from '../../chunks/internal.js-BRN1McAa.js';
import { J as getContext, Q as store_get, T as attr, U as stringify, Z as escape_html, S as unsubscribe_stores } from '../../chunks/index-server.js-DdhL7Abu.js';
import { p as page } from '../../chunks/stores.js-D5xmrOAP.js';
import '../../chunks/server.js-BlClO2ED.js';
import '../../chunks/internal2.js-CNe5OZUJ.js';
import '../../chunks/routing.js-N-OPb2ye.js';
import { $ as $format } from '../../chunks/runtime.js-BzHEw_ze.js';
import '../../chunks/rolldown-runtime.js-BMnQIuNT.js';
import 'node:module';
import '../../chunks/uneval.js-BAGiwb_L.js';
import '../../chunks/shared.js-B3c7sR3F.js';
import '../../chunks/exports.js-BxqLZ-Bq.js';

//#region src/lib/pages/Error.svelte
function Error($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		getContext("pageTitle").set(store_get($$store_subs ??= {}, "$_", $format)("pages.error.title", { values: { status: store_get($$store_subs ??= {}, "$page", page).status } }));
		$$renderer.push(`<div class="w-100 flex-grow-1 h-100 d-flex align-items-center"><div class="container"><div class="col-lg-6 mx-auto"><img${attr("alt", store_get($$store_subs ??= {}, "$_", $format)("pages.error.title", { values: { status: store_get($$store_subs ??= {}, "$page", page).status } }))} class="img-fluid d-block m-auto"${attr("src", `${stringify(base)}/assets/img/404.png`)} width="280"/> <div class="alert alert-danger" role="alert">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("page-error." + store_get($$store_subs ??= {}, "$page", page).status) || store_get($$store_subs ??= {}, "$page", page).error.message)}</div></div></div></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
	});
}
//#endregion
//#region src/routes/+error.svelte
function _error($$renderer) {
	Error($$renderer);
}

export { _error as default };
//# sourceMappingURL=_error.svelte.js-BK8fCgN9.js.map
