import { l as load } from '../../chunks/AppLayout.js-DQpVQODo.js';

var _layout = /*#__PURE__*/Object.freeze({
	__proto__: null,
	load: load
});

export { _layout as _ };
//# sourceMappingURL=_layout.js-DHw9XZHm.js.map
