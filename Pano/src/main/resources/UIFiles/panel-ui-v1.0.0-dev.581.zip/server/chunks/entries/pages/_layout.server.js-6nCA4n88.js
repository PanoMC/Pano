import { a as loadServer } from '../../chunks/AppLayout.js-DQpVQODo.js';

var _layout_server = /*#__PURE__*/Object.freeze({
	__proto__: null,
	load: loadServer
});

export { _layout_server as _ };
//# sourceMappingURL=_layout.server.js-6nCA4n88.js.map
