import { O as bind_props, W as slot } from '../../chunks/index-server.js-DdhL7Abu.js';
import '../../chunks/stores.js-D5xmrOAP.js';
import '../../chunks/specifiers.js-DAH8di1Y.js';
import { b as AppLayout } from '../../chunks/AppLayout.js-DQpVQODo.js';
import '../../chunks/rolldown-runtime.js-BMnQIuNT.js';
import 'node:module';
import '../../chunks/uneval.js-BAGiwb_L.js';
import '../../chunks/shared.js-B3c7sR3F.js';
import '../../chunks/exports.js-BxqLZ-Bq.js';
import '../../chunks/routing.js-N-OPb2ye.js';
import '../../chunks/server.js-BlClO2ED.js';
import '../../chunks/internal2.js-CNe5OZUJ.js';
import '../../chunks/exports2.js-VkmSkXbz.js';
import '../../chunks/internal.js-BRN1McAa.js';
import '../../chunks/Store.js-DT3aZHRb.js';
import '../../chunks/ToastContainer.js-Bv1jJ2dr.js';
import '../../chunks/runtime.js-BzHEw_ze.js';
import '../../chunks/auth.util.js-C77uoaNq.js';
import '../../chunks/WhatsNewModal.js-DYlgNmt1.js';
import '../../chunks/locale.js-DgLiJnqO.js';
import '../../chunks/en-US.js-Qz-txlMm.js';
import '../../chunks/toDate.js-DvNQTMH_.js';
import '../../chunks/server2.js-z2LG8ejq.js';
import '../../chunks/security.util.js-D4eJjJV6.js';
import '../../chunks/panelNotification.util.js-BhOOsCbR.js';
import '../../chunks/getTimezoneOffsetInMilliseconds.js-B7thhdAL.js';
import '../../chunks/differenceInMonths.js-dJH89BLU.js';
import '../../chunks/differenceInSeconds.js-DEJPF-lp.js';
import '../../chunks/Date.js-DCZp_jrB.js';
import '../../chunks/parseISO.js-Cr7JVAUm.js';
import '../../chunks/language.util.js-ByanOnuS.js';
import '../../chunks/tooltip.util.js-BeLZL-Tj.js';
import '../../chunks/DragAndDropZone.js-DkRk4oSS.js';
import '../../chunks/InstallingResourceModal.js-CaKAxtGU.js';
import '../../chunks/website-display.util.js-DvL-i3X3.js';
import '../../chunks/SiteNavigationMenu.js-DeoPp7eK.js';
import '../../chunks/NoContent.js-Coj2fA9d.js';
import '../../chunks/SearchInput.js-DPW0WADK.js';
import '../../chunks/CardHeader.js-XBureLRg.js';
import '../../chunks/Themes.js-B8ffV7iF.js';
import '../../chunks/VerifiedStatus.js-BWWM3WML.js';
import '../../chunks/LicenseStatusBadge.js-C5qJr3_k.js';
import '../../chunks/Pagination.js-sd1xTcbW.js';
import '../../chunks/CategoryBadge.js-DjLui7ZD.js';
import '../../chunks/CardFiltersItem.js-n0hSsrtm.js';
import 'fs';
import '../../chunks/copy-to-clipboard.js-Doa_mbw4.js';
import '../../chunks/ServersModal.js-BMcMWCMK.js';
import '../../chunks/ConfirmActionModal.js-C9rhvdA5.js';
import '../../chunks/PageActions.js-co-RIHDp.js';
import '../../chunks/PageNav.js-Bzzuwwjz.js';
import '../../chunks/PageLoading.js-BAdCAKhL.js';
import '../../chunks/Editor.js-Cs5tQi--.js';

//#endregion
//#region src/routes/+layout.svelte
function _layout($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		let data = $$props["data"];
		AppLayout($$renderer, {
			data,
			children: ($$renderer) => {
				$$renderer.push(`<!--[-->`);
				slot($$renderer, $$props, "default", {}, null);
				$$renderer.push(`<!--]-->`);
			},
			$$slots: { default: true }
		});
		bind_props($$props, { data });
	});
}

export { _layout as default };
//# sourceMappingURL=_layout.svelte.js-CbNNc8pU.js.map
