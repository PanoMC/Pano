const index = 1;
let component_cache;
const component = async () => component_cache ??= (await import('../entries/pages/_error.svelte.js-BK8fCgN9.js')).default;
const imports = ["_app/immutable/nodes/1.CPNYH3qO.js","_app/immutable/chunks/BBwmCR1K.js","_app/immutable/chunks/DUIz69l0.js","_app/immutable/chunks/W9ntaSi6.js","_app/immutable/chunks/VpgYMorP.js","_app/immutable/chunks/hePW80VL.js","_app/immutable/chunks/Sl6a2OsK.js","_app/immutable/chunks/BbBK2amj.js","_app/immutable/chunks/Bcuojitr.js","_app/immutable/chunks/Cy0-2RMI.js","_app/immutable/chunks/xihTtKlq.js","_app/immutable/chunks/DA94XoNu.js","_app/immutable/chunks/j24wdvhx.js","_app/immutable/chunks/DN6VyRYN.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=1.js-D6ZETjJh.js.map
