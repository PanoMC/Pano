export { _ as universal } from '../entries/pages/(panel)/translations/_layout.js-CwW01I9j.js';
import '../chunks/TranslationsLayout.js-CsaU5nVM.js';
import '../chunks/rolldown-runtime.js-BMnQIuNT.js';
import 'node:module';
import '../chunks/exports2.js-VkmSkXbz.js';
import '../chunks/shared.js-B3c7sR3F.js';
import '../chunks/uneval.js-BAGiwb_L.js';
import '../chunks/internal.js-BRN1McAa.js';
import '../chunks/index-server.js-DdhL7Abu.js';
import '../chunks/server.js-BlClO2ED.js';
import '../chunks/internal2.js-CNe5OZUJ.js';
import '../chunks/routing.js-N-OPb2ye.js';
import '../chunks/auth.util.js-C77uoaNq.js';
import '../chunks/stores.js-D5xmrOAP.js';
import '../chunks/exports.js-BxqLZ-Bq.js';

const index = 13;
let component_cache;
const component = async () => component_cache ??= (await import('../entries/pages/(panel)/translations/_layout.svelte.js-BT3Y5HoL.js')).default;
const universal_id = "src/routes/(panel)/translations/+layout.js";
const imports = ["_app/immutable/nodes/13.DWR5Y8iB.js","_app/immutable/chunks/hePW80VL.js","_app/immutable/chunks/BBwmCR1K.js","_app/immutable/chunks/DUIz69l0.js","_app/immutable/chunks/W9ntaSi6.js","_app/immutable/chunks/VpgYMorP.js","_app/immutable/chunks/Sl6a2OsK.js","_app/immutable/chunks/BbBK2amj.js","_app/immutable/chunks/xihTtKlq.js","_app/immutable/chunks/DA94XoNu.js","_app/immutable/chunks/BkQ8XDyj.js","_app/immutable/chunks/Bcuojitr.js","_app/immutable/chunks/Cy0-2RMI.js","_app/immutable/chunks/DA3CDSn2.js","_app/immutable/chunks/BRLFz19n.js","_app/immutable/chunks/DN6VyRYN.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets, universal_id };
//# sourceMappingURL=13.js-B0mBVsZW.js.map
