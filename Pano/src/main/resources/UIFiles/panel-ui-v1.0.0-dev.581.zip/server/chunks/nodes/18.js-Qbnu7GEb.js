const index = 18;
let component_cache;
const component = async () => component_cache ??= (await import('../entries/pages/(panel)/addons/detail/_addonId_/_page.svelte.js-Cgp5GMik.js')).default;
const imports = ["_app/immutable/nodes/18.DNXbHZdX.js","_app/immutable/chunks/BBwmCR1K.js","_app/immutable/chunks/DUIz69l0.js","_app/immutable/chunks/W9ntaSi6.js","_app/immutable/chunks/VpgYMorP.js","_app/immutable/chunks/hePW80VL.js","_app/immutable/chunks/Sl6a2OsK.js","_app/immutable/chunks/BbBK2amj.js","_app/immutable/chunks/Bcuojitr.js","_app/immutable/chunks/Cy0-2RMI.js","_app/immutable/chunks/xihTtKlq.js","_app/immutable/chunks/DA94XoNu.js","_app/immutable/chunks/j24wdvhx.js","_app/immutable/chunks/hgxHBHDa.js","_app/immutable/chunks/BigNxbZS.js","_app/immutable/chunks/D0s4iyvT.js","_app/immutable/chunks/uBIymjUX.js","_app/immutable/chunks/DN6VyRYN.js","_app/immutable/chunks/Cwg-EBee.js","_app/immutable/chunks/NyTMYjTO.js","_app/immutable/chunks/adgEAu7M.js","_app/immutable/chunks/DD4W-SqB.js","_app/immutable/chunks/D1wcNEKP.js"];
const stylesheets = ["_app/immutable/assets/tooltip.Lcq2UOUK.css"];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=18.js-Qbnu7GEb.js.map
