export { _ as universal } from '../entries/pages/(panel)/addons/_layout.js-BI-u0VqJ.js';
import '../chunks/AddonsLayout.js-D51u-QW6.js';
import '../chunks/rolldown-runtime.js-BMnQIuNT.js';
import 'node:module';
import '../chunks/exports2.js-VkmSkXbz.js';
import '../chunks/shared.js-B3c7sR3F.js';
import '../chunks/uneval.js-BAGiwb_L.js';
import '../chunks/internal.js-BRN1McAa.js';
import '../chunks/index-server.js-DdhL7Abu.js';
import '../chunks/server.js-BlClO2ED.js';
import '../chunks/internal2.js-CNe5OZUJ.js';
import '../chunks/routing.js-N-OPb2ye.js';
import '../chunks/auth.util.js-C77uoaNq.js';
import '../chunks/stores.js-D5xmrOAP.js';
import '../chunks/exports.js-BxqLZ-Bq.js';
import '../chunks/ConfirmEnablingAddonWillCauseMoreEnableModal.js-CyBJmbmY.js';
import '../chunks/runtime.js-BzHEw_ze.js';

const index = 2;
let component_cache;
const component = async () => component_cache ??= (await import('../entries/pages/(panel)/addons/_layout.svelte.js-Dpkk82mA.js')).default;
const universal_id = "src/routes/(panel)/addons/+layout.js";
const imports = ["_app/immutable/nodes/2.mGMTvzkK.js","_app/immutable/chunks/hePW80VL.js","_app/immutable/chunks/BBwmCR1K.js","_app/immutable/chunks/DUIz69l0.js","_app/immutable/chunks/W9ntaSi6.js","_app/immutable/chunks/VpgYMorP.js","_app/immutable/chunks/Sl6a2OsK.js","_app/immutable/chunks/BbBK2amj.js","_app/immutable/chunks/xihTtKlq.js","_app/immutable/chunks/DA94XoNu.js","_app/immutable/chunks/BHToZunT.js","_app/immutable/chunks/Bcuojitr.js","_app/immutable/chunks/Cy0-2RMI.js","_app/immutable/chunks/DA3CDSn2.js","_app/immutable/chunks/BRLFz19n.js","_app/immutable/chunks/DN6VyRYN.js","_app/immutable/chunks/Bhk59Km1.js","_app/immutable/chunks/j24wdvhx.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets, universal_id };
//# sourceMappingURL=2.js-B6jonvia.js.map
