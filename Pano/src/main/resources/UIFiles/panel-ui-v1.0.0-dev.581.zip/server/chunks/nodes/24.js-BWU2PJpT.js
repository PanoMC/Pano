const index = 24;
let component_cache;
const component = async () => component_cache ??= (await import('../entries/pages/(panel)/migration/platforms/_page.svelte.js-B8SNNd3K.js')).default;
const imports = ["_app/immutable/nodes/24.CmBu6L9M.js","_app/immutable/chunks/VpgYMorP.js","_app/immutable/chunks/hePW80VL.js","_app/immutable/chunks/BBwmCR1K.js","_app/immutable/chunks/DUIz69l0.js","_app/immutable/chunks/W9ntaSi6.js","_app/immutable/chunks/Sl6a2OsK.js","_app/immutable/chunks/BbBK2amj.js","_app/immutable/chunks/xihTtKlq.js","_app/immutable/chunks/DA94XoNu.js","_app/immutable/chunks/DLVSNlZ1.js","_app/immutable/chunks/j24wdvhx.js","_app/immutable/chunks/Cy0-2RMI.js","_app/immutable/chunks/CIQLsbxM.js"];
const stylesheets = ["_app/immutable/assets/MigrationPlatforms.BGALKhmm.css"];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=24.js-BWU2PJpT.js.map
