export { _ as universal } from '../entries/pages/(panel)/permissions/_page.js-fAOJe3SO.js';
import '../chunks/Permissions.js-B84fdrLw.js';
import '../chunks/exports2.js-VkmSkXbz.js';
import '../chunks/shared.js-B3c7sR3F.js';
import '../chunks/uneval.js-BAGiwb_L.js';
import '../chunks/index-server.js-DdhL7Abu.js';
import '../chunks/rolldown-runtime.js-BMnQIuNT.js';
import 'node:module';
import '../chunks/stores.js-D5xmrOAP.js';
import '../chunks/exports.js-BxqLZ-Bq.js';
import '../chunks/routing.js-N-OPb2ye.js';
import '../chunks/server.js-BlClO2ED.js';
import '../chunks/internal2.js-CNe5OZUJ.js';
import '../chunks/Store.js-DT3aZHRb.js';
import '../chunks/ToastContainer.js-Bv1jJ2dr.js';
import '../chunks/runtime.js-BzHEw_ze.js';
import '../chunks/language.util.js-ByanOnuS.js';
import '../chunks/internal.js-BRN1McAa.js';
import '../chunks/NoContent.js-Coj2fA9d.js';
import '../chunks/SearchInput.js-DPW0WADK.js';
import '../chunks/PageActions.js-co-RIHDp.js';
import '../chunks/SearchPlayerModal.js-BcRLy3K7.js';

const index = 28;
let component_cache;
const component = async () => component_cache ??= (await import('../entries/pages/(panel)/permissions/_page.svelte.js-CCYXRHV7.js')).default;
const universal_id = "src/routes/(panel)/permissions/+page.js";
const imports = ["_app/immutable/nodes/28.DsMec1IO.js","_app/immutable/chunks/hePW80VL.js","_app/immutable/chunks/BBwmCR1K.js","_app/immutable/chunks/DUIz69l0.js","_app/immutable/chunks/W9ntaSi6.js","_app/immutable/chunks/VpgYMorP.js","_app/immutable/chunks/Sl6a2OsK.js","_app/immutable/chunks/BbBK2amj.js","_app/immutable/chunks/Bcuojitr.js","_app/immutable/chunks/Cy0-2RMI.js","_app/immutable/chunks/uBIymjUX.js","_app/immutable/chunks/xihTtKlq.js","_app/immutable/chunks/DA94XoNu.js","_app/immutable/chunks/j24wdvhx.js","_app/immutable/chunks/hgxHBHDa.js","_app/immutable/chunks/DA3CDSn2.js","_app/immutable/chunks/Cvzc6TDL.js","_app/immutable/chunks/BigNxbZS.js","_app/immutable/chunks/D0s4iyvT.js","_app/immutable/chunks/DN6VyRYN.js","_app/immutable/chunks/Cwg-EBee.js","_app/immutable/chunks/CIQLsbxM.js","_app/immutable/chunks/B9l-OB6J.js","_app/immutable/chunks/DlxVxswb.js"];
const stylesheets = ["_app/immutable/assets/PageActions.CT5XVEJK.css","_app/immutable/assets/28.CIcBYuW0.css"];
const fonts = [];

export { component, fonts, imports, index, stylesheets, universal_id };
//# sourceMappingURL=28.js-B1w-JNGs.js.map
