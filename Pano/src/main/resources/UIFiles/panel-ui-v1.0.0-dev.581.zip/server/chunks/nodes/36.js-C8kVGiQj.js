export { _ as universal } from '../entries/pages/(panel)/server/dashboard/_page.js-hPB0bOGm.js';
import '../chunks/ServerPanel.js-CVWvVoM7.js';
import 'node:module';
import '../chunks/internal.js-BRN1McAa.js';
import '../chunks/index-server.js-DdhL7Abu.js';
import '../chunks/rolldown-runtime.js-BMnQIuNT.js';
import '../chunks/uneval.js-BAGiwb_L.js';
import '../chunks/server.js-BlClO2ED.js';
import '../chunks/internal2.js-CNe5OZUJ.js';
import '../chunks/routing.js-N-OPb2ye.js';
import '../chunks/runtime.js-BzHEw_ze.js';
import '../chunks/security.util.js-D4eJjJV6.js';
import '../chunks/tooltip.util.js-BeLZL-Tj.js';
import '../chunks/stores.js-D5xmrOAP.js';
import '../chunks/shared.js-B3c7sR3F.js';
import '../chunks/exports.js-BxqLZ-Bq.js';
import '../chunks/NoContent.js-Coj2fA9d.js';
import '../chunks/CardHeader.js-XBureLRg.js';
import '../chunks/copy-to-clipboard.js-Doa_mbw4.js';
import '../chunks/ServersModal.js-BMcMWCMK.js';
import '../chunks/Store.js-DT3aZHRb.js';
import '../chunks/ToastContainer.js-Bv1jJ2dr.js';
import '../chunks/SearchInput.js-DPW0WADK.js';
import '../chunks/ViewAllLink.js-Cn_c9MC0.js';

const index = 36;
let component_cache;
const component = async () => component_cache ??= (await import('../entries/pages/(panel)/server/dashboard/_page.svelte.js-C6AJMo_a.js')).default;
const universal_id = "src/routes/(panel)/server/dashboard/+page.js";
const imports = ["_app/immutable/nodes/36.XIhQB4jv.js","_app/immutable/chunks/hePW80VL.js","_app/immutable/chunks/BBwmCR1K.js","_app/immutable/chunks/DUIz69l0.js","_app/immutable/chunks/W9ntaSi6.js","_app/immutable/chunks/VpgYMorP.js","_app/immutable/chunks/Sl6a2OsK.js","_app/immutable/chunks/BbBK2amj.js","_app/immutable/chunks/Bcuojitr.js","_app/immutable/chunks/Cy0-2RMI.js","_app/immutable/chunks/xihTtKlq.js","_app/immutable/chunks/DA94XoNu.js","_app/immutable/chunks/j24wdvhx.js","_app/immutable/chunks/2M_uoStl.js","_app/immutable/chunks/jG02PIBb.js","_app/immutable/chunks/DD4W-SqB.js","_app/immutable/chunks/DN6VyRYN.js","_app/immutable/chunks/CIQLsbxM.js","_app/immutable/chunks/fHr7oLBD.js","_app/immutable/chunks/TwB8Neoh.js","_app/immutable/chunks/hgxHBHDa.js","_app/immutable/chunks/BigNxbZS.js","_app/immutable/chunks/Cfj1Okqx.js","_app/immutable/chunks/PwU_UItz.js","_app/immutable/chunks/D0s4iyvT.js","_app/immutable/chunks/uBIymjUX.js","_app/immutable/chunks/B9l-OB6J.js","_app/immutable/chunks/PgWcuZlr.js"];
const stylesheets = ["_app/immutable/assets/tooltip.Lcq2UOUK.css","_app/immutable/assets/ServersModal.yQxycS4B.css","_app/immutable/assets/36.CsSfpy9e.css"];
const fonts = [];

export { component, fonts, imports, index, stylesheets, universal_id };
//# sourceMappingURL=36.js-C8kVGiQj.js.map
