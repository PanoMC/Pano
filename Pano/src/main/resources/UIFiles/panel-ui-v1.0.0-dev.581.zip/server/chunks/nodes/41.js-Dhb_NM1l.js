export { _ as universal } from '../entries/pages/(panel)/settings/about/_page.js-hIx-SZXu.js';
import '../chunks/About.js-Dht8EU7j.js';
import '../chunks/index-server.js-DdhL7Abu.js';
import '../chunks/rolldown-runtime.js-BMnQIuNT.js';
import 'node:module';
import '../chunks/uneval.js-BAGiwb_L.js';
import '../chunks/Store.js-DT3aZHRb.js';
import '../chunks/stores.js-D5xmrOAP.js';
import '../chunks/shared.js-B3c7sR3F.js';
import '../chunks/exports.js-BxqLZ-Bq.js';
import '../chunks/routing.js-N-OPb2ye.js';
import '../chunks/server.js-BlClO2ED.js';
import '../chunks/internal2.js-CNe5OZUJ.js';
import '../chunks/ToastContainer.js-Bv1jJ2dr.js';
import '../chunks/runtime.js-BzHEw_ze.js';

const index = 41;
let component_cache;
const component = async () => component_cache ??= (await import('../entries/pages/(panel)/settings/about/_page.svelte.js-EFD01zpO.js')).default;
const universal_id = "src/routes/(panel)/settings/about/+page.js";
const imports = ["_app/immutable/nodes/41.o8T5TWcR.js","_app/immutable/chunks/hePW80VL.js","_app/immutable/chunks/BBwmCR1K.js","_app/immutable/chunks/DUIz69l0.js","_app/immutable/chunks/W9ntaSi6.js","_app/immutable/chunks/VpgYMorP.js","_app/immutable/chunks/Sl6a2OsK.js","_app/immutable/chunks/BbBK2amj.js","_app/immutable/chunks/xihTtKlq.js","_app/immutable/chunks/DA94XoNu.js","_app/immutable/chunks/j24wdvhx.js","_app/immutable/chunks/Cy0-2RMI.js","_app/immutable/chunks/D0s4iyvT.js","_app/immutable/chunks/Bcuojitr.js","_app/immutable/chunks/uBIymjUX.js","_app/immutable/chunks/DN6VyRYN.js","_app/immutable/chunks/BigNxbZS.js","_app/immutable/chunks/BRmBu_jM.js"];
const stylesheets = ["_app/immutable/assets/WhatsNewModal.BhAPAsgb.css"];
const fonts = [];

export { component, fonts, imports, index, stylesheets, universal_id };
//# sourceMappingURL=41.js-Dhb_NM1l.js.map
