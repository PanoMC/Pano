export { _ as universal } from '../entries/pages/(panel)/settings/platform/_page.js-ou8RBbiX.js';
import '../chunks/PlatformSettings.js-BOHofOJp.js';
import '../chunks/index-server.js-DdhL7Abu.js';
import '../chunks/rolldown-runtime.js-BMnQIuNT.js';
import 'node:module';
import '../chunks/uneval.js-BAGiwb_L.js';
import '../chunks/stores.js-D5xmrOAP.js';
import '../chunks/shared.js-B3c7sR3F.js';
import '../chunks/exports.js-BxqLZ-Bq.js';
import '../chunks/routing.js-N-OPb2ye.js';
import '../chunks/server.js-BlClO2ED.js';
import '../chunks/internal2.js-CNe5OZUJ.js';
import '../chunks/Store.js-DT3aZHRb.js';
import '../chunks/ToastContainer.js-Bv1jJ2dr.js';
import '../chunks/runtime.js-BzHEw_ze.js';
import '../chunks/Date.js-DCZp_jrB.js';
import '../chunks/locale.js-DgLiJnqO.js';
import '../chunks/en-US.js-Qz-txlMm.js';
import '../chunks/toDate.js-DvNQTMH_.js';
import '../chunks/parseISO.js-Cr7JVAUm.js';
import '../chunks/getTimezoneOffsetInMilliseconds.js-B7thhdAL.js';
import '../chunks/language.util.js-ByanOnuS.js';
import '../chunks/internal.js-BRN1McAa.js';
import '../chunks/tooltip.util.js-BeLZL-Tj.js';
import '../chunks/NoContent.js-Coj2fA9d.js';
import '../chunks/Pagination.js-sd1xTcbW.js';
import '../chunks/PageActions.js-co-RIHDp.js';
import '../chunks/ConfirmSaveCriticalSettingsModal.js-Coj5M9TO.js';

const index = 42;
let component_cache;
const component = async () => component_cache ??= (await import('../entries/pages/(panel)/settings/platform/_page.svelte.js-rDSg3nZq.js')).default;
const universal_id = "src/routes/(panel)/settings/platform/+page.js";
const imports = ["_app/immutable/nodes/42.BVdNsvyp.js","_app/immutable/chunks/hePW80VL.js","_app/immutable/chunks/BBwmCR1K.js","_app/immutable/chunks/DUIz69l0.js","_app/immutable/chunks/W9ntaSi6.js","_app/immutable/chunks/VpgYMorP.js","_app/immutable/chunks/Sl6a2OsK.js","_app/immutable/chunks/BbBK2amj.js","_app/immutable/chunks/Bcuojitr.js","_app/immutable/chunks/Cy0-2RMI.js","_app/immutable/chunks/xihTtKlq.js","_app/immutable/chunks/DA94XoNu.js","_app/immutable/chunks/j24wdvhx.js","_app/immutable/chunks/hgxHBHDa.js","_app/immutable/chunks/DN6VyRYN.js","_app/immutable/chunks/Cvzc6TDL.js","_app/immutable/chunks/BV5vb4gg.js","_app/immutable/chunks/BigNxbZS.js","_app/immutable/chunks/DXXgKXUu.js","_app/immutable/chunks/2B1CJgzA.js","_app/immutable/chunks/PwU_UItz.js","_app/immutable/chunks/C6BoehpJ.js","_app/immutable/chunks/Cyo-zYWJ.js","_app/immutable/chunks/Dn-MR7C2.js","_app/immutable/chunks/DD4W-SqB.js","_app/immutable/chunks/Cwg-EBee.js","_app/immutable/chunks/D0s4iyvT.js","_app/immutable/chunks/uBIymjUX.js","_app/immutable/chunks/CIQLsbxM.js","_app/immutable/chunks/C_EWDjzc.js","_app/immutable/chunks/DOQ7Evw-.js"];
const stylesheets = ["_app/immutable/assets/PageActions.CT5XVEJK.css","_app/immutable/assets/tooltip.Lcq2UOUK.css","_app/immutable/assets/42._Vsh401b.css"];
const fonts = [];

export { component, fonts, imports, index, stylesheets, universal_id };
//# sourceMappingURL=42.js-B-nI4B3l.js.map
