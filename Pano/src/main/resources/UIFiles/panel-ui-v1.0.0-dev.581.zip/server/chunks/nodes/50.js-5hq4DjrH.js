export { _ as universal } from '../entries/pages/(panel)/translations/languages/_page.js-HEwolcdw.js';
import '../chunks/Languages.js-R6xXh1u-.js';
import '../chunks/exports2.js-VkmSkXbz.js';
import '../chunks/shared.js-B3c7sR3F.js';
import '../chunks/uneval.js-BAGiwb_L.js';
import '../chunks/index-server.js-DdhL7Abu.js';
import '../chunks/rolldown-runtime.js-BMnQIuNT.js';
import 'node:module';
import '../chunks/stores.js-D5xmrOAP.js';
import '../chunks/exports.js-BxqLZ-Bq.js';
import '../chunks/routing.js-N-OPb2ye.js';
import '../chunks/server.js-BlClO2ED.js';
import '../chunks/internal2.js-CNe5OZUJ.js';
import '../chunks/Store.js-DT3aZHRb.js';
import '../chunks/ToastContainer.js-Bv1jJ2dr.js';
import '../chunks/runtime.js-BzHEw_ze.js';
import '../chunks/locale.js-DgLiJnqO.js';
import '../chunks/en-US.js-Qz-txlMm.js';
import '../chunks/toDate.js-DvNQTMH_.js';
import '../chunks/NoContent.js-Coj2fA9d.js';
import '../chunks/Pagination.js-sd1xTcbW.js';
import '../chunks/PageActions.js-co-RIHDp.js';
import '../chunks/PageNav.js-Bzzuwwjz.js';
import '../chunks/internal.js-BRN1McAa.js';

const index = 50;
let component_cache;
const component = async () => component_cache ??= (await import('../entries/pages/(panel)/translations/languages/_page.svelte.js-DwzjFnD0.js')).default;
const universal_id = "src/routes/(panel)/translations/languages/+page.js";
const imports = ["_app/immutable/nodes/50.CzZO7nPv.js","_app/immutable/chunks/hePW80VL.js","_app/immutable/chunks/BBwmCR1K.js","_app/immutable/chunks/DUIz69l0.js","_app/immutable/chunks/W9ntaSi6.js","_app/immutable/chunks/VpgYMorP.js","_app/immutable/chunks/Sl6a2OsK.js","_app/immutable/chunks/BbBK2amj.js","_app/immutable/chunks/Bcuojitr.js","_app/immutable/chunks/Cy0-2RMI.js","_app/immutable/chunks/xihTtKlq.js","_app/immutable/chunks/DA94XoNu.js","_app/immutable/chunks/j24wdvhx.js","_app/immutable/chunks/hgxHBHDa.js","_app/immutable/chunks/DA3CDSn2.js","_app/immutable/chunks/Cvzc6TDL.js","_app/immutable/chunks/DDQBNmpe.js","_app/immutable/chunks/DN6VyRYN.js","_app/immutable/chunks/BV5vb4gg.js","_app/immutable/chunks/BigNxbZS.js","_app/immutable/chunks/jG02PIBb.js","_app/immutable/chunks/Dn-MR7C2.js","_app/immutable/chunks/PwU_UItz.js","_app/immutable/chunks/2B1CJgzA.js","_app/immutable/chunks/D0s4iyvT.js","_app/immutable/chunks/uBIymjUX.js","_app/immutable/chunks/CIQLsbxM.js"];
const stylesheets = ["_app/immutable/assets/PageActions.CT5XVEJK.css","_app/immutable/assets/PageNav.Kti0FEme.css"];
const fonts = [];

export { component, fonts, imports, index, stylesheets, universal_id };
//# sourceMappingURL=50.js-5hq4DjrH.js.map
