import{a as r}from"../chunks/BmDcWsyK.js";import{y as t}from"../chunks/DSO43oG8.js";export{t as load_css,r as start};
