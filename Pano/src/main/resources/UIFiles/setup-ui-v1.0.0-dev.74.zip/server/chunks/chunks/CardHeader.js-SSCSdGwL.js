import { f as slot } from './root.js-QX3SkSrm.js';

function CardHeader($$renderer, $$props) {
  $$renderer.push(`<div class="card-header"><h5 class="mb-0"><!--[-->`);
  slot($$renderer, $$props, "default", {}, null);
  $$renderer.push(`<!--]--></h5></div>`);
}

export { CardHeader as C };
//# sourceMappingURL=CardHeader.js-SSCSdGwL.js.map
