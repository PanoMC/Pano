import { b as escape_html, s as store_get, u as unsubscribe_stores, c as bind_props } from './root.js-QX3SkSrm.js';
import { $ as $format } from './runtime.js-CSUW-DLZ.js';

function ErrorAlert($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    var $$store_subs;
    let error = $$props["error"];
    const alwaysVisible = false;
    if (error || alwaysVisible) {
      $$renderer2.push("<!--[0-->");
      $$renderer2.push(`<div class="alert alert-danger mb-0"><i class="fa-solid fa-triangle-exclamation me-2"></i> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("errors." + (error.key || error), { values: error.props }))}</div>`);
    } else {
      $$renderer2.push("<!--[-1-->");
    }
    $$renderer2.push(`<!--]-->`);
    if ($$store_subs) unsubscribe_stores($$store_subs);
    bind_props($$props, { error });
  });
}

export { ErrorAlert as E };
//# sourceMappingURL=ErrorAlert.js-BrOLI8U-.js.map
