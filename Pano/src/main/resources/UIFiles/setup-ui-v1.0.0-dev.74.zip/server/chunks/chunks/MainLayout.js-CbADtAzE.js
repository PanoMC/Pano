import { d as setContext, s as store_get, h as head, u as unsubscribe_stores, c as bind_props, f as slot, b as escape_html, g as attr_class, i as attr, j as stringify, k as getContext, l as attr_style, m as sanitize_slots, e as ensure_array_like } from './root.js-QX3SkSrm.js';
import { u as updateApiUrl, $ as $format, P as PANO_WEBSITE_URL, c as updatePanoWebsiteUrl } from './runtime.js-CSUW-DLZ.js';
import './exports.js-BZBK1HC9.js';
import './utils.js-BQzn9ikS.js';
import { w as writable } from './index.js-l_eu7De0.js';
import { b as base } from './server.js-Bf8x1V_n.js';
import { N as redirect } from './utils2.js-Ke2uzSud.js';
import './state.svelte.js-IvJbnGzW.js';
import { c as checkCurrentStep, s as session, a as currentStep, n as navigationState, T as ToastContainer, b as checkRoute, i as isFinishing } from './Store.js-vRMTfo1I.js';
import { E as ErrorAlert } from './ErrorAlert.js-BrOLI8U-.js';
import { a8 as fallback } from './effects.js-DAVcbH3F.js';
import { i as init } from './language.util.js-nasHThMs.js';

function html(value) {
  var html2 = String(value ?? "");
  var open = "<!---->";
  return open + html2 + "<!---->";
}
function App($$renderer, $$props) {
  head("xo6w1v", $$renderer, ($$renderer2) => {
    {
      $$renderer2.push("<!--[-1-->");
    }
    $$renderer2.push(`<!--]-->`);
  });
  $$renderer.push(`<!--[-->`);
  slot($$renderer, $$props, "default", {}, null);
  $$renderer.push(`<!--]-->`);
}
function Navbar($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    var $$store_subs;
    let version = fallback($$props["version"], "1.0");
    $$renderer2.push(`<nav class="navbar navbar-expand-xl border-bottom" style="z-index: 1040;"><div class="container d-flex align-items-center"><div class="col-4 d-flex align-items-center order-1"><div class="d-xl-none d-flex align-items-center"><button class="nav-link p-0" type="button" data-bs-toggle="offcanvas" data-bs-target="#mobileMenuOffcanvas" aria-controls="mobileMenuOffcanvas" aria-label="Toggle navigation"><i class="fa-solid fa-bars"></i></button></div> <div class="collapse navbar-collapse d-xl-flex" id="navbarContentDesktop"><ul class="navbar-nav gap-2"><li class="nav-item"><a class="nav-link"${attr("href", `${stringify(PANO_WEBSITE_URL)}/docs`)} target="_blank" rel="noreferrer"${attr("title", store_get($$store_subs ??= {}, "$_", $format)("buttons.docs"))}${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("buttons.docs"))}><i class="fa-solid fa-book"></i></a></li> <li class="nav-item"><a class="nav-link"${attr("href", `${stringify(PANO_WEBSITE_URL)}/discord`)} target="_blank" rel="noreferrer" title="Discord" aria-label="Discord"><i class="fa-brands fa-discord"></i></a></li></ul></div></div> <div class="col-4 d-flex justify-content-center order-2"><div class="navbar-brand me-0 d-inline-flex align-items-center justify-content-center bg-primary rounded" style="width: 32px; height: 32px;"><a${attr("href", PANO_WEBSITE_URL)} target="_blank" aria-label="Pano"><img src="/assets/img/logo.svg" width="24" height="24" alt="Pano"/></a></div></div> <div class="col-4 d-flex justify-content-end align-items-center gap-2 order-3"><span class="small">${escape_html(version === "local-build" ? version : "v" + version)}</span></div></div> <div class="offcanvas offcanvas-bottom d-xl-none w-100" tabindex="-1" id="mobileMenuOffcanvas" aria-labelledby="mobileMenuOffcanvasLabel" style="z-index: 1080; height: auto !important;"><div class="offcanvas-header border-bottom"><div class="offcanvas-title fw-bold" id="mobileMenuOffcanvasLabel"></div> <button type="button" class="btn-close shadow-none" data-bs-dismiss="offcanvas" aria-label="Close"></button></div> <div class="offcanvas-body p-0"><ul class="navbar-nav"><li class="nav-item text-center border-bottom py-3"><a class="nav-link d-block w-100"${attr("href", `${stringify(PANO_WEBSITE_URL)}/docs`)} target="_blank" rel="noreferrer"${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("buttons.docs"))}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.docs"))}</a></li> <li class="nav-item text-center border-bottom py-3"><a class="nav-link d-block w-100"${attr("href", `${stringify(PANO_WEBSITE_URL)}/discord`)} target="_blank" rel="noreferrer" aria-label="Discord">Discord</a></li></ul></div></div></nav>`);
    if ($$store_subs) unsubscribe_stores($$store_subs);
    bind_props($$props, { version });
  });
}
function PageTitle($$renderer, $$props) {
  let title = fallback($$props["title"], "");
  let subtitle = fallback($$props["subtitle"], "");
  let html$1 = fallback($$props["html"], false);
  let subtitleHtml = fallback($$props["subtitleHtml"], false);
  $$renderer.push(`<div class="container text-center animate__animated animate__fadeIn" style="animation-duration: 500ms;"><h2 class="mb-0 text-break fw-normal"><!--[-->`);
  slot($$renderer, $$props, "title", {}, () => {
    if (title) {
      $$renderer.push("<!--[0-->");
      if (html$1) {
        $$renderer.push("<!--[0-->");
        $$renderer.push(`${html(title)}`);
      } else {
        $$renderer.push("<!--[-1-->");
        $$renderer.push(`${escape_html(title)}`);
      }
      $$renderer.push(`<!--]-->`);
    } else {
      $$renderer.push("<!--[-1-->");
    }
    $$renderer.push(`<!--]-->`);
  });
  $$renderer.push(`<!--]--></h2> `);
  if (subtitle) {
    $$renderer.push("<!--[0-->");
    $$renderer.push(`<p class="mb-0 mt-2 opacity-75">`);
    if (subtitleHtml) {
      $$renderer.push("<!--[0-->");
      $$renderer.push(`${html(subtitle)}`);
    } else {
      $$renderer.push("<!--[-1-->");
      $$renderer.push(`${escape_html(subtitle)}`);
    }
    $$renderer.push(`<!--]--></p>`);
  } else {
    $$renderer.push("<!--[-1-->");
  }
  $$renderer.push(`<!--]--></div>`);
  bind_props($$props, { title, subtitle, html: html$1, subtitleHtml });
}
function PageHeader($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    var $$store_subs;
    let resolvedTitle;
    let backgroundImage = fallback($$props["backgroundImage"], void 0);
    let title = fallback($$props["title"], void 0);
    let subTitle = fallback($$props["subTitle"], void 0);
    const pageTitle2 = getContext("pageTitle");
    resolvedTitle = title || (!store_get($$store_subs ??= {}, "$pageTitle", pageTitle2) ? null : typeof store_get($$store_subs ??= {}, "$pageTitle", pageTitle2) === "object" ? store_get($$store_subs ??= {}, "$_", $format)(store_get($$store_subs ??= {}, "$pageTitle", pageTitle2).id, store_get($$store_subs ??= {}, "$pageTitle", pageTitle2).options) : store_get($$store_subs ??= {}, "$_", $format)(store_get($$store_subs ??= {}, "$pageTitle", pageTitle2)));
    $$renderer2.push(`<div class="hero"${attr_style(backgroundImage ? `--bg-image: radial-gradient(circle at 50% 100%, var(--bs-body-bg) 0%, transparent 500%), url('${backgroundImage}')` : "--bg-image: radial-gradient(circle at 50% 100%, var(--bs-body-bg) 0%, transparent 500%)")}><div class="hero-content d-flex justify-content-center align-items-center h-100 w-100"><!--[-->`);
    slot($$renderer2, $$props, "content", {}, () => {
      PageTitle($$renderer2, {
        subtitle: subTitle,
        $$slots: {
          title: ($$renderer3) => {
            {
              $$renderer3.push(`<!--[-->`);
              slot($$renderer3, $$props, "prefix", {}, null);
              $$renderer3.push(`<!--]-->${escape_html(resolvedTitle)}<!--[-->`);
              slot($$renderer3, $$props, "suffix", {}, null);
              $$renderer3.push(`<!--]-->`);
            }
          }
        }
      });
    });
    $$renderer2.push(`<!--]--></div></div>`);
    if ($$store_subs) unsubscribe_stores($$store_subs);
    bind_props($$props, { backgroundImage, title, subTitle });
  });
}
function PageActions($$renderer, $$props) {
  const $$slots = sanitize_slots($$props);
  let leftClasses = fallback($$props["leftClasses"], void 0);
  let middleClasses = fallback($$props["middleClasses"], void 0);
  let rightClasses = fallback($$props["rightClasses"], void 0);
  $$renderer.push(`<div class="row d-flex align-items-center gy-3 justify-content-lg-between justify-content-center">`);
  if (leftClasses !== null && $$slots.left || leftClasses !== null && leftClasses !== void 0) {
    $$renderer.push("<!--[0-->");
    $$renderer.push(`<div${attr_class(`col-lg-auto col-12 d-flex justify-content-lg-start overflow-x-auto scroll-center ${stringify(leftClasses || "")}`, "svelte-cy2g2a")}><!--[-->`);
    slot($$renderer, $$props, "left", {}, null);
    $$renderer.push(`<!--]--></div>`);
  } else {
    $$renderer.push("<!--[-1-->");
  }
  $$renderer.push(`<!--]--> `);
  if (middleClasses !== null && $$slots.middle || middleClasses !== null && middleClasses !== void 0) {
    $$renderer.push("<!--[0-->");
    $$renderer.push(`<div${attr_class(`col-lg-auto col-12 order-lg-2 order-last d-flex justify-content-center overflow-x-auto scroll-center ${stringify(middleClasses || "")}`, "svelte-cy2g2a")}><!--[-->`);
    slot($$renderer, $$props, "middle", {}, null);
    $$renderer.push(`<!--]--></div>`);
  } else {
    $$renderer.push("<!--[-1-->");
  }
  $$renderer.push(`<!--]--> `);
  if (rightClasses !== null && $$slots.right || rightClasses !== null && rightClasses !== void 0) {
    $$renderer.push("<!--[0-->");
    $$renderer.push(`<div${attr_class(`col-lg-auto col-12 order-3 d-flex justify-content-lg-end overflow-x-auto scroll-center ${stringify(rightClasses || "")}`, "svelte-cy2g2a")}><!--[-->`);
    slot($$renderer, $$props, "right", {}, null);
    $$renderer.push(`<!--]--></div>`);
  } else {
    $$renderer.push("<!--[-1-->");
  }
  $$renderer.push(`<!--]--></div>`);
  bind_props($$props, { leftClasses, middleClasses, rightClasses });
}
function PageNav($$renderer, $$props) {
  $$renderer.push(`<ul class="nav nav-pills d-flex flex-nowrap overflow-x-auto text-nowrap no-scrollbar scroll-center svelte-glgdy8"><!--[-->`);
  slot($$renderer, $$props, "default", {}, null);
  $$renderer.push(`<!--]--></ul>`);
}
const pageTitle = writable(null);
async function loadServer(input) {
  const { url: { pathname }, locals: { acceptedLanguage, CSRFToken } } = input;
  const apiUrlEnv = process.env.API_URL;
  const panoWebsiteUrlEnv = process.env.PANO_WEBSITE_URL;
  if (apiUrlEnv) {
    updateApiUrl(apiUrlEnv);
  }
  if (panoWebsiteUrlEnv) {
    updatePanoWebsiteUrl(panoWebsiteUrlEnv);
  }
  const stepInfo = await checkCurrentStep();
  const { step } = stepInfo;
  const route = checkRoute(step, pathname);
  if (route) {
    throw redirect(302, route);
  }
  return {
    stepInfo,
    acceptedLanguage,
    CSRFToken,
    apiUrlEnv,
    panoWebsiteUrlEnv
  };
}
async function load(event) {
  const {
    data,
    data: {
      stepInfo: { step, locale },
      CSRFToken,
      apiUrlEnv,
      panoWebsiteUrlEnv
    }
  } = event;
  if (apiUrlEnv) {
    updateApiUrl(apiUrlEnv);
  }
  if (panoWebsiteUrlEnv) {
    updatePanoWebsiteUrl(panoWebsiteUrlEnv);
  }
  session.set({ CSRFToken });
  currentStep.set(step);
  await init(locale, event);
  return data;
}
function MainLayout($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    var $$store_subs;
    const steps = [
      { name: "steps.website.title", icon: "fa-solid fa-globe" },
      { name: "steps.database.title", icon: "fa-solid fa-database" },
      { name: "steps.email.title", icon: "fa-solid fa-envelope" },
      { name: "steps.account.title", icon: "fa-solid fa-user" }
    ];
    let stepInfo = $$props["stepInfo"];
    setContext("pageTitle", pageTitle);
    if (store_get($$store_subs ??= {}, "$currentStep", currentStep) !== void 0) {
      navigationState.update((s) => ({
        ...s,
        nextDisabled: store_get($$store_subs ??= {}, "$currentStep", currentStep) === 4,
        nextLoading: false,
        nextLabel: store_get($$store_subs ??= {}, "$currentStep", currentStep) === 4 ? "buttons.finish" : store_get($$store_subs ??= {}, "$currentStep", currentStep) === 0 ? "buttons.start" : "buttons.next",
        nextAction: null,
        showSkip: store_get($$store_subs ??= {}, "$currentStep", currentStep) === 3,
        skipAction: null
      }));
    }
    if (store_get($$store_subs ??= {}, "$currentStep", currentStep) === 0) {
      pageTitle.set("welcome-title");
    } else {
      pageTitle.set(steps[store_get($$store_subs ??= {}, "$currentStep", currentStep) - 1]?.name || "");
    }
    head("1vud52s", $$renderer2, ($$renderer3) => {
      $$renderer3.title(($$renderer4) => {
        $$renderer4.push(`<title>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("title"))}</title>`);
      });
    });
    App($$renderer2, {
      children: ($$renderer3) => {
        $$renderer3.push(`<div${attr_class("svelte-1vud52s", void 0, {
          "d-none": store_get($$store_subs ??= {}, "$isFinishing", isFinishing)
        })}>`);
        Navbar($$renderer3, { version: stepInfo.version });
        $$renderer3.push(`<!----></div> <div${attr_class("page-header-wrapper svelte-1vud52s", void 0, {
          "finishing": store_get($$store_subs ??= {}, "$isFinishing", isFinishing) && !stepInfo.error
        })}>`);
        PageHeader($$renderer3, {
          title: store_get($$store_subs ??= {}, "$_", $format)("title"),
          subTitle: store_get($$store_subs ??= {}, "$currentStep", currentStep) !== 0 ? `(${store_get($$store_subs ??= {}, "$currentStep", currentStep)}/4)` : void 0,
          backgroundImage: "/assets/img/cover.png"
        });
        $$renderer3.push(`<!----></div> <div class="container svelte-1vud52s">`);
        if (store_get($$store_subs ??= {}, "$isFinishing", isFinishing)) {
          $$renderer3.push("<!--[0-->");
          $$renderer3.push(`<div class="loading-container svelte-1vud52s"><div class="loader-content position-relative svelte-1vud52s" style="height: 100px; width: 100px;"><div class="logo-wrapper pano-anim center-content svelte-1vud52s"><img alt="Pano"${attr("src", `${stringify(base)}/assets/img/logo.svg`)} class="logo-img svelte-1vud52s"/></div> <div class="mc-img-wrapper mc-anim center-content svelte-1vud52s"><img alt="Minecraft"${attr("src", `${stringify(base)}/assets/img/minecraft-icon.png`)} class="mc-img svelte-1vud52s"/></div> <div class="hytale-img-wrapper hytale-anim center-content svelte-1vud52s"><img alt="Hytale"${attr("src", `${stringify(base)}/assets/img/hytale-icon.png`)} class="hytale-img svelte-1vud52s"/></div></div></div>`);
        } else {
          $$renderer3.push("<!--[-1-->");
        }
        $$renderer3.push(`<!--]--> <div${attr_class("vstack gap-3 svelte-1vud52s", void 0, {
          "d-none": store_get($$store_subs ??= {}, "$isFinishing", isFinishing)
        })}>`);
        ErrorAlert($$renderer3, { error: stepInfo.error });
        $$renderer3.push(`<!----> `);
        PageActions($$renderer3, {
          $$slots: {
            left: ($$renderer4) => {
              $$renderer4.push(`<div slot="left" class="svelte-1vud52s">`);
              if (store_get($$store_subs ??= {}, "$currentStep", currentStep) !== 0) {
                $$renderer4.push("<!--[0-->");
                PageNav($$renderer4, {
                  children: ($$renderer5) => {
                    $$renderer5.push(`<!--[-->`);
                    const each_array = ensure_array_like(steps);
                    for (let index = 0, $$length = each_array.length; index < $$length; index++) {
                      let step = each_array[index];
                      const stepNumber = index + 1;
                      $$renderer5.push(`<li class="nav-item svelte-1vud52s"><button${attr_class("nav-link svelte-1vud52s", void 0, {
                        "active": store_get($$store_subs ??= {}, "$currentStep", currentStep) === stepNumber,
                        "completed": store_get($$store_subs ??= {}, "$currentStep", currentStep) > stepNumber,
                        "disabled": store_get($$store_subs ??= {}, "$currentStep", currentStep) < stepNumber
                      })}${attr("disabled", store_get($$store_subs ??= {}, "$currentStep", currentStep) < stepNumber, true)}><span class="svelte-1vud52s">${escape_html(store_get($$store_subs ??= {}, "$_", $format)(step.name))}</span></button></li>`);
                    }
                    $$renderer5.push(`<!--]-->`);
                  },
                  $$slots: { default: true }
                });
              } else {
                $$renderer4.push("<!--[-1-->");
              }
              $$renderer4.push(`<!--]--></div>`);
            },
            right: ($$renderer4) => {
              $$renderer4.push(`<div slot="right" class="hstack gap-2 svelte-1vud52s">`);
              if (store_get($$store_subs ??= {}, "$currentStep", currentStep) !== 0) {
                $$renderer4.push("<!--[0-->");
                $$renderer4.push(`<button class="btn btn-link svelte-1vud52s"${attr("disabled", store_get($$store_subs ??= {}, "$navigationState", navigationState).nextLoading, true)}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.back"))}</button>`);
              } else {
                $$renderer4.push("<!--[-1-->");
              }
              $$renderer4.push(`<!--]--> `);
              if (store_get($$store_subs ??= {}, "$currentStep", currentStep) === 0 && store_get($$store_subs ??= {}, "$navigationState", navigationState).showTransfer) {
                $$renderer4.push("<!--[0-->");
                $$renderer4.push(`<button class="btn btn-primary svelte-1vud52s"${attr("disabled", store_get($$store_subs ??= {}, "$navigationState", navigationState).nextLoading, true)}><i class="fa-solid fa-undo me-2 svelte-1vud52s"></i>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("import.toggle-btn"))}</button>`);
              } else {
                $$renderer4.push("<!--[-1-->");
              }
              $$renderer4.push(`<!--]--> <div class="btn-group svelte-1vud52s">`);
              if (store_get($$store_subs ??= {}, "$navigationState", navigationState).showSkip) {
                $$renderer4.push("<!--[0-->");
                $$renderer4.push(`<button class="btn btn-secondary svelte-1vud52s"${attr("disabled", store_get($$store_subs ??= {}, "$navigationState", navigationState).nextLoading, true)}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.skip"))}</button>`);
              } else {
                $$renderer4.push("<!--[-1-->");
              }
              $$renderer4.push(`<!--]--> <button class="btn btn-secondary svelte-1vud52s"${attr("disabled", store_get($$store_subs ??= {}, "$navigationState", navigationState).nextDisabled || store_get($$store_subs ??= {}, "$navigationState", navigationState).nextLoading, true)}>`);
              if (store_get($$store_subs ??= {}, "$navigationState", navigationState).nextLoading) {
                $$renderer4.push("<!--[0-->");
                $$renderer4.push(`<span class="spinner-border spinner-border-sm me-2 svelte-1vud52s" role="status"></span>`);
              } else {
                $$renderer4.push("<!--[-1-->");
              }
              $$renderer4.push(`<!--]--> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)(store_get($$store_subs ??= {}, "$navigationState", navigationState).nextLabel))}</button></div></div>`);
            }
          }
        });
        $$renderer3.push(`<!----> <div class="card svelte-1vud52s"><!--[-->`);
        slot($$renderer3, $$props, "default", {}, null);
        $$renderer3.push(`<!--]--></div></div></div>`);
      },
      $$slots: { default: true }
    });
    $$renderer2.push(`<!----> `);
    ToastContainer($$renderer2);
    $$renderer2.push(`<!---->`);
    if ($$store_subs) unsubscribe_stores($$store_subs);
    bind_props($$props, { stepInfo });
  });
}

export { MainLayout as M, loadServer as a, load as l };
//# sourceMappingURL=MainLayout.js-CbADtAzE.js.map
