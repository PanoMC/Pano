import { i as attr, b as escape_html, s as store_get, u as unsubscribe_stores, c as bind_props } from './root.js-QX3SkSrm.js';
import { C as CardHeader } from './CardHeader.js-SSCSdGwL.js';
import { n as navigationState, d as nextStep } from './Store.js-vRMTfo1I.js';
import { $ as $format } from './runtime.js-CSUW-DLZ.js';
import { o as onDestroy } from './index-server.js-DHKOtNbE.js';
import { a8 as fallback } from './effects.js-DAVcbH3F.js';

async function load({ parent }) {
  const { stepInfo: { websiteName, websiteDescription, websiteUrl } } = await parent();
  return { stepInfo: { websiteName, websiteDescription, websiteUrl } };
}
function Step1($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    var $$store_subs;
    let disabled, typedHost, hostMismatch, typedPort, hasExplicitPort, portMismatch;
    let loading = false;
    let websiteName = fallback($$props["websiteName"], "");
    let websiteDescription = fallback($$props["websiteDescription"], "");
    let websiteUrl = fallback($$props["websiteUrl"], "");
    function extractHost(value) {
      if (!value) return "";
      try {
        const normalized = value.includes("://") ? value : "https://" + value;
        return new URL(normalized).hostname;
      } catch (_) {
        return value.replace(/^https?:\/\//, "").split("/")[0].split(":")[0];
      }
    }
    function extractPort(value) {
      if (!value) return "";
      try {
        const normalized = value.includes("://") ? value : "https://" + value;
        return new URL(normalized).port;
      } catch (_) {
        return "";
      }
    }
    onDestroy(() => {
      navigationState.update((s) => {
        if (s.nextAction === submit) {
          return { ...s, nextAction: null, nextLoading: false };
        }
        return s;
      });
    });
    function submit() {
      if (!loading && !disabled) {
        loading = true;
        nextStep({ websiteName, websiteDescription, websiteUrl });
      }
    }
    disabled = websiteName === "" || websiteDescription === "" || websiteUrl === "";
    typedHost = extractHost(websiteUrl);
    hostMismatch = typeof window !== "undefined" && typedHost !== "" && typedHost.toLowerCase() !== window.location.hostname.toLowerCase();
    typedPort = extractPort(websiteUrl);
    hasExplicitPort = typedPort !== "";
    portMismatch = typeof window !== "undefined" && hasExplicitPort && typedPort !== window.location.port;
    navigationState.update((s) => ({
      ...s,
      nextDisabled: disabled,
      nextLoading: loading,
      nextAction: submit,
      showSkip: false
    }));
    $$renderer2.push(`<div class="animate__animated animate__fadeIn animate__slower"><form>`);
    CardHeader($$renderer2, {
      children: ($$renderer3) => {
        $$renderer3.push(`<!---->${escape_html(store_get($$store_subs ??= {}, "$_", $format)("steps.website.title"))}`);
      },
      $$slots: { default: true }
    });
    $$renderer2.push(`<!----> <div class="card-body vstack gap-3"><div class="d-flex flex-column"><div class="form-floating input-group-top svelte-664cqt"><input id="websiteName" class="form-control form-control-lg rounded-bottom-0 svelte-664cqt" placeholder="Panocraft" type="text"${attr("value", websiteName)}/> <label for="websiteName">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("steps.website.inputs.title"))}</label></div> <div class="form-floating input-group-bottom svelte-664cqt"><textarea id="websiteDescription" class="form-control rounded-top-0" placeholder=" " style="height: 128px;">`);
    const $$body = escape_html(websiteDescription);
    if ($$body) {
      $$renderer2.push(`${$$body}`);
    }
    $$renderer2.push(`</textarea> <label for="websiteDescription">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("steps.website.inputs.description"))}</label></div></div> <div><div class="form-floating"><input id="websiteUrl" class="form-control"${attr("placeholder", store_get($$store_subs ??= {}, "$_", $format)("steps.website.inputs.url-placeholder"))} type="text"${attr("value", websiteUrl)}/> <label for="websiteUrl">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("steps.website.inputs.url"))}</label></div> <div class="form-text">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("steps.website.inputs.url-helper"))}</div> `);
    if (hostMismatch) {
      $$renderer2.push("<!--[0-->");
      $$renderer2.push(`<div class="alert alert-warning d-flex align-items-start mt-2 mb-0"><i class="fas fa-triangle-exclamation me-2 mt-1"></i> <div>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("steps.website.inputs.url-host-mismatch"))}</div></div>`);
    } else {
      $$renderer2.push("<!--[-1-->");
    }
    $$renderer2.push(`<!--]--> `);
    if (portMismatch) {
      $$renderer2.push("<!--[0-->");
      $$renderer2.push(`<div class="alert alert-warning d-flex align-items-start mt-2 mb-0"><i class="fas fa-triangle-exclamation me-2 mt-1"></i> <div>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("steps.website.inputs.url-port-mismatch", {
        values: { port: typedPort, current: window.location.port || "80/443" }
      }))}</div></div>`);
    } else {
      $$renderer2.push("<!--[-1-->");
    }
    $$renderer2.push(`<!--]--> `);
    if (hasExplicitPort) {
      $$renderer2.push("<!--[0-->");
      $$renderer2.push(`<div class="alert alert-warning d-flex align-items-start mt-2 mb-0"><i class="fas fa-triangle-exclamation me-2 mt-1"></i> <div>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("steps.website.inputs.url-explicit-port", { values: { port: typedPort } }))}</div></div>`);
    } else {
      $$renderer2.push("<!--[-1-->");
    }
    $$renderer2.push(`<!--]--></div></div></form></div>`);
    if ($$store_subs) unsubscribe_stores($$store_subs);
    bind_props($$props, { websiteName, websiteDescription, websiteUrl });
  });
}

export { Step1 as S, load as l };
//# sourceMappingURL=Step1.js-Bgh0pr07.js.map
