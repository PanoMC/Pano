import { g as attr_class, b as escape_html, s as store_get, i as attr, u as unsubscribe_stores, c as bind_props } from './root.js-QX3SkSrm.js';
import { C as CardHeader } from './CardHeader.js-SSCSdGwL.js';
import { $ as $format } from './runtime.js-CSUW-DLZ.js';
import { o as onDestroy } from './index-server.js-DHKOtNbE.js';
import { n as navigationState, A as ApiUtil, d as nextStep, N as NETWORK_ERROR } from './Store.js-vRMTfo1I.js';
import { E as ErrorAlert } from './ErrorAlert.js-BrOLI8U-.js';
import { a8 as fallback } from './effects.js-DAVcbH3F.js';

async function load({ parent }) {
  const parentData = await parent();
  const { stepInfo } = parentData;
  return { stepInfo };
}
function Step2($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    var $$store_subs;
    let portableSupported, disabled;
    let loading = false;
    let error = null;
    let dbType = fallback($$props["dbType"], "mariadb");
    let installLoading = false;
    let installed = fallback($$props["installed"], false);
    let portableDatabaseSupported = fallback($$props["portableDatabaseSupported"], false);
    let supportedSystems = fallback($$props["supportedSystems"], () => [], true);
    let database = fallback($$props["database"], () => ({ host: "", dbName: "", username: "", password: "", prefix: "" }), true);
    onDestroy(() => {
      clearInterval(progressInterval);
      navigationState.update((s) => {
        if (s.nextAction === submit) {
          return { ...s, nextAction: null, nextLoading: false };
        }
        return s;
      });
    });
    let progressInterval;
    function submit() {
      if (loading || disabled) return;
      loading = true;
      error = null;
      if (dbType === "portable" && installed) {
        next();
        return;
      }
      ApiUtil.post({ path: "/api/setup/steps/2/verify", body: database }).then((body) => {
        if (body.result === "ok") {
          next();
        } else if (body.error) {
          showError(body.error === "INVALID_DATA" ? "INVALID_DB_DATA" : body.error);
        } else showError(NETWORK_ERROR);
      }).catch(() => {
        showError(NETWORK_ERROR);
      });
    }
    function next() {
      if (!portableSupported && dbType === "portable") dbType = "mariadb";
      nextStep({ ...database, dbType });
    }
    function showError(errorCode) {
      loading = false;
      error = errorCode;
    }
    portableSupported = portableDatabaseSupported;
    if (!portableSupported && dbType === "portable") dbType = "mariadb";
    disabled = dbType === "mariadb" ? database.host === "" || database.dbName === "" || database.username === "" : !installed;
    navigationState.update((s) => ({
      ...s,
      nextDisabled: disabled,
      nextLoading: loading,
      nextAction: submit
    }));
    $$renderer2.push(`<div class="animate__animated animate__fadeIn"><div>`);
    CardHeader($$renderer2, {
      children: ($$renderer3) => {
        $$renderer3.push(`<!---->${escape_html(store_get($$store_subs ??= {}, "$_", $format)("steps.database.title"))}`);
      },
      $$slots: { default: true }
    });
    $$renderer2.push(`<!----> <div class="card-body vstack gap-3"><ul class="nav nav-pills nav-fill"><li class="nav-item"><button type="button"${attr_class("nav-link", void 0, {
      "active": dbType === "portable",
      "disabled": !portableSupported
    })}>`);
    if (dbType === "portable") {
      $$renderer2.push("<!--[0-->");
      $$renderer2.push(`<i class="fa fa-check me-2"></i>`);
    } else {
      $$renderer2.push("<!--[-1-->");
    }
    $$renderer2.push(`<!--]--> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("steps.database.databases.local-portable-db"))}</button></li> <li class="nav-item"><button type="button"${attr_class("nav-link", void 0, { "active": dbType === "mariadb" })}>`);
    if (dbType === "mariadb") {
      $$renderer2.push("<!--[0-->");
      $$renderer2.push(`<i class="fa fa-check me-2"></i>`);
    } else {
      $$renderer2.push("<!--[-1-->");
    }
    $$renderer2.push(`<!--]--> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("steps.database.databases.mysql-or-mariadb"))}</button></li></ul> `);
    ErrorAlert($$renderer2, { error });
    $$renderer2.push(`<!----> `);
    if (dbType === "portable") {
      $$renderer2.push("<!--[0-->");
      $$renderer2.push(`<div class="vstack gap-2"><small class="opacity-75">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("steps.database.databases.local-portable-db-description"))}</small> `);
      if (!portableSupported) {
        $$renderer2.push("<!--[0-->");
        $$renderer2.push(`<div class="alert alert-warning mb-0 p-2 small"><i class="fa fa-exclamation-triangle me-2"></i> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("steps.database.databases.portable-not-supported"))} <br/> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("steps.database.databases.supported-systems", { values: { systems: supportedSystems.join(", ") } }))}</div>`);
      } else if (!installed) {
        $$renderer2.push("<!--[1-->");
        $$renderer2.push(`<button type="button" class="btn btn-primary mt-1 text-decoration-none"${attr("disabled", installLoading, true)}>`);
        {
          $$renderer2.push("<!--[-1-->");
          $$renderer2.push(`<i class="fa fa-download me-2"></i> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("steps.database.databases.download-and-install"))}`);
        }
        $$renderer2.push(`<!--]--></button>`);
      } else {
        $$renderer2.push("<!--[-1-->");
        $$renderer2.push(`<div class="badge text-bg-success rounded-pill me-auto"><i class="fa fa-check-circle me-1"></i> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("steps.database.databases.portable-installed"))}</div>`);
      }
      $$renderer2.push(`<!--]--></div>`);
    } else {
      $$renderer2.push("<!--[-1-->");
      $$renderer2.push(`<small class="opacity-75">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("steps.database.databases.mysql-or-mariadb-description"))}</small>`);
    }
    $$renderer2.push(`<!--]--> <div${attr_class("d-flex flex-column align-items-center w-100 pt-2", void 0, { "d-none": dbType === "portable" })}><div class="merged-grid w-100 svelte-9kuec6"><div class="form-floating svelte-9kuec6"><input class="form-control svelte-9kuec6" id="databaseAddress" placeholder="localhost:3306"${attr("value", database.host)} type="text"/> <label for="databaseAddress">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("steps.database.inputs.address"))}</label></div> <div class="form-floating svelte-9kuec6"><input class="form-control svelte-9kuec6" id="databaseName" placeholder="pano"${attr("value", database.dbName)} type="text"/> <label for="databaseName">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("steps.database.inputs.name"))}</label></div> <div class="form-floating svelte-9kuec6"><input class="form-control svelte-9kuec6" id="databaseUserName" placeholder="root"${attr("value", database.username)} type="text"/> <label for="databaseUserName">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("steps.database.inputs.username"))}</label></div> <div class="form-floating svelte-9kuec6"><input class="form-control svelte-9kuec6" id="databaseUserPassword" placeholder="****************"${attr("value", database.password)} type="password"/> <label for="databaseUserPassword">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("steps.database.inputs.password"))}</label></div></div> <div class="form-floating w-100 mt-3 prefix-input-wrapper"><input class="form-control" id="databaseTablePrefix" placeholder="pano_"${attr("value", database.prefix)} type="text"/> <label for="databaseTablePrefix">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("steps.database.inputs.prefix"))}</label></div></div></div></div></div>`);
    if ($$store_subs) unsubscribe_stores($$store_subs);
    bind_props($$props, {
      dbType,
      installed,
      portableDatabaseSupported,
      supportedSystems,
      database
    });
  });
}

export { Step2 as S, load as l };
//# sourceMappingURL=Step2.js-WmtNUeTK.js.map
