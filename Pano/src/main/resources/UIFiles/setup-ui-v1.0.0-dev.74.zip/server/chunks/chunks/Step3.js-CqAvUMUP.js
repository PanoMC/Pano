import { g as attr_class, b as escape_html, s as store_get, e as ensure_array_like, i as attr, u as unsubscribe_stores, c as bind_props } from './root.js-QX3SkSrm.js';
import { C as CardHeader } from './CardHeader.js-SSCSdGwL.js';
import { $ as $format } from './runtime.js-CSUW-DLZ.js';
import { o as onDestroy } from './index-server.js-DHKOtNbE.js';
import { n as navigationState, A as ApiUtil, d as nextStep, N as NETWORK_ERROR } from './Store.js-vRMTfo1I.js';
import { E as ErrorAlert } from './ErrorAlert.js-BrOLI8U-.js';
import { g as get, w as writable } from './index.js-l_eu7De0.js';
import { a8 as fallback } from './effects.js-DAVcbH3F.js';

const modalElement = writable();
let modal;
const error = writable(null);
const continueProcessObj = writable();
function show(continueProcess) {
  error.set(null);
  continueProcessObj.set(continueProcess);
  modal = new window.bootstrap.Modal(get(modalElement), { backdrop: "static", keyboard: false });
  modal.show();
}
function ConfirmSkipSMTPModal($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    var $$store_subs;
    let loading = false;
    $$renderer2.push(`<div aria-hidden="true" class="modal fade" role="dialog" tabindex="-1"><div class="modal-dialog modal-dialog-centered" role="dialog"><div class="modal-content"><div class="modal-body text-center"><div class="pb-3"><i class="fas fa-question-circle fa-3x d-block m-auto text-gray"></i></div> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.confirm-skip-smtp.title"))} <br/> <br/> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.confirm-skip-smtp.description"))}</div> <div class="modal-footer flex-nowrap"><button${attr_class("btn btn-link col-6 m-0", void 0, { "disabled": loading })} type="button">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.cancel"))}</button> <button${attr_class("btn btn-danger col-6 m-0", void 0, { "disabled": loading })} type="button">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.yes"))}</button></div></div></div></div>`);
    if ($$store_subs) unsubscribe_stores($$store_subs);
  });
}
const defaultMailConfiguration = Object.freeze({ ssl: true, starttls: "DISABLED", port: 465, authMethods: "" });
const services = Object.freeze({
  GMAIL: {
    name: "GMail",
    config: {
      ...defaultMailConfiguration,
      hostname: "smtp.gmail.com",
      port: 587,
      ssl: false,
      starttls: "REQUIRED",
      authMethods: "PLAIN"
    }
  },
  YAHOO: {
    name: "Yahoo",
    config: { ...defaultMailConfiguration, hostname: "smtp.mail.yahoo.com" }
  },
  YANDEX: {
    name: "Yandex",
    config: {
      ...defaultMailConfiguration,
      hostname: "smtp.yandex.com",
      port: 465,
      ssl: true,
      starttls: "DISABLED",
      authMethods: "PLAIN"
    }
  },
  MAIL_RU: {
    name: "Mail.ru",
    config: { ...defaultMailConfiguration, hostname: "smtp.mail.ru" }
  },
  OUTLOOK: {
    name: "Hotmail / Outlook",
    config: {
      ...defaultMailConfiguration,
      hostname: "smtp-mail.outlook.com",
      port: 587
    }
  },
  OTHER: {
    name: "buttons.other",
    config: { ...defaultMailConfiguration }
  }
});
async function load({ parent }) {
  const { stepInfo } = await parent();
  const { email } = stepInfo;
  const { sender, hostname, username, password, port } = email;
  let chosenService = null;
  if (sender && hostname && username && password && port) {
    Object.keys(services).forEach((service) => {
      const serviceOptions = services[service];
      if (serviceOptions.config.hostname === hostname) {
        chosenService = service;
      }
    });
    if (!chosenService) {
      chosenService = "OTHER";
    }
  }
  const mailConfiguration = { [chosenService]: email };
  return { stepInfo: { mailConfiguration, chosenService } };
}
function Step3($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    var $$store_subs;
    let disabled;
    let loading = false;
    let error2 = null;
    let chosenService = $$props["chosenService"];
    let lastChosenService = null;
    let mailConfiguration = fallback($$props["mailConfiguration"], () => ({}), true);
    onDestroy(() => {
      navigationState.update((s) => {
        if (s.nextAction === next) {
          return {
            ...s,
            nextAction: null,
            nextLoading: false,
            showSkip: false,
            skipAction: null
          };
        }
        return s;
      });
    });
    async function showError(errorCode) {
      loading = false;
      error2 = errorCode;
    }
    async function next() {
      if (disabled) {
        return;
      }
      loading = true;
      error2 = null;
      ApiUtil.post({
        path: "/api/setup/steps/3/verify",
        body: mailConfiguration[chosenService]
      }).then((body) => {
        if (body.result === "ok") {
          nextStep(mailConfiguration[chosenService]);
          return;
        }
        loading = false;
        if (body.error) {
          showError(body.error === "INVALID_DATA" ? {
            key: "INVALID_EMAIL_DATA",
            props: { mailError: body.mailError }
          } : body.error);
        } else showError(NETWORK_ERROR);
      }).catch(() => {
        loading = false;
        showError(NETWORK_ERROR);
      });
    }
    function skip() {
      show(() => {
        loading = true;
        error2 = null;
        nextStep();
      });
    }
    if (chosenService) {
      lastChosenService = chosenService;
    }
    disabled = !chosenService || chosenService && (!mailConfiguration[chosenService].port || !mailConfiguration[chosenService].sender || !mailConfiguration[chosenService].hostname || !mailConfiguration[chosenService].username || !mailConfiguration[chosenService].password);
    navigationState.update((s) => ({
      ...s,
      nextDisabled: disabled,
      nextLoading: loading,
      nextAction: next,
      showSkip: true,
      skipAction: skip
    }));
    $$renderer2.push(`<div class="animate__animated animate__fadeIn animate_animate__slower"><form>`);
    CardHeader($$renderer2, {
      children: ($$renderer3) => {
        $$renderer3.push(`<!---->${escape_html(store_get($$store_subs ??= {}, "$_", $format)("steps.email.title"))}`);
      },
      $$slots: { default: true }
    });
    $$renderer2.push(`<!----> <div class="card-body vstack gap-3 overflow-hidden p-0"><div${attr_class("smtp-steps-container svelte-9o2tcf", void 0, { "slide-active": chosenService })}><div class="smtp-step-pane p-3 svelte-9o2tcf"><div class="mb-3">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("steps.email.description"))}</div> <div class="list-group"><!--[-->`);
    const each_array = ensure_array_like(Object.keys(services));
    for (let index = 0, $$length = each_array.length; index < $$length; index++) {
      let service = each_array[index];
      $$renderer2.push(`<button type="button" class="list-group-item list-group-item-action fw-normal">${escape_html(store_get($$store_subs ??= {}, "$_", $format)(services[service].name) || services[service].name)}</button>`);
    }
    $$renderer2.push(`<!--]--></div></div> <div class="smtp-step-pane p-3 svelte-9o2tcf">`);
    if (lastChosenService && mailConfiguration[lastChosenService]) {
      $$renderer2.push("<!--[0-->");
      $$renderer2.push(`<button type="button" class="btn btn-link px-0 text-decoration-none mb-3"><i class="fa-solid fa-arrow-left me-1"></i> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("steps.email.return-back-to-service-list-text"))}</button> <div class="vstack gap-2"><h5>${escape_html(store_get($$store_subs ??= {}, "$_", $format)(services[lastChosenService].name))}</h5> `);
      ErrorAlert($$renderer2, { error: error2 });
      $$renderer2.push(`<!----> <div class="merged-grid w-100 svelte-9o2tcf"><div class="form-floating svelte-9o2tcf"><input class="form-control svelte-9o2tcf" id="mailUsername" type="text" placeholder="no-reply"${attr("value", mailConfiguration[lastChosenService].username)}/> <label for="mailUsername">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("steps.email.inputs.username"))}</label></div> <div class="form-floating svelte-9o2tcf"><input class="form-control svelte-9o2tcf" id="mailUserPassword" placeholder="****************" type="password"${attr("value", mailConfiguration[lastChosenService].password)}/> <label for="mailUserPassword">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("steps.email.inputs.password"))}</label></div></div></div> <details><summary class="pt-3">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("steps.email.inputs.details-button"))}</summary> <div class="row g-3 pt-2"><div class="col-12 col-md-6 mb-3"><label class="form-label">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("steps.email.inputs.ssl"))}</label> <div class="form-check"><input class="form-check-input" type="checkbox" name="ssl" id="ssl"${attr("aria-checked", mailConfiguration[lastChosenService].ssl)}${attr("checked", mailConfiguration[lastChosenService].ssl, true)}/> <label class="form-check-label" for="ssl">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("steps.email.inputs.active"))}</label></div></div> <div class="col-12 col-md-6 mb-3"><label class="form-label" for="port">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("steps.email.inputs.tls-setting"))}</label> `);
      $$renderer2.select(
        {
          class: "form-select",
          id: "port",
          value: mailConfiguration[lastChosenService].starttls
        },
        ($$renderer3) => {
          $$renderer3.option({ value: "REQUIRED" }, ($$renderer4) => {
            $$renderer4.push(`REQUIRED`);
          });
          $$renderer3.option({ value: "OPTIONAL" }, ($$renderer4) => {
            $$renderer4.push(`OPTIONAL`);
          });
          $$renderer3.option({ value: "DISABLED" }, ($$renderer4) => {
            $$renderer4.push(`DISABLED`);
          });
        }
      );
      $$renderer2.push(`</div></div> <div class="row"><div class="col-12 col-md-6"><div class="mb-3"><label class="form-label" for="sendingAddress">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("steps.email.inputs.sending-address"))}</label> <input class="form-control" id="sendingAddress" type="text" placeholder="no-reply@forexample.com"${attr("value", mailConfiguration[lastChosenService].sender)}/></div></div> <div class="col-12 col-md-6"><div class="mb-3"><label class="form-label" for="hostname">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("steps.email.inputs.hostname"))}</label> <input class="form-control" id="hostname" type="text" placeholder="smtp.forexample.com"${attr("value", mailConfiguration[lastChosenService].hostname)}/></div></div> <div class="col-12 col-md-6"><div class="mb-3"><label class="form-label" for="port">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("steps.email.inputs.port"))}</label> <input class="form-control" id="port" placeholder="465" type="number"${attr("value", mailConfiguration[lastChosenService].port)}/></div></div> <div class="col-12 col-md-6"><div class="mb-3"><label class="form-label" for="port">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("steps.email.inputs.auth-method"))}</label> `);
      $$renderer2.select(
        {
          class: "form-select",
          value: mailConfiguration[lastChosenService].authMethods
        },
        ($$renderer3) => {
          $$renderer3.option({ value: "PLAIN" }, ($$renderer4) => {
            $$renderer4.push(`PLAIN`);
          });
          $$renderer3.option({ value: "" }, ($$renderer4) => {
          });
        }
      );
      $$renderer2.push(`</div></div></div></details>`);
    } else {
      $$renderer2.push("<!--[-1-->");
    }
    $$renderer2.push(`<!--]--></div></div></div></form></div> `);
    ConfirmSkipSMTPModal($$renderer2);
    $$renderer2.push(`<!---->`);
    if ($$store_subs) unsubscribe_stores($$store_subs);
    bind_props($$props, { chosenService, mailConfiguration });
  });
}

export { Step3 as S, load as l };
//# sourceMappingURL=Step3.js-CqAvUMUP.js.map
