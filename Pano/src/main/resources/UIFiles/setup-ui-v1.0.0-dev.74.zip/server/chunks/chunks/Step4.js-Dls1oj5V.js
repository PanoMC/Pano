import { s as store_get, i as attr, b as escape_html, g as attr_class, l as attr_style, u as unsubscribe_stores, c as bind_props, o as store_set, p as derived, j as stringify } from './root.js-QX3SkSrm.js';
import { C as CardHeader } from './CardHeader.js-SSCSdGwL.js';
import { d as PANEL_URL, $ as $format } from './runtime.js-CSUW-DLZ.js';
import { o as onDestroy } from './index-server.js-DHKOtNbE.js';
import './exports.js-BZBK1HC9.js';
import './utils.js-BQzn9ikS.js';
import { a8 as fallback } from './effects.js-DAVcbH3F.js';
import { b as base } from './server.js-Bf8x1V_n.js';
import './utils2.js-Ke2uzSud.js';
import './state.svelte.js-IvJbnGzW.js';
import { n as navigationState, A as ApiUtil, i as isFinishing, N as NETWORK_ERROR } from './Store.js-vRMTfo1I.js';
import { E as ErrorAlert } from './ErrorAlert.js-BrOLI8U-.js';
import { c as currentLanguage } from './language.util.js-nasHThMs.js';

function ConfirmRemovePanoAccountModal($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    var $$store_subs;
    let loading = false;
    $$renderer2.push(`<div aria-hidden="true" class="modal fade" role="dialog" tabindex="-1"><div class="modal-dialog modal-dialog-centered" role="dialog"><div class="modal-content"><div class="modal-body text-center"><div class="pb-3"><i class="fas fa-question-circle fa-3x d-block m-auto text-gray"></i></div> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.confirm-remove-pano-account.title"))}</div> <div class="modal-footer flex-nowrap"><button${attr_class("btn btn-link col-6 m-0", void 0, { "disabled": loading })} type="button">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.cancel"))}</button> <button${attr_class("btn btn-danger col-6 m-0", void 0, { "disabled": loading })} type="button">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.yes"))}</button></div></div></div></div>`);
    if ($$store_subs) unsubscribe_stores($$store_subs);
  });
}
const PRIVACY_POLICY_URL = "https://panomc.com/privacy-policy";
const TELEMETRY_DOCS_URL = "https://panomc.com/docs/platform/configuration/telemetry/";
function UsageDataModal($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    var $$store_subs;
    const OPTION_TOKEN = "\0";
    const turnOffParts = derived(() => store_get($$store_subs ??= {}, "$_", $format)("components.modals.usage-data.turn-off", { values: { option: OPTION_TOKEN } }).split(OPTION_TOKEN));
    const turnOffOption = derived(() => store_get($$store_subs ??= {}, "$_", $format)("components.modals.usage-data.turn-off-option"));
    $$renderer2.push(`<div aria-hidden="true" class="modal fade" role="dialog" tabindex="-1"><div class="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable" role="dialog"><div class="modal-content"><div class="modal-header"><h5 class="modal-title">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.usage-data.title"))}</h5> <button${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("buttons.close"))} class="btn-close" type="button"></button></div> <div class="modal-body"><ul class="usage-data-list mb-3 svelte-15wue8v"><li class="svelte-15wue8v">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.usage-data.sent-platform"))}</li> <li class="svelte-15wue8v">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.usage-data.sent-system"))}</li> <li class="svelte-15wue8v">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.usage-data.sent-website"))}</li> <li class="svelte-15wue8v">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.usage-data.sent-ip"))}</li> <li class="svelte-15wue8v">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.usage-data.sent-resources"))}</li> <li class="svelte-15wue8v">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.usage-data.sent-counts"))}</li> <li class="svelte-15wue8v">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.usage-data.sent-account"))}</li> <li class="svelte-15wue8v">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.usage-data.sent-install"))}</li></ul> <p class="text-body-secondary mb-0">${escape_html(turnOffParts()[0])}<code>${escape_html(turnOffOption())}</code>${escape_html(turnOffParts()[1] ?? "")}</p></div> <div class="modal-footer"><a${attr("href", PRIVACY_POLICY_URL)} rel="noopener" target="_blank">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.usage-data.privacy-policy"))}</a> <a${attr("href", TELEMETRY_DOCS_URL)} rel="noopener" target="_blank">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.usage-data.learn-more"))}</a></div></div></div></div>`);
    if ($$store_subs) unsubscribe_stores($$store_subs);
  });
}
async function load({ parent, url: { searchParams } }) {
  const { stepInfo: { account, panoAccount } } = await parent();
  const failed = searchParams.get("failed");
  const encodedData = searchParams.get("encodedData");
  const state = searchParams.get("state");
  return {
    stepInfo: { account, panoAccount, failed, encodedData, state }
  };
}
function Step4($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    var $$store_subs;
    let telemetryLabelParts, disabled;
    let account = fallback($$props["account"], () => ({ username: "", password: "", email: "" }), true);
    let panoAccount = $$props["panoAccount"];
    let failed = $$props["failed"];
    let encodedData = $$props["encodedData"];
    let state = $$props["state"];
    let loading = false;
    let error = null;
    let connecting = !panoAccount && state && encodedData;
    let disconnecting;
    let telemetryEnabled = true;
    const TELEMETRY_LINK_TOKEN = "\0";
    onDestroy(() => {
      navigationState.update((s) => {
        if (s.nextAction === submit) {
          return {
            ...s,
            nextAction: null,
            nextLoading: false,
            nextLabel: "buttons.next"
          };
        }
        return s;
      });
    });
    async function submit() {
      store_set(isFinishing, true);
      loading = true;
      error = null;
      ApiUtil.post({
        path: "/api/setup/finish",
        body: {
          ...account,
          setupLocale: store_get($$store_subs ??= {}, "$currentLanguage", currentLanguage).locale,
          telemetryEnabled
        }
      }).then((body) => {
        if (body.result === "ok") {
          window.location.assign(PANEL_URL);
        } else if (body.error) {
          showError(body.error);
        } else {
          showError(NETWORK_ERROR);
          console.log(body);
        }
      }).catch(() => {
        showError(NETWORK_ERROR);
      });
    }
    async function showError(errorCode) {
      loading = false;
      store_set(isFinishing, false);
      error = errorCode;
    }
    function maskEmail(email) {
      const [localPart, domain] = email.split("@");
      const maskedLocal = localPart.length <= 3 ? `${localPart[0]}**` : `${localPart.substring(0, 2)}${"*".repeat(localPart.length - 2)}`;
      const domainParts = domain.split(".");
      const maskedDomain = `${domainParts[0][0]}${"*".repeat(domainParts[0].length - 1)}.${domainParts.slice(1).join(".")}`;
      return `${maskedLocal}@${maskedDomain}`;
    }
    telemetryLabelParts = store_get($$store_subs ??= {}, "$_", $format)("steps.account.telemetry.label", { values: { link: TELEMETRY_LINK_TOKEN } }).split(TELEMETRY_LINK_TOKEN);
    disabled = account.username === "" || account.password === "" || account.password.length < 6 || account.password.length > 128 || account.email === "" || account.passwordRepeat !== account.password;
    navigationState.update((s) => ({
      ...s,
      nextDisabled: disabled,
      nextLoading: loading,
      nextAction: submit,
      nextLabel: "buttons.finish"
    }));
    $$renderer2.push(`<div class="animate__animated animate__fadeIn animate__slower"><form>`);
    CardHeader($$renderer2, {
      children: ($$renderer3) => {
        $$renderer3.push(`<!---->${escape_html(store_get($$store_subs ??= {}, "$_", $format)("steps.account.title"))}`);
      },
      $$slots: { default: true }
    });
    $$renderer2.push(`<!----> <div class="card-body vstack gap-3">`);
    ErrorAlert($$renderer2, { error });
    $$renderer2.push(`<!----> `);
    if (!panoAccount && failed) {
      $$renderer2.push("<!--[0-->");
      $$renderer2.push(`<div class="alert alert-danger alert-dismissible fade show mb-0" role="alert"><button type="button" class="btn-close" data-bs-dismiss="alert"${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("buttons.close"))}></button> <i class="fa-solid fa-triangle-exclamation me-2"></i> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("connect-failed-alert"))}</div>`);
    } else {
      $$renderer2.push("<!--[-1-->");
    }
    $$renderer2.push(`<!--]--> <div class="d-flex flex-column align-items-center w-100"><div class="merged-grid w-100 svelte-1vh96co"><div class="form-floating svelte-1vh96co"><input class="form-control svelte-1vh96co" id="admin-email" type="email" placeholder="admin@example.com"${attr("value", account.email)}/> <label for="admin-email">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("steps.account.inputs.email"))}</label></div> <div class="form-floating svelte-1vh96co"><input class="form-control svelte-1vh96co" id="admin-username" type="text" placeholder="admin"${attr("value", account.username)}/> <label for="admin-username">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("steps.account.inputs.username"))}</label></div> <div class="form-floating svelte-1vh96co"><input type="password" class="form-control svelte-1vh96co" id="admin-password" placeholder="************"${attr("value", account.password)}/> <label for="admin-password">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("steps.account.inputs.password"))}</label></div> <div class="form-floating svelte-1vh96co"><input type="password" class="form-control svelte-1vh96co" id="admin-password-repeat" placeholder="************"${attr("value", account.passwordRepeat)}/> <label for="admin-password-repeat">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("steps.account.inputs.password-repeat"))}</label></div></div> <small class="text-body-secondary w-100 mt-2">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("steps.account.inputs.password-help-text"))}</small></div> <div class="row g-3"><div class="col vstack gap-2"><div${attr_class("alert alert-secondary connect-account-board border mb-0 focus-ring svelte-1vh96co", void 0, { "interactive": !panoAccount && !connecting })} role="alert"${attr_style(`background-image: var(--welcome-gradient), url('${stringify(base)}/assets/img/connect-pano-bg.png');`)}><div class="row align-items-center"><div class="col-lg-9"><h5 class="alert-heading mb-2"><i class="fa-solid fa-circle-user me-2"></i> ${escape_html(panoAccount ? panoAccount.username : store_get($$store_subs ??= {}, "$_", $format)("steps.account.online-account"))}</h5> <p${attr_class("mb-0", void 0, { "text-success": panoAccount, "text-body": !panoAccount })}>${escape_html(panoAccount ? "Pano hesabınız başarıyla bağlandı." : store_get($$store_subs ??= {}, "$_", $format)("steps.account.online-account-description"))}</p></div> <div class="col-lg-3 text-lg-end mt-3 mt-lg-0">`);
    if (panoAccount) {
      $$renderer2.push("<!--[0-->");
      $$renderer2.push(`<div class="hstack gap-2 justify-content-lg-end"><span class="badge text-bg-gray">${escape_html(maskEmail(panoAccount.email))}</span> <button type="button" class="btn-close"${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("buttons.remove"))}${attr("disabled", disconnecting, true)}></button></div>`);
    } else {
      $$renderer2.push("<!--[-1-->");
      $$renderer2.push(`<div class="alert-link rounded border-0 bg-transparent p-0 svelte-1vh96co">${escape_html(connecting ? store_get($$store_subs ??= {}, "$_", $format)("buttons.connecting") : store_get($$store_subs ??= {}, "$_", $format)("buttons.connect"))} `);
      if (connecting) {
        $$renderer2.push("<!--[0-->");
        $$renderer2.push(`<span class="spinner-border spinner-border-sm text-primary ms-2" role="status"></span>`);
      } else {
        $$renderer2.push("<!--[-1-->");
        $$renderer2.push(`<i class="fa-solid fa-arrow-right ms-1"></i>`);
      }
      $$renderer2.push(`<!--]--></div>`);
    }
    $$renderer2.push(`<!--]--></div></div></div></div></div> <div class="form-check"><input class="form-check-input" type="checkbox" id="telemetry-enabled"${attr("checked", telemetryEnabled, true)}/> <label class="form-check-label" for="telemetry-enabled">${escape_html(telemetryLabelParts[0])}<button class="btn btn-link align-baseline p-0" type="button">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("steps.account.telemetry.label-link"))}</button>${escape_html(telemetryLabelParts[1] ?? "")}</label> <small class="text-body-secondary d-block">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("steps.account.telemetry.description"))}</small></div></div></form></div> `);
    ConfirmRemovePanoAccountModal($$renderer2);
    $$renderer2.push(`<!----> `);
    UsageDataModal($$renderer2);
    $$renderer2.push(`<!---->`);
    if ($$store_subs) unsubscribe_stores($$store_subs);
    bind_props($$props, { account, panoAccount, failed, encodedData, state });
  });
}

export { Step4 as S, load as l };
//# sourceMappingURL=Step4.js-Dls1oj5V.js.map
