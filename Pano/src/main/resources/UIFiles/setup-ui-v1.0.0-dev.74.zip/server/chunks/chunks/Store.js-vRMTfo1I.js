import { A as API_URL, b as CSRF_HEADER } from './runtime.js-CSUW-DLZ.js';
import { w as writable, g as get } from './index.js-l_eu7De0.js';
import { a7 as browser } from './effects.js-DAVcbH3F.js';
import './exports.js-BZBK1HC9.js';
import './utils.js-BQzn9ikS.js';
import './utils2.js-Ke2uzSud.js';
import { e as ensure_array_like, s as store_get, a as spread_props, u as unsubscribe_stores } from './root.js-QX3SkSrm.js';
import './state.svelte.js-IvJbnGzW.js';

function goto(url, opts = {}) {
  {
    throw new Error("Cannot call goto(...) on the server");
  }
}
const toasts = writable([]);
Array.prototype.insert = function(index, item) {
  this.splice(index, 0, item);
  return this;
};
Array.prototype.remove = function(index) {
  this.splice(index, 1);
  return this;
};
function ToastContainer($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    var $$store_subs;
    $$renderer2.push(`<div class="toast-container position-fixed bottom-0 start-50 translate-middle-x mb-3"><!--[-->`);
    const each_array = ensure_array_like(store_get($$store_subs ??= {}, "$toasts", toasts));
    for (let index = 0, $$length = each_array.length; index < $$length; index++) {
      let toast = each_array[index];
      if (toast.component) {
        $$renderer2.push("<!--[-->");
        toast.component($$renderer2, spread_props([{ id: toast.id }, toast.params]));
        $$renderer2.push("<!--]-->");
      } else {
        $$renderer2.push("<!--[!-->");
        $$renderer2.push("<!--]-->");
      }
    }
    $$renderer2.push(`<!--]--></div>`);
    if ($$store_subs) unsubscribe_stores($$store_subs);
  });
}
const NETWORK_ERROR = "NETWORK_ERROR";
const ApiUtil = {
  interceptors: {},
  // GET request
  async get({ path, request, csrfToken, token, blob, handler }) {
    return this.customRequest({
      path,
      request,
      csrfToken,
      token,
      blob,
      handler
    });
  },
  // POST request
  async post({ path, request, body, headers, csrfToken, token, blob, handler, onUploadProgress }) {
    return this.customRequest({
      path,
      data: { method: "POST", credentials: "include", body, headers },
      request,
      csrfToken,
      token,
      blob,
      handler,
      onUploadProgress
    });
  },
  // PUT request
  async put({ path, request, body, headers, csrfToken, token, blob, handler, onUploadProgress }) {
    return this.customRequest({
      path,
      data: { method: "PUT", credentials: "include", body, headers },
      request,
      csrfToken,
      token,
      blob,
      handler,
      onUploadProgress
    });
  },
  // DELETE request
  async delete({ path, request, headers, csrfToken, token, blob, handler }) {
    return this.customRequest({
      path,
      data: { method: "DELETE", headers },
      request,
      csrfToken,
      token,
      blob,
      handler
    });
  },
  // Custom request handler
  async customRequest({ path, data = {}, request, csrfToken, token, blob, handler, onUploadProgress }) {
    if (!csrfToken) {
      let session2;
      if (request && typeof request.parent === "function") {
        const parentData = await request.parent();
        session2 = parentData.session;
      }
      csrfToken = session2 && session2.csrfToken;
    }
    const CSRFHeader = csrfToken ? { [CSRF_HEADER]: csrfToken } : {};
    if (!(data.body instanceof FormData)) {
      data.body = JSON.stringify(data.body);
      data.headers = { "Content-Type": "application/json", ...data.headers };
    }
    const options = {
      ...data,
      headers: { ...data.headers, ...CSRFHeader }
    };
    if (token) {
      options.headers["Authorization"] = `Bearer ${token}`;
    } else if ("credentials" in Request.prototype) {
      options["credentials"] = "include";
    }
    const hasEventFetch = request && request.fetch;
    const isReverseProxied = !API_URL.includes(".panomc.com");
    if (hasEventFetch && isReverseProxied) {
      if (!path.startsWith("/api/")) {
        path = `/api/${path.replace("/api/", "")}`;
      }
    } else if (request && !get(initialized) || !browser || API_URL.includes(".panomc.com")) {
      let apiUrl = API_URL;
      if (!API_URL.includes(".panomc.com") && true && browser) ;
      path = `${apiUrl}/${path.replace("/api/", "")}`;
    }
    const bodyHandler = (response) => blob ? response.blob() : response.text();
    const jsonParseHandler = (json) => {
      try {
        return JSON.parse(json);
      } catch (err) {
        return json;
      }
    };
    const requestCall = (rejectHandler) => {
      const reject = async (err) => {
        console.log(err);
        if (rejectHandler) {
          throw new Error(err);
        }
        if (!this.interceptors.errorHandler || !handler) {
          return;
        }
        this.interceptors.errorHandler(requestCall);
      };
      const fetchMethod = request && request.fetch ? request.fetch(path, options) : fetch(path, options);
      return fetchMethod.then(bodyHandler).then(jsonParseHandler).then(async (parsedJson) => {
        if (parsedJson?.error === "DISABLED_FOR_DEMO") {
          return;
        }
        return handler ? await handler(parsedJson, reject) : parsedJson;
      }).catch(reject);
    };
    return requestCall();
  }
};
const isFinishing = writable(false);
const session = writable({});
const currentStep = writable(0);
const initialized = writable(false);
function checkRoute(step, pathname) {
  const stepLocation = "/step-" + step;
  if (step === 0 && pathname !== "/") {
    return "/";
  } else if (step !== 0 && pathname !== stepLocation) {
    return stepLocation;
  } else {
    return null;
  }
}
const navigationState = writable({
  nextDisabled: false,
  nextLoading: false,
  nextLabel: "buttons.next",
  nextAction: null,
  backDisabled: false,
  showSkip: false,
  skipAction: null
});
function checkCurrentStep() {
  return ApiUtil.get({ path: "/api/setup/step" }).then((body) => {
    if (body.error) {
      return { ...body, step: 0 };
    }
    return body;
  }).catch(() => {
    return { error: NETWORK_ERROR, step: 0 };
  });
}
function initializeCurrentStep(path) {
  checkCurrentStep().then(async (stepInfo) => {
    const { step } = stepInfo;
    currentStep.set(step);
    await goto();
  });
}
function nextStep(body, path) {
  ApiUtil.put({
    path: "/api/setup/step",
    body: { ...body, clientStep: get(currentStep) }
  }).then(() => {
    initializeCurrentStep();
  });
}

export { ApiUtil as A, NETWORK_ERROR as N, ToastContainer as T, currentStep as a, checkRoute as b, checkCurrentStep as c, nextStep as d, isFinishing as i, navigationState as n, session as s };
//# sourceMappingURL=Store.js-vRMTfo1I.js.map
