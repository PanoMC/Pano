import { n as ssr_context } from './root.js-QX3SkSrm.js';

function onDestroy(fn) {
  /** @type {SSRContext} */
  ssr_context.r.on_destroy(fn);
}

export { onDestroy as o };
//# sourceMappingURL=index-server.js-DHKOtNbE.js.map
