import { r as root } from './root.js-QX3SkSrm.js';

let read_implementation = null;
function set_read_implementation(fn) {
  read_implementation = fn;
}
let public_env = {};
function set_private_env(environment) {
}
function set_public_env(environment) {
  public_env = environment;
}
const error = ({ status, message }) => '<!doctype html>\n<html lang="en">\n	<head>\n		<meta charset="utf-8" />\n		<title>' + message + `</title>

		<style>
			body {
				--bg: white;
				--fg: #222;
				--divider: #ccc;
				background: var(--bg);
				color: var(--fg);
				font-family:
					system-ui,
					-apple-system,
					BlinkMacSystemFont,
					'Segoe UI',
					Roboto,
					Oxygen,
					Ubuntu,
					Cantarell,
					'Open Sans',
					'Helvetica Neue',
					sans-serif;
				display: flex;
				align-items: center;
				justify-content: center;
				height: 100vh;
				margin: 0;
			}

			.error {
				display: flex;
				align-items: center;
				max-width: 32rem;
				margin: 0 1rem;
			}

			.status {
				font-weight: 200;
				font-size: 3rem;
				line-height: 1;
				position: relative;
				top: -0.05rem;
			}

			.message {
				border-left: 1px solid var(--divider);
				padding: 0 0 0 1rem;
				margin: 0 0 0 1rem;
				min-height: 2.5rem;
				display: flex;
				align-items: center;
			}

			.message h1 {
				font-weight: 400;
				font-size: 1em;
				margin: 0;
			}

			@media (prefers-color-scheme: dark) {
				body {
					--bg: #222;
					--fg: #ddd;
					--divider: #666;
				}
			}
		</style>
	</head>
	<body>
		<div class="error">
			<span class="status">` + status + '</span>\n			<div class="message">\n				<h1>' + message + "</h1>\n			</div>\n		</div>\n	</body>\n</html>\n";
const options = {
  app_template_contains_nonce: false,
  async: false,
  csp: { "mode": "auto", "directives": { "upgrade-insecure-requests": false, "block-all-mixed-content": false }, "reportOnly": { "upgrade-insecure-requests": false, "block-all-mixed-content": false } },
  csrf_check_origin: true,
  csrf_trusted_origins: [],
  embedded: false,
  env_public_prefix: "PUBLIC_",
  env_private_prefix: "",
  hash_routing: false,
  hooks: null,
  // added lazily, via `get_hooks`
  preload_strategy: "modulepreload",
  root,
  service_worker: false,
  service_worker_options: void 0,
  server_error_boundaries: false,
  templates: {
    app: ({ head, body, assets, nonce, env }) => '<!DOCTYPE html>\n<html lang="en" data-bs-theme="dark">\n  <head>\n    <meta charset="utf-8" />\n    <meta name="description" content="" />\n    <link rel="icon" href="' + assets + `/assets/favicon/favicon.ico" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <script>
      // Hydration watchdog. A failed ES-module fetch is cached in the browser's
      // module map for the lifetime of the document (per HTML spec), so a single
      // transient 404/5xx on any script chunk leaves the SSR'd wizard permanently
      // dead with no retry. Recover with ONE cache-busting reload; the root layout
      // sets __PANO_APP_BOOTED__ once the page really hydrated.
      (function () {
        var KEY = "pano:hydration-reload";
        var MODULE_ERROR =
          /(failed to fetch dynamically imported module|error loading dynamically imported module|importing a module script failed|failed to resolve module specifier|import map|pano-runtime|failed to load module script)/i;
        function recover(message) {
          if (window.__PANO_APP_BOOTED__) return;
          if (!MODULE_ERROR.test(String(message || ""))) return;
          try {
            if (sessionStorage.getItem(KEY) === "1") return;
            sessionStorage.setItem(KEY, "1");
          } catch (e) {
            return;
          }
          var url = new URL(location.href);
          url.searchParams.set("pano-rl", Date.now().toString(36));
          location.replace(url.href);
        }
        addEventListener(
          "error",
          function (e) {
            recover(e.message || (e.error && e.error.message));
          },
          true,
        );
        addEventListener("unhandledrejection", function (e) {
          var r = e.reason;
          recover(r && (r.message || r));
        });
      })();
    <\/script>
    %pano_lib_import%
    ` + head + '\n  </head>\n  <body class="blocks">\n    <div>' + body + "</div>\n  </body>\n</html>\n",
    error
  },
  version_hash: "11kip91"
};
async function get_hooks() {
  let handle;
  let handleFetch;
  let handleError;
  let handleValidationError;
  let init;
  ({ handle, handleFetch, handleError, handleValidationError, init } = await import('../entries/hooks.server.js-PfE6n8yO.js'));
  let reroute;
  let transport;
  return {
    handle,
    handleFetch,
    handleError,
    handleValidationError,
    init,
    reroute,
    transport
  };
}

export { set_public_env as a, set_read_implementation as b, get_hooks as g, options as o, public_env as p, read_implementation as r, set_private_env as s };
//# sourceMappingURL=internal2.js-2stKda1M.js.map
