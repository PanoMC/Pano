import { g as get, w as writable } from './index.js-l_eu7De0.js';
import { w as waitLocale, i as init$1, r as registerLocaleLoader } from './runtime.js-CSUW-DLZ.js';

const loadedLanguages = writable([]);
const languageLoading = writable(false);
const currentLanguage = writable(null);
const Languages = writable({});
async function fetchLanguages(event) {
  if (Object.keys(get(Languages)).length > 0) {
    return;
  }
  const response = await event.fetch("/setup-api/languages");
  const languages = await response.json();
  Languages.set(languages);
}
async function init(initialLocale, event) {
  languageLoading.set(true);
  await fetchLanguages(event);
  const language = getLanguageByLocale(initialLocale);
  const languageToLoad = language || get(Languages)["en-US"];
  await loadLanguage(get(Languages)["en-US"], event);
  await loadLanguage(languageToLoad, event);
  currentLanguage.set(languageToLoad);
  await waitLocale();
  init$1({
    fallbackLocale: "en-US",
    initialLocale: languageToLoad.locale
  });
  languageLoading.set(false);
}
function getAcceptedLanguage(headers) {
  if (typeof headers.get("accept-language") === "undefined" || headers.get("accept-language") == null) {
    return "";
  }
  return headers.get("accept-language").split(",")[0];
}
async function loadLanguage(language, event) {
  if (get(loadedLanguages).indexOf(language) !== -1) {
    return;
  }
  loadedLanguages.update((list) => {
    list.push(language);
    return list;
  });
  const useFetch = event ? event.fetch : fetch;
  const response = await useFetch(`/setup-api/languages/${language.locale}.json`);
  const languageFile = await response.json();
  registerLocaleLoader(language.locale, async () => languageFile);
  await waitLocale(language.locale);
  if (language.derivatives) {
    for (const derivative of language.derivatives) {
      registerLocaleLoader(derivative, async () => languageFile);
      await waitLocale(language.locale);
    }
  }
}
function getLanguageByLocale(locale) {
  let foundLanguage = null;
  const languages = get(Languages);
  Object.keys(languages).forEach((key) => {
    const language = languages[key];
    if (language.locale === locale) {
      foundLanguage = language;
    }
  });
  return foundLanguage;
}

export { Languages as L, currentLanguage as c, getAcceptedLanguage as g, init as i, languageLoading as l };
//# sourceMappingURL=language.util.js-nasHThMs.js.map
