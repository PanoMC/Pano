import { n as noop } from './effects.js-DAVcbH3F.js';
import './exports.js-BZBK1HC9.js';
import './utils2.js-Ke2uzSud.js';
import './root.js-QX3SkSrm.js';

const is_legacy = noop.toString().includes("$$") || /function \w+\(\) \{\}/.test(noop.toString());
const placeholder_url = "a:";
if (is_legacy) {
  ({
    url: new URL(placeholder_url)
  });
}
//# sourceMappingURL=state.svelte.js-IvJbnGzW.js.map
