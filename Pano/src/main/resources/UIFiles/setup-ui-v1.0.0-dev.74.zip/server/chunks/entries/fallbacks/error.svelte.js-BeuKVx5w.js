import { b as escape_html, k as getContext } from '../../chunks/root.js-QX3SkSrm.js';
import '../../chunks/state.svelte.js-IvJbnGzW.js';
import '../../chunks/exports.js-BZBK1HC9.js';
import '../../chunks/utils.js-BQzn9ikS.js';
import '../../chunks/utils2.js-Ke2uzSud.js';
import '../../chunks/effects.js-DAVcbH3F.js';

function context() {
  return getContext("__request__");
}
const page$1 = {
  get error() {
    return context().page.error;
  },
  get status() {
    return context().page.status;
  }
};
const page = page$1;
function Error$1($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    $$renderer2.push(`<h1>${escape_html(page.status)}</h1> <p>${escape_html(page.error?.message)}</p>`);
  });
}

export { Error$1 as default };
//# sourceMappingURL=error.svelte.js-BeuKVx5w.js.map
