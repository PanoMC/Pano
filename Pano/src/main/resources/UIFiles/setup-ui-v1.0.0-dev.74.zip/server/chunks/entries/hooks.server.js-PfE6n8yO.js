import { A as API_URL, C as COOKIE_PREFIX, a as CSRF_TOKEN_COOKIE_NAME } from '../chunks/runtime.js-CSUW-DLZ.js';
import { g as getAcceptedLanguage } from '../chunks/language.util.js-nasHThMs.js';
import '../chunks/index.js-l_eu7De0.js';
import '../chunks/effects.js-DAVcbH3F.js';
import '../index.js-BVhB7Rbp.js';
import '../chunks/utils2.js-Ke2uzSud.js';
import '../chunks/utils.js-BQzn9ikS.js';
import '../chunks/server.js-Bf8x1V_n.js';
import '../chunks/exports.js-BZBK1HC9.js';
import '../chunks/internal2.js-2stKda1M.js';
import '../chunks/root.js-QX3SkSrm.js';

const isDev = process.env.NODE_ENV === "development";
const v = isDev ? "" : `?v=${Date.now()}`;
const LIB_IMPORT = `<script defer src="/lib/bootstrap/bootstrap.bundle.min.js${v}"><\/script>`;
const PLACEHOLDER = "%pano_lib_import%";
const PLACEHOLDER_LEN = PLACEHOLDER.length;
function getCookieWithHttpFallback(cookies, baseName) {
  return cookies.get(baseName) ?? cookies.get(`${baseName}_http`);
}
async function handle({
  event,
  event: {
    cookies,
    request: { headers }
  },
  resolve
}) {
  event.locals.acceptedLanguage = getAcceptedLanguage(headers);
  event.locals.CSRFToken = getCookieWithHttpFallback(cookies, COOKIE_PREFIX + CSRF_TOKEN_COOKIE_NAME);
  return resolve(event, {
    transformPageChunk: ({ html }) => {
      const index = html.indexOf(PLACEHOLDER);
      if (index === -1) return html;
      return html.substring(0, index) + LIB_IMPORT + html.substring(index + PLACEHOLDER_LEN);
    }
  });
}
function handleError({ error, event }) {
  console.log("!!! [GLOBAL ERROR EVENT]:", event.url.href);
  console.error("!!! [GLOBAL ERROR CONTENT]:", error);
  return {
    message: "Internal Error",
    code: error?.code
  };
}
async function handleFetch({ event, request, fetch }) {
  if (request.url.startsWith(event.url.origin + "/api/")) {
    const apiPath = new URL(request.url).pathname + new URL(request.url).search;
    const backendUrl = API_URL.replace(/\/api\/?$/, "") + apiPath;
    request = new Request(backendUrl, request);
    request.headers.set("cookie", event.request.headers.get("cookie") || "");
    request.headers.set("Origin", API_URL);
  } else if (request.url.startsWith(API_URL)) {
    request.headers.set("cookie", event.request.headers.get("cookie") || "");
    request.headers.set("Origin", API_URL);
  }
  return fetch(request);
}

export { handle, handleError, handleFetch };
//# sourceMappingURL=hooks.server.js-PfE6n8yO.js.map
