function _page($$renderer) {
}

export { _page as default };
//# sourceMappingURL=_page.svelte.js-D-vLhrzB.js.map
