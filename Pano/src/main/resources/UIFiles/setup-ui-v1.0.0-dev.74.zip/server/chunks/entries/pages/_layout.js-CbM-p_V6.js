import { l as load } from '../../chunks/MainLayout.js-CbADtAzE.js';

var _layout = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

export { _layout as _ };
//# sourceMappingURL=_layout.js-CbM-p_V6.js.map
