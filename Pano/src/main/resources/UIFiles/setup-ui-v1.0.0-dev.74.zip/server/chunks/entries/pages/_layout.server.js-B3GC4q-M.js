import { a as loadServer } from '../../chunks/MainLayout.js-CbADtAzE.js';

var _layout_server = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: loadServer
});

export { _layout_server as _ };
//# sourceMappingURL=_layout.server.js-B3GC4q-M.js.map
