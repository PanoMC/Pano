import { c as bind_props, f as slot } from '../../chunks/root.js-QX3SkSrm.js';
import '../../chunks/exports.js-BZBK1HC9.js';
import '../../chunks/utils.js-BQzn9ikS.js';
import '../../chunks/utils2.js-Ke2uzSud.js';
import '../../chunks/state.svelte.js-IvJbnGzW.js';
import { M as MainLayout } from '../../chunks/MainLayout.js-CbADtAzE.js';
import '../../chunks/effects.js-DAVcbH3F.js';
import '../../chunks/runtime.js-CSUW-DLZ.js';
import '../../chunks/index.js-l_eu7De0.js';
import '../../index.js-BVhB7Rbp.js';
import '../../chunks/server.js-Bf8x1V_n.js';
import '../../chunks/internal2.js-2stKda1M.js';
import '../../chunks/Store.js-vRMTfo1I.js';
import '../../chunks/ErrorAlert.js-BrOLI8U-.js';
import '../../chunks/language.util.js-nasHThMs.js';

function _layout($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let data = $$props["data"];
    MainLayout($$renderer2, {
      stepInfo: data.stepInfo,
      children: ($$renderer3) => {
        $$renderer3.push(`<!--[-->`);
        slot($$renderer3, $$props, "default", {}, null);
        $$renderer3.push(`<!--]-->`);
      },
      $$slots: { default: true }
    });
    bind_props($$props, { data });
  });
}

export { _layout as default };
//# sourceMappingURL=_layout.svelte.js-DI1wGey6.js.map
