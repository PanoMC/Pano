import { c as bind_props, g as attr_class, s as store_get, b as escape_html, i as attr, e as ensure_array_like, u as unsubscribe_stores, j as stringify } from '../../chunks/root.js-QX3SkSrm.js';
import { n as navigationState, d as nextStep } from '../../chunks/Store.js-vRMTfo1I.js';
import { o as onDestroy } from '../../chunks/index-server.js-DHKOtNbE.js';
import { c as currentLanguage, L as Languages, l as languageLoading } from '../../chunks/language.util.js-nasHThMs.js';
import { e as $isLoading, $ as $format, P as PANO_WEBSITE_URL } from '../../chunks/runtime.js-CSUW-DLZ.js';
import '../../chunks/effects.js-DAVcbH3F.js';
import '../../chunks/utils2.js-Ke2uzSud.js';
import '../../chunks/utils.js-BQzn9ikS.js';
import '../../chunks/index.js-l_eu7De0.js';
import '../../chunks/exports.js-BZBK1HC9.js';
import '../../chunks/state.svelte.js-IvJbnGzW.js';
import '../../index.js-BVhB7Rbp.js';
import '../../chunks/server.js-Bf8x1V_n.js';
import '../../chunks/internal2.js-2stKda1M.js';

function Beginning($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    var $$store_subs;
    let disabled;
    let stepInfo = $$props["stepInfo"];
    let loading = false;
    let showTransferModal = false;
    let modalStep = "selection";
    let transferCode = "";
    let platformUrl = "";
    let urlConnecting = false;
    let isUrlConnected = false;
    function openTransferModal() {
      modalStep = "selection";
      transferCode = "";
      platformUrl = "";
      urlConnecting = false;
      isUrlConnected = false;
      showTransferModal = true;
    }
    onDestroy(() => {
      navigationState.update((s) => {
        if (s.nextAction === start) {
          return {
            ...s,
            nextAction: null,
            nextLoading: false,
            backDisabled: false,
            nextLabel: "buttons.next",
            showTransfer: false,
            transferAction: null
          };
        }
        return s;
      });
    });
    function start() {
      if (!disabled) {
        loading = true;
        nextStep({
          locale: store_get($$store_subs ??= {}, "$currentLanguage", currentLanguage).locale
        });
      }
    }
    disabled = !!stepInfo.error;
    navigationState.update((s) => ({
      ...s,
      nextDisabled: disabled,
      nextLoading: loading,
      nextAction: start,
      nextLabel: "buttons.start",
      backDisabled: true,
      showTransfer: true,
      transferAction: openTransferModal
    }));
    $$renderer2.push(`<div${attr_class("", void 0, { "opacity-50": disabled })}>`);
    if (stepInfo.stage === "ALPHA" && !store_get($$store_subs ??= {}, "$languageLoading", languageLoading) && !store_get($$store_subs ??= {}, "$isLoading", $isLoading)) {
      $$renderer2.push("<!--[0-->");
      $$renderer2.push(`<div class="card-body pb-0"><div class="alert alert-warning mb-0"><h6 class="alert-heading hstack gap-2"><i class="fa-solid fa-triangle-exclamation"></i> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("alpha-warning.title"))}</h6> <p class="mb-0 small">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("alpha-warning.description"))}</p></div></div>`);
    } else {
      $$renderer2.push("<!--[-1-->");
    }
    $$renderer2.push(`<!--]--> `);
    if (stepInfo.stage === "BETA" && !store_get($$store_subs ??= {}, "$languageLoading", languageLoading) && !store_get($$store_subs ??= {}, "$isLoading", $isLoading)) {
      $$renderer2.push("<!--[0-->");
      $$renderer2.push(`<div class="card-body pb-0"><div class="alert alert-info mb-0"><h6 class="alert-heading hstack gap-2"><i class="fa-solid fa-circle-info"></i> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("beta-warning.title"))}</h6> <p class="mb-0 small">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("beta-warning.description"))}</p></div></div>`);
    } else {
      $$renderer2.push("<!--[-1-->");
    }
    $$renderer2.push(`<!--]--> <div class="card-body"><div class="form-floating"><select class="form-select" id="languageSelect"${attr("disabled", store_get($$store_subs ??= {}, "$languageLoading", languageLoading), true)} autocomplete="false"><!--[-->`);
    const each_array = ensure_array_like(Object.keys(store_get($$store_subs ??= {}, "$Languages", Languages)));
    for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
      let language = each_array[$$index];
      $$renderer2.option(
        {
          value: language,
          selected: store_get($$store_subs ??= {}, "$currentLanguage", currentLanguage) === store_get($$store_subs ??= {}, "$Languages", Languages)[language]
        },
        ($$renderer3) => {
          $$renderer3.push(`${escape_html(store_get($$store_subs ??= {}, "$Languages", Languages)[language].name)}`);
        }
      );
    }
    $$renderer2.push(`<!--]--></select> <label for="languageSelect">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("language-label"))}</label></div></div></div> `);
    if (showTransferModal) {
      $$renderer2.push("<!--[0-->");
      $$renderer2.push(`<div class="modal-backdrop fade show"></div>  <div class="modal fade show d-block" tabindex="-1" style="background: rgba(0, 0, 0, 0.5);"><div class="modal-dialog modal-dialog-centered"><div class="modal-content text-start"><div class="modal-header"><h5 class="modal-title">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("import.modal-title"))}</h5> <button type="button" class="btn-close" aria-label="Close"></button></div> <div class="modal-body overflow-hidden p-0"><div${attr_class("modal-steps-container svelte-19wkarn", void 0, { "slide-active": modalStep === "pano-transfer" })}><div class="modal-step-pane p-3 svelte-19wkarn"><div class="list-group"><button type="button" class="list-group-item list-group-item-action host-item-gradient d-flex justify-content-between align-items-start p-3 svelte-19wkarn"><div class="me-auto text-start"><div class="d-flex align-items-center gap-2"><div class="d-inline-flex align-items-center justify-content-center bg-primary rounded" style="width: 24px; height: 24px;"><img src="/assets/img/logo.svg" width="16" height="16" alt="Pano"/></div> <h5 class="mb-0">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("import.pano-host.title"))}</h5> <span class="badge text-bg-primary">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("import.pano-host.badge"))}</span></div> <div class="text-body-secondary mt-2 fw-normal">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("import.pano-host.description"))}</div></div> <i class="fa-solid fa-cloud-arrow-down text-body-secondary align-self-center fs-5"></i></button> <button type="button" class="list-group-item list-group-item-action d-flex justify-content-between align-items-start p-3"><div class="me-auto text-start"><div class="d-flex align-items-center gap-2"><h5 class="mb-0">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("import.other-pano.title"))}</h5></div> <div class="text-body-secondary mt-1 fw-normal">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("import.other-pano.description"))}</div></div> <i class="fa-solid fa-file-import text-body-secondary align-self-center fs-5"></i></button></div></div> <div class="modal-step-pane p-3 svelte-19wkarn"><button type="button" class="btn btn-link text-decoration-none p-0 mb-3 hstack gap-2"><i class="fa-solid fa-arrow-left"></i> <span>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.back"))}</span></button> <div class="mb-0"><div class="form-floating svelte-19wkarn"><input type="url"${attr_class("form-control", void 0, { "rounded-bottom-0": isUrlConnected })} id="platformUrlInput" placeholder="Platform URL"${attr("disabled", urlConnecting || isUrlConnected, true)}${attr("value", platformUrl)}/> <label for="platformUrlInput">Platform URL</label></div> `);
      if (!isUrlConnected) {
        $$renderer2.push("<!--[0-->");
        $$renderer2.push(`<div class="mt-1 ms-1 small"><a${attr("href", `${stringify(PANO_WEBSITE_URL)}/profile/platforms`)} target="_blank" rel="noreferrer" class="text-decoration-none small d-inline-flex align-items-center gap-1"><span>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("import.get-platform-url"))}</span> <i class="fa-solid fa-arrow-up-right-from-square"></i></a></div>`);
      } else {
        $$renderer2.push("<!--[-1-->");
      }
      $$renderer2.push(`<!--]--> `);
      if (isUrlConnected) {
        $$renderer2.push("<!--[0-->");
        $$renderer2.push(`<div class="form-floating svelte-19wkarn"><input type="text" class="form-control rounded-top-0" style="margin-top: -1px;" id="transferCodeInput" placeholder="Transfer Kodu"${attr("value", transferCode)}/> <label for="transferCodeInput">Transfer Kodu</label></div>`);
      } else {
        $$renderer2.push("<!--[-1-->");
      }
      $$renderer2.push(`<!--]--></div></div></div></div> `);
      if (modalStep === "pano-transfer") {
        $$renderer2.push("<!--[0-->");
        $$renderer2.push(`<div class="modal-footer">`);
        if (!isUrlConnected) {
          $$renderer2.push("<!--[0-->");
          $$renderer2.push(`<button type="button" class="btn btn-primary w-100"${attr("disabled", !platformUrl || urlConnecting, true)}>`);
          if (urlConnecting) {
            $$renderer2.push("<!--[0-->");
            $$renderer2.push(`<span class="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.connecting"))}`);
          } else {
            $$renderer2.push("<!--[-1-->");
            $$renderer2.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.connect"))}`);
          }
          $$renderer2.push(`<!--]--></button>`);
        } else {
          $$renderer2.push("<!--[-1-->");
          $$renderer2.push(`<button type="button" class="btn btn-secondary w-100"${attr("disabled", !transferCode, true)}>Transfer Et</button>`);
        }
        $$renderer2.push(`<!--]--></div>`);
      } else {
        $$renderer2.push("<!--[-1-->");
      }
      $$renderer2.push(`<!--]--></div></div></div>`);
    } else {
      $$renderer2.push("<!--[-1-->");
    }
    $$renderer2.push(`<!--]-->`);
    if ($$store_subs) unsubscribe_stores($$store_subs);
    bind_props($$props, { stepInfo });
  });
}
function _page($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let data = $$props["data"];
    Beginning($$renderer2, { stepInfo: data.stepInfo });
    bind_props($$props, { data });
  });
}

export { _page as default };
//# sourceMappingURL=_page.svelte.js-xqALb3Pw.js.map
