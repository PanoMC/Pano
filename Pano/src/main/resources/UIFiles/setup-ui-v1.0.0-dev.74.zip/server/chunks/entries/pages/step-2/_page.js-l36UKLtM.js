import { l as load } from '../../../chunks/Step2.js-WmtNUeTK.js';

var _page = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

export { _page as _ };
//# sourceMappingURL=_page.js-l36UKLtM.js.map
