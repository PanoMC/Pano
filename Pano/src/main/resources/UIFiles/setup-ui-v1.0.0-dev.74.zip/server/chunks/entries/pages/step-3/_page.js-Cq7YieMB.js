import { l as load } from '../../../chunks/Step3.js-CqAvUMUP.js';

var _page = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

export { _page as _ };
//# sourceMappingURL=_page.js-Cq7YieMB.js.map
