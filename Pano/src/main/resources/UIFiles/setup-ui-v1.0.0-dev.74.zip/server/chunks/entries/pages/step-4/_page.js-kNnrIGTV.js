import { l as load } from '../../../chunks/Step4.js-Dls1oj5V.js';

var _page = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

export { _page as _ };
//# sourceMappingURL=_page.js-kNnrIGTV.js.map
