import { a as spread_props, c as bind_props } from '../../../chunks/root.js-QX3SkSrm.js';
import { S as Step4 } from '../../../chunks/Step4.js-Dls1oj5V.js';
import '../../../chunks/effects.js-DAVcbH3F.js';
import '../../../chunks/utils2.js-Ke2uzSud.js';
import '../../../chunks/utils.js-BQzn9ikS.js';
import '../../../chunks/CardHeader.js-SSCSdGwL.js';
import '../../../chunks/runtime.js-CSUW-DLZ.js';
import '../../../chunks/index.js-l_eu7De0.js';
import '../../../index.js-BVhB7Rbp.js';
import '../../../chunks/server.js-Bf8x1V_n.js';
import '../../../chunks/exports.js-BZBK1HC9.js';
import '../../../chunks/internal2.js-2stKda1M.js';
import '../../../chunks/index-server.js-DHKOtNbE.js';
import '../../../chunks/state.svelte.js-IvJbnGzW.js';
import '../../../chunks/Store.js-vRMTfo1I.js';
import '../../../chunks/ErrorAlert.js-BrOLI8U-.js';
import '../../../chunks/language.util.js-nasHThMs.js';

function _page($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let data = $$props["data"];
    Step4($$renderer2, spread_props([data.stepInfo]));
    bind_props($$props, { data });
  });
}

export { _page as default };
//# sourceMappingURL=_page.svelte.js-6V8fNoll.js.map
