const manifest = (() => {
function __memo(fn) {
	let value;
	return () => value ??= (value = fn());
}

return {
	appDir: "_app",
	appPath: "_app",
	assets: new Set(["assets/favicon/android-icon-144x144.png","assets/favicon/android-icon-192x192.png","assets/favicon/android-icon-36x36.png","assets/favicon/android-icon-48x48.png","assets/favicon/android-icon-72x72.png","assets/favicon/android-icon-96x96.png","assets/favicon/apple-icon-114x114.png","assets/favicon/apple-icon-120x120.png","assets/favicon/apple-icon-144x144.png","assets/favicon/apple-icon-152x152.png","assets/favicon/apple-icon-180x180.png","assets/favicon/apple-icon-57x57.png","assets/favicon/apple-icon-60x60.png","assets/favicon/apple-icon-72x72.png","assets/favicon/apple-icon-76x76.png","assets/favicon/apple-icon-precomposed.png","assets/favicon/apple-icon.png","assets/favicon/browserconfig.xml","assets/favicon/favicon-16x16.png","assets/favicon/favicon-32x32.png","assets/favicon/favicon-96x96.png","assets/favicon/favicon.ico","assets/favicon/manifest.json","assets/favicon/ms-icon-144x144.png","assets/favicon/ms-icon-150x150.png","assets/favicon/ms-icon-310x310.png","assets/favicon/ms-icon-70x70.png","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-300.eot","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-300.svg","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-300.ttf","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-300.woff","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-300.woff2","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-500.eot","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-500.svg","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-500.ttf","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-500.woff","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-500.woff2","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-700.eot","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-700.svg","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-700.ttf","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-700.woff","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-700.woff2","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-regular.eot","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-regular.svg","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-regular.ttf","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-regular.woff","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-regular.woff2","assets/img/cover.png","assets/img/green.svg","assets/img/hytale-icon.png","assets/img/logo.svg","assets/img/minecraft-icon.png","assets/img/red.svg","assets/img/wallpaper_minecraft_caves_cliffs(part2)_1920x1080.png","assets/img/yellow.svg","assets/webfonts/fa-brands-400.ttf","assets/webfonts/fa-brands-400.woff2","assets/webfonts/fa-regular-400.ttf","assets/webfonts/fa-regular-400.woff2","assets/webfonts/fa-solid-900.ttf","assets/webfonts/fa-solid-900.woff2","assets/webfonts/fa-v4compatibility.ttf","assets/webfonts/fa-v4compatibility.woff2","lib/bootstrap/bootstrap.bundle.min.js"]),
	mimeTypes: {".png":"image/png",".xml":"text/xml",".json":"application/json",".svg":"image/svg+xml",".ttf":"font/ttf",".woff":"font/woff",".woff2":"font/woff2",".js":"text/javascript"},
	_: {
		client: {start:"_app/immutable/entry/start.Co46q-PI.js",app:"_app/immutable/entry/app.YgJR56s4.js",imports:["_app/immutable/entry/start.Co46q-PI.js","_app/immutable/chunks/BmDcWsyK.js","_app/immutable/chunks/BMZIGfcb.js","_app/immutable/chunks/DIeogL5L.js","_app/immutable/chunks/DSO43oG8.js","_app/immutable/entry/app.YgJR56s4.js","_app/immutable/chunks/PPVm8Dsz.js","_app/immutable/chunks/BMZIGfcb.js","_app/immutable/chunks/DIeogL5L.js","_app/immutable/chunks/CbJTZKWK.js","_app/immutable/chunks/DsnmJJEf.js","_app/immutable/chunks/Du4Q7XJp.js","_app/immutable/chunks/BCH5Er3S.js"],stylesheets:[],fonts:[],uses_env_dynamic_public:false},
		nodes: [
			__memo(() => import('./nodes/0.js-UxJLmg87.js')),
			__memo(() => import('./nodes/1.js-Byxvckq2.js')),
			__memo(() => import('./nodes/2.js-DvcVYb9E.js')),
			__memo(() => import('./nodes/3.js-C6WDF7Gy.js')),
			__memo(() => import('./nodes/4.js-B5sO5j80.js')),
			__memo(() => import('./nodes/5.js-yBss0oKs.js')),
			__memo(() => import('./nodes/6.js-BqGzjJRG.js')),
			__memo(() => import('./nodes/7.js-DwGNjBB-.js'))
		],
		remotes: {
			
		},
		routes: [
			{
				id: "/",
				pattern: /^\/$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 2 },
				endpoint: null
			},
			{
				id: "/setup-api/languages",
				pattern: /^\/setup-api\/languages\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/setup-api/languages/_server.js-J3hjOU-B.js'))
			},
			{
				id: "/setup-api/languages/[language].json",
				pattern: /^\/setup-api\/languages\/([^/]+?)\.json\/?$/,
				params: [{"name":"language","optional":false,"rest":false,"chained":false}],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/setup-api/languages/_language_.json/_server.js-h-GTtCCu.js'))
			},
			{
				id: "/step-1",
				pattern: /^\/step-1\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 4 },
				endpoint: null
			},
			{
				id: "/step-2",
				pattern: /^\/step-2\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 5 },
				endpoint: null
			},
			{
				id: "/step-3",
				pattern: /^\/step-3\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 6 },
				endpoint: null
			},
			{
				id: "/step-4",
				pattern: /^\/step-4\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 7 },
				endpoint: null
			},
			{
				id: "/[...fallback]",
				pattern: /^(?:\/([^]*))?\/?$/,
				params: [{"name":"fallback","optional":false,"rest":true,"chained":true}],
				page: { layouts: [0,], errors: [1,], leaf: 3 },
				endpoint: null
			}
		],
		prerendered_routes: new Set([]),
		matchers: async () => {
			
			return {  };
		},
		server_assets: {}
	}
}
})();

export { manifest as m };
//# sourceMappingURL=manifest.js-BGXNhs92.js.map
