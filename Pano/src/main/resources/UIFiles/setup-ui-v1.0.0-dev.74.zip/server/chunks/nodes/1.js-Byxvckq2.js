const index = 1;
let component_cache;
const component = async () => component_cache ??= (await import('../entries/fallbacks/error.svelte.js-BeuKVx5w.js')).default;
const imports = ["_app/immutable/nodes/1.CQtpwB64.js","_app/immutable/chunks/DsnmJJEf.js","_app/immutable/chunks/BMZIGfcb.js","_app/immutable/chunks/DIeogL5L.js","_app/immutable/chunks/CbJTZKWK.js","_app/immutable/chunks/DSO43oG8.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=1.js-Byxvckq2.js.map
