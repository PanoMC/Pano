const index = 2;
let component_cache;
const component = async () => component_cache ??= (await import('../entries/pages/_page.svelte.js-xqALb3Pw.js')).default;
const imports = ["_app/immutable/nodes/2.DeJumEop.js","_app/immutable/chunks/DsnmJJEf.js","_app/immutable/chunks/69_IOA4Y.js","_app/immutable/chunks/DIeogL5L.js","_app/immutable/chunks/BMZIGfcb.js","_app/immutable/chunks/B_2TBhvn.js","_app/immutable/chunks/BmDcWsyK.js","_app/immutable/chunks/DSO43oG8.js","_app/immutable/chunks/CbJTZKWK.js","_app/immutable/chunks/Du4Q7XJp.js","_app/immutable/chunks/BxFt3rCy.js","_app/immutable/chunks/CE8w0c9u.js","_app/immutable/chunks/ixDJpjHw.js","_app/immutable/chunks/-NSwfHmg.js"];
const stylesheets = ["_app/immutable/assets/2.PVCJipfr.css"];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=2.js-DvcVYb9E.js.map
