const index = 3;
let component_cache;
const component = async () => component_cache ??= (await import('../entries/pages/_...fallback_/_page.svelte.js-D-vLhrzB.js')).default;
const imports = ["_app/immutable/nodes/3.DPzO339H.js","_app/immutable/chunks/DsnmJJEf.js","_app/immutable/chunks/69_IOA4Y.js","_app/immutable/chunks/DIeogL5L.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=3.js-C6WDF7Gy.js.map
