import{E as e,Fn as t,Jt as n,K as r,P as i,Q as a,T as o,_n as s,a as c,f as l,ht as u,mn as d,pt as f,qt as p,vn as m}from"./Biz4eTeZ.js";import{Ft as h,S as g,ft as _,ht as v,pt as y,tt as b,yt as x}from"./DgaXQ5Dw.js";import{C as S,S as C,b as w}from"./CYMlyaez.js";import"./xihTtKlq.js";import"./DA94XoNu.js";import{n as T}from"./CBwcy369.js";var E=S(`<div><div id="header"><a href="/"><div style="padding-top: 80px; padding-bottom: 40px;"><img/></div></a></div></div>`);function D(S,D){m(D,!1);let O=()=>n(T,`$_`,A),k=()=>n(R,`$session`,A),[A,j]=p(),M=f(),N=f(),P=f(),F=f(),I=f(),L=f(),R=d(`session`),z=d(`themeSettings`),B={dark:``,light:``,copper:`#b87333`,emerald:`#10b981`,midnight:`#8b5cf6`,crimson:`#ef4444`};function V(e){return e===`zoom`?`logo-animation-zoom`:e===`floating`?`logo-animation-floating`:``}function H(e){return e===`TOP_START`?`top-0 start-0`:e===`TOP`?`top-0 start-50 translate-middle-x`:e===`TOP_END`?`top-0 end-0`:e===`CENTER_START`?`top-50 start-0 translate-middle-y`:e===`CENTER`?`top-50 start-50 translate-middle`:e===`CENTER_END`?`top-50 end-0 translate-middle-y`:e===`BOTTOM_START`?`bottom-0 start-0 `:e===`BOTTOM`?`bottom-0 start-50 translate-middle-x`:e===`BOTTOM_END`?`bottom-0 end-0`:`top-50 start-50 translate-middle`}let U=z.defaultHeaderBg===void 0||z.defaultHeaderBg,W=`
    .hero::before {
      ${c(M)?`background-color: ${c(M)};`:``}
      background-image: url(${U?`/assets/img/default-header-bg.png`:z.files?.headerBackgroundImage?`/api/theme/file/`+z.files?.headerBackgroundImage:``}) !important;
      ${z.headerBgImagePosition?`background-position: ${z.headerBgImagePosition} !important;`:``}
      ${z.headerBgImageRepeat?`background-repeat: ${z.headerBgImageRepeat} !important;`:``}
      background-size: ${z.headerBgImageSize||`cover`} !important;
    }

    .logo-animation-zoom {
      animation: logo-zoom 5s ease-in-out infinite;
    }
    
    .logo-animation-floating {
      animation: logo-floating 3s ease-in-out infinite;
    }

    @keyframes logo-zoom {
      0%, 100% { transform: scale(1); }
      50% { transform: scale(1.05); }
    }

    @keyframes logo-floating {
      0%, 100% { transform: translateY(0); }
      50% { transform: translateY(-20px); }
    }
  `;o(()=>{},()=>{u(M,z.headerBgColor||B[z.themeColor||`dark`])}),o(()=>{},()=>{u(N,z.logoPosition?z.logoPosition:`CENTER`)}),o(()=>c(N),()=>{u(P,H(c(N)))}),o(()=>{},()=>{u(F,z.logoAnimation||`off`)}),o(()=>c(F),()=>{u(I,V(c(F)))}),o(()=>{},()=>{u(L,z.headerWidthOption||`FULL_SIZE`)}),e(),g();var G=E();x(`15cuno1`,e=>{var t=C();h(a(t),()=>l(()=>`<style>;</style>`.replace(`;`,W))),w(e,t)});let K;var q=r(G);let J;var Y=r(q),X=r(Y);let Z;var Q=r(X);t(X),t(Y),t(q),t(G),i(e=>{K=y(G,1,`hero`,null,K,{container:c(L)!==`FULL_SIZE`}),J=y(q,1,`hero-content position-relative p-0`,null,J,{"bg-transparent":!c(M)}),_(q,`background-position: center; height: ${l(()=>z.headerHeight||`256`)??``}px;`),Z=y(X,1,`position-absolute ${c(P)??``} px-3`,null,Z,{"d-none":z.logoVisibility===!1}),b(Q,`alt`,e),y(Q,1,v(c(I))),b(Q,`src`,`/api/websiteLogo?hash=${(k(),l(()=>k().siteInfo.websiteLogoHash))??``}`),_(Q,`object-fit: contain; width: ${l(()=>z.logoWidth||`256`)??``}px; height: ${l(()=>z.logoHeight?z.logoHeight+`px`:`auto`)??``}; max-width: 100%;`),b(Q,`title`,(k(),l(()=>k().siteInfo.websiteName)))},[()=>(O(),l(()=>O()(`components.header.alt`)))]),w(S,G),s(),j()}export{D as default};