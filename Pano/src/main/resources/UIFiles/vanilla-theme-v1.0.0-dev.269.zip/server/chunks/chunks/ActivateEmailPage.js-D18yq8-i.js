import { W as bind_props, T as writable } from './server.js-D28cBEJ-.js';
import 'node:module';
import { p as panoApiClient, e as executeLifecycle, b as executeViewLoad } from './PluginManager.js-B5x3OKEW.js';
import { r as resolveView } from './registry2.js-BubD3cPq.js';
import { s as sendVerifyEmail, N as NETWORK_ERROR } from './Store.js-C2vdyE6V.js';

//#region node_modules/@panomc/theme-core/src/lib/ui-logics/page-logics/ActiveEmailPageLogics.js
/**
* @type {import("@sveltejs/kit").Load}
*/
async function processLoad(event) {
	const { parent, url: { searchParams } } = event;
	await parent();
	const token = searchParams.get("token") || "";
	await executeLifecycle("theme:activate:load", { token }, event);
	await executeViewLoad("activate-content", event);
	return {
		token,
		pageTitle: "pages.activate.title"
	};
}
async function verifyEmail(error, successMessage, loading, data) {
	error.set(null);
	successMessage.set(null);
	loading.set(true);
	await sendVerifyEmail(data.token).then((body) => {
		loading.set(false);
		if (body.result === "ok") successMessage.set("VALIDATION_SUCCESSFUL");
		else if (body.error === "PLUGIN_DENIED_LOGIN" && body.reason) error.set(body.reason);
		else error.set(body.error);
	}).catch(() => {
		loading.set(false);
		error.set(NETWORK_ERROR);
	});
}
//#endregion
//#region node_modules/@panomc/theme-core/src/lib/pages/ActivateEmailPage.svelte
async function load(event) {
	const viewPromise = resolveView("ActivateEmailView", () => import('./ActivateEmailView.js-DgemyPQd.js'));
	return {
		...await processLoad(event),
		View: await viewPromise
	};
}
function ActivateEmailPage($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		let data = $$props["data"];
		const activateContentItems = panoApiClient.ui.auth.activate.content.get();
		let loading = writable();
		let error = writable();
		let successMessage = writable(null);
		if (data.View) {
			$$renderer.push("<!--[-->");
			data.View($$renderer, {
				data,
				error,
				successMessage,
				loading,
				activateContentItems,
				verifyEmail
			});
			$$renderer.push("<!--]-->");
		} else {
			$$renderer.push("<!--[!-->");
			$$renderer.push("<!--]-->");
		}
		bind_props($$props, { data });
	});
}

export { ActivateEmailPage as A, load as l };
//# sourceMappingURL=ActivateEmailPage.js-D18yq8-i.js.map
