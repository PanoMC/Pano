import { a0 as store_get, $ as ensure_array_like, Z as attr_class, X as attr, a5 as escape_html, a2 as unsubscribe_stores, W as bind_props } from './server.js-D28cBEJ-.js';
import { $ as $format } from './runtime.js-CJgfVvxa.js';
import { V as ViewComponent } from './ViewComponent.js-C6amYVVM.js';
import { E as ErrorAlert } from './ErrorAlert.js-DbwaZ_OB.js';
import { S as SuccessAlert } from './SuccessAlert.js-D6Etg0s_.js';
import './uneval.js-BL1Qg77w.js';
import './rolldown-runtime.js-B5FuG9Gw.js';
import 'node:module';

//#region node_modules/@panomc/theme-core/src/lib/views/ActivateEmailView.svelte
function ActivateEmailView($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let data = $$props["data"];
		let error = $$props["error"];
		let successMessage = $$props["successMessage"];
		let loading = $$props["loading"];
		let activateContentItems = $$props["activateContentItems"];
		let verifyEmail = $$props["verifyEmail"];
		$$renderer.push(`<div class="col-lg-4 col-md-6 mx-auto"><div class="vstack gap-3"><div class="card"><div class="card-body"><div class="vstack gap-3"><img alt="Allay" class="d-block mx-auto" src="https://cdn3.emoji.gg/emojis/8182-allay-dancing.gif"/> `);
		ErrorAlert($$renderer, { error: store_get($$store_subs ??= {}, "$error", error) });
		$$renderer.push(`<!----> `);
		SuccessAlert($$renderer, { message: store_get($$store_subs ??= {}, "$successMessage", successMessage) });
		$$renderer.push(`<!----> <!--[-->`);
		const each_array = ensure_array_like(store_get($$store_subs ??= {}, "$activateContentItems", activateContentItems));
		for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
			let item = each_array[$$index];
			if (item.component) {
				$$renderer.push("<!--[0-->");
				ViewComponent($$renderer, {
					component: item.component,
					data: { pageType: "activate" }
				});
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]-->`);
		}
		$$renderer.push(`<!--]--> <button${attr_class("btn btn-secondary w-100", void 0, { "disabled": store_get($$store_subs ??= {}, "$loading", loading) || store_get($$store_subs ??= {}, "$error", error) === "INVALID_LINK" || store_get($$store_subs ??= {}, "$successMessage", successMessage) !== null })}${attr("disabled", store_get($$store_subs ??= {}, "$loading", loading) || store_get($$store_subs ??= {}, "$error", error) === "INVALID_LINK" || store_get($$store_subs ??= {}, "$successMessage", successMessage) !== null, true)}>`);
		if (store_get($$store_subs ??= {}, "$loading", loading)) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<span class="spinner-border spinner-border-sm me-2" role="status" aria-label="Loading"></span> <span>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.activate-email"))}...</span>`);
		} else {
			$$renderer.push("<!--[-1-->");
			$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.activate-email"))}`);
		}
		$$renderer.push(`<!--]--></button></div></div></div></div></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
		bind_props($$props, {
			data,
			error,
			successMessage,
			loading,
			activateContentItems,
			verifyEmail
		});
	});
}

export { ActivateEmailView as default };
//# sourceMappingURL=ActivateEmailView.js-DgemyPQd.js.map
