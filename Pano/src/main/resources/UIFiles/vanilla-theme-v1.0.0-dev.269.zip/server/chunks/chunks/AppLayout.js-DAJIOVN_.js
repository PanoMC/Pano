import { _ as __exportAll, b as __toESM } from './rolldown-runtime.js-B5FuG9Gw.js';
import { r as redirect, e as error } from './exports2.js-DxZfja4I.js';
import { b as base } from './internal.js-BlXt2rfE.js';
import { V as fallback, a0 as store_get, _ as slot, a2 as unsubscribe_stores, W as bind_props, T as writable, s as setContext } from './server.js-D28cBEJ-.js';
import { o as onDestroy } from './index-server2.js-DlblWyyK.js';
import { g as goto } from './client.js-CPEkJ2-P.js';
import { p as page, n as navigating } from './stores.js-QbD2A2ib.js';
import { $ as $format } from './runtime.js-CJgfVvxa.js';
import { a as preparePlugins, s as setPanoContext, i as initializePlugins, e as executeLifecycle, b as executeViewLoad } from './PluginManager.js-B5x3OKEW.js';
import { r as resolveView } from './registry2.js-BubD3cPq.js';
import { r as require_copy_to_clipboard } from './copy-to-clipboard.js-CF5RgzCy.js';
import { d as ApiUtil, c as avatarVersion, u as updateApiUrl, f as api_util_exports, b as updatePanoWebsiteUrl, h as updatePanoWebsiteApiUrl, i as checkDomainRedirection, P as PANO_WEBSITE_URL, j as PANO_WEBSITE_API_URL, k as PANEL_URL, J as JWT_COOKIE_NAME, a as CSRF_TOKEN_COOKIE_NAME, l as CSRF_HEADER, C as COOKIE_PREFIX, A as API_URL } from './Store.js-C2vdyE6V.js';
import { T as ToastContainer_exports } from './ToastContainer.js-CtmBBvhr.js';
import { l as language_util_exports, i as init$1 } from './language.util.js-C2xYQq5-.js';
import { t as tooltip } from './tooltip.util.js-Bd9x5X7L.js';
import { h as hasPermission } from './auth.util.js-BGCV_dhB.js';
import { D as Date_1 } from './Date.js-ZK3lGml2.js';
import { P as Pagination } from './Pagination.js-CeyG1SGU.js';
import { N as NoContent } from './NoContent.js-BBe0Mapz.js';
import { P as PageActions } from './PageActions.js-CkhIQPLY.js';
import { P as PageTitle } from './PageTitle.js-D99NSXzQ.js';
import { P as PlayerHead } from './PlayerHead.js-Bggv1de7.js';

//#region node_modules/@panomc/theme-core/src/lib/variables.js
var import_copy_to_clipboard = /* @__PURE__ */ __toESM(require_copy_to_clipboard());
var variables_exports = /* @__PURE__ */ __exportAll({
	API_URL: () => API_URL,
	COOKIE_PREFIX: () => COOKIE_PREFIX,
	CSRF_HEADER: () => CSRF_HEADER,
	CSRF_TOKEN_COOKIE_NAME: () => CSRF_TOKEN_COOKIE_NAME,
	JWT_COOKIE_NAME: () => JWT_COOKIE_NAME,
	PANEL_URL: () => PANEL_URL,
	PANO_WEBSITE_API_URL: () => PANO_WEBSITE_API_URL,
	PANO_WEBSITE_URL: () => PANO_WEBSITE_URL,
	PRERELEASE: () => void 0,
	SETUP_URL: () => "/",
	UI_URL: () => "/",
	checkDomainRedirection: () => checkDomainRedirection,
	updateApiUrl: () => updateApiUrl,
	updatePanoWebsiteApiUrl: () => updatePanoWebsiteApiUrl,
	updatePanoWebsiteUrl: () => updatePanoWebsiteUrl
});
//#endregion
//#region node_modules/@panomc/theme-core/src/lib/ui-logics/layout-logics/AppLayoutLogics.js
var initLanguage = init$1;
async function processServerLoad(event) {
	const { locals: { user, csrfToken, apiUrlEnv, panoWebsiteUrlEnv } } = event;
	let siteInfo = await ApiUtil.get({
		path: "/api/siteInfo",
		request: event,
		csrfToken
	});
	await preparePlugins(siteInfo);
	return {
		user,
		csrfToken,
		siteInfo,
		apiUrlEnv,
		panoWebsiteUrlEnv,
		avatarVersionDate: `v=${Date.now()}`
	};
}
async function processLoad(event) {
	const { data: { user, csrfToken, siteInfo, apiUrlEnv, panoWebsiteUrlEnv, avatarVersionDate }, parent } = event;
	await parent();
	avatarVersion.set(avatarVersionDate);
	if (apiUrlEnv) updateApiUrl(apiUrlEnv);
	if (panoWebsiteUrlEnv) updatePanoWebsiteUrl(panoWebsiteUrlEnv);
	const [ResolvedDate, ResolvedPagination, ResolvedNoContent, ResolvedPageActions, ResolvedPageTitle, ResolvedPlayerHead] = await Promise.all([
		resolveView("Date", async () => Date_1),
		resolveView("Pagination", async () => Pagination),
		resolveView("NoContent", async () => NoContent),
		resolveView("PageActions", async () => PageActions),
		resolveView("PageTitle", async () => PageTitle),
		resolveView("PlayerHead", async () => PlayerHead)
	]);
	setPanoContext({
		page,
		base,
		navigating,
		browser: false,
		goto,
		error,
		redirect,
		components: {
			Date: ResolvedDate,
			Pagination: ResolvedPagination,
			NoContent: ResolvedNoContent,
			PageActions: ResolvedPageActions,
			PageTitle: ResolvedPageTitle,
			PlayerHead: ResolvedPlayerHead
		},
		utils: {
			api: {
				ApiUtil,
				...api_util_exports
			},
			language: {
				...language_util_exports,
				_: $format
			},
			tooltip: { tooltip },
			toast: { ...ToastContainer_exports },
			auth: { hasPermission },
			text: { copy: import_copy_to_clipboard.default }
		},
		variables: { ...variables_exports }
	});
	await initializePlugins(siteInfo);
	const output = {
		session: {
			user,
			csrfToken,
			siteInfo
		},
		_pageTitleStore: writable(null),
		_breadcrumbsStore: writable(null)
	};
	await executeLifecycle("theme:navbar:load", output, event);
	await Promise.all([
		executeViewLoad("navbar-right", event),
		executeViewLoad("navbar-profile-dropdown", event),
		executeLifecycle("theme:app:load", output, event),
		initLanguage(siteInfo.locale, event)
	]);
	return output;
}
function init(data) {
	const session = writable(data.session);
	const sidebar = writable(null);
	const sidebarProps = writable({});
	const pageUnsubscribe = page.subscribe((currentPage) => {
		session.update((current) => {
			const incoming = currentPage.data.session;
			if (!incoming) return current;
			if (!!current?.user !== !!incoming.user) return {
				...incoming,
				user: current.user,
				csrfToken: current.csrfToken
			};
			return incoming;
		});
		sidebar.update(() => currentPage.data.sidebar);
		sidebarProps.update(() => currentPage.data.sidebarProps || {});
		data._pageTitleStore.set(currentPage.data.pageTitle || null);
		data._breadcrumbsStore.set(currentPage.data.breadcrumbs || null);
	});
	setContext("session", session);
	setContext("sidebar", sidebar);
	setContext("sidebarProps", sidebarProps);
	setContext("pageTitle", data._pageTitleStore);
	setContext("breadcrumbs", data._breadcrumbsStore);
	setContext("themeSettings", data.session.siteInfo.themeSettings);
	onDestroy(() => {
		pageUnsubscribe();
	});
	return {
		session,
		sidebar,
		sidebarProps,
		pageTitle: data._pageTitleStore,
		breadcrumbs: data._breadcrumbsStore
	};
}
//#endregion
//#region node_modules/@panomc/theme-core/src/lib/layouts/AppLayout.svelte
var AppLayout_exports = /* @__PURE__ */ __exportAll({
	default: () => AppLayout,
	load: () => load,
	loadServer: () => loadServer
});
async function loadServer(event) {
	return await processServerLoad(event);
}
/**
* @type {import("@sveltejs/kit").LayoutLoad}
*/
async function load(event) {
	const viewPromise = resolveView("AppLayoutView", () => import('./AppLayoutView.js-C3JUo6Wl.js'));
	return {
		...await processLoad(event),
		appLayoutView: await viewPromise
	};
}
function AppLayout($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let viewData, layoutView;
		let data = fallback($$props["data"], void 0);
		const { session, pageTitle } = init(data);
		function getTitle(pt, siteName) {
			if (!pt) return siteName;
			return `${typeof pt === "string" ? store_get($$store_subs ??= {}, "$_", $format)(pt) : pt.title ? store_get($$store_subs ??= {}, "$_", $format)(pt.title, { values: pt.titleValues || {} }) : ""} \u2014 ${siteName}`;
		}
		viewData = data ?? store_get($$store_subs ??= {}, "$page", page).data;
		layoutView = viewData?.appLayoutView ?? store_get($$store_subs ??= {}, "$page", page).data.appLayoutView;
		if (layoutView) {
			$$renderer.push("<!--[-->");
			layoutView($$renderer, {
				data: viewData,
				session,
				pageTitle,
				getTitle,
				children: ($$renderer) => {
					$$renderer.push(`<!--[-->`);
					slot($$renderer, $$props, "default", {}, null);
					$$renderer.push(`<!--]-->`);
				},
				$$slots: { default: true }
			});
			$$renderer.push("<!--]-->");
		} else {
			$$renderer.push("<!--[!-->");
			$$renderer.push("<!--]-->");
		}
		if ($$store_subs) unsubscribe_stores($$store_subs);
		bind_props($$props, { data });
	});
}

export { AppLayout_exports as A, loadServer as a, AppLayout as b, load as l };
//# sourceMappingURL=AppLayout.js-DAJIOVN_.js.map
