import { ab as head, W as bind_props, _ as slot, a5 as escape_html, a0 as store_get, X as attr, Y as stringify, a2 as unsubscribe_stores } from './server.js-D28cBEJ-.js';
import { b as ToastContainer } from './ToastContainer.js-CtmBBvhr.js';
import './uneval.js-BL1Qg77w.js';
import './rolldown-runtime.js-B5FuG9Gw.js';
import 'node:module';
import './index-server2.js-DlblWyyK.js';
import './runtime.js-CJgfVvxa.js';

//#region node_modules/@panomc/theme-core/src/lib/components/App.svelte
function App($$renderer, $$props) {
	$$renderer.push(`<!--[-->`);
	slot($$renderer, $$props, "default", {}, null);
	$$renderer.push(`<!--]-->`);
}
//#endregion
//#region node_modules/@panomc/theme-core/src/lib/views/AppLayoutView.svelte
function AppLayoutView($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let data = $$props["data"];
		let session = $$props["session"];
		let pageTitle = $$props["pageTitle"];
		let getTitle = $$props["getTitle"];
		head("wd7lt6", $$renderer, ($$renderer) => {
			$$renderer.title(($$renderer) => {
				$$renderer.push(`<title>${escape_html(getTitle(store_get($$store_subs ??= {}, "$pageTitle", pageTitle), store_get($$store_subs ??= {}, "$session", session).siteInfo.websiteName))}</title>`);
			});
			$$renderer.push(`<link${attr("href", `/api/favicon?hash=${stringify(store_get($$store_subs ??= {}, "$session", session).siteInfo.faviconHash)}`)} rel="icon"/>`);
		});
		App($$renderer, {
			children: ($$renderer) => {
				$$renderer.push(`<!--[-->`);
				slot($$renderer, $$props, "default", {}, null);
				$$renderer.push(`<!--]-->`);
			},
			$$slots: { default: true }
		});
		$$renderer.push(`<!----> `);
		ToastContainer($$renderer);
		$$renderer.push(`<!---->`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
		bind_props($$props, {
			data,
			session,
			pageTitle,
			getTitle
		});
	});
}

export { AppLayoutView as default };
//# sourceMappingURL=AppLayoutView.js-C3JUo6Wl.js.map
