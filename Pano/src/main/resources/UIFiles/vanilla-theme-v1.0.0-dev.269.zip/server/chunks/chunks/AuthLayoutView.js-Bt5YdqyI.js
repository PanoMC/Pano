import { _ as slot, W as bind_props } from './server.js-D28cBEJ-.js';
import './uneval.js-BL1Qg77w.js';

//#region node_modules/@panomc/theme-core/src/lib/views/AuthLayoutView.svelte
function AuthLayoutView($$renderer, $$props) {
	let data = $$props["data"];
	$$renderer.push(`<div class="container mx-auto svelte-lpwdq7"><!--[-->`);
	slot($$renderer, $$props, "default", {}, null);
	$$renderer.push(`<!--]--></div>`);
	bind_props($$props, { data });
}

export { AuthLayoutView as default };
//# sourceMappingURL=AuthLayoutView.js-Bt5YdqyI.js.map
