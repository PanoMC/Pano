import { a7 as sanitize_slots, V as fallback, Z as attr_class, Y as stringify, _ as slot, W as bind_props } from './server.js-D28cBEJ-.js';

//#region node_modules/@panomc/theme-core/src/lib/components/CardHeader.svelte
function CardHeader($$renderer, $$props) {
	const $$slots = sanitize_slots($$props);
	let headerClasses = fallback($$props["headerClasses"], "");
	let leftClasses = fallback($$props["leftClasses"], "");
	let rightClasses = fallback($$props["rightClasses"], "");
	let middleClasses = fallback($$props["middleClasses"], "");
	let showRight = fallback($$props["showRight"], true);
	/** When false, left slot text wraps (e.g. long subtitles); default truncates for compact headers */
	let truncateLeft = fallback($$props["truncateLeft"], true);
	$$renderer.push(`<div${attr_class(`card-header py-3 ${stringify(headerClasses)}`)}><div class="row d-flex align-items-center gx-0 gy-2"><div${attr_class(`${stringify($$slots.middle ? $$slots.right && showRight ? "col-lg-3" : "col-lg-6" : $$slots.right && showRight ? "col-lg-6" : "col-12")} d-flex ${stringify($$slots.right && showRight && !$$slots.middle ? "justify-content-lg-between" : "justify-content-lg-start")} justify-content-center text-center text-lg-start ${stringify(truncateLeft ? "text-truncate text-nowrap" : "min-w-0 text-wrap text-break")} ${stringify(leftClasses)}`)}><!--[-->`);
	slot($$renderer, $$props, "left", {}, null);
	$$renderer.push(`<!--]--></div> `);
	if ($$slots.middle) {
		$$renderer.push("<!--[0-->");
		$$renderer.push(`<div${attr_class(`col-lg-6 d-flex justify-content-center ${stringify(middleClasses)}`)}><!--[-->`);
		slot($$renderer, $$props, "middle", {}, null);
		$$renderer.push(`<!--]--></div>`);
	} else $$renderer.push("<!--[-1-->");
	$$renderer.push(`<!--]--> `);
	if ($$slots.right && showRight) {
		$$renderer.push("<!--[0-->");
		$$renderer.push(`<div${attr_class(`${stringify($$slots.middle ? "col-lg-3" : "col-lg-6")} d-flex justify-content-lg-end justify-content-center ${stringify(rightClasses)}`)}><!--[-->`);
		slot($$renderer, $$props, "right", {}, null);
		$$renderer.push(`<!--]--></div>`);
	} else $$renderer.push("<!--[-1-->");
	$$renderer.push(`<!--]--></div></div>`);
	bind_props($$props, {
		headerClasses,
		leftClasses,
		rightClasses,
		middleClasses,
		showRight,
		truncateLeft
	});
}

export { CardHeader as C };
//# sourceMappingURL=CardHeader.js-DpkWpoy6.js.map
