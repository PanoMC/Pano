import { X as attr, a0 as store_get, a5 as escape_html, Z as attr_class, a2 as unsubscribe_stores, T as writable } from './server.js-D28cBEJ-.js';
import { $ as $format } from './runtime.js-CJgfVvxa.js';
import { d as ApiUtil, e as buildQueryParams } from './Store.js-C2vdyE6V.js';
import { E as ErrorAlert } from './ErrorAlert.js-DbwaZ_OB.js';

//#region node_modules/@panomc/theme-core/src/lib/services/tickets.js
var getTickets = async ({ page, pageType, categoryUrl, request, csrfToken }) => {
	const queryParams = buildQueryParams({
		page,
		pageType,
		categoryUrl
	});
	return ApiUtil.get({
		path: `/api/tickets${queryParams}`,
		request,
		csrfToken
	}).then((body) => {
		body.page = parseInt(page);
		body.pageType = pageType;
		return body;
	});
};
var getTicketCategories = async ({ page, request, csrfToken }) => {
	return ApiUtil.get({
		path: `/api/ticket/categories?page=${page}`,
		request,
		csrfToken
	}).then((body) => {
		body.page = parseInt(page);
		return body;
	});
};
var createTicket = async ({ title, message, categoryId, request, csrfToken }) => {
	return ApiUtil.post({
		path: `/api/tickets`,
		body: {
			title,
			message,
			categoryId
		},
		request,
		csrfToken
	});
};
var getTicketDetail = async ({ id, request, csrfToken }) => {
	return ApiUtil.get({
		path: `/api/tickets/${id}`,
		request,
		csrfToken
	});
};
var loadMoreTicketMessages = async ({ id, lastMessageId, request, csrfToken }) => {
	return ApiUtil.get({
		path: `/api/tickets/${id}/messages?lastMessageId=${lastMessageId}`,
		request,
		csrfToken
	});
};
var sendTicketMessage = async ({ ticketId, message, request, csrfToken }) => {
	return ApiUtil.post({
		path: `/api/tickets/${ticketId}/messages`,
		body: { message },
		request,
		csrfToken
	});
};
//#endregion
//#region node_modules/@panomc/theme-core/src/lib/components/modals/CloseTicketConfirmModal.svelte
var dialogID = "closeTicketConfirmModal";
var error = writable();
var modal;
function show(newTicket) {
	error.set(null);
	modal = new window.bootstrap.Modal(document.getElementById(dialogID), {
		backdrop: "static",
		keyboard: false
	});
	modal.show();
}
function CloseTicketConfirmModal($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let loading = false;
		$$renderer.push(`<div aria-hidden="true" class="modal fade"${attr("id", dialogID)} role="dialog" tabindex="-1"><div class="modal-dialog modal-dialog-centered" role="dialog"><div class="modal-content"><div class="modal-body text-center">`);
		ErrorAlert($$renderer, { error: store_get($$store_subs ??= {}, "$error", error) });
		$$renderer.push(`<!----> <div class="pb-3"><i class="fas fa-question-circle fa-3x d-block m-auto text-gray"></i></div> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.close-ticket-confirm.title"))}</div> <div class="modal-footer flex-nowrap"><button${attr_class("btn btn-link col-6 m-0", void 0, { "disabled": loading })} data-bs-dismiss="modal" type="button"${attr("aria-disabled", loading)}${attr("disabled", loading, true)}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.cancel"))}</button> <button${attr_class("btn btn-danger col-6 m-0", void 0, { "disabled": loading })} type="button"${attr("aria-disabled", loading)}${attr("disabled", loading, true)}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.yes"))}</button></div></div></div></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
	});
}

export { CloseTicketConfirmModal as C, getTicketCategories as a, getTickets as b, createTicket as c, show as d, getTicketDetail as g, loadMoreTicketMessages as l, sendTicketMessage as s };
//# sourceMappingURL=CloseTicketConfirmModal.js-ex0CkG3p.js.map
