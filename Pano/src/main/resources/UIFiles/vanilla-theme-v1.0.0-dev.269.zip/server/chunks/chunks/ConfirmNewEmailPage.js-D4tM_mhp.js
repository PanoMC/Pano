import { W as bind_props, T as writable } from './server.js-D28cBEJ-.js';
import 'node:module';
import { p as panoApiClient, e as executeLifecycle, b as executeViewLoad } from './PluginManager.js-B5x3OKEW.js';
import { r as resolveView } from './registry2.js-BubD3cPq.js';
import { n as sendVerifyNewEmail, N as NETWORK_ERROR } from './Store.js-C2vdyE6V.js';

//#region node_modules/@panomc/theme-core/src/lib/ui-logics/page-logics/ConfirmNewEmailPageLogics.js
/**
* @type {import("@sveltejs/kit").Load}
*/
async function processLoad(event) {
	const { parent, url: { searchParams } } = event;
	await parent();
	const token = searchParams.get("token") || "";
	await executeLifecycle("theme:activate-new-email:load", { token }, event);
	await executeViewLoad("activate-new-email-content", event);
	return {
		token,
		pageTitle: "pages.activate-new-email.title"
	};
}
async function verifyEmail(error, successMessage, loading, data) {
	error.set(null);
	successMessage.set(null);
	loading.set(true);
	await sendVerifyNewEmail(data.token).then((body) => {
		loading.set(false);
		if (body.result === "ok") successMessage.set("VALIDATION_SUCCESSFUL");
		else if (body.error === "PLUGIN_DENIED_LOGIN" && body.reason) error.set(body.reason);
		else error.set(body.error);
	}).catch(() => {
		error.set(NETWORK_ERROR);
		loading.set(false);
	});
}
//#endregion
//#region node_modules/@panomc/theme-core/src/lib/pages/ConfirmNewEmailPage.svelte
async function load(event) {
	const viewPromise = resolveView("ConfirmNewEmailView", () => import('./ConfirmNewEmailView.js-FiKpEZdR.js'));
	return {
		...await processLoad(event),
		View: await viewPromise
	};
}
function ConfirmNewEmailPage($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		let data = $$props["data"];
		const activateNewEmailContentItems = panoApiClient.ui.auth.activateNewEmail.content.get();
		let loading = writable();
		let error = writable();
		let successMessage = writable(null);
		if (data.View) {
			$$renderer.push("<!--[-->");
			data.View($$renderer, {
				data,
				activateNewEmailContentItems,
				loading,
				error,
				successMessage,
				verifyEmail
			});
			$$renderer.push("<!--]-->");
		} else {
			$$renderer.push("<!--[!-->");
			$$renderer.push("<!--]-->");
		}
		bind_props($$props, { data });
	});
}

export { ConfirmNewEmailPage as C, load as l };
//# sourceMappingURL=ConfirmNewEmailPage.js-D4tM_mhp.js.map
