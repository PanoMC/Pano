import { X as attr, a5 as escape_html, a0 as store_get, Z as attr_class, a2 as unsubscribe_stores } from './server.js-D28cBEJ-.js';
import { $ as $format } from './runtime.js-CJgfVvxa.js';
import 'node:module';
import './shared.js-3i5_hmQ1.js';
import './client.js-CPEkJ2-P.js';
import './ToastContainer.js-CtmBBvhr.js';

//#region node_modules/@panomc/theme-core/src/lib/components/modals/ConfirmRemoveAllNotificationsModal.svelte
var dialogID = "confirmDeleteAllNotifications";
function ConfirmRemoveAllNotificationsModal($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let loading;
		$$renderer.push(`<div aria-hidden="true" class="modal fade"${attr("id", dialogID)} role="dialog" tabindex="-1"><div class="modal-dialog modal-dialog-centered" role="dialog"><div class="modal-content"><div class="modal-body text-center"><div class="pb-3"><i class="fas fa-question-circle fa-3x d-block m-auto text-gray"></i></div> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.confirm-remove-all-notifications.title"))}</div> <div class="modal-footer flex-nowrap"><button${attr_class("btn btn-link col-6 m-0", void 0, { "disabled": loading })} type="button"${attr("aria-disabled", loading)}${attr("disabled", loading, true)}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.cancel"))}</button> <button${attr_class("btn btn-danger col-6 m-0", void 0, { "disabled": loading })} type="button"${attr("aria-disabled", loading)}${attr("disabled", loading, true)}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.yes"))}</button></div></div></div></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
	});
}

export { ConfirmRemoveAllNotificationsModal as C };
//# sourceMappingURL=ConfirmRemoveAllNotificationsModal.js-CYg4_hFF.js.map
