import { e as error } from './exports2.js-DxZfja4I.js';
import { W as bind_props, a4 as get, T as writable } from './server.js-D28cBEJ-.js';
import 'node:module';
import { g as goto } from './client.js-CPEkJ2-P.js';
import { r as resolveView } from './registry2.js-BubD3cPq.js';
import { N as NETWORK_ERROR } from './Store.js-C2vdyE6V.js';
import { a as getTicketCategories, c as createTicket } from './CloseTicketConfirmModal.js-ex0CkG3p.js';
import { l as load$1, T as TicketCreateAndDetailSidebar } from './TicketCreateAndDetailSidebar.js-BcHSjF3Z.js';

//#region node_modules/@panomc/theme-core/src/lib/ui-logics/page-logics/CreateTicketPageLogics.js
/**
* @type {import("@sveltejs/kit").Load}
*/
async function processLoad(event) {
	const { parent } = event;
	const { session } = await parent();
	const themeSettings = session.siteInfo.themeSettings;
	const onlineAdminsEnabled = typeof themeSettings.sidebarCarts?.onlineAdmins === "undefined" ? true : themeSettings.sidebarCarts.onlineAdmins;
	if (onlineAdminsEnabled) await load$1(event);
	let data = {
		categories: [],
		categoryPage: 0
	};
	await getTicketCategories({
		page: data.categoryPage,
		request: event
	}).then((body) => {
		if (body.error) {
			if (body.error === "NOT_EXISTS") throw error(404, body.error);
			throw error(500, body.error);
		}
		data = body;
	});
	return {
		...data,
		sidebar: onlineAdminsEnabled ? TicketCreateAndDetailSidebar : null,
		pageTitle: "pages.create-ticket.title"
	};
}
async function submit(error, loading, title, message, categoryId) {
	error.set(null);
	loading.set(true);
	await createTicket({
		title: get(title),
		message: get(message),
		categoryId: get(categoryId)
	}).then((body) => {
		loading.set(false);
		if (body.error) {
			error.set(body.error);
			return;
		}
		goto("/ticket/" + body.id);
	}).catch(() => {
		loading.set(false);
		error.set(NETWORK_ERROR);
	});
}
//#endregion
//#region node_modules/@panomc/theme-core/src/lib/pages/ticket/CreateTicketPage.svelte
async function load(event) {
	const viewPromise = resolveView("CreateTicketView", () => import('./CreateTicketView.js-WN7Ajv3c.js'));
	return {
		...await processLoad(event),
		View: await viewPromise
	};
}
function CreateTicketPage($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		let data = $$props["data"];
		let error = writable();
		let title = writable("");
		let message = writable("");
		let categoryId = writable(-1);
		let loading = writable(false);
		if (data.View) {
			$$renderer.push("<!--[-->");
			data.View($$renderer, {
				data,
				error,
				title,
				message,
				categoryId,
				loading,
				submit
			});
			$$renderer.push("<!--]-->");
		} else {
			$$renderer.push("<!--[!-->");
			$$renderer.push("<!--]-->");
		}
		bind_props($$props, { data });
	});
}

export { CreateTicketPage as C, load as l };
//# sourceMappingURL=CreateTicketPage.js-BDUrD2Ao.js.map
