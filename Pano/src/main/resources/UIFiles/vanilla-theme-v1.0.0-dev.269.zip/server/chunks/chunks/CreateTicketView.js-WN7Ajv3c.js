import { a0 as store_get, X as attr, a5 as escape_html, $ as ensure_array_like, Z as attr_class, a2 as unsubscribe_stores, W as bind_props } from './server.js-D28cBEJ-.js';
import { $ as $format } from './runtime.js-CJgfVvxa.js';
import { E as ErrorAlert } from './ErrorAlert.js-DbwaZ_OB.js';
import './uneval.js-BL1Qg77w.js';
import './rolldown-runtime.js-B5FuG9Gw.js';
import 'node:module';

//#region node_modules/@panomc/theme-core/src/lib/views/CreateTicketView.svelte
function CreateTicketView($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let isButtonDisabled;
		let data = $$props["data"];
		let error = $$props["error"];
		let title = $$props["title"];
		let message = $$props["message"];
		let categoryId = $$props["categoryId"];
		let loading = $$props["loading"];
		let submit = $$props["submit"];
		isButtonDisabled = store_get($$store_subs ??= {}, "$title", title) === "" || store_get($$store_subs ??= {}, "$message", message) === "";
		$$renderer.push(`<div class="vstack gap-3">`);
		ErrorAlert($$renderer, { error: store_get($$store_subs ??= {}, "$error", error) });
		$$renderer.push(`<!----> <div class="vstack gap-0"><input id="ticketTitle" type="text" class="form-control form-control-lg rounded-bottom-0 svelte-1r5vhff"${attr("placeholder", store_get($$store_subs ??= {}, "$_", $format)("pages.create-ticket.inputs.title"))}${attr("value", store_get($$store_subs ??= {}, "$title", title))}/> `);
		$$renderer.select({
			class: "form-select form-select-lg rounded-top-0",
			id: "datalistOptions",
			value: store_get($$store_subs ??= {}, "$categoryId", categoryId)
		}, ($$renderer) => {
			$$renderer.option({ value: -1 }, ($$renderer) => {
				$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.create-ticket.inputs.no-category"))}`);
			});
			$$renderer.push(`<!--[-->`);
			const each_array = ensure_array_like(data.categories);
			for (let index = 0, $$length = each_array.length; index < $$length; index++) {
				let category = each_array[index];
				$$renderer.option({ value: category.id }, ($$renderer) => {
					$$renderer.push(`${escape_html(category.title)}`);
				});
			}
			$$renderer.push(`<!--]-->`);
		});
		$$renderer.push(`</div> <textarea class="form-control" rows="6">`);
		const $$body = escape_html(store_get($$store_subs ??= {}, "$message", message));
		if ($$body) $$renderer.push(`${$$body}`);
		$$renderer.push(`</textarea> <button${attr_class("btn btn-lg btn-secondary w-100", void 0, { "disabled": store_get($$store_subs ??= {}, "$loading", loading) || isButtonDisabled })}${attr("disabled", store_get($$store_subs ??= {}, "$loading", loading) || isButtonDisabled, true)}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.create-ticket"))}</button></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
		bind_props($$props, {
			data,
			error,
			title,
			message,
			categoryId,
			loading,
			submit
		});
	});
}

export { CreateTicketView as default };
//# sourceMappingURL=CreateTicketView.js-WN7Ajv3c.js.map
