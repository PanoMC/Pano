import { V as fallback, _ as slot, W as bind_props, a5 as escape_html, a0 as store_get, a2 as unsubscribe_stores } from './server.js-D28cBEJ-.js';
import { c as currentLanguage } from './language.util.js-C2xYQq5-.js';
import './tooltip.util.js-Bd9x5X7L.js';
import { l as locale_exports, n as normalizeDates, e as enUS, g as getDefaultOptions } from './locale.js-DnnPB87K.js';
import { f as format, d as differenceInCalendarDays } from './format.js-CzDFIcjs.js';

//#region node_modules/date-fns/formatRelative.js
/**
* The {@link formatRelative} function options.
*/
/**
* @name formatRelative
* @category Common Helpers
* @summary Represent the date in words relative to the given base date.
*
* @description
* Represent the date in words relative to the given base date.
*
* | Distance to the base date | Result                    |
* |---------------------------|---------------------------|
* | Previous 6 days           | last Sunday at 04:30 AM   |
* | Last day                  | yesterday at 04:30 AM     |
* | Same day                  | today at 04:30 AM         |
* | Next day                  | tomorrow at 04:30 AM      |
* | Next 6 days               | Sunday at 04:30 AM        |
* | Other                     | 12/31/2017                |
*
* @param date - The date to format
* @param baseDate - The date to compare with
* @param options - An object with options
*
* @returns The date in words
*
* @throws `date` must not be Invalid Date
* @throws `baseDate` must not be Invalid Date
* @throws `options.locale` must contain `localize` property
* @throws `options.locale` must contain `formatLong` property
* @throws `options.locale` must contain `formatRelative` property
*
* @example
* // Represent the date of 6 days ago in words relative to the given base date. In this example, today is Wednesday
* const result = formatRelative(subDays(new Date(), 6), new Date())
* //=> "last Thursday at 12:45 AM"
*/
function formatRelative(date, baseDate, options) {
	const [date_, baseDate_] = normalizeDates(options?.in, date, baseDate);
	const defaultOptions = getDefaultOptions();
	const locale = options?.locale ?? defaultOptions.locale ?? enUS;
	const weekStartsOn = options?.weekStartsOn ?? options?.locale?.options?.weekStartsOn ?? defaultOptions.weekStartsOn ?? defaultOptions.locale?.options?.weekStartsOn ?? 0;
	const diff = differenceInCalendarDays(date_, baseDate_);
	if (isNaN(diff)) throw new RangeError("Invalid time value");
	let token;
	if (diff < -6) token = "other";
	else if (diff < -1) token = "lastWeek";
	else if (diff < 0) token = "yesterday";
	else if (diff < 1) token = "today";
	else if (diff < 2) token = "tomorrow";
	else if (diff < 7) token = "nextWeek";
	else token = "other";
	return format(date_, locale.formatRelative(token, date_, baseDate_, {
		locale,
		weekStartsOn
	}), {
		locale,
		weekStartsOn
	});
}
//#endregion
//#region node_modules/@panomc/theme-core/src/lib/components/Date.svelte
function Date_1($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let date;
		String.prototype.capitalize = function() {
			return this.charAt(0).toUpperCase() + this.slice(1);
		};
		let time = $$props["time"];
		let relativeFormat = fallback($$props["relativeFormat"], false);
		date = time;
		$$renderer.push(`<span><!--[-->`);
		slot($$renderer, $$props, "default", {}, () => {
			if (relativeFormat) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`${escape_html(formatRelative(new Date(parseInt(date)), /* @__PURE__ */ new Date(), { locale: locale_exports[store_get($$store_subs ??= {}, "$currentLanguage", currentLanguage).dateFnsCode] }).capitalize())}`);
			} else {
				$$renderer.push("<!--[-1-->");
				$$renderer.push(`${escape_html(format(new Date(parseInt(date)), "dd MMMM yyyy", { locale: locale_exports[store_get($$store_subs ??= {}, "$currentLanguage", currentLanguage).dateFnsCode] }))}`);
			}
			$$renderer.push(`<!--]-->`);
		});
		$$renderer.push(`<!--]--></span>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
		bind_props($$props, {
			time,
			relativeFormat
		});
	});
}

export { Date_1 as D };
//# sourceMappingURL=Date.js-ZK3lGml2.js.map
