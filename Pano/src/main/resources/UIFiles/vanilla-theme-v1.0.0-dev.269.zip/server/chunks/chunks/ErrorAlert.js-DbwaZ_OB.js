import { a5 as escape_html, a0 as store_get, a2 as unsubscribe_stores, W as bind_props } from './server.js-D28cBEJ-.js';
import { $ as $format } from './runtime.js-CJgfVvxa.js';

//#region node_modules/@panomc/theme-core/src/lib/components/ErrorAlert.svelte
function ErrorAlert($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let error = $$props["error"];
		if (error || false) {
			$$renderer.push("<!--[0-->");
			const errorKey = error.key || error;
			$$renderer.push(`<div class="alert alert-danger">${escape_html(store_get($$store_subs ??= {}, "$_", $format)(errorKey.includes(".") ? errorKey : "errors." + errorKey, { values: error.props }))}</div>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]-->`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
		bind_props($$props, { error });
	});
}

export { ErrorAlert as E };
//# sourceMappingURL=ErrorAlert.js-DbwaZ_OB.js.map
