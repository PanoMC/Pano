import { V as fallback, a0 as store_get, a5 as escape_html, a2 as unsubscribe_stores, W as bind_props } from './server.js-D28cBEJ-.js';
import { $ as $format } from './runtime.js-CJgfVvxa.js';
import { P as PageTitle } from './PageTitle.js-D99NSXzQ.js';
import './uneval.js-BL1Qg77w.js';
import './rolldown-runtime.js-B5FuG9Gw.js';
import 'node:module';

//#region node_modules/@panomc/theme-core/src/lib/views/ErrorView.svelte
function ErrorView($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let data = fallback($$props["data"], void 0);
		let page = $$props["page"];
		$$renderer.push(`<div class="vstack gap-3">`);
		PageTitle($$renderer, {
			title: store_get($$store_subs ??= {}, "$_", $format)("page-errors.title", {
				values: { status: page.status },
				default: `Error: ${page.status}`
			}),
			subtitle: page.status === 404 ? store_get($$store_subs ??= {}, "$_", $format)("page-errors.404-description") : page.error?.code === "MODULE_LOAD_FAILED" ? store_get($$store_subs ??= {}, "$_", $format)("page-errors.assets-failed") : store_get($$store_subs ??= {}, "$_", $format)("errors.INTERNAL_SERVER_ERROR")
		});
		$$renderer.push(`<!----> <div class="text-center mb-3"><img src="/assets/img/404.png" alt="Error" width="256" height="auto"/></div> <div class="text-center"><a href="/" class="btn btn-primary"><i class="fas fa-home me-2"></i> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("nav-links.homepage"))}</a></div></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
		bind_props($$props, {
			data,
			page
		});
	});
}

export { ErrorView as default };
//# sourceMappingURL=ErrorView.js-BTyrvSYN.js.map
