import 'node:module';
import { g as getContext, a0 as store_get, $ as ensure_array_like, X as attr, a5 as escape_html, Y as stringify, Z as attr_class, a3 as html, a2 as unsubscribe_stores } from './server.js-D28cBEJ-.js';
import { $ as $format } from './runtime.js-CJgfVvxa.js';
import { p as panoApiClient, o as orderLinksBySavedOrder } from './PluginManager.js-B5x3OKEW.js';
import { r as require_copy_to_clipboard } from './copy-to-clipboard.js-CF5RgzCy.js';
import { P as PANO_WEBSITE_URL } from './Store.js-C2vdyE6V.js';
import './tooltip.util.js-Bd9x5X7L.js';
import { h as hasPermission } from './auth.util.js-BGCV_dhB.js';
import './uneval.js-BL1Qg77w.js';
import './rolldown-runtime.js-B5FuG9Gw.js';
import './exports2.js-DxZfja4I.js';
import './shared.js-3i5_hmQ1.js';
import './internal.js-BlXt2rfE.js';
import './client.js-CPEkJ2-P.js';
import './exports.js-CKkpMUqI.js';
import './internal2.js-KmQU-gaY.js';
import './index-server2.js-DlblWyyK.js';
import 'fs';
import './ToastContainer.js-CtmBBvhr.js';
import './stores.js-QbD2A2ib.js';

require_copy_to_clipboard();
//#endregion
//#region node_modules/@panomc/theme-core/src/lib/components/Footer.svelte
function Footer($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let nativeLinks, ipBadgeClass, displayLinks, visibleLinks, moreLinks, moreLinksInMenuOrder;
		const session = getContext("session");
		const themeSettings = getContext("themeSettings");
		const navLinks = panoApiClient.ui.nav.site.getNavLinks();
		const MAX_INLINE_FOOTER_LINKS = 3;
		nativeLinks = [
			{
				id: "home",
				text: "nav-links.homepage",
				href: "/"
			},
			{
				id: "support",
				text: "nav-links.support",
				href: "/support"
			},
			{
				id: "rules",
				text: "nav-links.rules",
				href: "/rules",
				condition: !!store_get($$store_subs ??= {}, "$session", session).siteInfo?.hasRegisterAgreement
			}
		];
		ipBadgeClass = themeSettings.themeColor === "emerald" ? "text-bg-success" : themeSettings.themeColor === "midnight" ? "text-bg-purple" : themeSettings.themeColor === "crimson" ? "text-bg-danger" : themeSettings.themeColor === "copper" ? "text-bg-warning" : "text-bg-secondary";
		displayLinks = (() => {
			if (themeSettings.footerLinksEnabled === false) return [];
			const pluginLinks = store_get($$store_subs ??= {}, "$navLinks", navLinks).map((l) => ({
				...l,
				id: l.href,
				isPlugin: true,
				target: l.target === "_self" ? null : l.target
			}));
			return orderLinksBySavedOrder([...nativeLinks, ...pluginLinks], themeSettings.footerLinksOrder).filter((link) => {
				if (link.isPlugin && themeSettings.footerPluginLinksEnabled === false) return false;
				if (themeSettings.footerLinksEnableStatus?.[link.id] === false) return false;
				if (typeof link.condition !== "undefined" && !link.condition) return false;
				if (link.loginRequired && !store_get($$store_subs ??= {}, "$session", session).user) return false;
				if (link.permission && !hasPermission(link.permission)) return false;
				return true;
			});
		})();
		visibleLinks = displayLinks.slice(0, MAX_INLINE_FOOTER_LINKS);
		moreLinks = displayLinks.length > MAX_INLINE_FOOTER_LINKS ? displayLinks.slice(MAX_INLINE_FOOTER_LINKS) : [];
		moreLinksInMenuOrder = [...moreLinks].reverse();
		$$renderer.push(`<footer class="border-top bg-gray bg-opacity-10 py-5"><div class="container py-lg-5 position-relative z-1"><div class="row justify-content-center align-items-center g-3"><div class="col-lg-4 d-flex justify-content-center align-items-center order-lg-first order-md-2 order-last"><ul class="nav nav-pills justify-content-lg-start justify-content-center small flex-wrap"><!--[-->`);
		const each_array = ensure_array_like(visibleLinks);
		for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
			let link = each_array[$$index];
			$$renderer.push(`<li class="nav-item"><a class="nav-link rounded-pill small"${attr("href", link.href)}${attr("target", link.target)}${attr("title", link.text && link.text.includes(".") ? store_get($$store_subs ??= {}, "$_", $format)(link.text) : link.text)}>${escape_html(link.text && link.text.includes(".") ? store_get($$store_subs ??= {}, "$_", $format)(link.text) : link.text)}</a></li>`);
		}
		$$renderer.push(`<!--]--> `);
		if (moreLinks.length > 0) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<li class="nav-item dropup"><button class="nav-link rounded-pill small dropdown-toggle no-caret svelte-27e5qv" data-bs-toggle="dropdown" type="button"${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("buttons.toggle"))} aria-expanded="false"><i class="fa-solid fa-ellipsis"></i></button> <ul class="dropdown-menu dropdown-menu-end"><!--[-->`);
			const each_array_1 = ensure_array_like(moreLinksInMenuOrder);
			for (let $$index_1 = 0, $$length = each_array_1.length; $$index_1 < $$length; $$index_1++) {
				let link = each_array_1[$$index_1];
				$$renderer.push(`<li><a class="dropdown-item small"${attr("href", link.href)}${attr("target", link.target)}>${escape_html(link.text && link.text.includes(".") ? store_get($$store_subs ??= {}, "$_", $format)(link.text) : link.text)}</a></li>`);
			}
			$$renderer.push(`<!--]--></ul></li>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--></ul></div> <div class="col-lg-4 col-sm-8"><div class="text-center vstack align-items-center gap-3">`);
		if (themeSettings.footerLogoEnabled ?? true) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<a href="/" class="d-inline-block"><img class="d-block mx-auto" width="128" height="auto"${attr("alt", store_get($$store_subs ??= {}, "$_", $format)("components.header.alt"))}${attr("src", `/api/websiteLogo?hash=${stringify(store_get($$store_subs ??= {}, "$session", session).siteInfo.websiteLogoHash)}`)}/></a>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--> `);
		if (themeSettings.footerTitleEnabled ?? true) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<h5>${escape_html(themeSettings.footerTitle || store_get($$store_subs ??= {}, "$session", session).siteInfo.websiteName)}</h5>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--> `);
		if (themeSettings.footerContentEnabled ?? true) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<small class="text-center">${escape_html(themeSettings.footerContent || store_get($$store_subs ??= {}, "$session", session).siteInfo.websiteDescription)}</small>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--></div></div> <div class="col-lg-4 d-flex justify-content-center align-items-center"><button type="button"${attr_class(`badge fs-6 ${stringify(ipBadgeClass)} border-0`, "svelte-27e5qv")}${attr("aria-label", store_get($$store_subs ??= {}, "$session", session).siteInfo.ipAddress)}>${escape_html(store_get($$store_subs ??= {}, "$session", session).siteInfo.ipAddress)}</button></div> <div class="w-100"></div> <div class="col order-last"><div class="text-center vstack align-items-center mt-5"><a${attr("href", PANO_WEBSITE_URL)} target="_blank" rel="noreferrer" class="d-inline-flex align-items-center justify-content-center bg-primary rounded-3 mb-2" style="width: 32px; height: 32px;" title="Pano"><img src="/assets/img/logo.svg" width="20" height="20" alt="Pano"/></a> <small>${html(store_get($$store_subs ??= {}, "$_", $format)("footer.been-created-with", { values: { pano: `<a href="${PANO_WEBSITE_URL}" class="rounded focus-ring" target="_blank" rel="noreferrer">Pano</a>` } }))}</small></div></div></div></div></footer>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
	});
}

export { Footer as default };
//# sourceMappingURL=Footer.js-mr8_pWqO.js.map
