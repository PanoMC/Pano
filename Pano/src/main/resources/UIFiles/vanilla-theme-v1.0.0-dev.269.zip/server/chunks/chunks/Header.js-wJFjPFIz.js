import { g as getContext, ab as head, Z as attr_class, a8 as attr_style, Y as stringify, X as attr, a0 as store_get, a6 as clsx, a2 as unsubscribe_stores, a3 as html } from './server.js-D28cBEJ-.js';
import 'node:module';
import { $ as $format } from './runtime.js-CJgfVvxa.js';
import './uneval.js-BL1Qg77w.js';
import './rolldown-runtime.js-B5FuG9Gw.js';

//#region node_modules/@panomc/theme-core/src/lib/components/Header.svelte
function Header($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let effectiveHeaderBgColor, logoPosition, logoPositionClasses, logoAnimation, logoAnimationClass, headerWidthOption;
		const session = getContext("session");
		const themeSettings = getContext("themeSettings");
		const headerDefaults = {
			dark: "",
			light: "",
			copper: "#b87333",
			emerald: "#10b981",
			midnight: "#8b5cf6",
			crimson: "#ef4444"
		};
		function getLogoAnimationClass(animation) {
			if (animation === "zoom") return "logo-animation-zoom";
			if (animation === "floating") return "logo-animation-floating";
			return "";
		}
		function getLogoPositionClasses(logoPosition) {
			if (logoPosition === "TOP_START") return "top-0 start-0";
			else if (logoPosition === "TOP") return "top-0 start-50 translate-middle-x";
			else if (logoPosition === "TOP_END") return "top-0 end-0";
			else if (logoPosition === "CENTER_START") return "top-50 start-0 translate-middle-y";
			else if (logoPosition === "CENTER") return "top-50 start-50 translate-middle";
			else if (logoPosition === "CENTER_END") return "top-50 end-0 translate-middle-y";
			else if (logoPosition === "BOTTOM_START") return "bottom-0 start-0 ";
			else if (logoPosition === "BOTTOM") return "bottom-0 start-50 translate-middle-x";
			else if (logoPosition === "BOTTOM_END") return "bottom-0 end-0";
			return "top-50 start-50 translate-middle";
		}
		const defaultHeaderBg = typeof themeSettings.defaultHeaderBg === "undefined" ? true : themeSettings.defaultHeaderBg;
		const styles = `
    .hero::before {
      ${effectiveHeaderBgColor ? `background-color: ${effectiveHeaderBgColor};` : ""}
      background-image: url(${defaultHeaderBg ? "/assets/img/default-header-bg.png" : themeSettings.files?.headerBackgroundImage ? "/api/theme/file/" + themeSettings.files?.headerBackgroundImage : ""}) !important;
      ${themeSettings.headerBgImagePosition ? `background-position: ${themeSettings.headerBgImagePosition} !important;` : ""}
      ${themeSettings.headerBgImageRepeat ? `background-repeat: ${themeSettings.headerBgImageRepeat} !important;` : ""}
      background-size: ${themeSettings.headerBgImageSize || "cover"} !important;
    }

    .logo-animation-zoom {
      animation: logo-zoom 5s ease-in-out infinite;
    }
    
    .logo-animation-floating {
      animation: logo-floating 3s ease-in-out infinite;
    }

    @keyframes logo-zoom {
      0%, 100% { transform: scale(1); }
      50% { transform: scale(1.05); }
    }

    @keyframes logo-floating {
      0%, 100% { transform: translateY(0); }
      50% { transform: translateY(-20px); }
    }
  `;
		effectiveHeaderBgColor = themeSettings.headerBgColor || headerDefaults[themeSettings.themeColor || "dark"];
		logoPosition = themeSettings.logoPosition ? themeSettings.logoPosition : "CENTER";
		logoPositionClasses = getLogoPositionClasses(logoPosition);
		logoAnimation = themeSettings.logoAnimation || "off";
		logoAnimationClass = getLogoAnimationClass(logoAnimation);
		headerWidthOption = themeSettings.headerWidthOption || "FULL_SIZE";
		head("15cuno1", $$renderer, ($$renderer) => {
			$$renderer.push(`${html(`<style>;</style>`.replace(";", styles))}`);
		});
		$$renderer.push(`<div${attr_class("hero", void 0, { "container": headerWidthOption !== "FULL_SIZE" })}><div${attr_class("hero-content position-relative p-0", void 0, { "bg-transparent": !effectiveHeaderBgColor })} id="header"${attr_style(`background-position: center; height: ${stringify(themeSettings.headerHeight || "256")}px;`)}><a href="/"><div${attr_class(`position-absolute ${stringify(logoPositionClasses)} px-3`, void 0, { "d-none": themeSettings.logoVisibility === false })} style="padding-top: 80px; padding-bottom: 40px;"><img${attr("alt", store_get($$store_subs ??= {}, "$_", $format)("components.header.alt"))}${attr_class(clsx(logoAnimationClass))}${attr("src", `/api/websiteLogo?hash=${stringify(store_get($$store_subs ??= {}, "$session", session).siteInfo.websiteLogoHash)}`)}${attr_style(`object-fit: contain; width: ${stringify(themeSettings.logoWidth || "256")}px; height: ${stringify(themeSettings.logoHeight ? themeSettings.logoHeight + "px" : "auto")}; max-width: 100%;`)}${attr("title", store_get($$store_subs ??= {}, "$session", session).siteInfo.websiteName)}/></div></a></div></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
	});
}

export { Header as default };
//# sourceMappingURL=Header.js-wJFjPFIz.js.map
