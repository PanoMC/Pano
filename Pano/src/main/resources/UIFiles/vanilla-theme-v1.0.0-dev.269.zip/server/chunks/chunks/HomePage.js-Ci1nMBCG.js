import 'node:module';
import { e as error } from './exports2.js-DxZfja4I.js';
import { g as getContext, W as bind_props, a0 as store_get, a2 as unsubscribe_stores, T as writable, $ as ensure_array_like, Z as attr_class, Y as stringify, a8 as attr_style, a5 as escape_html, X as attr, a1 as spread_props } from './server.js-D28cBEJ-.js';
import { g as goto } from './client.js-CPEkJ2-P.js';
import { $ as $format } from './runtime.js-CJgfVvxa.js';
import { c as executeHookLoad, d as panoApi, g as executeSidebarLoad } from './PluginManager.js-B5x3OKEW.js';
import { r as resolveView } from './registry2.js-BubD3cPq.js';
import { r as require_copy_to_clipboard } from './copy-to-clipboard.js-CF5RgzCy.js';
import { d as ApiUtil, e as buildQueryParams, c as avatarVersion } from './Store.js-C2vdyE6V.js';
import './tooltip.util.js-Bd9x5X7L.js';
import { g as getPosts } from './posts.js-DGnD0CAT.js';
import { S as Sidebar } from './Sidebar.js-BwVxP8m2.js';
import { C as CardHeader } from './CardHeader.js-DpkWpoy6.js';
import { V as ViewComponent } from './ViewComponent.js-C6amYVVM.js';

require_copy_to_clipboard();
//#endregion
//#region node_modules/@panomc/theme-core/src/lib/components/sidebars/HomeSidebar.svelte
var data = writable({});
var load$1 = async (event) => {
	panoApi.ui.sidebar.register({
		sidebarId: "home",
		id: "play-button",
		component: "local:play-button",
		priority: 100
	});
	panoApi.ui.sidebar.register({
		sidebarId: "home",
		id: "last-registrants",
		component: "local:last-registrants",
		priority: 80
	});
	await executeSidebarLoad("home", event);
	data.set(await ApiUtil.get({
		path: "/api/sidebars/home",
		request: event
	}));
};
function HomeSidebar($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let serverOnline, headerBgImage, defaultPlayCardBg, playCardBgImage, playCardOpacity, playCardBgEffect, playCardBgStyle, playCardHeaderClass, playCardIpColor, playCardBtnColor, playCardBorderColor, playCardIpText, playCardIpLength, showPlayCardStatusBadge, showPlayCardPlayerCount, showPlayCardVersionInfo;
		let side = $$props["side"];
		const themeSettings = getContext("themeSettings");
		const items = panoApi.ui.sidebar.get("home");
		const defaultHeaderBg = typeof themeSettings.defaultHeaderBg === "undefined" ? true : themeSettings.defaultHeaderBg;
		serverOnline = store_get($$store_subs ??= {}, "$data", data).mainServer && store_get($$store_subs ??= {}, "$data", data).mainServer.status === "ONLINE";
		headerBgImage = defaultHeaderBg ? "/assets/img/default-header-bg.png" : themeSettings.files?.headerBackgroundImage ? "/api/theme/file/" + themeSettings.files?.headerBackgroundImage : "";
		defaultPlayCardBg = typeof themeSettings.defaultPlayCardBg === "undefined" ? true : themeSettings.defaultPlayCardBg;
		playCardBgImage = themeSettings.files?.playCardBackgroundImage ? "/api/theme/file/" + themeSettings.files?.playCardBackgroundImage : defaultPlayCardBg ? headerBgImage : "";
		playCardOpacity = themeSettings.playCardBgOpacity ?? .5;
		playCardBgEffect = themeSettings.playCardBgEffect || "solid";
		playCardBgStyle = playCardBgEffect === "gradient" ? `background: linear-gradient(180deg, transparent 0%, var(--bs-body-bg) 100%);` : `background-color: color-mix(in srgb, var(--bs-body-bg) 70%, transparent);`;
		playCardHeaderClass = !themeSettings.playCardBorderColor || themeSettings.playCardBorderColor === "default" ? "text-bg-secondary" : themeSettings.playCardBorderColor.replace("border-", "text-bg-");
		playCardIpColor = !themeSettings.playCardIpColor || themeSettings.playCardIpColor === "default" ? "link-secondary" : "link-" + themeSettings.playCardIpColor;
		playCardBtnColor = !themeSettings.playCardIpColor || themeSettings.playCardIpColor === "default" ? !themeSettings.playCardBorderColor || themeSettings.playCardBorderColor === "default" ? "secondary" : themeSettings.playCardBorderColor.replace("border-", "") : themeSettings.playCardIpColor;
		playCardBorderColor = !themeSettings.playCardBorderColor || themeSettings.playCardBorderColor === "default" ? "border-secondary" : themeSettings.playCardBorderColor;
		playCardIpText = themeSettings.playCardIpText || store_get($$store_subs ??= {}, "$data", data).ipAddress;
		playCardIpLength = String(playCardIpText || "").length || 1;
		showPlayCardStatusBadge = themeSettings.playCardStatusBadge ?? true;
		showPlayCardPlayerCount = themeSettings.playCardPlayerCount ?? true;
		showPlayCardVersionInfo = themeSettings.playCardVersionInfo ?? true;
		Sidebar($$renderer, {
			side,
			children: ($$renderer) => {
				$$renderer.push(`<div class="vstack gap-3"><!--[-->`);
				const each_array = ensure_array_like(store_get($$store_subs ??= {}, "$items", items));
				for (let $$index_1 = 0, $$length = each_array.length; $$index_1 < $$length; $$index_1++) {
					let item = each_array[$$index_1];
					if (item.id === "play-button") {
						$$renderer.push("<!--[0-->");
						if ((themeSettings.playCardStyle || "style-2") === "style-2") {
							$$renderer.push("<!--[0-->");
							$$renderer.push(`<div class="card position-relative overflow-hidden square-card-desktop svelte-16eugu3"><div${attr_class(`card-body position-relative z-1 rounded overflow-hidden border border-2 ${stringify(playCardBorderColor)}`, "svelte-16eugu3")}><div class="position-absolute top-0 start-0 w-100 h-100"${attr_style(`background-image: url(${stringify(playCardBgImage)}); background-size: cover; background-position: ${stringify(themeSettings.headerBgImagePosition || "center")}; opacity: ${stringify(playCardOpacity)}; z-index: -2;`)}></div> <div class="position-absolute top-0 start-0 w-100 h-100"${attr_style(`${stringify(playCardBgStyle)} z-index: -1;`)}></div> <ul class="list-group list-group-flush text-center bg-transparent position-relative z-1"><li class="list-group-item border-0 py-2 bg-transparent"><button${attr_class(`btn btn-link ${stringify(playCardIpColor)} border-0 shadow-none text-decoration-none w-100 focus-ring play-card-ip`, "svelte-16eugu3")}${attr_style(`--ip-len: ${stringify(playCardIpLength)}; --ip-max: 28px;`)} type="button"><b class="d-block svelte-16eugu3">${escape_html(playCardIpText)}</b></button></li> `);
							if (showPlayCardStatusBadge) {
								$$renderer.push("<!--[0-->");
								$$renderer.push(`<li class="list-group-item border-0 py-2 bg-transparent">`);
								if (serverOnline) {
									$$renderer.push("<!--[0-->");
									$$renderer.push(`<span class="badge text-bg-success">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("sidebars.home.online"))}</span>`);
								} else {
									$$renderer.push("<!--[-1-->");
									$$renderer.push(`<span class="badge text-bg-danger rounded-pill">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("sidebars.home.offline"))}</span>`);
								}
								$$renderer.push(`<!--]--></li>`);
							} else $$renderer.push("<!--[-1-->");
							$$renderer.push(`<!--]--> `);
							if (showPlayCardPlayerCount) {
								$$renderer.push("<!--[0-->");
								$$renderer.push(`<li class="list-group-item border-0 py-2 bg-transparent">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("sidebars.home.playing", { values: {
									playerCount: store_get($$store_subs ??= {}, "$data", data).mainServer?.playerCount || 0,
									maxPlayerCount: store_get($$store_subs ??= {}, "$data", data).mainServer?.maxPlayerCount || 0
								} }))}</li>`);
							} else $$renderer.push("<!--[-1-->");
							$$renderer.push(`<!--]--> `);
							if (showPlayCardVersionInfo) {
								$$renderer.push("<!--[0-->");
								$$renderer.push(`<li class="list-group-item border-0 py-2 bg-transparent">${escape_html(store_get($$store_subs ??= {}, "$data", data).serverGameVersion)}</li>`);
							} else $$renderer.push("<!--[-1-->");
							$$renderer.push(`<!--]--></ul></div></div>`);
						} else {
							$$renderer.push("<!--[-1-->");
							$$renderer.push(`<div class="card border-0 square-card-desktop svelte-16eugu3"><div${attr_class(`card-header ${stringify(playCardHeaderClass)} p-0 rounded-top border-bottom border-5 ${stringify(playCardBorderColor)}`, "svelte-16eugu3")}><button${attr_class(`btn btn-${stringify(playCardBtnColor)} border-0 shadow-none text-decoration-none w-100 focus-ring py-2 play-card-ip`, "svelte-16eugu3")}${attr_style(`--ip-len: ${stringify(playCardIpLength)}; --ip-max: 24px;`)} type="button"><b class="d-block svelte-16eugu3">${escape_html(playCardIpText)}</b></button></div> <div${attr_class(`card-body position-relative z-1 overflow-hidden border border-2 ${stringify(playCardBorderColor)} border-top-0 rounded-bottom`, "svelte-16eugu3")}><div class="position-absolute top-0 start-0 w-100 h-100"${attr_style(`background-image: url(${stringify(playCardBgImage)}); background-size: cover; background-position: ${stringify(themeSettings.headerBgImagePosition || "center")}; opacity: ${stringify(playCardOpacity)}; z-index: -2;`)}></div> <div class="position-absolute top-0 start-0 w-100 h-100"${attr_style(`${stringify(playCardBgStyle)} z-index: -1;`)}></div> <ul class="list-group list-group-flush text-center bg-transparent position-relative z-1">`);
							if (showPlayCardStatusBadge) {
								$$renderer.push("<!--[0-->");
								$$renderer.push(`<li class="list-group-item border-0 py-2 bg-transparent">`);
								if (serverOnline) {
									$$renderer.push("<!--[0-->");
									$$renderer.push(`<span class="badge text-bg-success">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("sidebars.home.online"))}</span>`);
								} else {
									$$renderer.push("<!--[-1-->");
									$$renderer.push(`<span class="badge text-bg-danger rounded-pill">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("sidebars.home.offline"))}</span>`);
								}
								$$renderer.push(`<!--]--></li>`);
							} else $$renderer.push("<!--[-1-->");
							$$renderer.push(`<!--]--> `);
							if (showPlayCardPlayerCount) {
								$$renderer.push("<!--[0-->");
								$$renderer.push(`<li class="list-group-item border-0 py-2 bg-transparent">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("sidebars.home.playing", { values: {
									playerCount: store_get($$store_subs ??= {}, "$data", data).mainServer?.playerCount || 0,
									maxPlayerCount: store_get($$store_subs ??= {}, "$data", data).mainServer?.maxPlayerCount || 0
								} }))}</li>`);
							} else $$renderer.push("<!--[-1-->");
							$$renderer.push(`<!--]--> `);
							if (showPlayCardVersionInfo) {
								$$renderer.push("<!--[0-->");
								$$renderer.push(`<li class="list-group-item border-0 py-2 bg-transparent">${escape_html(store_get($$store_subs ??= {}, "$data", data).serverGameVersion)}</li>`);
							} else $$renderer.push("<!--[-1-->");
							$$renderer.push(`<!--]--></ul></div></div>`);
						}
						$$renderer.push(`<!--]-->`);
					} else if (item.id === "server-info") $$renderer.push("<!--[1-->");
					else if (item.id === "last-registrants") {
						$$renderer.push("<!--[2-->");
						$$renderer.push(`<div class="card position-relative overflow-hidden mb-lg-0 mb-3 square-card-desktop svelte-16eugu3"${attr("hidden", typeof themeSettings.sidebarCarts?.lastRegistrants === "undefined" ? false : !themeSettings.sidebarCarts.lastRegistrants)}>`);
						CardHeader($$renderer, {
							headerClasses: "bg-transparent",
							$$slots: { left: ($$renderer) => {
								$$renderer.push(`<div slot="left">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("sidebars.home.last-registrants"))}</div>`);
							} }
						});
						$$renderer.push(`<!----> <div class="card-body pt-3 d-flex flex-column justify-content-start"><div class="row g-3 justify-content-evenly align-items-start align-content-start"><!--[-->`);
						const each_array_1 = ensure_array_like(store_get($$store_subs ??= {}, "$data", data).lastRegisteredUsers || []);
						for (let index = 0, $$length = each_array_1.length; index < $$length; index++) {
							let player = each_array_1[index];
							$$renderer.push(`<div class="col-auto"><a${attr("href", `/player/${stringify(player.username)}`)} class="d-inline-block rounded focus-ring"><img${attr("alt", player.username)}${attr_class("rounded", void 0, {
								"border": player.lastActivityTime > Date.now() - 3e5 || player.inGame,
								"border-2": player.lastActivityTime > Date.now() - 3e5 || player.inGame,
								"border-success": player.lastActivityTime > Date.now() - 3e5 || player.inGame
							})}${attr("src", `/api/profile/picture/${stringify(player.username)}?${stringify(store_get($$store_subs ??= {}, "$avatarVersion", avatarVersion))}`)} width="48" height="48" onload="this.__e=event" onerror="this.__e=event"/></a></div>`);
						}
						$$renderer.push(`<!--]--></div></div></div>`);
					} else {
						$$renderer.push("<!--[-1-->");
						ViewComponent($$renderer, spread_props([{
							component: item.component,
							data: store_get($$store_subs ??= {}, "$data", data)
						}, item.props]));
					}
					$$renderer.push(`<!--]-->`);
				}
				$$renderer.push(`<!--]--></div>`);
			},
			$$slots: { default: true }
		});
		if ($$store_subs) unsubscribe_stores($$store_subs);
		bind_props($$props, { side });
	});
}
//#endregion
//#region node_modules/@panomc/theme-core/src/lib/ui-logics/page-logics/HomePageLogics.js
/**
* @type {import("@sveltejs/kit").PageLoad}
*/
async function processLoad(event) {
	const { parent, url: { searchParams } } = event;
	const parentData = await parent();
	const page = parseInt(searchParams.get("page")) || 1;
	const categoryUrl = searchParams.get("category");
	const parallelTasks = [getPosts({
		page,
		categoryUrl,
		request: event
	})];
	if (!categoryUrl) {
		parallelTasks.push(load$1(event));
		parallelTasks.push(executeHookLoad("page:home:top", event));
	}
	const [data, , homeTopHookProps] = await Promise.all(parallelTasks);
	if (data.error) {
		if (data.error === "PAGE_NOT_FOUND" || data.error === "NOT_EXISTS" || data.error === "CATEGORY_NOT_EXISTS" || data.error === "BAD_REQUEST") throw error(404, data.error);
		throw error(500, data.error);
	}
	data.page = page;
	data.categoryUrl = categoryUrl;
	return {
		...data,
		sidebar: categoryUrl ? null : HomeSidebar,
		hookProps: categoryUrl ? void 0 : {
			...parentData.hookProps,
			"page:home:top": homeTopHookProps
		}
	};
}
async function refreshData(data) {
	await goto(buildQueryParams({
		page: data.page,
		category: data.categoryUrl
	}));
}
async function onPageClick(data, page) {
	data.page = page;
	await refreshData(data);
}
//#endregion
//#region node_modules/@panomc/theme-core/src/lib/pages/HomePage.svelte
async function load(event) {
	const viewPromise = resolveView("HomeView", () => import('./HomeView.js-CsfC5vs-.js'));
	return {
		...await processLoad(event),
		View: await viewPromise
	};
}
function HomePage($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		let data = $$props["data"];
		const themeSettings = getContext("themeSettings");
		if (data.View) {
			$$renderer.push("<!--[-->");
			data.View($$renderer, {
				data,
				themeSettings,
				onPageClick
			});
			$$renderer.push("<!--]-->");
		} else {
			$$renderer.push("<!--[!-->");
			$$renderer.push("<!--]-->");
		}
		bind_props($$props, { data });
	});
}

export { HomePage as H, load as l };
//# sourceMappingURL=HomePage.js-Ci1nMBCG.js.map
