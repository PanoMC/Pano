import { a5 as escape_html, a0 as store_get, a2 as unsubscribe_stores, W as bind_props, $ as ensure_array_like, V as fallback, g as getContext, Z as attr_class, X as attr, Y as stringify, a3 as html } from './server.js-D28cBEJ-.js';
import 'node:module';
import { $ as $format } from './runtime.js-CJgfVvxa.js';
import { c as avatarVersion } from './Store.js-C2vdyE6V.js';
import './tooltip.util.js-Bd9x5X7L.js';
import { D as Date_1 } from './Date.js-ZK3lGml2.js';
import { P as Pagination } from './Pagination.js-CeyG1SGU.js';
import { N as NoContent } from './NoContent.js-BBe0Mapz.js';
import { t as truncate } from './string.util.js-dF34MZ_o.js';
import { H as Hook } from './Hook.js-DEYNBNbZ.js';
import './uneval.js-BL1Qg77w.js';
import './rolldown-runtime.js-B5FuG9Gw.js';
import './exports2.js-DxZfja4I.js';
import './shared.js-3i5_hmQ1.js';
import './client.js-CPEkJ2-P.js';
import './exports.js-CKkpMUqI.js';
import './internal2.js-KmQU-gaY.js';
import './index-server2.js-DlblWyyK.js';
import './ToastContainer.js-CtmBBvhr.js';
import './stores.js-QbD2A2ib.js';
import './language.util.js-C2xYQq5-.js';
import './internal.js-BlXt2rfE.js';
import './locale.js-DnnPB87K.js';
import './format.js-CzDFIcjs.js';
import './PluginManager.js-B5x3OKEW.js';
import 'fs';
import './auth.util.js-BGCV_dhB.js';

//#region node_modules/@panomc/theme-core/src/lib/components/Post.svelte
function Post($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let post = $$props["post"];
		let detail = fallback($$props["detail"], false);
		const themeSettings = getContext("themeSettings");
		$$renderer.push(`<div${attr_class("card vanilla-post-card h-100 rounded-4 focus-ring position-relative overflow-hidden", void 0, {
			"post-clickable": !detail,
			"post-detail": detail,
			"is-overlay": !detail,
			"has-thumbnail": !detail && post.thumbnailUrl
		})}>`);
		if (!detail && post.thumbnailUrl) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<img${attr("src", post.thumbnailUrl)} class="card-img h-100 object-fit-cover"${attr("alt", post.title)}/>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--> `);
		if ((typeof themeSettings.postCoverImageEnabled === "undefined" ? true : themeSettings.postCoverImageEnabled) && detail && post.thumbnailUrl) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<div class="post-card-thumbnail-wrapper d-block"><div class="ratio ratio-16x9"><img${attr("src", post.thumbnailUrl)} class="card-img-top"${attr("alt", post.title)}${attr("title", post.title)}/></div></div>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--> <div${attr_class("d-flex flex-column justify-content-end", void 0, {
			"card-img-overlay": !detail,
			"card-body": detail
		})}><div class="d-flex justify-content-between align-items-start mb-3 gap-2 mt-auto"><a${attr_class("text-decoration-none rounded text-reset flex-grow-1 z-1", void 0, { "stretched-link": !detail })}${attr("href", `/post/${stringify(post.url)}`)}><h3 class="mb-0 text-break h4 fw-bold clamp-title"${attr("title", post.title)}>${escape_html(post.title)}</h3></a></div> <div${attr_class("card-text text-break word-break mb-4", void 0, {
			"text-muted": detail || !post.thumbnailUrl,
			"clamp-text": !detail
		})}>`);
		if (detail) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`${html(post.text)}`);
		} else {
			$$renderer.push("<!--[-1-->");
			$$renderer.push(`${escape_html(truncate(post.text.replace(/<[^>]*>?/gm, ""), 80))}...`);
		}
		$$renderer.push(`<!--]--></div> <div class="d-flex align-items-center justify-content-between">`);
		if (detail) {
			$$renderer.push("<!--[0-->");
			if (typeof themeSettings.postViewCountEnabled === "undefined" ? true : themeSettings.postViewCountEnabled) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<div class="text-muted small d-flex align-items-center"><i class="fas fa-eye me-2"></i> ${escape_html(post.views)}</div>`);
			} else {
				$$renderer.push("<!--[-1-->");
				$$renderer.push(`<div></div>`);
			}
			$$renderer.push(`<!--]--> <div class="d-flex align-items-center gap-2">`);
			Date_1($$renderer, {
				time: post.date,
				class: "text-muted small"
			});
			$$renderer.push(`<!----> <a${attr("href", `/player/${stringify(post.writer.username)}`)} class="d-inline-block rounded focus-ring rounded-circle"${attr("hidden", typeof themeSettings.postAuthorImageEnabled === "undefined" ? false : !themeSettings.postAuthorImageEnabled)}><img${attr("src", `/api/profile/picture/${stringify(post.writer.username)}?${stringify(store_get($$store_subs ??= {}, "$avatarVersion", avatarVersion))}`)}${attr("alt", post.writer.username)} width="32" height="32" class="rounded-circle border" onload="this.__e=event" onerror="this.__e=event"/></a></div>`);
		} else {
			$$renderer.push("<!--[-1-->");
			if (post.category.title !== "-") {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<a class="badge category-badge text-decoration-none rounded-pill focus-ring z-2"${attr("href", `/?category=${stringify(post.category.url)}`)}>${escape_html(post.category.title)}</a>`);
			} else {
				$$renderer.push("<!--[-1-->");
				$$renderer.push(`<div></div>`);
			}
			$$renderer.push(`<!--]--> <div class="d-flex align-items-center gap-2 z-2">`);
			Date_1($$renderer, {
				time: post.date,
				class: "small"
			});
			$$renderer.push(`<!----> <a class="d-inline-block rounded focus-ring rounded-circle"${attr("href", `/player/${stringify(post.writer.username)}`)}${attr("hidden", typeof themeSettings.postAuthorImageEnabled === "undefined" ? false : !themeSettings.postAuthorImageEnabled)}><img${attr("src", `/api/profile/picture/${stringify(post.writer.username)}?${stringify(store_get($$store_subs ??= {}, "$avatarVersion", avatarVersion))}`)}${attr("alt", post.writer.username)} width="28" height="28" class="rounded-circle border border-2 border-white" onload="this.__e=event" onerror="this.__e=event"/></a></div>`);
		}
		$$renderer.push(`<!--]--></div></div></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
		bind_props($$props, {
			post,
			detail
		});
	});
}
//#endregion
//#region node_modules/@panomc/theme-core/src/lib/components/Posts.svelte
function Posts($$renderer, $$props) {
	let posts = $$props["posts"];
	$$renderer.push(`<div class="row g-3">`);
	const each_array = ensure_array_like(posts);
	if (each_array.length !== 0) {
		$$renderer.push("<!--[-->");
		for (let index = 0, $$length = each_array.length; index < $$length; index++) {
			let post = each_array[index];
			$$renderer.push(`<div class="col-md-6">`);
			Post($$renderer, { post });
			$$renderer.push(`<!----></div>`);
		}
	} else {
		$$renderer.push("<!--[!-->");
		$$renderer.push(`<div class="col-12">`);
		NoContent($$renderer, {});
		$$renderer.push(`<!----></div>`);
	}
	$$renderer.push(`<!--]--></div>`);
	bind_props($$props, { posts });
}
//#endregion
//#region node_modules/@panomc/theme-core/src/lib/views/HomeView.svelte
function HomeView($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let data = $$props["data"];
		let themeSettings = $$props["themeSettings"];
		let onPageClick = $$props["onPageClick"];
		if (data.categoryUrl) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<div class="row justify-content-between mb-3"><div class="col-auto"><h4>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.category-posts.title", { values: {
				categoryTitle: data.category.title,
				postCount: data.postCount
			} }))}</h4></div> <div class="col-auto"><a href="/"><i class="fas fa-arrow-left me-2"></i> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.category-posts.posts"))}</a></div></div>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--> <div class="vstack gap-3">`);
		if (!data.categoryUrl) {
			$$renderer.push("<!--[0-->");
			Hook($$renderer, { name: "page:home:top" });
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--> `);
		if (typeof themeSettings.postsEnabled === "undefined" ? true : themeSettings.postsEnabled) {
			$$renderer.push("<!--[0-->");
			Posts($$renderer, { posts: data.posts });
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]-->  `);
		if ((typeof themeSettings.postsEnabled === "undefined" ? true : themeSettings.postsEnabled) && data.postCount > 0) {
			$$renderer.push("<!--[0-->");
			Pagination($$renderer, {
				page: data.page,
				totalPage: data.totalPage});
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
		bind_props($$props, {
			data,
			themeSettings,
			onPageClick
		});
	});
}

export { HomeView as default };
//# sourceMappingURL=HomeView.js-CsfC5vs-.js.map
