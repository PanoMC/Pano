import { a as getAllContexts, $ as ensure_array_like, a0 as store_get, ac as element, a1 as spread_props, a2 as unsubscribe_stores, M as derived, ad as attributes, Y as stringify } from './server.js-D28cBEJ-.js';
import 'node:module';
import { p as page } from './stores.js-QbD2A2ib.js';
import { p as panoApiClient } from './PluginManager.js-B5x3OKEW.js';
import { h as hasPermission } from './auth.util.js-BGCV_dhB.js';

//#region node_modules/@panomc/theme-core/src/lib/components/Hook.svelte
function Hook($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let { name, tag = "div", $$slots, $$events, ...rest } = $$props;
		const hookStore = derived(() => panoApiClient.ui.hook.get(name));
		const filteredHooks = derived(() => store_get($$store_subs ??= {}, "$hookStore", hookStore()) || []);
		let resolvedHooks = [];
		const hookList = derived(() => resolvedHooks.length > 0 ? resolvedHooks.map((h) => h.component || h) : filteredHooks().map((h) => h.component || h));
		getAllContexts();
		const hookProps = derived(() => store_get($$store_subs ??= {}, "$page", page).data.hookProps?.[name] || []);
		$$renderer.push(`<!--[-->`);
		const each_array = ensure_array_like(hookList());
		for (let i = 0, $$length = each_array.length; i < $$length; i++) {
			let module = each_array[i];
			const props = hookProps()[i] || {};
			const hasPerm = !filteredHooks()[i]?.permission || hasPermission(filteredHooks()[i]?.permission, store_get($$store_subs ??= {}, "$page", page).data.user);
			if (module && hasPerm && typeof module !== "function") {
				$$renderer.push("<!--[0-->");
				const Component = module.default || module;
				if (!(props.hookOptions?.invisible || filteredHooks()[i]?.invisible)) {
					$$renderer.push("<!--[0-->");
					element($$renderer, tag, () => {
						$$renderer.push(`${attributes({
							class: `hook-view-container ${stringify(rest.class || "")}`,
							style: `${stringify(tag === "div" ? "display: contents;" : "")} ${stringify(rest.style || "")}`,
							hookname: name,
							...props,
							...rest
						})}`);
					});
					$$renderer.push(` `);
					if (Component) {
						$$renderer.push("<!--[-->");
						Component($$renderer, spread_props([
							{ hookName: name },
							props,
							rest
						]));
						$$renderer.push("<!--]-->");
					} else {
						$$renderer.push("<!--[!-->");
						$$renderer.push("<!--]-->");
					}
				} else $$renderer.push("<!--[-1-->");
				$$renderer.push(`<!--]-->`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]-->`);
		}
		$$renderer.push(`<!--]-->`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
	});
}

export { Hook as H };
//# sourceMappingURL=Hook.js-DEYNBNbZ.js.map
