import { e as error } from './exports2.js-DxZfja4I.js';
import { b as base } from './internal.js-BlXt2rfE.js';
import { a as getAllContexts, a8 as attr_style, _ as slot } from './server.js-D28cBEJ-.js';
import 'node:module';
import './client.js-CPEkJ2-P.js';
import { f as findMatch, r as registeredPages } from './PluginManager.js-B5x3OKEW.js';
import { A as AppLayout_exports } from './AppLayout.js-DAJIOVN_.js';
import { h as hasPermission } from './auth.util.js-BGCV_dhB.js';
import { M as MainLayout_exports } from './MainLayout.js-D6bbLTwz.js';
import { A as AuthLayout_exports } from './AuthLayout.js-CZsvwKoS.js';
import { P as ProfileLayout_exports } from './ProfileLayout.js-B2Aj3-w1.js';
import { T as ThemeSettingsLayout_exports } from './ThemeSettingsLayout.js-C5M-p3G5.js';
import { T as TicketsLayout_exports } from './TicketsLayout.js-OiCrCQml.js';

//#region node_modules/@panomc/theme-core/src/routes/plugin-ui/Layout.svelte
var layoutMap = {
	AppLayout: AppLayout_exports,
	AuthLayout: AuthLayout_exports,
	MainLayout: MainLayout_exports,
	ProfileLayout: ProfileLayout_exports,
	ThemeSettingsLayout: ThemeSettingsLayout_exports,
	TicketsLayout: TicketsLayout_exports
};
function removePrefix(str, prefix) {
	return str.startsWith(prefix) ? str.slice(prefix.length) : str;
}
/**
* @type {import("@sveltejs/kit").PageLoad}
*/
async function load(event) {
	const { url: { pathname }, parent } = event;
	const { session: { user } } = await parent();
	const registeredPage = findMatch(registeredPages, removePrefix(pathname, base));
	if (registeredPage === void 0 || registeredPage === null) throw error(404);
	if (registeredPage.permission && !hasPermission(registeredPage.permission, user)) throw error(404);
	const resetLayout = registeredPage.resetLayout || false;
	let systemLayout = null;
	let systemLayoutOutput = {};
	if (registeredPage.systemLayout) {
		const systemLayoutModule = layoutMap[registeredPage.systemLayout];
		if (systemLayoutModule) {
			systemLayout = systemLayoutModule.default;
			if (typeof systemLayoutModule.load === "function") systemLayoutOutput = await systemLayoutModule.load(event);
		}
	}
	let layoutOutput = {};
	let layout = null;
	if (registeredPage.layout) {
		layout = typeof registeredPage.layout === "function" ? await registeredPage.layout() : registeredPage.layout;
		if (layout.load !== void 0) layoutOutput = await layout.load(event);
	}
	const output = {
		registeredPage,
		layout,
		systemLayout,
		props: layoutOutput,
		params: registeredPage.params,
		...systemLayoutOutput,
		resetLayout
	};
	if (layoutOutput && typeof layoutOutput === "object") {
		for (const key of [
			"pageTitle",
			"breadcrumbs",
			"sidebar",
			"sidebarProps"
		]) if (layoutOutput[key] !== void 0) output[key] = layoutOutput[key];
	}
	return output;
}
function Layout($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		let { data } = $$props;
		getAllContexts();
		if (data.systemLayout) {
			$$renderer.push("<!--[0-->");
			if (data.systemLayout) {
				$$renderer.push("<!--[-->");
				data.systemLayout($$renderer, {
					data,
					children: ($$renderer) => {
						$$renderer.push(`<div class="plugin-layout-container svelte-1osptfl"${attr_style(data.layout ? "" : "display: none;")}></div> <div class="plugin-content-wrapper"${attr_style(data.layout ? "display: none;" : "")}><!---->`);
						$$renderer.push(`<!--[-->`);
						slot($$renderer, $$props, "default", {}, null);
						$$renderer.push(`<!--]-->`);
						$$renderer.push(`<!----></div>`);
					},
					$$slots: { default: true }
				});
				$$renderer.push("<!--]-->");
			} else {
				$$renderer.push("<!--[!-->");
				$$renderer.push("<!--]-->");
			}
		} else {
			$$renderer.push("<!--[-1-->");
			$$renderer.push(`<div class="plugin-layout-container svelte-1osptfl"${attr_style(data.layout ? "" : "display: none;")}></div> <div class="plugin-content-wrapper"${attr_style(data.layout ? "display: none;" : "")}><!---->`);
			$$renderer.push(`<!--[-->`);
			slot($$renderer, $$props, "default", {}, null);
			$$renderer.push(`<!--]-->`);
			$$renderer.push(`<!----></div>`);
		}
		$$renderer.push(`<!--]-->`);
	});
}

export { Layout as L, load as l };
//# sourceMappingURL=Layout.js-BQtxiVwm.js.map
