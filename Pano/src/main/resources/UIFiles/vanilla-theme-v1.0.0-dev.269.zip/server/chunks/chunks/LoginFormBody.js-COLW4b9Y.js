import { V as fallback, X as attr, a5 as escape_html, a0 as store_get, $ as ensure_array_like, _ as slot, Z as attr_class, a2 as unsubscribe_stores, W as bind_props } from './server.js-D28cBEJ-.js';
import { $ as $format } from './runtime.js-CJgfVvxa.js';
import { p as panoApiClient } from './PluginManager.js-B5x3OKEW.js';
import { V as ViewComponent } from './ViewComponent.js-C6amYVVM.js';
import './uneval.js-BL1Qg77w.js';
import './rolldown-runtime.js-B5FuG9Gw.js';
import 'node:module';
import './exports2.js-DxZfja4I.js';
import './shared.js-3i5_hmQ1.js';
import './internal.js-BlXt2rfE.js';
import './client.js-CPEkJ2-P.js';
import './exports.js-CKkpMUqI.js';
import './internal2.js-KmQU-gaY.js';
import './index-server2.js-DlblWyyK.js';
import './Store.js-C2vdyE6V.js';
import './ToastContainer.js-CtmBBvhr.js';
import 'fs';

//#region node_modules/@panomc/theme-core/src/lib/components/LoginFormBody.svelte
function LoginFormBody($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let usernameOrEmail = fallback($$props["usernameOrEmail"], "");
		let password = fallback($$props["password"], "");
		let loading = fallback($$props["loading"], false);
		let usernameDisabled = fallback($$props["usernameDisabled"], false);
		let submitLabel = fallback($$props["submitLabel"], null);
		const contentItems = panoApiClient.ui.auth.login.content.get();
		$$renderer.push(`<div class="form-group"><div class="form-floating"><input${attr("value", usernameOrEmail)} class="form-control rounded-bottom-0 svelte-1jch2d1" id="lfb-usernameOrEmail"${attr("disabled", loading || usernameDisabled, true)} type="text"/> <label for="lfb-usernameOrEmail">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.login.inputs.username-email"))}</label></div> <div class="form-floating"><input${attr("value", password)} class="form-control rounded-top-0 svelte-1jch2d1" id="lfb-password"${attr("disabled", loading, true)} type="password"/> <label for="lfb-password">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.login.inputs.password"))}</label></div></div> <!--[-->`);
		const each_array = ensure_array_like(store_get($$store_subs ??= {}, "$contentItems", contentItems));
		for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
			let item = each_array[$$index];
			if (item.id !== "login-form" && item.component && (item.priority || 0) < 100) {
				$$renderer.push("<!--[0-->");
				ViewComponent($$renderer, {
					component: item.component,
					data: { pageType: "login" }
				});
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]-->`);
		}
		$$renderer.push(`<!--]--> <!--[-->`);
		slot($$renderer, $$props, "beforeSubmit", {}, null);
		$$renderer.push(`<!--]--> <div class="vstack gap-2"><button${attr_class("btn btn-lg btn-secondary", void 0, { "disabled": loading || !usernameOrEmail || !password })}${attr("disabled", loading || !usernameOrEmail || !password, true)} type="submit">`);
		if (loading) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<span class="spinner-border spinner-border-sm me-2" role="status" aria-label="Loading"></span> <span>${escape_html(submitLabel || store_get($$store_subs ??= {}, "$_", $format)("buttons.login"))}...</span>`);
		} else {
			$$renderer.push("<!--[-1-->");
			$$renderer.push(`${escape_html(submitLabel || store_get($$store_subs ??= {}, "$_", $format)("buttons.login"))}`);
		}
		$$renderer.push(`<!--]--></button> <!--[-->`);
		slot($$renderer, $$props, "footer", {}, null);
		$$renderer.push(`<!--]--></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
		bind_props($$props, {
			usernameOrEmail,
			password,
			loading,
			usernameDisabled,
			submitLabel
		});
	});
}

export { LoginFormBody as default };
//# sourceMappingURL=LoginFormBody.js-COLW4b9Y.js.map
