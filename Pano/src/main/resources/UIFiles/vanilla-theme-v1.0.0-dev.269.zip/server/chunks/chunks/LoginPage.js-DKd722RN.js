import { a9 as store_set, g as getContext, a0 as store_get, a2 as unsubscribe_stores, W as bind_props, T as writable } from './server.js-D28cBEJ-.js';
import 'node:module';
import { a as afterNavigate, g as goto } from './client.js-CPEkJ2-P.js';
import { h as panoApiServer, e as executeLifecycle, b as executeViewLoad, p as panoApiClient } from './PluginManager.js-B5x3OKEW.js';
import { r as resolveView } from './registry2.js-BubD3cPq.js';
import { o as sendRegister, N as NETWORK_ERROR, p as getCredentials, q as sendLogin, v as verifyLinkCode } from './Store.js-C2vdyE6V.js';
import { s as showSuccess } from './ToastContainer.js-CtmBBvhr.js';
import { c as currentLanguage } from './language.util.js-C2xYQq5-.js';
import { l as locale_exports } from './locale.js-DnnPB87K.js';
import { f as format } from './format.js-CzDFIcjs.js';
import { s as stripIdentifierWhitespace } from './loginInput.util.js-BxkO11lZ.js';

//#region node_modules/@panomc/theme-core/src/lib/pages/LoginPage.svelte
async function load(event) {
	const viewPromise = resolveView("LoginView", () => import('./LoginView.js-ByTehmc8.js'));
	const { parent } = event;
	await parent();
	panoApiServer.ui.auth.login.content.edit((items) => {
		items.push({
			id: "login-form",
			priority: 100,
			hidden: false
		});
	});
	const lifecycleData = {
		error: null,
		event
	};
	await executeLifecycle("theme:login:load", lifecycleData, event);
	await executeViewLoad("login-content", event);
	await executeViewLoad("login-alt-methods", event);
	return {
		initialError: lifecycleData.error || null,
		pageTitle: "components.modals.login.title",
		View: await viewPromise
	};
}
function LoginPage($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let data = $$props["data"];
		const viewState = writable("LOGIN");
		const usernameOrEmail = writable("");
		const password = writable("");
		const loading = writable();
		const error = writable();
		if (data?.initialError) store_set(error, data.initialError);
		let _skipFirstNav = !!data?.initialError;
		const passwordVisible = writable(false);
		const linkCode = writable("");
		const email = writable("");
		const passwordRepeat = writable("");
		const agreement = writable(false);
		let registerToken = "";
		const autoVerifyDone = writable(false);
		const emailRequired = writable(false);
		const emailVerificationSent = writable(false);
		const newUsername = writable("");
		const usernameRequiredUserId = writable(null);
		const session = getContext("session");
		function onUsernameOrEmailFieldInput() {
			const c = stripIdentifierWhitespace(store_get($$store_subs ??= {}, "$usernameOrEmail", usernameOrEmail));
			if (c !== store_get($$store_subs ??= {}, "$usernameOrEmail", usernameOrEmail)) store_set(usernameOrEmail, c);
			if (!store_get($$store_subs ??= {}, "$emailRequired", emailRequired) && !(store_get($$store_subs ??= {}, "$session", session)?.siteInfo?.isDemo && store_get($$store_subs ??= {}, "$usernameOrEmail", usernameOrEmail) === "demo")) {
				store_set(passwordVisible, false);
				store_set(password, "");
			}
			store_set(error, null);
		}
		function onRegisterEmailFieldInput() {
			const c = stripIdentifierWhitespace(store_get($$store_subs ??= {}, "$email", email));
			if (c !== store_get($$store_subs ??= {}, "$email", email)) store_set(email, c);
			store_set(error, null);
		}
		function onNewUsernameFieldInput() {
			const c = stripIdentifierWhitespace(store_get($$store_subs ??= {}, "$newUsername", newUsername));
			if (c !== store_get($$store_subs ??= {}, "$newUsername", newUsername)) store_set(newUsername, c);
			store_set(error, null);
		}
		afterNavigate(() => {
			if (_skipFirstNav) {
				_skipFirstNav = false;
				return;
			}
			store_set(viewState, "LOGIN");
			store_set(error, null);
			store_set(autoVerifyDone, false);
			store_set(linkCode, "");
			store_set(passwordVisible, false);
			store_set(emailRequired, false);
			store_set(email, "");
			store_set(emailVerificationSent, false);
			store_set(password, "");
			store_set(newUsername, "");
			store_set(usernameRequiredUserId, null);
		});
		async function onVerifyLink() {
			if (store_get($$store_subs ??= {}, "$linkCode", linkCode).length !== 6) return;
			store_set(loading, true);
			store_set(error, null);
			store_set(autoVerifyDone, true);
			try {
				const body = await verifyLinkCode(store_get($$store_subs ??= {}, "$usernameOrEmail", usernameOrEmail), store_get($$store_subs ??= {}, "$linkCode", linkCode));
				if (body.result === "ok") {
					registerToken = body.token;
					if (body.username) store_set(usernameOrEmail, body.username);
					store_set(viewState, "REGISTER");
				} else if (body.error === "PLUGIN_DENIED_LOGIN" && body.reason) store_set(error, body.reason);
				else store_set(error, body.result === "error" ? body.error : NETWORK_ERROR);
			} catch (err) {
				console.error(err);
				store_set(error, NETWORK_ERROR);
			} finally {
				store_set(loading, false);
			}
		}
		async function onCompleteRegister() {
			store_set(loading, true);
			store_set(error, null);
			try {
				const body = await sendRegister({
					registerWithLinkToken: registerToken,
					email: store_get($$store_subs ??= {}, "$email", email),
					password: store_get($$store_subs ??= {}, "$password", password),
					passwordRepeat: store_get($$store_subs ??= {}, "$passwordRepeat", passwordRepeat),
					agreement: store_get($$store_subs ??= {}, "$agreement", agreement)
				});
				if (body.result !== "ok") {
					if (body.error === "INVALID_TOKEN") {
						store_set(viewState, "LOGIN");
						store_set(error, null);
						store_set(autoVerifyDone, false);
						store_set(linkCode, "");
						store_set(loading, false);
						return;
					}
					store_set(error, body.result === "error" ? body.error : NETWORK_ERROR);
					store_set(loading, false);
					return;
				}
				if (body.login) {
					const csrfToken = body.csrfToken;
					const credsBody = await getCredentials(csrfToken);
					session.update((data) => {
						data.user = { ...Object.keys(credsBody).filter((key) => !["result"].includes(key)).reduce((object, key) => {
							object[key] = credsBody[key];
							return object;
						}, {}) };
						data.csrfToken = csrfToken;
						return data;
					});
					await showSuccess("successes.LOGIN_SUCCESSFUL");
					await goto("/");
					return;
				}
				if (body.emailVerificationRequired) {
					store_set(viewState, "LOGIN");
					registerToken = "";
					store_set(linkCode, "");
					store_set(password, "");
					store_set(passwordRepeat, "");
					store_set(error, {
						key: "LOGIN_EMAIL_NOT_VERIFIED",
						props: { email: body.email ?? store_get($$store_subs ??= {}, "$email", email) }
					});
					return;
				}
				await showSuccess("successes.REGISTER_SUCCESSFUL");
				const loginBody = await sendLogin({
					usernameOrEmail: store_get($$store_subs ??= {}, "$usernameOrEmail", usernameOrEmail),
					password: store_get($$store_subs ??= {}, "$password", password)
				});
				if (loginBody.result !== "ok") {
					store_set(error, loginBody.error);
					store_set(loading, false);
					return;
				}
				const csrfToken = loginBody.csrfToken;
				const credsBody = await getCredentials(csrfToken);
				session.update((data) => {
					data.user = { ...Object.keys(credsBody).filter((key) => !["result"].includes(key)).reduce((object, key) => {
						object[key] = credsBody[key];
						return object;
					}, {}) };
					data.csrfToken = csrfToken;
					return data;
				});
				await goto("/");
			} catch (err) {
				console.error(err);
				store_set(error, NETWORK_ERROR);
			} finally {
				store_set(loading, false);
			}
		}
		async function onSubmit() {
			store_set(error, null);
			store_set(loading, true);
			await sendLogin({
				usernameOrEmail: store_get($$store_subs ??= {}, "$usernameOrEmail", usernameOrEmail),
				password: store_get($$store_subs ??= {}, "$password", password),
				registerEmail: store_get($$store_subs ??= {}, "$emailRequired", emailRequired) ? store_get($$store_subs ??= {}, "$email", email) : void 0,
				newUsername: store_get($$store_subs ??= {}, "$viewState", viewState) === "SET_USERNAME" ? store_get($$store_subs ??= {}, "$newUsername", newUsername) : void 0
			}).then(async (body) => {
				if (body.result !== "ok") {
					store_set(loading, false);
					if (body.error === "LINK_CODE_REQUIRED") {
						store_set(viewState, "LINK_CODE");
						store_set(passwordVisible, false);
						store_set(password, "");
						store_set(error, null);
						return;
					}
					if (body.error === "LOGIN_EMAIL_NOT_VERIFIED") {
						if (store_get($$store_subs ??= {}, "$emailRequired", emailRequired)) {
							store_set(emailVerificationSent, true);
							store_set(error, null);
							return;
						}
						store_set(error, {
							key: "LOGIN_EMAIL_NOT_VERIFIED",
							props: { email: body.email }
						});
						return;
					}
					if (body.error === "REGISTER_EMAIL_REQUIRED") {
						store_set(emailRequired, true);
						store_set(passwordVisible, true);
						if (store_get($$store_subs ??= {}, "$session", session)?.siteInfo?.isDemo && store_get($$store_subs ??= {}, "$usernameOrEmail", usernameOrEmail) === "demo") store_set(password, "123456");
						store_set(error, null);
						setTimeout(() => document.getElementById("email")?.focus(), 50);
						return;
					}
					if (body.error === "USERNAME_REQUIRED") {
						store_set(usernameRequiredUserId, body.userId);
						store_set(viewState, "SET_USERNAME");
						store_set(error, null);
						setTimeout(() => document.getElementById("newUsername")?.focus(), 50);
						return;
					}
					if (body.error === "LOGIN_IS_INVALID" && !store_get($$store_subs ??= {}, "$passwordVisible", passwordVisible)) {
						store_set(passwordVisible, true);
						if (store_get($$store_subs ??= {}, "$session", session)?.siteInfo?.isDemo && store_get($$store_subs ??= {}, "$usernameOrEmail", usernameOrEmail) === "demo") store_set(password, "123456");
						store_set(error, null);
						setTimeout(() => document.getElementById("password")?.focus(), 50);
						return;
					}
					if (body.error === "PLUGIN_DENIED_LOGIN" && body.reason) {
						store_set(error, body.reason);
						return;
					}
					store_set(error, body.result === "error" ? body.error : NETWORK_ERROR);
					if (body.result === "error" && body.error === "LOGIN_USER_IS_BANNED") if (!body.until) {
						store_set(error, { key: "LOGIN_USER_IS_BANNED_PERMANENTLY" });
						if (body.reason) store_set(error, {
							key: "LOGIN_USER_IS_BANNED_PERMANENTLY_WITH_REASON",
							props: { reason: `'${body.reason}'` }
						});
					} else {
						const formattedUntil = format(new Date(body.until), "dd/MM/yyyy HH:mm", { locale: locale_exports[store_get($$store_subs ??= {}, "$currentLanguage", currentLanguage).dateFnsCode] });
						store_set(error, {
							key: "LOGIN_USER_IS_BANNED_TEMPORARY",
							props: { untilTime: formattedUntil }
						});
						if (body.reason) store_set(error, {
							key: "LOGIN_USER_IS_BANNED_TEMPORARY_WITH_REASON",
							props: {
								reason: `'${body.reason}'`,
								untilTime: formattedUntil
							}
						});
					}
					return;
				}
				const csrfToken = body.csrfToken;
				await getCredentials(csrfToken).then(async (body) => {
					session.update((data) => {
						data.user = { ...Object.keys(body).filter((key) => !["result"].includes(key)).reduce((object, key) => {
							object[key] = body[key];
							return object;
						}, {}) };
						data.csrfToken = csrfToken;
						return data;
					});
					await showSuccess("successes.LOGIN_SUCCESSFUL");
					await goto();
					store_set(loading, false);
				});
			}).catch((err) => {
				console.log(err);
				store_set(loading, false);
			});
		}
		const pageTitle = getContext("pageTitle");
		const contentItems = panoApiClient.ui.auth.login.content.get();
		const altMethods = panoApiClient.ui.auth.login.alternativeMethods.get();
		if (store_get($$store_subs ??= {}, "$session", session)?.siteInfo?.isDemo && store_get($$store_subs ??= {}, "$usernameOrEmail", usernameOrEmail) === "demo") {
			store_set(password, "123456");
			store_set(passwordVisible, true);
		}
		if (store_get($$store_subs ??= {}, "$viewState", viewState) === "LOGIN") store_set(pageTitle, "components.modals.login.title");
		else if (store_get($$store_subs ??= {}, "$viewState", viewState) === "LINK_CODE") store_set(pageTitle, "components.modals.login.link-code.title");
		else if (store_get($$store_subs ??= {}, "$viewState", viewState) === "REGISTER") store_set(pageTitle, "components.modals.login.register-with-link.title");
		if (data.View) {
			$$renderer.push("<!--[-->");
			data.View($$renderer, {
				data,
				session,
				contentItems,
				altMethods,
				viewState,
				usernameOrEmail,
				password,
				email,
				passwordRepeat,
				agreement,
				newUsername,
				linkCode,
				loading,
				error,
				passwordVisible,
				emailRequired,
				emailVerificationSent,
				autoVerifyDone,
				usernameRequiredUserId,
				onSubmit,
				onVerifyLink,
				onCompleteRegister,
				onUsernameOrEmailFieldInput,
				onRegisterEmailFieldInput,
				onNewUsernameFieldInput
			});
			$$renderer.push("<!--]-->");
		} else {
			$$renderer.push("<!--[!-->");
			$$renderer.push("<!--]-->");
		}
		if ($$store_subs) unsubscribe_stores($$store_subs);
		bind_props($$props, { data });
	});
}

export { LoginPage as L, load as l };
//# sourceMappingURL=LoginPage.js-DKd722RN.js.map
