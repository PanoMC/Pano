import { W as bind_props, $ as ensure_array_like, a0 as store_get, a5 as escape_html, X as attr, Z as attr_class, Y as stringify, a3 as html, a9 as store_set, V as fallback, a2 as unsubscribe_stores } from './server.js-D28cBEJ-.js';
import 'node:module';
import { $ as $format } from './runtime.js-CJgfVvxa.js';
import { P as PageTitle } from './PageTitle.js-D99NSXzQ.js';
import { V as ViewComponent } from './ViewComponent.js-C6amYVVM.js';
import { E as ErrorAlert } from './ErrorAlert.js-DbwaZ_OB.js';
import { R as RegisterForm } from './RegisterForm.js-DuIBDPut.js';
import './uneval.js-BL1Qg77w.js';
import './rolldown-runtime.js-B5FuG9Gw.js';

//#region node_modules/@panomc/theme-core/src/lib/components/LinkCodeInput.svelte
function LinkCodeInput($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		let length = fallback($$props["length"], 6);
		let disabled = fallback($$props["disabled"], false);
		let isInvalid = fallback($$props["isInvalid"], false);
		let values = Array(length).fill("");
		$$renderer.push(`<div class="d-flex gap-2 justify-content-center"><!--[-->`);
		const each_array = ensure_array_like(values);
		for (let index = 0, $$length = each_array.length; index < $$length; index++) {
			each_array[index];
			$$renderer.push(`<input${attr_class(`form-control text-center p-0 fs-4 ${stringify(isInvalid ? "border-danger" : "")}`)}${attr("disabled", disabled, true)} inputmode="numeric" style="width: 3rem; height: 3.5rem;" type="text"${attr("value", values[index])}/>`);
		}
		$$renderer.push(`<!--]--></div>`);
		bind_props($$props, {
			length,
			disabled,
			isInvalid
		});
	});
}
//#endregion
//#region node_modules/@panomc/theme-core/src/lib/views/LoginView.svelte
function LoginView($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let data = $$props["data"];
		let session = $$props["session"];
		let contentItems = $$props["contentItems"];
		let altMethods = $$props["altMethods"];
		let viewState = $$props["viewState"];
		let usernameOrEmail = $$props["usernameOrEmail"];
		let password = $$props["password"];
		let email = $$props["email"];
		let passwordRepeat = $$props["passwordRepeat"];
		let agreement = $$props["agreement"];
		let newUsername = $$props["newUsername"];
		let linkCode = $$props["linkCode"];
		let loading = $$props["loading"];
		let error = $$props["error"];
		let passwordVisible = $$props["passwordVisible"];
		let emailRequired = $$props["emailRequired"];
		let emailVerificationSent = $$props["emailVerificationSent"];
		let autoVerifyDone = $$props["autoVerifyDone"];
		let usernameRequiredUserId = $$props["usernameRequiredUserId"];
		let onSubmit = $$props["onSubmit"];
		let onVerifyLink = $$props["onVerifyLink"];
		let onCompleteRegister = $$props["onCompleteRegister"];
		let onUsernameOrEmailFieldInput = $$props["onUsernameOrEmailFieldInput"];
		let onRegisterEmailFieldInput = $$props["onRegisterEmailFieldInput"];
		let onNewUsernameFieldInput = $$props["onNewUsernameFieldInput"];
		let $$settled = true;
		let $$inner_renderer;
		function $$render_inner($$renderer) {
			$$renderer.push(`<!--[-->`);
			const each_array = ensure_array_like(store_get($$store_subs ??= {}, "$contentItems", contentItems));
			for (let $$index_2 = 0, $$length = each_array.length; $$index_2 < $$length; $$index_2++) {
				let item = each_array[$$index_2];
				if (item.id === "login-form") {
					$$renderer.push("<!--[0-->");
					if (store_get($$store_subs ??= {}, "$viewState", viewState) === "LOGIN") {
						$$renderer.push("<!--[0-->");
						$$renderer.push(`<form><div class="vstack gap-3">`);
						if (store_get($$store_subs ??= {}, "$session", session).siteInfo.isDemo) {
							$$renderer.push("<!--[0-->");
							$$renderer.push(`<div class="alert alert-info py-2" role="alert">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.login.demo-mode-alert"))}</div>`);
						} else $$renderer.push("<!--[-1-->");
						$$renderer.push(`<!--]--> `);
						if (store_get($$store_subs ??= {}, "$emailRequired", emailRequired) && !store_get($$store_subs ??= {}, "$emailVerificationSent", emailVerificationSent)) {
							$$renderer.push("<!--[0-->");
							$$renderer.push(`<div class="alert alert-info py-2" role="alert">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.login.register-email-required-info"))}</div>`);
						} else $$renderer.push("<!--[-1-->");
						$$renderer.push(`<!--]--> `);
						ErrorAlert($$renderer, { error: store_get($$store_subs ??= {}, "$error", error) });
						$$renderer.push(`<!----> `);
						if (!store_get($$store_subs ??= {}, "$emailVerificationSent", emailVerificationSent)) {
							$$renderer.push("<!--[0-->");
							$$renderer.push(`<div class="form-group"><div class="form-floating"><input${attr("value", store_get($$store_subs ??= {}, "$usernameOrEmail", usernameOrEmail))}${attr_class(`form-control ${stringify(store_get($$store_subs ??= {}, "$passwordVisible", passwordVisible) ? "rounded-bottom-0" : "rounded")}`, "svelte-g1eiyu")} id="usernameOrEmail"${attr("disabled", store_get($$store_subs ??= {}, "$loading", loading) || store_get($$store_subs ??= {}, "$emailRequired", emailRequired), true)} type="text"/> <label for="usernameOrEmail">${escape_html(store_get($$store_subs ??= {}, "$emailRequired", emailRequired) ? store_get($$store_subs ??= {}, "$_", $format)("components.modals.register.inputs.username") : store_get($$store_subs ??= {}, "$_", $format)("components.modals.login.inputs.username-email"))}</label></div> `);
							if (store_get($$store_subs ??= {}, "$passwordVisible", passwordVisible)) {
								$$renderer.push("<!--[0-->");
								$$renderer.push(`<div class="form-floating"><input${attr("value", store_get($$store_subs ??= {}, "$password", password))}${attr_class(`form-control rounded-0 ${stringify(store_get($$store_subs ??= {}, "$emailRequired", emailRequired) ? "" : "rounded-bottom")}`, "svelte-g1eiyu")} id="password"${attr("disabled", store_get($$store_subs ??= {}, "$loading", loading) || store_get($$store_subs ??= {}, "$emailRequired", emailRequired), true)} type="password"/> <label for="password">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.login.inputs.password"))}</label></div>`);
							} else $$renderer.push("<!--[-1-->");
							$$renderer.push(`<!--]--> `);
							if (store_get($$store_subs ??= {}, "$emailRequired", emailRequired)) {
								$$renderer.push("<!--[0-->");
								$$renderer.push(`<div class="form-floating"><input${attr("value", store_get($$store_subs ??= {}, "$email", email))}${attr_class(`form-control rounded-top-0 rounded-bottom ${stringify(store_get($$store_subs ??= {}, "$error", error) ? "border-danger" : "")}`, "svelte-g1eiyu")} id="email"${attr("disabled", store_get($$store_subs ??= {}, "$loading", loading), true)} type="email"/> <label for="email">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.register.inputs.email"))}</label></div>`);
							} else $$renderer.push("<!--[-1-->");
							$$renderer.push(`<!--]--></div> <!--[-->`);
							const each_array_1 = ensure_array_like(store_get($$store_subs ??= {}, "$contentItems", contentItems));
							for (let $$index = 0, $$length = each_array_1.length; $$index < $$length; $$index++) {
								let inlineItem = each_array_1[$$index];
								if (inlineItem.id !== "login-form" && inlineItem.component && (inlineItem.priority || 0) < 100) {
									$$renderer.push("<!--[0-->");
									ViewComponent($$renderer, {
										component: inlineItem.component,
										data: { pageType: "login" }
									});
								} else $$renderer.push("<!--[-1-->");
								$$renderer.push(`<!--]-->`);
							}
							$$renderer.push(`<!--]--> <div class="vstack gap-2"><button${attr_class("btn btn-lg btn-secondary", void 0, { "disabled": store_get($$store_subs ??= {}, "$loading", loading) || !store_get($$store_subs ??= {}, "$usernameOrEmail", usernameOrEmail) || store_get($$store_subs ??= {}, "$emailRequired", emailRequired) && !store_get($$store_subs ??= {}, "$email", email).includes("@") })}${attr("disabled", store_get($$store_subs ??= {}, "$loading", loading) || !store_get($$store_subs ??= {}, "$usernameOrEmail", usernameOrEmail) || store_get($$store_subs ??= {}, "$emailRequired", emailRequired) && !store_get($$store_subs ??= {}, "$email", email).includes("@"), true)} type="submit">`);
							if (store_get($$store_subs ??= {}, "$loading", loading)) {
								$$renderer.push("<!--[0-->");
								$$renderer.push(`<span class="spinner-border spinner-border-sm me-2" role="status" aria-label="Loading"></span> <span>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.login"))}...</span>`);
							} else {
								$$renderer.push("<!--[-1-->");
								$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.login"))}`);
							}
							$$renderer.push(`<!--]--></button> `);
							if (store_get($$store_subs ??= {}, "$passwordVisible", passwordVisible) && !store_get($$store_subs ??= {}, "$emailRequired", emailRequired)) {
								$$renderer.push("<!--[0-->");
								$$renderer.push(`<a${attr_class(`btn btn-link ${stringify(store_get($$store_subs ??= {}, "$loading", loading) ? "disabled pe-none" : "")}`)}${attr("aria-disabled", store_get($$store_subs ??= {}, "$loading", loading))}${attr("tabindex", store_get($$store_subs ??= {}, "$loading", loading) ? -1 : void 0)} href="/reset-password">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.forgot-password"))}</a>`);
							} else $$renderer.push("<!--[-1-->");
							$$renderer.push(`<!--]--></div>`);
						} else {
							$$renderer.push("<!--[-1-->");
							$$renderer.push(`<div class="alert alert-info py-2" role="alert">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.login.email-verification-sent-info"))}</div> <button class="btn btn-link" type="button">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.inputs.change-email.back"))}</button>`);
						}
						$$renderer.push(`<!--]--></div></form>`);
					} else if (store_get($$store_subs ??= {}, "$viewState", viewState) === "LINK_CODE") {
						$$renderer.push("<!--[1-->");
						$$renderer.push(`<form><div class="vstack gap-3"><p class="text-center text-muted mb-0">${html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.login.link-code.description"))}</p> `);
						ErrorAlert($$renderer, { error: store_get($$store_subs ??= {}, "$error", error) });
						$$renderer.push(`<!----> <div class="form-group"><div class="form-floating"><input${attr("value", store_get($$store_subs ??= {}, "$usernameOrEmail", usernameOrEmail))} class="form-control svelte-g1eiyu" id="usernameOrEmail"${attr("disabled", true, true)} type="text"/> <label for="usernameOrEmail">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.login.inputs.username-email"))}</label></div></div> <div class="my-2">`);
						LinkCodeInput($$renderer, {
							isInvalid: store_get($$store_subs ??= {}, "$error", error) === "REGISTER_LINK_CODE_INVALID",
							disabled: store_get($$store_subs ??= {}, "$loading", loading)
						});
						$$renderer.push(`<!----></div> <!--[-->`);
						const each_array_2 = ensure_array_like(store_get($$store_subs ??= {}, "$contentItems", contentItems));
						for (let $$index_1 = 0, $$length = each_array_2.length; $$index_1 < $$length; $$index_1++) {
							let inlineItem = each_array_2[$$index_1];
							if (inlineItem.id !== "login-form" && inlineItem.component && (inlineItem.priority || 0) < 100) {
								$$renderer.push("<!--[0-->");
								ViewComponent($$renderer, {
									component: inlineItem.component,
									data: { pageType: "login" }
								});
							} else $$renderer.push("<!--[-1-->");
							$$renderer.push(`<!--]-->`);
						}
						$$renderer.push(`<!--]--> <div class="vstack gap-2"><button${attr_class("btn btn-lg btn-secondary", void 0, { "disabled": store_get($$store_subs ??= {}, "$loading", loading) || store_get($$store_subs ??= {}, "$linkCode", linkCode).length !== 6 })}${attr("disabled", store_get($$store_subs ??= {}, "$loading", loading) || store_get($$store_subs ??= {}, "$linkCode", linkCode).length !== 6, true)} type="submit">`);
						if (store_get($$store_subs ??= {}, "$loading", loading)) {
							$$renderer.push("<!--[0-->");
							$$renderer.push(`<span class="spinner-border spinner-border-sm me-2" role="status" aria-label="Loading"></span> <span>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.login.link-code.verify"))}...</span>`);
						} else {
							$$renderer.push("<!--[-1-->");
							$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.login.link-code.verify"))}`);
						}
						$$renderer.push(`<!--]--></button> <button class="btn btn-link"${attr("disabled", store_get($$store_subs ??= {}, "$loading", loading), true)} type="button">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.inputs.change-email.back"))}</button></div></div></form>`);
					} else if (store_get($$store_subs ??= {}, "$viewState", viewState) === "REGISTER") {
						$$renderer.push("<!--[2-->");
						$$renderer.push(`<form><div class="vstack gap-3">`);
						ErrorAlert($$renderer, { error: store_get($$store_subs ??= {}, "$error", error) });
						$$renderer.push(`<!----> `);
						RegisterForm($$renderer, {
							loading: store_get($$store_subs ??= {}, "$loading", loading),
							usernameDisabled: true,
							get username() {
								return store_get($$store_subs ??= {}, "$usernameOrEmail", usernameOrEmail);
							},
							set username($$value) {
								store_set(usernameOrEmail, $$value);
								$$settled = false;
							},
							get email() {
								return store_get($$store_subs ??= {}, "$email", email);
							},
							set email($$value) {
								store_set(email, $$value);
								$$settled = false;
							},
							get password() {
								return store_get($$store_subs ??= {}, "$password", password);
							},
							set password($$value) {
								store_set(password, $$value);
								$$settled = false;
							},
							get passwordRepeat() {
								return store_get($$store_subs ??= {}, "$passwordRepeat", passwordRepeat);
							},
							set passwordRepeat($$value) {
								store_set(passwordRepeat, $$value);
								$$settled = false;
							},
							get agreement() {
								return store_get($$store_subs ??= {}, "$agreement", agreement);
							},
							set agreement($$value) {
								store_set(agreement, $$value);
								$$settled = false;
							}
						});
						$$renderer.push(`<!----></div></form>`);
					} else if (store_get($$store_subs ??= {}, "$viewState", viewState) === "SET_USERNAME") {
						$$renderer.push("<!--[3-->");
						$$renderer.push(`<form><div class="vstack gap-3">`);
						PageTitle($$renderer, { title: store_get($$store_subs ??= {}, "$_", $format)("pages.login.set-username-title") });
						$$renderer.push(`<!----> <p class="text-center text-muted mb-0">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.login.set-username-description"))}</p> `);
						ErrorAlert($$renderer, { error: store_get($$store_subs ??= {}, "$error", error) });
						$$renderer.push(`<!----> <div class="form-group"><div class="form-floating"><input${attr("value", store_get($$store_subs ??= {}, "$newUsername", newUsername))} class="form-control" id="newUsername"${attr("disabled", store_get($$store_subs ??= {}, "$loading", loading), true)} type="text" maxlength="16"/> <label for="newUsername">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.register.inputs.username"))}</label></div></div> <div class="vstack gap-2"><button${attr_class("btn btn-lg btn-secondary", void 0, { "disabled": store_get($$store_subs ??= {}, "$loading", loading) || !store_get($$store_subs ??= {}, "$newUsername", newUsername) || store_get($$store_subs ??= {}, "$newUsername", newUsername).length < 3 })}${attr("disabled", store_get($$store_subs ??= {}, "$loading", loading) || !store_get($$store_subs ??= {}, "$newUsername", newUsername) || store_get($$store_subs ??= {}, "$newUsername", newUsername).length < 3, true)} type="submit">`);
						if (store_get($$store_subs ??= {}, "$loading", loading)) {
							$$renderer.push("<!--[0-->");
							$$renderer.push(`<span class="spinner-border spinner-border-sm me-2" role="status" aria-label="Loading"></span> <span>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.save"))}...</span>`);
						} else {
							$$renderer.push("<!--[-1-->");
							$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.save"))}`);
						}
						$$renderer.push(`<!--]--></button> <button class="btn btn-link"${attr("disabled", store_get($$store_subs ??= {}, "$loading", loading), true)} type="button">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.inputs.change-email.back"))}</button></div></div></form>`);
					} else $$renderer.push("<!--[-1-->");
					$$renderer.push(`<!--]-->`);
				} else if (item.component && store_get($$store_subs ??= {}, "$viewState", viewState) !== "SET_USERNAME" && (item.priority || 0) >= 100) {
					$$renderer.push("<!--[1-->");
					ViewComponent($$renderer, {
						component: item.component,
						data: { pageType: "login" }
					});
				} else $$renderer.push("<!--[-1-->");
				$$renderer.push(`<!--]-->`);
			}
			$$renderer.push(`<!--]--> `);
			if (store_get($$store_subs ??= {}, "$viewState", viewState) !== "SET_USERNAME" && store_get($$store_subs ??= {}, "$altMethods", altMethods) && store_get($$store_subs ??= {}, "$altMethods", altMethods).length > 0) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<div class="alt-methods-divider svelte-g1eiyu"><span>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.login.or"))}</span></div> <div class="vstack gap-2"><!--[-->`);
				const each_array_3 = ensure_array_like(store_get($$store_subs ??= {}, "$altMethods", altMethods));
				for (let $$index_3 = 0, $$length = each_array_3.length; $$index_3 < $$length; $$index_3++) {
					let method = each_array_3[$$index_3];
					ViewComponent($$renderer, {
						component: method.component,
						data: { pageType: "login" }
					});
				}
				$$renderer.push(`<!--]--></div>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]-->`);
		}
		do {
			$$settled = true;
			$$inner_renderer = $$renderer.copy();
			$$render_inner($$inner_renderer);
		} while (!$$settled);
		$$renderer.subsume($$inner_renderer);
		if ($$store_subs) unsubscribe_stores($$store_subs);
		bind_props($$props, {
			data,
			session,
			contentItems,
			altMethods,
			viewState,
			usernameOrEmail,
			password,
			email,
			passwordRepeat,
			agreement,
			newUsername,
			linkCode,
			loading,
			error,
			passwordVisible,
			emailRequired,
			emailVerificationSent,
			autoVerifyDone,
			usernameRequiredUserId,
			onSubmit,
			onVerifyLink,
			onCompleteRegister,
			onUsernameOrEmailFieldInput,
			onRegisterEmailFieldInput,
			onNewUsernameFieldInput
		});
	});
}

export { LoginView as default };
//# sourceMappingURL=LoginView.js-ByTehmc8.js.map
