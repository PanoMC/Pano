import { _ as __exportAll } from './rolldown-runtime.js-B5FuG9Gw.js';
import { V as fallback, g as getContext, a0 as store_get, _ as slot, a2 as unsubscribe_stores, W as bind_props } from './server.js-D28cBEJ-.js';
import { p as page } from './stores.js-QbD2A2ib.js';
import { c as executeHookLoad } from './PluginManager.js-B5x3OKEW.js';
import { r as resolveView } from './registry2.js-BubD3cPq.js';

//#region node_modules/@panomc/theme-core/src/lib/ui-logics/layout-logics/MainLayoutLogics.js
async function processLoad(event) {
	const { parent } = event;
	await parent();
	const [themeTop, pageTop] = await Promise.all([executeHookLoad("theme:top", event), executeHookLoad("page:top", event)]);
	return { hookProps: {
		"theme:top": themeTop,
		"page:top": pageTop
	} };
}
//#endregion
//#region node_modules/@panomc/theme-core/src/lib/layouts/MainLayout.svelte
var MainLayout_exports = /* @__PURE__ */ __exportAll({
	default: () => MainLayout,
	load: () => load
});
async function load(event) {
	const viewPromise = resolveView("MainLayoutView", () => import('./MainLayoutView.js-CiqYA2Wm.js'));
	const data = await processLoad(event);
	const [View, NavbarC, HeaderC, FooterC] = await Promise.all([
		viewPromise,
		resolveView("Navbar", () => import('./Navbar.js-CdO1-02y.js')),
		resolveView("Header", () => import('./Header.js-wJFjPFIz.js')),
		resolveView("Footer", () => import('./Footer.js-mr8_pWqO.js'))
	]);
	return {
		...data,
		mainLayoutView: View,
		mainLayoutChrome: {
			Navbar: NavbarC,
			Header: HeaderC,
			Footer: FooterC
		}
	};
}
function MainLayout($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let View, viewData, chrome;
		let data = fallback($$props["data"], void 0);
		const themeSettings = getContext("themeSettings");
		const session = getContext("session");
		View = data?.mainLayoutView ?? store_get($$store_subs ??= {}, "$page", page).data.mainLayoutView;
		viewData = data ?? store_get($$store_subs ??= {}, "$page", page).data;
		chrome = viewData?.mainLayoutChrome ?? store_get($$store_subs ??= {}, "$page", page).data.mainLayoutChrome;
		if (View) {
			$$renderer.push("<!--[-->");
			View($$renderer, {
				data: viewData,
				themeSettings,
				session,
				chrome,
				children: ($$renderer) => {
					$$renderer.push(`<!--[-->`);
					slot($$renderer, $$props, "default", {}, null);
					$$renderer.push(`<!--]-->`);
				},
				$$slots: { default: true }
			});
			$$renderer.push("<!--]-->");
		} else {
			$$renderer.push("<!--[!-->");
			$$renderer.push("<!--]-->");
		}
		if ($$store_subs) unsubscribe_stores($$store_subs);
		bind_props($$props, { data });
	});
}

export { MainLayout_exports as M, MainLayout as a, load as l };
//# sourceMappingURL=MainLayout.js-D6bbLTwz.js.map
