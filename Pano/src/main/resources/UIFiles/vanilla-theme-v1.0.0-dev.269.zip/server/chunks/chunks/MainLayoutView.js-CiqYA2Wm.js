import { ab as head, Z as attr_class, Y as stringify, W as bind_props, g as getContext, a0 as store_get, $ as ensure_array_like, X as attr, a6 as clsx, a3 as html, a5 as escape_html, a2 as unsubscribe_stores, a1 as spread_props, _ as slot, T as writable } from './server.js-D28cBEJ-.js';
import { o as onDestroy } from './index-server2.js-DlblWyyK.js';
import { $ as $format } from './runtime.js-CJgfVvxa.js';
import { c as avatarVersion } from './Store.js-C2vdyE6V.js';
import { c as currentLanguage } from './language.util.js-C2xYQq5-.js';
import { l as locale_exports } from './locale.js-DnnPB87K.js';
import { a as setSiteNotificationsSubscription, f as formatDistanceToNow, s as sanitize } from './siteRealtime.js-DF-ZW4fv.js';
import { P as PageTitle } from './PageTitle.js-D99NSXzQ.js';
import { H as Hook } from './Hook.js-DEYNBNbZ.js';
import './uneval.js-BL1Qg77w.js';
import './rolldown-runtime.js-B5FuG9Gw.js';
import 'node:module';
import './exports2.js-DxZfja4I.js';
import './shared.js-3i5_hmQ1.js';
import './client.js-CPEkJ2-P.js';
import './exports.js-CKkpMUqI.js';
import './internal2.js-KmQU-gaY.js';
import './ToastContainer.js-CtmBBvhr.js';
import './internal.js-BlXt2rfE.js';
import './stores.js-QbD2A2ib.js';
import './PluginManager.js-B5x3OKEW.js';
import 'fs';
import './auth.util.js-BGCV_dhB.js';

//#region node_modules/@panomc/theme-core/src/lib/components/Main.svelte
function Main($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let sidebarEnabled, sidebarPosition;
		const sidebar = getContext("sidebar");
		const sidebarProps = getContext("sidebarProps");
		const pageTitle = getContext("pageTitle");
		const themeSettings = getContext("themeSettings");
		sidebarEnabled = typeof themeSettings.sidebarEnabled === "undefined" ? true : themeSettings.sidebarEnabled;
		sidebarPosition = typeof themeSettings.sidebarPosition !== "undefined" ? themeSettings.sidebarPosition : !store_get($$store_subs ??= {}, "$sidebarProps", sidebarProps).side ? "RIGHT" : store_get($$store_subs ??= {}, "$sidebarProps", sidebarProps).side === "left" ? "LEFT" : "RIGHT";
		head("dwjw01", $$renderer, ($$renderer) => {
			$$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]-->`);
		});
		$$renderer.push(`<main class="container">`);
		if (store_get($$store_subs ??= {}, "$pageTitle", pageTitle)) {
			$$renderer.push("<!--[0-->");
			const isString = typeof store_get($$store_subs ??= {}, "$pageTitle", pageTitle) === "string";
			const titleText = isString ? store_get($$store_subs ??= {}, "$_", $format)(store_get($$store_subs ??= {}, "$pageTitle", pageTitle)) : store_get($$store_subs ??= {}, "$pageTitle", pageTitle)?.title ? store_get($$store_subs ??= {}, "$_", $format)(store_get($$store_subs ??= {}, "$pageTitle", pageTitle).title, { values: store_get($$store_subs ??= {}, "$pageTitle", pageTitle).titleValues || {} }) : "";
			const subtitleText = isString ? "" : store_get($$store_subs ??= {}, "$pageTitle", pageTitle)?.subtitle ? store_get($$store_subs ??= {}, "$_", $format)(store_get($$store_subs ??= {}, "$pageTitle", pageTitle).subtitle, { values: store_get($$store_subs ??= {}, "$pageTitle", pageTitle).subtitleValues || {} }) : "";
			$$renderer.push(`<div class="row"><div class="col-12 mb-3">`);
			PageTitle($$renderer, {
				title: titleText,
				subtitle: subtitleText,
				html: isString ? void 0 : store_get($$store_subs ??= {}, "$pageTitle", pageTitle).html,
				subtitleHtml: isString ? void 0 : store_get($$store_subs ??= {}, "$pageTitle", pageTitle).subtitleHtml
			});
			$$renderer.push(`<!----></div></div>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--> <div class="row gx-3 align-items-start">`);
		if (sidebarEnabled) {
			$$renderer.push("<!--[0-->");
			if (store_get($$store_subs ??= {}, "$sidebar", sidebar)) {
				$$renderer.push("<!--[-->");
				store_get($$store_subs ??= {}, "$sidebar", sidebar)($$renderer, spread_props([{
					...store_get($$store_subs ??= {}, "$sidebarProps", sidebarProps),
					side: sidebarPosition === "LEFT" ? "left" : "right"
				}]));
				$$renderer.push("<!--]-->");
			} else {
				$$renderer.push("<!--[!-->");
				$$renderer.push("<!--]-->");
			}
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--> <div${attr_class("", void 0, {
			"col": !sidebarEnabled,
			"col-lg-8": sidebarEnabled && store_get($$store_subs ??= {}, "$sidebar", sidebar)
		})}><!--[-->`);
		slot($$renderer, $$props, "default", {}, null);
		$$renderer.push(`<!--]--></div></div></main>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
	});
}
//#endregion
//#region node_modules/@panomc/theme-core/src/lib/components/NotificationContainer.svelte
var notifications = writable([]);
Array.prototype.insert = function(index, item) {
	this.splice(index, 0, item);
	return this;
};
Array.prototype.remove = function(index) {
	this.splice(index, 1);
	return this;
};
function NotificationContainer($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let checkTime = 0;
		let interval;
		getContext("session");
		function getTime(check, time, locale) {
			return formatDistanceToNow(time, {
				addSuffix: true,
				locale
			});
		}
		onDestroy(() => {
			setSiteNotificationsSubscription();
			clearInterval(interval);
		});
		function sanitizeObject(obj) {
			return Object.keys(obj).reduce((sanitizedObj, key) => {
				sanitizedObj[key] = sanitize(obj[key]);
				return sanitizedObj;
			}, {});
		}
		$$renderer.push(`<div class="toast-container position-fixed bottom-0 end-0 p-3 d-xl-block d-none"><!--[-->`);
		const each_array = ensure_array_like(store_get($$store_subs ??= {}, "$notifications", notifications));
		for (let index = 0, $$length = each_array.length; index < $$length; index++) {
			let notification = each_array[index];
			$$renderer.push(`<article${attr("id", `notificationToast${stringify(notification.id)}`)} class="toast position-relative" aria-live="assertive" aria-atomic="true"><div class="toast-header text-bg-primary"><strong class="me-auto">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.notification-container.notification"))}</strong> <small>${escape_html(getTime(checkTime, parseInt(notification.createdAt), locale_exports[store_get($$store_subs ??= {}, "$currentLanguage", currentLanguage).dateFnsCode]))}</small> <button type="button" class="btn-close btn-close-white position-relative z-3"${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("buttons.close"))} data-bs-dismiss="toast"></button></div> <div class="toast-body"><div class="fw-normal list-group-item list-group-item-action d-flex align-items-center gap-3 text-wrap"><button type="button"${attr("title", store_get($$store_subs ??= {}, "$_", $format)("buttons.view"))} class="text-start border-0 bg-transparent p-0 d-flex align-items-center gap-3"><span class="d-flex align-items-center">`);
			if (notification.details.faIcon) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<i${attr_class(`${stringify(notification.details.faIcon)} fa-fw`)}></i>`);
			} else if (notification.details.image || notification.details.username) {
				$$renderer.push("<!--[1-->");
				$$renderer.push(`<img${attr("src", notification.details.image || `/api/profile/picture/${notification.details.username}?${store_get($$store_subs ??= {}, "$avatarVersion", avatarVersion)}`)}${attr("alt", store_get($$store_subs ??= {}, "$_", $format)("buttons.view"))} width="48" height="48" class="rounded"/>`);
			} else {
				$$renderer.push("<!--[-1-->");
				$$renderer.push(`<i class="fa fa-fw fa-bolt"></i>`);
			}
			$$renderer.push(`<!--]--></span> <span class="text-start"><span class="text-wrap markdown-renderer text-break">${html(store_get($$store_subs ??= {}, "$_", $format)("notifications." + notification.type, { values: { ...sanitizeObject(notification.details || {}) } }))}</span></span></button></div></div> <button type="button" class="stretched-link p-0 border-0 bg-transparent position-absolute top-0 start-0 w-100 h-100"${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("buttons.view"))}></button></article>`);
		}
		$$renderer.push(`<!--]--></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
	});
}
//#endregion
//#region node_modules/@panomc/theme-core/src/lib/components/Breadcrumb.svelte
function Breadcrumb($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let items;
		const breadcrumbsStore = getContext("breadcrumbs");
		function resolveLabel(item) {
			if (item == null) return "";
			if (typeof item === "string") return store_get($$store_subs ??= {}, "$_", $format)(item);
			if (item.raw || item.html) return item.label ?? "";
			if (!item.label) return "";
			return store_get($$store_subs ??= {}, "$_", $format)(item.label, { values: item.labelValues || {} });
		}
		function normalize(item) {
			if (typeof item === "string") return { label: resolveLabel(item) };
			return {
				label: resolveLabel(item),
				href: item?.href,
				icon: item?.icon,
				html: !!item?.html
			};
		}
		items = Array.isArray(store_get($$store_subs ??= {}, "$breadcrumbsStore", breadcrumbsStore)) ? store_get($$store_subs ??= {}, "$breadcrumbsStore", breadcrumbsStore).map(normalize) : [];
		if (items.length > 0) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<nav aria-label="breadcrumb"><ol class="breadcrumb justify-content-center mb-0 svelte-4iqrr9"><!--[-->`);
			const each_array = ensure_array_like(items);
			for (let i = 0, $$length = each_array.length; i < $$length; i++) {
				let crumb = each_array[i];
				const isLast = i === items.length - 1;
				$$renderer.push(`<li${attr_class("breadcrumb-item", void 0, { "active": isLast })}${attr("aria-current", isLast ? "page" : void 0)}>`);
				if (isLast || !crumb.href) {
					$$renderer.push("<!--[0-->");
					if (crumb.icon) {
						$$renderer.push("<!--[0-->");
						$$renderer.push(`<i${attr_class(clsx(crumb.icon), "svelte-4iqrr9")}></i>`);
					} else if (crumb.html) {
						$$renderer.push("<!--[1-->");
						$$renderer.push(`${html(crumb.label)}`);
					} else {
						$$renderer.push("<!--[-1-->");
						$$renderer.push(`${escape_html(crumb.label)}`);
					}
					$$renderer.push(`<!--]-->`);
				} else {
					$$renderer.push("<!--[-1-->");
					$$renderer.push(`<a${attr("href", crumb.href)} class="text-decoration-none badge text-bg-primary rounded-pill px-1">`);
					if (crumb.icon) {
						$$renderer.push("<!--[0-->");
						$$renderer.push(`<i${attr_class(clsx(crumb.icon), "svelte-4iqrr9")}></i>`);
					} else if (crumb.html) {
						$$renderer.push("<!--[1-->");
						$$renderer.push(`${html(crumb.label)}`);
					} else {
						$$renderer.push("<!--[-1-->");
						$$renderer.push(`${escape_html(crumb.label)}`);
					}
					$$renderer.push(`<!--]--></a>`);
				}
				$$renderer.push(`<!--]--></li>`);
			}
			$$renderer.push(`<!--]--></ol></nav>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]-->`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
	});
}
//#endregion
//#region node_modules/@panomc/theme-core/src/lib/views/MainLayoutView.svelte
function MainLayoutView($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let breadcrumbEnabled;
		let data = $$props["data"];
		let themeSettings = $$props["themeSettings"];
		let session = $$props["session"];
		let chrome = $$props["chrome"];
		const styles = `
    body {
      min-height: 100vh;
      ${themeSettings.backgroundColor ? `background-color: ${themeSettings.backgroundColor} !important;` : ""}
      ${themeSettings.files?.backgroundImage ? `background-image: url(/api/theme/file/${themeSettings.files.backgroundImage}) !important;` : ""}
      ${themeSettings.bgImagePosition ? `background-position: ${themeSettings.bgImagePosition} !important;` : ""}
      ${themeSettings.bgImageRepeat ? `background-repeat: ${themeSettings.bgImageRepeat} !important;` : ""}
      ${themeSettings.bgImageSize ? `background-size: ${themeSettings.bgImageSize} !important;` : ""}
    }

    ${themeSettings.customCss || ""}
  `;
		breadcrumbEnabled = typeof themeSettings.breadcrumbEnabled === "undefined" ? true : themeSettings.breadcrumbEnabled;
		head("yaifes", $$renderer, ($$renderer) => {
			$$renderer.push(`<meta${attr("content", store_get($$store_subs ??= {}, "$session", session).siteInfo.keywords.join(", "))} name="keywords"/> <meta${attr("content", store_get($$store_subs ??= {}, "$session", session).siteInfo.websiteDescription)} name="description"/> <meta${attr("content", themeSettings.themeColor || "dark")} name="x-theme"/> ${html(`<style>;</style>`.replace(";", styles))}`);
		});
		Hook($$renderer, { name: "theme:top" });
		$$renderer.push(`<!----> <div class="vstack gap-3 min-vh-100"><div${attr_class(`vstack gap-${stringify(themeSettings.headerNavBarGap || "3")} flex-grow-0`)}>`);
		if (chrome.Header) {
			$$renderer.push("<!--[-->");
			chrome.Header($$renderer, {});
			$$renderer.push("<!--]-->");
		} else {
			$$renderer.push("<!--[!-->");
			$$renderer.push("<!--]-->");
		}
		$$renderer.push(` `);
		if (chrome.Navbar) {
			$$renderer.push("<!--[-->");
			chrome.Navbar($$renderer, {});
			$$renderer.push("<!--]-->");
		} else {
			$$renderer.push("<!--[!-->");
			$$renderer.push("<!--]-->");
		}
		$$renderer.push(`</div> `);
		Hook($$renderer, { name: "page:top" });
		$$renderer.push(`<!----> `);
		if (breadcrumbEnabled) {
			$$renderer.push("<!--[0-->");
			Breadcrumb($$renderer);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--> <div class="flex-grow-1">`);
		Main($$renderer, {
			children: ($$renderer) => {
				$$renderer.push(`<!--[-->`);
				slot($$renderer, $$props, "default", {}, null);
				$$renderer.push(`<!--]-->`);
			},
			$$slots: { default: true }
		});
		$$renderer.push(`<!----></div> `);
		if (typeof themeSettings.footerEnabled === "undefined" ? true : themeSettings.footerEnabled) {
			$$renderer.push("<!--[0-->");
			if (chrome.Footer) {
				$$renderer.push("<!--[-->");
				chrome.Footer($$renderer, {});
				$$renderer.push("<!--]-->");
			} else {
				$$renderer.push("<!--[!-->");
				$$renderer.push("<!--]-->");
			}
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--></div> `);
		NotificationContainer($$renderer);
		$$renderer.push(`<!---->`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
		bind_props($$props, {
			data,
			themeSettings,
			session,
			chrome
		});
	});
}

export { MainLayoutView as default };
//# sourceMappingURL=MainLayoutView.js-CiqYA2Wm.js.map
