import { g as getContext, a0 as store_get, Z as attr_class, X as attr, Y as stringify, a8 as attr_style, $ as ensure_array_like, a5 as escape_html, a2 as unsubscribe_stores } from './server.js-D28cBEJ-.js';
import 'node:module';
import { p as page } from './stores.js-QbD2A2ib.js';
import { $ as $format } from './runtime.js-CJgfVvxa.js';
import { p as panoApiClient, o as orderLinksBySavedOrder } from './PluginManager.js-B5x3OKEW.js';
import { k as PANEL_URL, c as avatarVersion, y as notificationsCount } from './Store.js-C2vdyE6V.js';
import './tooltip.util.js-Bd9x5X7L.js';
import { h as hasPermission } from './auth.util.js-BGCV_dhB.js';
import { V as ViewComponent } from './ViewComponent.js-C6amYVVM.js';
import './uneval.js-BL1Qg77w.js';
import './client.js-CPEkJ2-P.js';
import './shared.js-3i5_hmQ1.js';
import './exports.js-CKkpMUqI.js';
import './internal2.js-KmQU-gaY.js';
import './index-server2.js-DlblWyyK.js';
import './rolldown-runtime.js-B5FuG9Gw.js';
import './exports2.js-DxZfja4I.js';
import './internal.js-BlXt2rfE.js';
import 'fs';
import './ToastContainer.js-CtmBBvhr.js';

//#region node_modules/@panomc/theme-core/src/lib/components/Navbar.svelte
function Navbar($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let effectiveNavbarBgColor, nativeLinks, displayLinks;
		const themeDefaults = {
			dark: "#044389",
			light: "#ffffff",
			copper: "#9c622b",
			emerald: "#0d8a61",
			midnight: "#6d44c5",
			crimson: "#bf3636"
		};
		function getContrast(hexcolor) {
			if (!hexcolor || hexcolor.startsWith("bg-")) return "dark";
			hexcolor = hexcolor.replace("#", "");
			const r = parseInt(hexcolor.substr(0, 2), 16);
			const g = parseInt(hexcolor.substr(2, 2), 16);
			const b = parseInt(hexcolor.substr(4, 2), 16);
			return (r * 299 + g * 587 + b * 114) / 1e3 >= 128 ? "light" : "dark";
		}
		const navLinks = panoApiClient.ui.nav.site.getNavLinks();
		panoApiClient.ui.nav.rightComponents.edit((items) => {
			items.push({
				id: "panel-button",
				priority: 100,
				hidden: false
			}, {
				id: "profile-dropdown",
				priority: 90,
				hidden: false
			}, {
				id: "auth-buttons",
				priority: 80,
				hidden: false
			});
		});
		panoApiClient.ui.nav.profileDropdown.edit((items) => {
			items.push({
				id: "profile",
				priority: 100,
				hidden: false
			}, {
				id: "notifications",
				priority: 90,
				hidden: false
			}, {
				id: "tickets",
				priority: 80,
				hidden: false
			}, {
				id: "settings",
				priority: 70,
				hidden: false
			}, {
				id: "logout",
				priority: 10,
				hidden: false
			});
		});
		const navbarRightComponents = panoApiClient.ui.nav.rightComponents.get();
		const profileDropdownItems = panoApiClient.ui.nav.profileDropdown.get();
		let navbarCollapseInstance = null;
		const session = getContext("session");
		const themeSettings = getContext("themeSettings");
		function matching(path, pathName, startsWith = false) {
			return path.toUpperCase() === pathName?.toUpperCase() || path.toUpperCase() === (pathName + "/").toUpperCase() || startsWith && path.startsWith(pathName);
		}
		effectiveNavbarBgColor = themeSettings.navbarBgColor || themeDefaults[themeSettings.themeColor || "dark"] || themeDefaults.dark;
		if (store_get($$store_subs ??= {}, "$page", page).url.pathname && navbarCollapseInstance);
		themeSettings.navbarWidthOption;
		nativeLinks = [
			{
				id: "home",
				text: "nav-links.homepage",
				href: "/"
			},
			{
				id: "support",
				text: "nav-links.support",
				href: "/support"
			},
			{
				id: "rules",
				text: "nav-links.rules",
				href: "/rules",
				condition: !!store_get($$store_subs ??= {}, "$session", session).siteInfo?.hasRegisterAgreement
			}
		];
		displayLinks = (() => {
			const pluginLinks = store_get($$store_subs ??= {}, "$navLinks", navLinks).map((l) => ({
				...l,
				id: l.href,
				isPlugin: true,
				target: l.target === "_self" ? null : l.target
			}));
			return orderLinksBySavedOrder([...nativeLinks, ...pluginLinks], themeSettings.navLinksOrder).filter((link) => {
				if (themeSettings.navLinksEnableStatus?.[link.id] === false) return false;
				if (typeof link.condition !== "undefined" && !link.condition) return false;
				if (link.loginRequired && !store_get($$store_subs ??= {}, "$session", session).user) return false;
				if (link.permission && !hasPermission(link.permission)) return false;
				return true;
			});
		})();
		$$renderer.push(`<div${attr_class("", void 0, { "container": themeSettings.navbarWidthOption !== "FULL_SIZE" })}><nav${attr("data-bs-theme", getContrast(effectiveNavbarBgColor))}${attr_class(`navbar navbar-expand-lg rounded rounded-${stringify(themeSettings.navRoundLevel ? +themeSettings.navRoundLevel : "5")} shadow-sm`, "svelte-ks6k4w")}${attr_style(`background-color: ${stringify(effectiveNavbarBgColor)}`)}><div class="container"><ul class="navbar-nav flex-row me-auto"><li><button${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("buttons.toggle"))} class="navbar-toggler d-lg-none" data-bs-target="#navbar" data-bs-toggle="collapse" type="button"><i aria-hidden="true" class="fa fa-bars"></i></button></li></ul> <ul class="navbar-nav flex-row ml-auto order-lg-last gap-lg-0 gap-3 svelte-ks6k4w"><!--[-->`);
		const each_array = ensure_array_like(store_get($$store_subs ??= {}, "$navbarRightComponents", navbarRightComponents));
		for (let $$index_1 = 0, $$length = each_array.length; $$index_1 < $$length; $$index_1++) {
			let component = each_array[$$index_1];
			if (component.id === "panel-button") {
				$$renderer.push("<!--[0-->");
				if (store_get($$store_subs ??= {}, "$session", session).user && store_get($$store_subs ??= {}, "$session", session).user.panelAccess) {
					$$renderer.push("<!--[0-->");
					$$renderer.push(`<li class="nav-item position-relative"><a class="nav-link svelte-ks6k4w"${attr("href", PANEL_URL)} target="_blank" rel="noreferrer"${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("nav-links.panel"))}><i class="fa-solid fa-columns"></i></a> `);
					$$renderer.push("<!--[-1-->");
					$$renderer.push(`<!--]--></li>`);
				} else $$renderer.push("<!--[-1-->");
				$$renderer.push(`<!--]-->`);
			} else if (component.id === "profile-dropdown") {
				$$renderer.push("<!--[1-->");
				if (store_get($$store_subs ??= {}, "$session", session).user) {
					$$renderer.push("<!--[0-->");
					$$renderer.push(`<li class="nav-item dropdown position-relative"><button type="button" class="nav-link position-relative d-flex align-items-center svelte-ks6k4w" data-bs-toggle="dropdown" aria-expanded="false"><span class="me-2 d-none d-lg-inline">${escape_html(store_get($$store_subs ??= {}, "$session", session).user.username)}</span> <img${attr("alt", store_get($$store_subs ??= {}, "$session", session).user.username)} class="rounded"${attr("src", `/api/profile/picture/${stringify(store_get($$store_subs ??= {}, "$session", session).user.username)}?${stringify(store_get($$store_subs ??= {}, "$avatarVersion", avatarVersion))}`)} width="24" height="24"/> `);
					if (store_get($$store_subs ??= {}, "$notificationsCount", notificationsCount) !== 0) {
						$$renderer.push("<!--[0-->");
						$$renderer.push(`<span class="position-absolute top-0 end-0 badge rounded-pill bg-danger px-2 py-1">${escape_html(store_get($$store_subs ??= {}, "$notificationsCount", notificationsCount))}</span>`);
					} else $$renderer.push("<!--[-1-->");
					$$renderer.push(`<!--]--></button> <ul class="dropdown-menu dropdown-menu-end position-absolute"><h6 class="dropdown-header">${escape_html(store_get($$store_subs ??= {}, "$session", session).user.username)}</h6> <!--[-->`);
					const each_array_1 = ensure_array_like(store_get($$store_subs ??= {}, "$profileDropdownItems", profileDropdownItems));
					for (let $$index = 0, $$length = each_array_1.length; $$index < $$length; $$index++) {
						let item = each_array_1[$$index];
						if (item.id === "profile") {
							$$renderer.push("<!--[0-->");
							$$renderer.push(`<li><a${attr_class("dropdown-item focus-ring", void 0, { "active": matching(store_get($$store_subs ??= {}, "$page", page).url.pathname, "/profile") })} href="/profile">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.profile"))}</a></li>`);
						} else if (item.id === "notifications") {
							$$renderer.push("<!--[1-->");
							$$renderer.push(`<li><a${attr_class("dropdown-item focus-ring position-relative", void 0, { "active": matching(store_get($$store_subs ??= {}, "$page", page).url.pathname, "/notifications") })} href="/notifications">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.notifications"))} `);
							if (store_get($$store_subs ??= {}, "$notificationsCount", notificationsCount) !== 0) {
								$$renderer.push("<!--[0-->");
								$$renderer.push(`<span class="position-absolute top-0 badge rounded-pill bg-danger p-1 d-inline"></span>`);
							} else $$renderer.push("<!--[-1-->");
							$$renderer.push(`<!--]--></a></li>`);
						} else if (item.id === "tickets") {
							$$renderer.push("<!--[2-->");
							$$renderer.push(`<li><a${attr_class("dropdown-item focus-ring", void 0, { "active": matching(store_get($$store_subs ??= {}, "$page", page).url.pathname, "/tickets") })} href="/tickets">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.tickets"))}</a></li>`);
						} else if (item.id === "settings") {
							$$renderer.push("<!--[3-->");
							$$renderer.push(`<li><a${attr_class("dropdown-item focus-ring", void 0, { "active": matching(store_get($$store_subs ??= {}, "$page", page).url.pathname, "/profile/settings") })} href="/profile/settings">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.settings"))}</a></li>`);
						} else if (item.id === "logout") {
							$$renderer.push("<!--[4-->");
							$$renderer.push(`<li><button type="button" class="dropdown-item focus-ring link-danger">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.logout"))}</button></li>`);
						} else if (item.props) {
							$$renderer.push("<!--[5-->");
							$$renderer.push(`<li><a class="dropdown-item focus-ring"${attr("href", item.props.href)}>`);
							if (item.props.icon) {
								$$renderer.push("<!--[0-->");
								$$renderer.push(`<i${attr_class(`${stringify(item.props.icon)} me-2`, "svelte-ks6k4w")}></i>`);
							} else $$renderer.push("<!--[-1-->");
							$$renderer.push(`<!--]--> ${escape_html(item.props.text && item.props.text.includes(".") ? store_get($$store_subs ??= {}, "$_", $format)(item.props.text) : item.props.text)}</a></li>`);
						} else $$renderer.push("<!--[-1-->");
						$$renderer.push(`<!--]-->`);
					}
					$$renderer.push(`<!--]--></ul></li>`);
				} else $$renderer.push("<!--[-1-->");
				$$renderer.push(`<!--]-->`);
			} else if (component.id === "auth-buttons") {
				$$renderer.push("<!--[2-->");
				if (!store_get($$store_subs ??= {}, "$session", session).user) {
					$$renderer.push("<!--[0-->");
					$$renderer.push(`<li class="nav-item position-relative me-lg-2"><a href="/login" class="nav-link svelte-ks6k4w">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.login"))}</a> `);
					$$renderer.push("<!--[-1-->");
					$$renderer.push(`<!--]--></li> <li class="nav-item"><a href="/register" class="btn btn-secondary rounded-pill">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.register"))}</a></li>`);
				} else $$renderer.push("<!--[-1-->");
				$$renderer.push(`<!--]-->`);
			} else {
				$$renderer.push("<!--[-1-->");
				$$renderer.push(`<li class="nav-item">`);
				ViewComponent($$renderer, { component: component.component });
				$$renderer.push(`<!----></li>`);
			}
			$$renderer.push(`<!--]-->`);
		}
		$$renderer.push(`<!--]--></ul> `);
		if (typeof themeSettings.navLinksEnabled === "undefined" ? true : themeSettings.navLinksEnabled) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<div class="collapse navbar-collapse" id="navbar"><ul class="navbar-nav mr-auto mt-2 mt-lg-0 text-lg-left text-center svelte-ks6k4w"><!--[-->`);
			const each_array_2 = ensure_array_like(displayLinks);
			for (let $$index_2 = 0, $$length = each_array_2.length; $$index_2 < $$length; $$index_2++) {
				let link = each_array_2[$$index_2];
				$$renderer.push(`<li class="nav-item"><a${attr("href", link.href)}${attr("target", link.target)}${attr_class("nav-link svelte-ks6k4w", void 0, { "active": matching(store_get($$store_subs ??= {}, "$page", page).url.pathname, link.href, link.startsWith) })}${attr("title", link.text && link.text.includes(".") ? store_get($$store_subs ??= {}, "$_", $format)(link.text) : link.text)}>`);
				if (link.icon) {
					$$renderer.push("<!--[0-->");
					$$renderer.push(`<i${attr_class(`${stringify(link.icon)} me-1`, "svelte-ks6k4w")} aria-hidden="true"></i>`);
				} else $$renderer.push("<!--[-1-->");
				$$renderer.push(`<!--]--> ${escape_html(link.text && link.text.includes(".") ? store_get($$store_subs ??= {}, "$_", $format)(link.text) : link.text)}</a></li>`);
			}
			$$renderer.push(`<!--]--></ul></div>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--></div></nav></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
	});
}

export { Navbar as default };
//# sourceMappingURL=Navbar.js-CdO1-02y.js.map
