import { V as fallback, a0 as store_get, Z as attr_class, a6 as clsx, a5 as escape_html, _ as slot, a2 as unsubscribe_stores, W as bind_props } from './server.js-D28cBEJ-.js';
import { $ as $format } from './runtime.js-CJgfVvxa.js';

//#region node_modules/@panomc/theme-core/src/lib/components/NoContent.svelte
function NoContent($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let icon = fallback($$props["icon"], "fa-solid fa-square fa-3x");
		let text = fallback($$props["text"], () => store_get($$store_subs ??= {}, "$_", $format)("components.no-content.text"), true);
		$$renderer.push(`<div class="card opacity-50 bg-transparent border-none"><div class="card-body vstack gap-3 text-center"><span${attr_class(clsx(icon))}></span> <p class="mb-0">${escape_html(text)}</p> <!--[-->`);
		slot($$renderer, $$props, "default", {}, null);
		$$renderer.push(`<!--]--></div></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
		bind_props($$props, {
			icon,
			text
		});
	});
}

export { NoContent as N };
//# sourceMappingURL=NoContent.js-BBe0Mapz.js.map
