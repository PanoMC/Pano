//#region node_modules/@panomc/sdk/core/js/NotificationManager.js
var actionListeners = {};
function onNotificationClick(notification) {
	const listeners = actionListeners[notification.type];
	if (listeners) listeners.forEach((listener) => {
		listener(notification);
	});
}

export { onNotificationClick as o };
//# sourceMappingURL=NotificationManager.js-5CX8pNRh.js.map
