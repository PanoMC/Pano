import { W as bind_props, T as writable, a4 as get } from './server.js-D28cBEJ-.js';
import { o as onDestroy } from './index-server2.js-DlblWyyK.js';
import { r as resolveView } from './registry2.js-BubD3cPq.js';
import { c as avatarVersion, m as requireLogin, d as ApiUtil } from './Store.js-C2vdyE6V.js';
import { c as currentLanguage } from './language.util.js-C2xYQq5-.js';
import { o as onNotificationClick } from './NotificationManager.js-5CX8pNRh.js';
import { l as locale_exports } from './locale.js-DnnPB87K.js';
import { s as sanitize, f as formatDistanceToNow } from './siteRealtime.js-DF-ZW4fv.js';
import './runtime.js-CJgfVvxa.js';
import { l as load$1, P as ProfileSidebar } from './ProfileSidebar.js-BIu8zSKN.js';

//#region node_modules/@panomc/theme-core/src/lib/ui-logics/page-logics/NotificationsPageLogics.js
Array.prototype.insert = function(index, item) {
	this.splice(index, 0, item);
	return this;
};
Array.prototype.remove = function(index) {
	this.splice(index, 1);
	return this;
};
async function loadData({ request }) {
	return new Promise((resolve, reject) => {
		ApiUtil.get({
			path: "/api/notifications",
			request
		}).then((body) => {
			if (body.result === "ok") resolve(body);
			else reject(body);
		});
	});
}
/**
* @type {import("@sveltejs/kit").PageLoad}
*/
async function processLoad(event) {
	const { parent } = event;
	const { session } = await parent();
	requireLogin(session);
	const [{ notifications, notificationCount }] = await Promise.all([loadData({ request: event }), load$1(event)]);
	return {
		notifications,
		notificationCount: parseInt(notificationCount),
		sidebar: ProfileSidebar,
		sidebarProps: { showDeleteAll: true },
		pageTitle: "pages.notifications.page-title"
	};
}
function loadMore(notifications, loadMoreLoading) {
	loadMoreLoading.set(true);
	ApiUtil.get({ path: `/api/notifications/${get(notifications)[get(notifications).length - 1].id}/more` }).then((body) => {
		if (body.result === "ok") {
			body.notifications.forEach((notification) => {
				notifications.update((value) => value.insert(value.length, notification));
			});
			loadMoreLoading.set(false);
		}
	});
}
function onDeleteNotificationClick(notifications, count, id) {
	ApiUtil.delete({ path: `/api/notifications/${id}` }).then((body) => {
		if (body.result === "ok") get(notifications).forEach((notification) => {
			if (notification.id === id) {
				notifications.update((value) => {
					return value.remove(value.indexOf(notification));
				});
				count.update((value) => {
					value--;
					return value;
				});
			}
		});
	});
}
function stopNotificationsCountdown(notificationProcessID, interval) {
	notificationProcessID.update((notificationProcessID) => {
		notificationProcessID++;
		return notificationProcessID;
	});
	clearInterval(get(interval));
}
function getTime(check, time, locale) {
	return formatDistanceToNow(time, {
		addSuffix: true,
		locale
	});
}
function init(data) {
	const notifications = writable(data.notifications || []);
	const count = writable(data.notificationCount || 0);
	const notificationProcessID = writable(0);
	const checkTime = writable(0);
	const interval = writable();
	const page = writable(0);
	const loadMoreLoading = writable(false);
	onDestroy(() => {
		stopNotificationsCountdown(notificationProcessID, interval);
	});
	return {
		notifications,
		count,
		notificationProcessID,
		page,
		loadMoreLoading,
		checkTime,
		interval
	};
}
function sanitizeObject(obj) {
	return Object.keys(obj).reduce((sanitizedObj, key) => {
		sanitizedObj[key] = sanitize(obj[key]);
		return sanitizedObj;
	}, {});
}
//#endregion
//#region node_modules/@panomc/theme-core/src/lib/pages/NotificationsPage.svelte
async function load(event) {
	const viewPromise = resolveView("NotificationsView", () => import('./NotificationsView.js-jNfYnsF5.js'));
	return {
		...await processLoad(event),
		View: await viewPromise
	};
}
function NotificationsPage($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		let data = $$props["data"];
		const { notifications, count, page, loadMoreLoading, checkTime} = init(data);
		if (data.View) {
			$$renderer.push("<!--[-->");
			data.View($$renderer, {
				data,
				notifications,
				count,
				page,
				loadMoreLoading,
				checkTime,
				avatarVersion,
				currentLanguage,
				locales: locale_exports,
				onNotificationClick,
				onDeleteNotificationClick,
				getTime,
				loadMore,
				sanitizeObject
			});
			$$renderer.push("<!--]-->");
		} else {
			$$renderer.push("<!--[!-->");
			$$renderer.push("<!--]-->");
		}
		bind_props($$props, { data });
	});
}

export { NotificationsPage as N, load as l };
//# sourceMappingURL=NotificationsPage.js-BxLUec4T.js.map
