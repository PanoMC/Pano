import { Z as attr_class, a0 as store_get, $ as ensure_array_like, X as attr, Y as stringify, a3 as html, a5 as escape_html, a2 as unsubscribe_stores, W as bind_props } from './server.js-D28cBEJ-.js';
import { $ as $format } from './runtime.js-CJgfVvxa.js';
import './tooltip.util.js-Bd9x5X7L.js';
import { N as NoContent } from './NoContent.js-BBe0Mapz.js';
import { C as ConfirmRemoveAllNotificationsModal } from './ConfirmRemoveAllNotificationsModal.js-CYg4_hFF.js';
import './uneval.js-BL1Qg77w.js';
import './rolldown-runtime.js-B5FuG9Gw.js';
import 'node:module';
import './stores.js-QbD2A2ib.js';
import './client.js-CPEkJ2-P.js';
import './shared.js-3i5_hmQ1.js';
import './exports.js-CKkpMUqI.js';
import './internal2.js-KmQU-gaY.js';
import './index-server2.js-DlblWyyK.js';
import './ToastContainer.js-CtmBBvhr.js';

//#region node_modules/@panomc/theme-core/src/lib/views/NotificationsView.svelte
function NotificationsView($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let data = $$props["data"];
		let notifications = $$props["notifications"];
		let count = $$props["count"];
		let page = $$props["page"];
		let loadMoreLoading = $$props["loadMoreLoading"];
		let checkTime = $$props["checkTime"];
		let avatarVersion = $$props["avatarVersion"];
		let currentLanguage = $$props["currentLanguage"];
		let locales = $$props["locales"];
		let onNotificationClick = $$props["onNotificationClick"];
		let onDeleteNotificationClick = $$props["onDeleteNotificationClick"];
		let getTime = $$props["getTime"];
		let loadMore = $$props["loadMore"];
		let sanitizeObject = $$props["sanitizeObject"];
		$$renderer.push(`<div class="vstack gap-3"><div class="card mt-3 mt-lg-0"><div class="card-body"><div${attr_class("list-group", void 0, { "d-none": store_get($$store_subs ??= {}, "$notifications", notifications).length === 0 })}><!--[-->`);
		const each_array = ensure_array_like(store_get($$store_subs ??= {}, "$notifications", notifications));
		for (let index = 0, $$length = each_array.length; index < $$length; index++) {
			let notification = each_array[index];
			$$renderer.push(`<div${attr_class("site-notification-row fw-normal list-group-item list-group-item-action d-flex align-items-center gap-3 text-wrap", void 0, { "notification-unread": notification.status === "NOT_READ" })}><button type="button"${attr("title", store_get($$store_subs ??= {}, "$_", $format)("buttons.view"))} class="flex-grow-1 text-start border-0 bg-transparent p-0 d-flex align-items-center gap-3"><span class="d-flex align-items-center">`);
			if (notification.details.faIcon) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<i${attr_class(`${stringify(notification.details.faIcon)} fa-xl fa-fw text-primary`)}></i>`);
			} else if (notification.details.image || notification.details.username) {
				$$renderer.push("<!--[1-->");
				$$renderer.push(`<img${attr("src", notification.details.image || `/api/profile/picture/${notification.details.username}?${store_get($$store_subs ??= {}, "$avatarVersion", avatarVersion)}`)}${attr("alt", store_get($$store_subs ??= {}, "$_", $format)("buttons.view"))} width="30" height="30" class="rounded"/>`);
			} else {
				$$renderer.push("<!--[-1-->");
				$$renderer.push(`<i class="fa fa-bolt fa-xl fa-fw text-primary"></i>`);
			}
			$$renderer.push(`<!--]--></span> <div class="fw-normal"><span class="text-wrap markdown-renderer text-break">${html(store_get($$store_subs ??= {}, "$_", $format)("notifications." + notification.type, { values: { ...sanitizeObject(notification.details || {}) } }))}</span> <br/> <small>${escape_html(getTime(checkTime, parseInt(notification.createdAt), locales[store_get($$store_subs ??= {}, "$currentLanguage", currentLanguage).dateFnsCode]))}</small></div></button> <button type="button" class="btn-close ms-2"${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("pages.notifications.delete-notification"))}></button></div>`);
		}
		$$renderer.push(`<!--]--></div> `);
		if (store_get($$store_subs ??= {}, "$notifications", notifications).length === 0) {
			$$renderer.push("<!--[0-->");
			NoContent($$renderer, {});
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--> `);
		if (store_get($$store_subs ??= {}, "$notifications", notifications).length < store_get($$store_subs ??= {}, "$count", count) && store_get($$store_subs ??= {}, "$count", count) > 10 + 10 * store_get($$store_subs ??= {}, "$page", page)) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<div class="mt-3"><button${attr_class("btn btn-primary d-block m-auto", void 0, { "disabled": store_get($$store_subs ??= {}, "$loadMoreLoading", loadMoreLoading) })}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.notifications.show-more", { values: { count: store_get($$store_subs ??= {}, "$count", count) - store_get($$store_subs ??= {}, "$notifications", notifications).length } }))}</button></div>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--></div></div></div> `);
		ConfirmRemoveAllNotificationsModal($$renderer);
		$$renderer.push(`<!---->`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
		bind_props($$props, {
			data,
			notifications,
			count,
			page,
			loadMoreLoading,
			checkTime,
			avatarVersion,
			currentLanguage,
			locales,
			onNotificationClick,
			onDeleteNotificationClick,
			getTime,
			loadMore,
			sanitizeObject
		});
	});
}

export { NotificationsView as default };
//# sourceMappingURL=NotificationsView.js-jNfYnsF5.js.map
