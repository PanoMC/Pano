import { g as getContext, X as attr, a5 as escape_html, a0 as store_get, $ as ensure_array_like, Y as stringify, a2 as unsubscribe_stores, W as bind_props } from './server.js-D28cBEJ-.js';
import 'node:module';
import { $ as $format } from './runtime.js-CJgfVvxa.js';
import { c as avatarVersion } from './Store.js-C2vdyE6V.js';
import './tooltip.util.js-Bd9x5X7L.js';
import { N as NoContent } from './NoContent.js-BBe0Mapz.js';
import { C as CardHeader } from './CardHeader.js-DpkWpoy6.js';

//#region node_modules/@panomc/theme-core/src/lib/components/OnlineAdmins.svelte
function OnlineAdmins($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let onlineAdmins = $$props["onlineAdmins"];
		const themeSettings = getContext("themeSettings");
		$$renderer.push(`<div class="card h-100 mb-3 mb-lg-0"${attr("hidden", typeof themeSettings.sidebarCarts?.onlineAdmins === "undefined" ? false : !themeSettings.sidebarCarts.onlineAdmins)}>`);
		CardHeader($$renderer, {
			headerClasses: "bg-transparent",
			$$slots: { left: ($$renderer) => {
				$$renderer.push(`<div slot="left">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.online-admins.online-admins"))}</div>`);
			} }
		});
		$$renderer.push(`<!----> <div class="card-body pt-3 d-flex flex-column justify-content-start">`);
		if (onlineAdmins && onlineAdmins.length > 0) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<div class="row g-3 justify-content-evenly align-items-start align-content-start"><!--[-->`);
			const each_array = ensure_array_like(onlineAdmins);
			for (let index = 0, $$length = each_array.length; index < $$length; index++) {
				let onlineAdmin = each_array[index];
				$$renderer.push(`<div class="col-auto"><a${attr("href", `/player/${stringify(onlineAdmin)}`)} class="online-admin-link focus-ring rounded position-relative d-inline-block svelte-f5o863"><img${attr("src", `/api/profile/picture/${stringify(onlineAdmin)}?${stringify(store_get($$store_subs ??= {}, "$avatarVersion", avatarVersion))}`)} class="online-admin-avatar rounded border border-3 border-success svelte-f5o863"${attr("alt", onlineAdmin)} onload="this.__e=event" onerror="this.__e=event"/></a></div>`);
			}
			$$renderer.push(`<!--]--></div>`);
		} else {
			$$renderer.push("<!--[-1-->");
			NoContent($$renderer, {});
		}
		$$renderer.push(`<!--]--></div></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
		bind_props($$props, { onlineAdmins });
	});
}

export { OnlineAdmins as O };
//# sourceMappingURL=OnlineAdmins.js-FcRIIIBU.js.map
