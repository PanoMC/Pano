import { a as getAllContexts, a1 as spread_props, W as bind_props } from './server.js-D28cBEJ-.js';
import 'node:module';

//#region node_modules/@panomc/theme-core/src/routes/plugin-ui/Page.svelte
async function load(event) {
	const { parent } = event;
	const { registeredPage } = await parent();
	let componentOutput = {};
	const component = await registeredPage.component();
	if (registeredPage.params) event.params = {
		...event.params,
		...registeredPage.params
	};
	if (component.load !== void 0) componentOutput = await component.load(event);
	const output = {
		registeredPage,
		component,
		props: componentOutput
	};
	if (componentOutput && typeof componentOutput === "object") {
		for (const key of [
			"pageTitle",
			"breadcrumbs",
			"sidebar",
			"sidebarProps"
		]) if (componentOutput[key] !== void 0) output[key] = componentOutput[key];
	}
	return output;
}
function Page($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		let data = $$props["data"];
		getAllContexts();
		$$renderer.push("<!--[0-->");
		if (data.component.default) {
			$$renderer.push("<!--[-->");
			data.component.default($$renderer, spread_props([data.props || {}]));
			$$renderer.push("<!--]-->");
		} else {
			$$renderer.push("<!--[!-->");
			$$renderer.push("<!--]-->");
		}
		$$renderer.push(`<!--]-->`);
		bind_props($$props, { data });
	});
}

export { Page as P, load as l };
//# sourceMappingURL=Page.js-CHxlFwZT.js.map
