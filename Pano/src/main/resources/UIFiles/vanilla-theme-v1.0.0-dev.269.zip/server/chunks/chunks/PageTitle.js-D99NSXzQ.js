import { V as fallback, g as getContext, _ as slot, a3 as html, a5 as escape_html, W as bind_props } from './server.js-D28cBEJ-.js';
import 'node:module';

//#region node_modules/@panomc/theme-core/src/lib/components/PageTitle.svelte
function PageTitle($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		let title = fallback($$props["title"], "");
		let subtitle = fallback($$props["subtitle"], "");
		let html$1 = $$props["html"];
		let subtitleHtml = fallback($$props["subtitleHtml"], false);
		getContext("themeSettings");
		if (title || subtitle) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<div class="text-center animate__animated animate__fadeIn"><h1 class="fs-3 mb-0 text-break word-break"><!--[-->`);
			slot($$renderer, $$props, "title", {}, () => {
				if (title) {
					$$renderer.push("<!--[0-->");
					if (html$1) {
						$$renderer.push("<!--[0-->");
						$$renderer.push(`${html(title)}`);
					} else {
						$$renderer.push("<!--[-1-->");
						$$renderer.push(`${escape_html(title)}`);
					}
					$$renderer.push(`<!--]-->`);
				} else $$renderer.push("<!--[-1-->");
				$$renderer.push(`<!--]-->`);
			});
			$$renderer.push(`<!--]--></h1> `);
			if (subtitle) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<p class="mb-0 mt-2 opacity-75">`);
				if (subtitleHtml) {
					$$renderer.push("<!--[0-->");
					$$renderer.push(`${html(subtitle)}`);
				} else {
					$$renderer.push("<!--[-1-->");
					$$renderer.push(`${escape_html(subtitle)}`);
				}
				$$renderer.push(`<!--]--></p>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--> <!--[-->`);
			slot($$renderer, $$props, "default", {}, null);
			$$renderer.push(`<!--]--></div>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]-->`);
		bind_props($$props, {
			title,
			subtitle,
			html: html$1,
			subtitleHtml
		});
	});
}

export { PageTitle as P };
//# sourceMappingURL=PageTitle.js-D99NSXzQ.js.map
