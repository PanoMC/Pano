import { Z as attr_class, X as attr, a0 as store_get, $ as ensure_array_like, a5 as escape_html, a2 as unsubscribe_stores, M as derived } from './server.js-D28cBEJ-.js';
import 'node:module';
import { $ as $format } from './runtime.js-CJgfVvxa.js';

//#region node_modules/@panomc/theme-core/src/lib/components/Pagination.svelte
function Pagination($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let { page = 1, totalPage = 1 } = $$props;
		const pages = derived(() => Array.from({ length: totalPage }, (_, i) => i + 1));
		$$renderer.push(`<nav><ul class="pagination pagination-sm mb-0 justify-content-start flex-wrap"><li${attr_class("page-item", void 0, { "disabled": parseInt(page) === 1 })}><button type="button" class="page-link"${attr("title", store_get($$store_subs ??= {}, "$_", $format)("components.pagination.previous-page"))}${attr("aria-hidden", parseInt(page) === 1)}><i class="fa-solid fa-caret-left"></i></button></li> <!--[-->`);
		const each_array = ensure_array_like(pages());
		for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
			let index = each_array[$$index];
			$$renderer.push(`<li${attr_class("page-item", void 0, { "active": parseInt(page) === index })}${attr("aria-current", parseInt(page) === index ? "page" : "")}><button type="button" class="page-link"${attr("aria-hidden", parseInt(page) === index)}>${escape_html(index)}</button></li>`);
		}
		$$renderer.push(`<!--]--> <li${attr_class("page-item", void 0, { "disabled": parseInt(page) === totalPage })}><button type="button" class="page-link"${attr("title", store_get($$store_subs ??= {}, "$_", $format)("components.pagination.next-page"))}${attr("aria-hidden", parseInt(page) === totalPage)}><i class="fa-solid fa-caret-right"></i></button></li></ul></nav>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
	});
}

export { Pagination as P };
//# sourceMappingURL=Pagination.js-CeyG1SGU.js.map
