import { e as error } from './exports2.js-DxZfja4I.js';
import { W as bind_props, T as writable, $ as ensure_array_like, a0 as store_get, a1 as spread_props, a2 as unsubscribe_stores } from './server.js-D28cBEJ-.js';
import { o as onDestroy } from './index-server2.js-DlblWyyK.js';
import './runtime.js-CJgfVvxa.js';
import { d as panoApi, g as executeSidebarLoad } from './PluginManager.js-B5x3OKEW.js';
import { r as resolveView } from './registry2.js-BubD3cPq.js';
import { d as ApiUtil } from './Store.js-C2vdyE6V.js';
import { P as PageTitle } from './PageTitle.js-D99NSXzQ.js';
import { P as PlayerHead } from './PlayerHead.js-Bggv1de7.js';
import { S as Sidebar } from './Sidebar.js-BwVxP8m2.js';
import { V as ViewComponent } from './ViewComponent.js-C6amYVVM.js';
import { P as PlayerStatusBadge, a as PlayerPermissionBadge } from './PlayerStatusBadge.js-DO05KLuW.js';
import { g as getPlayerProfile } from './profile.js-C7iU3TQf.js';

//#region node_modules/@panomc/theme-core/src/lib/components/sidebars/PlayerDetailSidebar.svelte
var data = writable({
	username: "",
	lastActivityTime: 0,
	inGame: false,
	permissionGroupName: "",
	banned: false
});
var load$1 = async (event) => {
	panoApi.ui.sidebar.register({
		sidebarId: "player-detail",
		id: "player-info",
		component: "local:player-info",
		priority: 100
	});
	await executeSidebarLoad("player-detail", event);
	data.set({
		...await ApiUtil.get({
			path: `/api/sidebars/profile/${event.params.player}`,
			request: event
		}),
		username: event.params.player
	});
};
String.prototype.capitalize = function() {
	return this.charAt(0).toUpperCase() + this.slice(1);
};
function PlayerDetailSidebar($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let checkTime = 0;
		let interval;
		let side = $$props["side"];
		onDestroy(() => {
			clearInterval(interval);
		});
		const items = panoApi.ui.sidebar.get("player-detail");
		Sidebar($$renderer, {
			side,
			children: ($$renderer) => {
				$$renderer.push(`<div class="vstack gap-3"><!--[-->`);
				const each_array = ensure_array_like(store_get($$store_subs ??= {}, "$items", items));
				for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
					let item = each_array[$$index];
					if (item.id === "player-info") {
						$$renderer.push("<!--[0-->");
						$$renderer.push(`<div class="card border-0 square-card-desktop svelte-1qyeccw"><div class="card-body vstack gap-3">`);
						PlayerHead($$renderer, {
							username: store_get($$store_subs ??= {}, "$data", data).username,
							inGame: store_get($$store_subs ??= {}, "$data", data).inGame,
							banned: store_get($$store_subs ??= {}, "$data", data).banned,
							lastActivityTime: store_get($$store_subs ??= {}, "$data", data).lastActivityTime,
							checkTime,
							width: "64",
							height: "64"
						});
						$$renderer.push(`<!----> `);
						PageTitle($$renderer, {
							title: store_get($$store_subs ??= {}, "$data", data).username,
							breadcrumb: false
						});
						$$renderer.push(`<!----> <div class="text-center">`);
						PlayerStatusBadge($$renderer, {
							banned: store_get($$store_subs ??= {}, "$data", data).banned,
							lastActivityTime: store_get($$store_subs ??= {}, "$data", data).lastActivityTime,
							inGame: store_get($$store_subs ??= {}, "$data", data).inGame,
							checkTime
						});
						$$renderer.push(`<!----></div> <div class="text-center">`);
						PlayerPermissionBadge($$renderer, { permissionGroupName: store_get($$store_subs ??= {}, "$data", data).permissionGroupName });
						$$renderer.push(`<!----></div></div></div>`);
					} else {
						$$renderer.push("<!--[-1-->");
						ViewComponent($$renderer, spread_props([{
							component: item.component,
							data: store_get($$store_subs ??= {}, "$data", data),
							checkTime
						}, item.props]));
					}
					$$renderer.push(`<!--]-->`);
				}
				$$renderer.push(`<!--]--></div>`);
			},
			$$slots: { default: true }
		});
		if ($$store_subs) unsubscribe_stores($$store_subs);
		bind_props($$props, { side });
	});
}
//#endregion
//#region node_modules/@panomc/theme-core/src/lib/ui-logics/page-logics/PlayerDetailPageLogics.js
/**
* @type {import("@sveltejs/kit").Load}
*/
async function processLoad(event) {
	const { parent } = event;
	await parent();
	let data = { registerDate: 0 };
	const [, profileBody] = await Promise.all([load$1(event), getPlayerProfile({
		username: event.params.player,
		request: event
	})]);
	if (profileBody.error) {
		if (profileBody.error === "NOT_EXISTS") throw error(404, profileBody.error);
		throw error(500, profileBody.error);
	}
	data = profileBody;
	return {
		...data,
		sidebar: PlayerDetailSidebar,
		sidebarProps: { side: "left" },
		pageTitle: "pages.player-profile.title"
	};
}
//#endregion
//#region node_modules/@panomc/theme-core/src/lib/pages/PlayerDetailPage.svelte
async function load(event) {
	const viewPromise = resolveView("PlayerDetailView", () => import('./PlayerDetailView.js-BOmTXMBa.js'));
	return {
		...await processLoad(event),
		View: await viewPromise
	};
}
function PlayerDetailPage($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		let data = $$props["data"];
		if (data.View) {
			$$renderer.push("<!--[-->");
			data.View($$renderer, { data });
			$$renderer.push("<!--]-->");
		} else {
			$$renderer.push("<!--[!-->");
			$$renderer.push("<!--]-->");
		}
		bind_props($$props, { data });
	});
}

export { PlayerDetailPage as P, load as l };
//# sourceMappingURL=PlayerDetailPage.js-rBYWXnsV.js.map
