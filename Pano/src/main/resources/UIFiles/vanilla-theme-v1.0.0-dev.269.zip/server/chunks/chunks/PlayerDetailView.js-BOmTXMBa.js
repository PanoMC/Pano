import { a5 as escape_html, a0 as store_get, a2 as unsubscribe_stores, W as bind_props } from './server.js-D28cBEJ-.js';
import { $ as $format } from './runtime.js-CJgfVvxa.js';
import { D as Date_1 } from './Date.js-ZK3lGml2.js';
import './uneval.js-BL1Qg77w.js';
import './rolldown-runtime.js-B5FuG9Gw.js';
import 'node:module';
import './language.util.js-C2xYQq5-.js';
import './internal.js-BlXt2rfE.js';
import './client.js-CPEkJ2-P.js';
import './shared.js-3i5_hmQ1.js';
import './exports.js-CKkpMUqI.js';
import './internal2.js-KmQU-gaY.js';
import './index-server2.js-DlblWyyK.js';
import './Store.js-C2vdyE6V.js';
import './exports2.js-DxZfja4I.js';
import './ToastContainer.js-CtmBBvhr.js';
import './tooltip.util.js-Bd9x5X7L.js';
import './stores.js-QbD2A2ib.js';
import './locale.js-DnnPB87K.js';
import './format.js-CzDFIcjs.js';

//#region node_modules/@panomc/theme-core/src/lib/views/PlayerDetailView.svelte
function PlayerDetailView($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let data = $$props["data"];
		$$renderer.push(`<div class="vstack gap-3"><div class="card"><div class="card-header">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.player-profile.title"))}</div> <table class="table"><tbody><tr><td>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.player-profile.register-date"))}</td><td>`);
		Date_1($$renderer, { time: data.registerDate });
		$$renderer.push(`<!----></td></tr></tbody></table></div></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
		bind_props($$props, { data });
	});
}

export { PlayerDetailView as default };
//# sourceMappingURL=PlayerDetailView.js-BOmTXMBa.js.map
