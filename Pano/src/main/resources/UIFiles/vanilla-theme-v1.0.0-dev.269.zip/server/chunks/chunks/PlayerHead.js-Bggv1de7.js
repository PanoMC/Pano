import { V as fallback, X as attr, Y as stringify, a0 as store_get, Z as attr_class, a2 as unsubscribe_stores, W as bind_props } from './server.js-D28cBEJ-.js';
import './runtime.js-CJgfVvxa.js';
import { c as avatarVersion } from './Store.js-C2vdyE6V.js';
import 'node:module';
import './client.js-CPEkJ2-P.js';
import './tooltip.util.js-Bd9x5X7L.js';

//#region node_modules/@panomc/theme-core/src/lib/components/PlayerHead.svelte
function PlayerHead($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let isOnline;
		let username = $$props["username"];
		let width = fallback($$props["width"], 64);
		let height = fallback($$props["height"], 64);
		let checkTime = $$props["checkTime"];
		let inGame = fallback($$props["inGame"], false);
		let lastActivityTime = $$props["lastActivityTime"];
		let banned = $$props["banned"];
		String.prototype.capitalize = function() {
			return this.charAt(0).toUpperCase() + this.slice(1);
		};
		isOnline = lastActivityTime > Date.now() - 300 * 1e3 || inGame;
		if (lastActivityTime) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<img${attr("src", `/api/profile/picture/${stringify(username)}?${stringify(store_get($$store_subs ??= {}, "$avatarVersion", avatarVersion))}`)}${attr_class("img-thumbnail rounded d-block m-auto", void 0, {
				"border": banned || isOnline,
				"border-3": banned || isOnline,
				"border-success": !banned && isOnline,
				"border-danger": banned
			})}${attr("width", width)}${attr("height", height)}${attr("alt", username)} onload="this.__e=event" onerror="this.__e=event"/>`);
		} else {
			$$renderer.push("<!--[-1-->");
			$$renderer.push(`<img${attr("src", `/api/profile/picture/${stringify(username)}?${stringify(store_get($$store_subs ??= {}, "$avatarVersion", avatarVersion))}`)}${attr_class("rounded d-block m-auto", void 0, {
				"border": banned,
				"border-3": banned,
				"border-danger": banned
			})}${attr("width", width)}${attr("height", height)}${attr("alt", username)}/>`);
		}
		$$renderer.push(`<!--]-->`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
		bind_props($$props, {
			username,
			width,
			height,
			checkTime,
			inGame,
			lastActivityTime,
			banned
		});
	});
}

export { PlayerHead as P };
//# sourceMappingURL=PlayerHead.js-Bggv1de7.js.map
