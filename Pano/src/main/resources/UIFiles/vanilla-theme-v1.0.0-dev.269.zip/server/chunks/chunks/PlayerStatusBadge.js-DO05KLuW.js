import { V as fallback, a5 as escape_html, a0 as store_get, a2 as unsubscribe_stores, W as bind_props } from './server.js-D28cBEJ-.js';
import { $ as $format } from './runtime.js-CJgfVvxa.js';
import './tooltip.util.js-Bd9x5X7L.js';

//#region node_modules/@panomc/theme-core/src/lib/components/PlayerPermissionBadge.svelte
String.prototype.capitalize = function() {
	return this.charAt(0).toUpperCase() + this.slice(1);
};
function PlayerPermissionBadge($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let permissionGroupName = $$props["permissionGroupName"];
		$$renderer.push(`<span class="badge rounded-pill text-bg-secondary">`);
		if (permissionGroupName) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`${escape_html(permissionGroupName.capitalize())}`);
		} else {
			$$renderer.push("<!--[-1-->");
			$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.player-permission-badge.player"))}`);
		}
		$$renderer.push(`<!--]--></span>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
		bind_props($$props, { permissionGroupName });
	});
}
//#endregion
//#region node_modules/@panomc/theme-core/src/lib/components/PlayerStatusBadge.svelte
String.prototype.capitalize = function() {
	return this.charAt(0).toUpperCase() + this.slice(1);
};
function PlayerStatusBadge($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let isOnline;
		let banned = fallback($$props["banned"], false);
		let lastActivityTime = fallback($$props["lastActivityTime"], 0);
		let inGame = fallback($$props["inGame"], false);
		let checkTime = fallback($$props["checkTime"], 0);
		isOnline = lastActivityTime > Date.now() - 300 * 1e3 || inGame;
		if (banned) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<div class="badge rounded-pill text-bg-danger"><i class="fa-solid fa-hammer me-1"></i> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.player-status-badge.banned"))}</div>`);
		} else if (isOnline) {
			$$renderer.push("<!--[1-->");
			$$renderer.push(`<div class="badge rounded-pill text-bg-success"><span>`);
			if (inGame) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<i class="fa-solid fa-gamepad me-1"></i>`);
			} else {
				$$renderer.push("<!--[-1-->");
				$$renderer.push(`<i class="fa-solid fa-globe me-1"></i>`);
			}
			$$renderer.push(`<!--]--> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.player-status-badge.online"))}</span></div>`);
		} else {
			$$renderer.push("<!--[-1-->");
			$$renderer.push(`<div class="badge rounded-pill text-bg-primary"><span>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.player-status-badge.offline"))}</span></div>`);
		}
		$$renderer.push(`<!--]-->`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
		bind_props($$props, {
			banned,
			lastActivityTime,
			inGame,
			checkTime
		});
	});
}

export { PlayerStatusBadge as P, PlayerPermissionBadge as a };
//# sourceMappingURL=PlayerStatusBadge.js-DO05KLuW.js.map
