import { b as __toESM } from './rolldown-runtime.js-B5FuG9Gw.js';
import { e as error } from './exports2.js-DxZfja4I.js';
import { b as base } from './internal.js-BlXt2rfE.js';
import { a4 as get, T as writable, U as derived$1 } from './server.js-D28cBEJ-.js';
import './client.js-CPEkJ2-P.js';
import { c as avatarVersion, d as ApiUtil } from './Store.js-C2vdyE6V.js';
import fs from 'fs';

//#region node_modules/@panomc/sdk/src/internal/pano-context.js
var GLOBAL_KEY$1 = "__PANO_CONTEXT__";
function getStore$1() {
	if (!globalThis[GLOBAL_KEY$1]) globalThis[GLOBAL_KEY$1] = {
		context: {},
		listeners: []
	};
	return globalThis[GLOBAL_KEY$1];
}
/**
* @typedef {import('../types.js').Pano} Pano
*/
/**
* @param {Partial<Pano>} partial
*/
function setPanoContext(partial) {
	const store = getStore$1();
	if (typeof partial !== "object" || partial === null) {
		console.warn("[PanoSDK] setPanoContext expects an object");
		return;
	}
	Object.assign(store.context, partial);
	store.listeners.forEach((fn) => {
		try {
			fn(store.context);
		} catch (e) {
			console.error("[PanoSDK] listener error", e);
		}
	});
}
//#endregion
//#region node_modules/@panomc/sdk/core/js/RouteMatcher.js
/**
* Simple route matcher that supports literals, dynamic segments [param],
* catch-all segments [...param], and basic regex patterns.
*/
var RouteMatcher = class {
	/**
	* Matches a path against a pattern.
	* @param {string} pattern - The route pattern (e.g., '/announcements/[id]')
	* @param {string} path - The actual path (e.g., '/announcements/123')
	* @returns {object|null} - Params object if matched, null otherwise
	*/
	static match(pattern, path) {
		const [pathOnly] = path.split("?");
		const normalizedPath = pathOnly === "/" ? "/" : pathOnly.replace(/\/$/, "");
		const normalizedPattern = pattern === "/" ? "/" : pattern.replace(/\/$/, "");
		if (normalizedPattern === normalizedPath) return {};
		if (pattern.startsWith("re:")) try {
			const regex = new RegExp(`^(?:${pattern.slice(3)})$`);
			const match = normalizedPath.match(regex);
			if (match) return match.groups || {};
		} catch (e) {
			console.error("Invalid regex pattern:", pattern, e);
		}
		const patternSegments = normalizedPattern.split("/").filter(Boolean);
		const pathSegments = normalizedPath.split("/").filter(Boolean);
		const params = {};
		const catchAllIndex = patternSegments.findIndex((s) => s.startsWith("[...") && s.endsWith("]"));
		if (catchAllIndex !== -1) {
			if (catchAllIndex !== patternSegments.length - 1) return null;
			if (pathSegments.length < catchAllIndex) return null;
			for (let i = 0; i < catchAllIndex; i++) if (!this.segmentsMatch(patternSegments[i], pathSegments[i], params)) return null;
			const paramName = patternSegments[catchAllIndex].slice(4, -1);
			params[paramName] = pathSegments.slice(catchAllIndex).join("/");
			return params;
		}
		if (patternSegments.length !== pathSegments.length) return null;
		for (let i = 0; i < patternSegments.length; i++) if (!this.segmentsMatch(patternSegments[i], pathSegments[i], params)) return null;
		return params;
	}
	static segmentsMatch(patternSegment, pathSegment, params) {
		if (patternSegment.startsWith("[") && patternSegment.endsWith("]")) {
			const paramName = patternSegment.slice(1, -1);
			params[paramName] = pathSegment;
			return true;
		}
		if (patternSegment.startsWith(":")) {
			const paramName = patternSegment.slice(1);
			params[paramName] = pathSegment;
			return true;
		}
		return patternSegment === pathSegment;
	}
};
/**
* Canonical form of a route key/path used for the exact-match fast path: query stripped and a
* single trailing slash removed (but `/` preserved). Used at BOTH registration and lookup so
* `/foo` and `/foo/` collapse to one entry and the exact-match map lookup always hits instead
* of falling through to the slower (and buggier) regex/segment branch.
* @param {string} path
* @returns {string}
*/
function canonicalizeRouteKey(path) {
	const [pathOnly] = String(path).split("?");
	return pathOnly === "/" ? "/" : pathOnly.replace(/\/$/, "");
}
/**
* Finds a registered page matching the given path.
* @param {Object} registeredPages - Map of patterns to page objects
* @param {string} path - The path to match
* @returns {Object|null} - The matching page object with params, or null
*/
function findMatch(registeredPages, path) {
	const normalizedPath = canonicalizeRouteKey(path);
	if (registeredPages[normalizedPath]) return {
		...registeredPages[normalizedPath],
		params: {}
	};
	for (const pattern in registeredPages) {
		const params = RouteMatcher.match(pattern, path);
		if (params) return {
			...registeredPages[pattern],
			params
		};
	}
	return null;
}
var baseAPI = {
	isPanel: base === "/panel",
	debug: false
};
var pageAPI = { page: {
	register(page = {
		path: "",
		component: Promise,
		systemLayout: String,
		restLayout: Boolean
	}) {
		registeredPages[canonicalizeRouteKey(page.path)] = page;
	},
	unregister(path = "") {
		delete registeredPages[canonicalizeRouteKey(path)];
	},
	isPluginPage: (path = "") => registeredPages[canonicalizeRouteKey(path)] !== void 0
} };
//#endregion
//#region node_modules/@panomc/theme-core/src/lib/orderNavLinks.util.js
/**
* Applies a saved id order to a combined list (native + plugin links).
* Matches the theme settings UI: dedupe order, then known order first, then
* remaining links in source order.
*
* @template {{ id: string }} T
* @param {T[]} allLinks
* @param {string[] | undefined} savedOrder
* @returns {T[]}
*/
function orderLinksBySavedOrder(allLinks, savedOrder) {
	let orderIds = savedOrder || [];
	orderIds = [...new Set(orderIds)];
	const sorted = [];
	const sourceMap = new Map(allLinks.map((l) => [l.id, l]));
	for (const id of orderIds) if (sourceMap.has(id)) {
		sorted.push(sourceMap.get(id));
		sourceMap.delete(id);
	}
	for (const link of sourceMap.values()) sorted.push(link);
	return sorted;
}
/**
* Stable order for plugin-registered site nav links (same result regardless of
* which plugin finishes loading first). Uses numeric `priority` when set (lower
* = earlier), then `href`, then `text`.
*
* @param {unknown[] | undefined} links
* @returns {unknown[]}
*/
function sortSiteNavLinks(links) {
	if (!Array.isArray(links) || links.length < 2) return links || [];
	return links.slice().sort((a, b) => {
		const ap = a && typeof a.priority === "number" && !Number.isNaN(a.priority) ? a.priority : 1e6;
		const bp = b && typeof b.priority === "number" && !Number.isNaN(b.priority) ? b.priority : 1e6;
		if (ap !== bp) return ap - bp;
		const hA = String(a?.href ?? "");
		const hB = String(b?.href ?? "");
		if (hA !== hB) return hA.localeCompare(hB, void 0, {
			numeric: true,
			sensitivity: "base"
		});
		return String(a?.text ?? "").localeCompare(String(b?.text ?? ""), void 0, { sensitivity: "base" });
	});
}
//#endregion
//#region node_modules/@panomc/theme-core/src/plugin-engine/engine.js
/**
* Pano plugin engine — the profile-agnostic machinery shared by every PluginAPI profile
* (the theme profile in `$lib/PluginAPI.js` and the panel profile in panel-ui).
*
* A "profile" is the thin file plugins actually import (`$lib/PluginAPI.js`). It composes the
* factories exported here — {@link createLifecycleRegistry}, {@link createHookEngine},
* {@link createSlotRegistry} — into its own `pano.*` namespace tree and re-exports the host
* contract (`init`, `panoApiClient`, `panoApiServer`). All the ordering/caching/SSR-safety
* fixes live here once, so both profiles get them.
*
* Nothing in this module reads SvelteKit app aliases ($app/environment, the PluginManager) or a
* theme's utils directly — the profile injects `plugins` and `browser` so this file stays a pure,
* portable engine that both the theme and panel bundles can consume.
*/
/**
* Deduplicate items by id, keeping the last occurrence. Items without an id are all kept
* (each gets a fresh Symbol key). Mutates `arr` in place.
*/
function deduplicateById(arr) {
	const seen = /* @__PURE__ */ new Map();
	for (const item of arr) if (item.id) seen.set(item.id, item);
	else seen.set(Symbol(), item);
	arr.length = 0;
	arr.push(...seen.values());
}
/**
* Deep-clone a slot item's serializable parts without touching its `component`
* (a function / component module that is not structured-cloneable). Used on the server so
* resolved load() props are merged into a per-request copy instead of the shared global entry.
*/
function structuredCloneSafe(item) {
	const { component, ...rest } = item;
	let cloned;
	try {
		cloned = structuredClone(rest);
	} catch {
		try {
			cloned = JSON.parse(JSON.stringify(rest));
		} catch {
			cloned = {
				...rest,
				props: rest.props ? { ...rest.props } : void 0
			};
		}
	}
	cloned.component = component;
	return cloned;
}
/**
* Sort hooks by their stable registration index. Sorting by the hook's importer `.toString()`
* is unsafe — that source contains build-specific chunk hashes that differ between the server
* and client bundles, so the two sides produce different orders -> hydration mismatch. The
* monotonic `_seq` captured at register time is identical across bundles, so it is the only
* deterministic key.
*/
function sortHooks(rawHooks) {
	return [...rawHooks].sort((a, b) => {
		const seqA = a._seq ?? 0;
		const seqB = b._seq ?? 0;
		if (seqA !== seqB) return seqA - seqB;
		return String(a.id ?? a.name ?? "").localeCompare(String(b.id ?? b.name ?? ""));
	});
}
/**
* Comparator for view-slot items: higher priority first, then stable registration sequence
* (so equal-priority items keep a stable order across SSR and client instead of depending on
* array insertion order), then id as the final deterministic tiebreak.
*/
function compareViewItems(a, b) {
	if (b.priority !== a.priority) return b.priority - a.priority;
	const seqA = a._seq ?? 0;
	const seqB = b._seq ?? 0;
	if (seqA !== seqB) return seqA - seqB;
	return String(a.id ?? "").localeCompare(String(b.id ?? ""));
}
/** A private monotonic counter. Each registry gets its own so hook/view sequences never collide. */
function createSeq() {
	let n = 0;
	return () => n++;
}
/**
* Named lifecycle hooks (theme:profile:load, panel:posts:load, …). Handlers run with
* Promise.allSettled so one throwing handler never blocks the others.
*/
function createLifecycleRegistry() {
	const lifecycleHandlers = writable({});
	function on(name, handler) {
		lifecycleHandlers.update((h) => {
			if (!h[name]) h[name] = [];
			h[name].push(handler);
			return h;
		});
	}
	async function executeLifecycle(name, data, event) {
		const handlers = get(lifecycleHandlers)[name] || [];
		await Promise.allSettled(handlers.map(async (handler) => {
			try {
				await handler(data, event);
			} catch (e) {
				console.error(`[Lifecycle:${name}] failed`, e);
			}
		}));
	}
	function reset() {
		lifecycleHandlers.set({});
	}
	return {
		lifecycleHandlers,
		on,
		executeLifecycle,
		reset
	};
}
/**
* Registry of render "hooks" — components mounted into named extension points that can also
* contribute load() props. Deterministic ordering (via {@link sortHooks}) is crucial for
* server/client prop synchronization; without it SSR and CSR insertion order drift and hydrate
* out of sync.
*/
function createHookEngine() {
	const hooks = writable({});
	const nextSeq = createSeq();
	const hookExecutionCache = /* @__PURE__ */ new WeakMap();
	const componentLoadCache = /* @__PURE__ */ new WeakMap();
	function register(options) {
		const { name } = options;
		const entry = options._seq === void 0 ? {
			...options,
			_seq: nextSeq()
		} : options;
		hooks.update((h) => {
			if (!h[name]) h[name] = [];
			h[name].push(entry);
			return h;
		});
	}
	function getHook(name) {
		return derived$1(hooks, ($h) => {
			return sortHooks($h[name] || []);
		});
	}
	function setVisible(name, component, visible) {
		hooks.update((h) => {
			if (!h[name]) return h;
			const idx = h[name].findIndex((item) => item.component === component || item.component?._original === component);
			if (idx !== -1) h[name][idx].invisible = !visible;
			return h;
		});
	}
	async function executeHookLoad(name, originalEvent) {
		const event = originalEvent ? {
			...originalEvent,
			hookName: name
		} : { hookName: name };
		const cacheKey = originalEvent && typeof originalEvent === "object" ? originalEvent : event;
		if (cacheKey) {
			if (!hookExecutionCache.has(cacheKey)) hookExecutionCache.set(cacheKey, {});
			const cache = hookExecutionCache.get(cacheKey);
			if (cache[name]) return cache[name];
		}
		let list = sortHooks(get(hooks)[name] || []);
		const results = await Promise.all(list.map(async (entry) => {
			const raw = entry.component || entry;
			let module = raw;
			if (typeof raw === "function" && !raw.prototype) {
				try {
					module = await raw();
				} catch (e) {
					console.error(`[Hook:${name}] Failed to load plugin module`, e);
					return {};
				}
				hooks.update((h) => {
					if (h[name]) {
						const actualIdx = h[name].findIndex((item) => (item.component || item) === raw);
						if (actualIdx !== -1) {
							const resolved = {
								...module,
								_original: raw
							};
							if (module.default) resolved.default = module.default;
							if (h[name][actualIdx].component) h[name][actualIdx].component = resolved;
							else h[name][actualIdx] = {
								...resolved,
								_seq: h[name][actualIdx]._seq
							};
						}
					}
					return h;
				});
			} else if (typeof raw !== "object" || !raw.default) module = { default: raw };
			let props = {};
			const Component = module.default || module;
			const loadFn = module.load || Component && Component.load;
			if (loadFn && !entry.skipLoad) {
				let eventCache = null;
				if (cacheKey) {
					if (!componentLoadCache.has(cacheKey)) componentLoadCache.set(cacheKey, /* @__PURE__ */ new Map());
					eventCache = componentLoadCache.get(cacheKey);
				}
				if (eventCache && eventCache.has(module)) props = eventCache.get(module);
				else try {
					props = await loadFn(event);
					if (eventCache) eventCache.set(module, props);
				} catch (e) {
					console.warn(`[Hook:${name}] Load failed`, e);
				}
			}
			return props && typeof props === "object" ? { ...props } : {};
		}));
		if (cacheKey && results.length > 0) {
			const cache = hookExecutionCache.get(cacheKey);
			cache[name] = results;
		}
		return results;
	}
	function reset() {
		hooks.set({});
	}
	return {
		hooks,
		register,
		get: getHook,
		setVisible,
		executeHookLoad,
		reset
	};
}
/**
* Registry of view-slot items — the components plugins inject into named containers
* (profile-content, navbar-right, login-content, …), plus the SSR-safe load() pipeline that
* resolves their code-split modules and merges their load() props.
*
* @param {object} deps
* @param {() => Record<string, any>} deps.getPlugins  returns the current plugin map (already
*   `get()`-resolved from the PluginManager `plugins` store). A thunk, not the store itself, so
*   this factory never reads the store at construction — the PluginManager<->PluginAPI import
*   cycle would otherwise put that binding in the temporal dead zone at module-eval time.
* @param {boolean} deps.browser  `$app/environment`'s browser flag — decides whether to clone
*   items per-request on the server.
* @param {(name: string, data: any, event: any) => Promise<void>} [deps.executeLifecycle]
*   the lifecycle registry's executor, used by executeViewLoad/executeSidebarLoad.
* @param {string} [deps.lifecyclePrefix]  lifecycle-event namespace (default "theme").
*/
function createSlotRegistry({ getPlugins, browser, executeLifecycle, lifecyclePrefix = "theme" }) {
	const uiItems = writable({});
	const nextSeq = createSeq();
	const uiLoadedCacheKeys = /* @__PURE__ */ new Map();
	function generatePluginCacheKey() {
		const loadedPlugins = getPlugins();
		if (!loadedPlugins || typeof loadedPlugins !== "object") return "";
		return Object.keys(loadedPlugins).sort().map((pluginId) => {
			const plugin = loadedPlugins[pluginId];
			return `${pluginId}:${plugin.version?.version || plugin.version || "dev"}`;
		}).join(",");
	}
	/** The register+dedupe pattern shared by every `.content.edit` / `.cardRows.edit` helper. */
	function edit(slotId, callback) {
		uiItems.update((items) => {
			if (!items[slotId]) items[slotId] = [];
			callback(items[slotId]);
			deduplicateById(items[slotId]);
			return items;
		});
	}
	/** Upsert a raw item by id (no dedup/priority/seq stamping) — used by alternativeMethods.add. */
	function upsert(slotId, item) {
		uiItems.update((items) => {
			if (!items[slotId]) items[slotId] = [];
			const existing = items[slotId].findIndex((i) => i.id === item.id);
			if (existing !== -1) items[slotId][existing] = item;
			else items[slotId].push(item);
			return items;
		});
	}
	function register(options) {
		const { viewId, id, component, priority = 10 } = options;
		uiItems.update((items) => {
			if (!items[viewId]) items[viewId] = [];
			const existingIdx = items[viewId].findIndex((i) => i.id === id);
			if (existingIdx !== -1) items[viewId][existingIdx] = {
				...items[viewId][existingIdx],
				component,
				priority,
				_seq: items[viewId][existingIdx]._seq ?? nextSeq()
			};
			else items[viewId].push({
				id,
				component,
				priority,
				hidden: false,
				_seq: nextSeq()
			});
			return items;
		});
	}
	function hide(viewId, id) {
		uiItems.update((items) => {
			if (!items[viewId]) return items;
			const item = items[viewId].find((i) => i.id === id);
			if (item) item.hidden = true;
			return items;
		});
	}
	function show(viewId, id) {
		uiItems.update((items) => {
			if (!items[viewId]) return items;
			const item = items[viewId].find((i) => i.id === id);
			if (item) item.hidden = false;
			return items;
		});
	}
	function move(viewId, id, priority) {
		uiItems.update((items) => {
			if (!items[viewId]) return items;
			const item = items[viewId].find((i) => i.id === id);
			if (item) item.priority = priority;
			return items;
		});
	}
	function getView(viewId) {
		return derived$1(uiItems, ($items) => {
			return ($items[viewId] || []).filter((item) => !item.hidden).sort(compareViewItems);
		});
	}
	async function executeComponentLoad(containerId, type, event) {
		const freshPluginCacheKey = generatePluginCacheKey();
		const items = get(uiItems)[containerId] || [];
		const resolvedItems = await Promise.all(items.map(async (item) => {
			let module = item.component;
			if (typeof item.component === "function" && !item.component.prototype) try {
				module = await item.component();
			} catch (e) {
				console.error(`[${type}:${containerId}] Failed to load component ${item.id}`, e);
				return item;
			}
			if (!module) return item;
			const Component = module.default || module;
			const loadFn = module.load || Component && Component.load;
			let props = null;
			if (loadFn) try {
				props = await loadFn(event);
			} catch (e) {
				console.warn(`[${type}:${containerId}:${item.id}] Load failed`, e);
			}
			const updatedItem = {
				...structuredCloneSafe(item),
				component: module
			};
			if (props && typeof props === "object" && Object.keys(props).length > 0) {
				if (!updatedItem.props) updatedItem.props = {};
				updatedItem.props.data = {
					...updatedItem.props.data,
					...props
				};
			}
			return updatedItem;
		}));
		uiItems.update((current) => ({
			...current,
			[containerId]: resolvedItems
		}));
		uiLoadedCacheKeys.set(containerId, freshPluginCacheKey);
		return resolvedItems;
	}
	async function executeViewLoad(viewId, event) {
		if (executeLifecycle) await executeLifecycle(`${lifecyclePrefix}:view:${viewId}:load`, {}, event);
		return await executeComponentLoad(viewId, "View", event);
	}
	async function executeSidebarLoad(sidebarId, event) {
		if (executeLifecycle) await executeLifecycle(`${lifecyclePrefix}:sidebar:${sidebarId}:load`, {}, event);
		return await executeComponentLoad(sidebarId, "Sidebar", event);
	}
	function reset() {
		uiItems.set({});
		uiLoadedCacheKeys.clear();
	}
	return {
		uiItems,
		uiLoadedCacheKeys,
		generatePluginCacheKey,
		edit,
		upsert,
		register,
		hide,
		show,
		move,
		get: getView,
		executeComponentLoad,
		executeViewLoad,
		executeSidebarLoad,
		reset
	};
}
//#endregion
//#region node_modules/@panomc/theme-core/src/lib/PluginAPI.js
var lifecycle = createLifecycleRegistry();
var hooks = createHookEngine();
var slots = createSlotRegistry({
	getPlugins: () => get(plugins),
	browser: false,
	executeLifecycle: lifecycle.executeLifecycle,
	lifecyclePrefix: "theme"
});
var siteNavLinks = writable([]);
async function init() {
	hooks.reset();
	slots.reset();
	siteNavLinks.set([]);
	lifecycle.reset();
}
var executeLifecycle = lifecycle.executeLifecycle;
var executeSidebarLoad = slots.executeSidebarLoad;
var executeViewLoad = slots.executeViewLoad;
var executeHookLoad = hooks.executeHookLoad;
var panoApi = {
	...baseAPI,
	ui: {
		...pageAPI,
		nav: {
			site: {
				editNavLinks(callback) {
					siteNavLinks.update((links) => {
						return sortSiteNavLinks(callback(links) || links);
					});
				},
				getNavLinks() {
					return siteNavLinks;
				}
			},
			profileDropdown: {
				edit(callback) {
					slots.edit("navbar-profile-dropdown", callback);
				},
				get() {
					return panoApi.ui.view.get("navbar-profile-dropdown");
				}
			},
			rightComponents: {
				edit(callback) {
					slots.edit("navbar-right", callback);
				},
				get() {
					return panoApi.ui.view.get("navbar-right");
				}
			},
			onLoad(handler) {
				panoApi.ui.lifecycle.on("theme:navbar:load", handler);
			}
		},
		profile: {
			content: {
				edit(callback) {
					slots.edit("profile-content", callback);
				},
				get() {
					return panoApi.ui.view.get("profile-content");
				}
			},
			cardRows: {
				edit(callback) {
					slots.edit("profile-card-rows", callback);
				},
				get() {
					return panoApi.ui.view.get("profile-card-rows");
				}
			},
			onLoad(handler) {
				panoApi.ui.lifecycle.on("theme:profile:load", handler);
			}
		},
		settings: {
			content: {
				edit(callback) {
					slots.edit("settings-content", callback);
				},
				get() {
					return panoApi.ui.view.get("settings-content");
				}
			},
			cardRows: {
				edit(callback) {
					slots.edit("settings-card-rows", callback);
				},
				get() {
					return panoApi.ui.view.get("settings-card-rows");
				}
			},
			onLoad(handler) {
				panoApi.ui.lifecycle.on("theme:settings:load", handler);
			}
		},
		tickets: {
			content: {
				edit(callback) {
					slots.edit("tickets-content", callback);
				},
				get() {
					return panoApi.ui.view.get("tickets-content");
				}
			},
			onLoad(handler) {
				panoApi.ui.lifecycle.on("theme:tickets:load", handler);
			}
		},
		auth: {
			login: {
				content: {
					edit(callback) {
						slots.edit("login-content", callback);
					},
					get() {
						return panoApi.ui.view.get("login-content");
					}
				},
				alternativeMethods: {
					add(method) {
						slots.upsert("login-alt-methods", method);
					},
					get() {
						return panoApi.ui.view.get("login-alt-methods");
					}
				},
				onLoad(handler) {
					panoApi.ui.lifecycle.on("theme:login:load", handler);
				},
				async load(event) {
					const data = {
						error: null,
						username: null,
						event
					};
					await executeLifecycle("theme:login:load", data, event);
					await executeViewLoad("login-content", event);
					await executeViewLoad("login-alt-methods", event);
					return data;
				},
				form: { async get() {
					const { resolveView } = await import('./registry.js-thvVliUS.js');
					return resolveView("LoginFormBody", () => import('./LoginFormBody.js-COLW4b9Y.js'));
				} }
			},
			register: {
				content: {
					edit(callback) {
						slots.edit("register-content", callback);
					},
					get() {
						return panoApi.ui.view.get("register-content");
					}
				},
				alternativeMethods: {
					add(method) {
						slots.upsert("register-alt-methods", method);
					},
					get() {
						return panoApi.ui.view.get("register-alt-methods");
					}
				},
				onLoad(handler) {
					panoApi.ui.lifecycle.on("theme:register:load", handler);
				},
				async load(event) {
					const data = {
						error: null,
						username: null,
						event
					};
					await executeLifecycle("theme:register:load", data, event);
					await executeViewLoad("register-content", event);
					await executeViewLoad("register-alt-methods", event);
					return data;
				},
				form: { async get() {
					const { resolveView } = await import('./registry.js-thvVliUS.js');
					return resolveView("RegisterForm", () => import('./RegisterForm2.js-DJ_aRpR2.js'));
				} }
			},
			resetPassword: {
				content: {
					edit(callback) {
						slots.edit("reset-password-content", callback);
					},
					get() {
						return panoApi.ui.view.get("reset-password-content");
					}
				},
				onLoad(handler) {
					panoApi.ui.lifecycle.on("theme:reset-password:load", handler);
				}
			},
			activate: {
				content: {
					edit(callback) {
						slots.edit("activate-content", callback);
					},
					get() {
						return panoApi.ui.view.get("activate-content");
					}
				},
				onLoad(handler) {
					panoApi.ui.lifecycle.on("theme:activate:load", handler);
				}
			},
			activateNewEmail: {
				content: {
					edit(callback) {
						slots.edit("activate-new-email-content", callback);
					},
					get() {
						return panoApi.ui.view.get("activate-new-email-content");
					}
				},
				onLoad(handler) {
					panoApi.ui.lifecycle.on("theme:activate-new-email:load", handler);
				}
			},
			renewPassword: {
				content: {
					edit(callback) {
						slots.edit("renew-password-content", callback);
					},
					get() {
						return panoApi.ui.view.get("renew-password-content");
					}
				},
				onLoad(handler) {
					panoApi.ui.lifecycle.on("theme:renew-password:load", handler);
				}
			}
		},
		app: { onLoad(handler) {
			panoApi.ui.lifecycle.on("theme:app:load", handler);
		} },
		view: {
			register(options) {
				slots.register(options);
			},
			hide(viewId, id) {
				slots.hide(viewId, id);
			},
			show(viewId, id) {
				slots.show(viewId, id);
			},
			move(viewId, id, priority) {
				slots.move(viewId, id, priority);
			},
			get(viewId) {
				return slots.get(viewId);
			},
			onLoad(viewId, handler) {
				panoApi.ui.lifecycle.on(`theme:view:${viewId}:load`, handler);
			},
			async load(viewId, event) {
				return await executeViewLoad(viewId, event);
			}
		},
		sidebar: {
			register(options) {
				const { sidebarId, ...rest } = options;
				panoApi.ui.view.register({
					viewId: sidebarId,
					...rest
				});
			},
			hide(sidebarId, id) {
				panoApi.ui.view.hide(sidebarId, id);
			},
			show(sidebarId, id) {
				panoApi.ui.view.show(sidebarId, id);
			},
			move(sidebarId, id, priority) {
				panoApi.ui.view.move(sidebarId, id, priority);
			},
			get(sidebarId) {
				return panoApi.ui.view.get(sidebarId);
			},
			onLoad(sidebarId, handler) {
				panoApi.ui.lifecycle.on(`theme:sidebar:${sidebarId}:load`, handler);
			}
		},
		post: { onLoad(handler) {
			panoApi.ui.lifecycle.on("theme:post-detail:load", handler);
		} },
		support: { onLoad(handler) {
			panoApi.ui.lifecycle.on("theme:support:load", handler);
		} },
		lifecycle: {
			on(name, handler) {
				lifecycle.on(name, handler);
			},
			async execute(name, data = {}, event) {
				await lifecycle.executeLifecycle(name, data, event);
				return data;
			}
		},
		hook: {
			register(options) {
				hooks.register(options);
			},
			get(name) {
				return hooks.get(name);
			},
			setVisible(name, component, visible) {
				hooks.setVisible(name, component, visible);
			}
		},
		avatar: {
			updateVersion() {
				avatarVersion.set(`&v=${Date.now()}`);
			},
			getVersion() {
				return avatarVersion;
			}
		}
	}
};
var panoApiServer = { ...panoApi };
var panoApiClient = { ...panoApi };
//#endregion
//#region node_modules/@panomc/sdk/src/api/plugin-context.js
var GLOBAL_KEY = "__PANO_PLUGIN_CONTEXTS__";
function getStore() {
	if (!globalThis[GLOBAL_KEY]) globalThis[GLOBAL_KEY] = Object.create(null);
	return globalThis[GLOBAL_KEY];
}
function createPluginContext(pluginId) {
	if (!pluginId) throw new Error("[PanoSDK] pluginId is required");
	const store = getStore();
	if (!store[pluginId]) store[pluginId] = {
		context: {},
		listeners: []
	};
	const pluginStore = store[pluginId];
	return {
		context: pluginStore.context,
		set(partial) {
			if (typeof partial !== "object" || partial === null) return;
			Object.assign(pluginStore.context, partial);
			pluginStore.listeners.forEach((fn) => {
				try {
					fn(pluginStore.context);
				} catch (e) {
					console.error(`[PanoSDK][${pluginId}] listener error`, e);
				}
			});
		},
		subscribe(fn) {
			pluginStore.listeners.push(fn);
			return () => {
				pluginStore.listeners = pluginStore.listeners.filter((l) => l !== fn);
			};
		},
		destroy() {
			delete store[pluginId];
		}
	};
}
//#endregion
//#region node_modules/@panomc/sdk/src/api/plugin.js
/**
* @typedef {import('../types.js').Pano} Pano
* @typedef {import('../types.js').PanoPluginContext} PanoPluginContext
*/
var PanoPlugin = class {
	static isPanoPlugin = true;
	/** @type {Pano} */
	pano;
	/** @type {PanoPluginContext} */
	contextApi;
	/** @type {any} */
	context;
	constructor({ pluginId, scope } = {}) {
		if (!pluginId) throw new Error("[PanoPlugin] pluginId is required");
		this.contextApi = createPluginContext(pluginId);
		this.context = this.contextApi.context;
		this._unsubscribers = [];
	}
	/**
	* @param {Pano} pano
	*/
	onLoad(pano) {}
	onUnload() {}
	/** plugin context helper */
	setContext(partial) {
		this.contextApi.set(partial);
	}
	/** internal cleanup */
	__destroy() {
		this._unsubscribers.forEach((fn) => fn());
		this.contextApi.destroy?.();
		this.onUnload();
	}
};
//#endregion
//#region node_modules/@panomc/sdk/core/js/PluginManager.js
var registeredPages = {};
var path;
var url;
var admZip;
var serverSidePrepared = false;
var serverSideInitialized = false;
var lastProcessedBackendHash = null;
var lastProcessedFrontendHash = null;
var preparePluginsInflight = null;
var initializePluginsInflight = null;
var initializePluginsInflightHash = null;
{
	const pathStuff = await import('path');
	const urlStuff = await import('url');
	const admZipStuff = await import('./adm-zip.js-abq2qQje.js').then((m) => /* @__PURE__ */ __toESM(m.default));
	path = pathStuff;
	url = urlStuff;
	admZip = admZipStuff.default;
}
var plugins = writable({});
var pluginsFolder = "plugins";
var manifestFileName = "manifest.json";
var pluginUiZipFileName = "plugin-ui.zip";
function createPluginsFolder() {
	if (!fs.existsSync(pluginsFolder)) fs.mkdirSync(pluginsFolder, { recursive: true });
}
function isDirectory(path) {
	try {
		return fs.statSync(path).isDirectory();
	} catch (error) {
		return false;
	}
}
async function downloadAndExtractZip(file, outputDir) {
	const arrayBuffer = await file.arrayBuffer();
	const buffer = Buffer.from(arrayBuffer);
	new admZip(buffer, {}).extractAllTo(outputDir, true);
}
function readPluginsFromFolder(siteInfo) {
	const readPluginsFolder = fs.readdirSync(pluginsFolder);
	const plugins = {};
	readPluginsFolder.filter((pluginId) => isDirectory(path.join(pluginsFolder, pluginId))).forEach((pluginId) => {
		try {
			const manifestFile = fs.readFileSync(path.join(pluginsFolder, pluginId, manifestFileName), {
				encoding: "utf8",
				flag: "r"
			});
			plugins[pluginId] = JSON.parse(manifestFile);
		} catch (_) {}
	});
	return plugins;
}
async function downloadPluginUiZip(pluginId) {
	return await ApiUtil.get({
		path: `/api/plugins/${pluginId}/resources/${pluginUiZipFileName}`,
		blob: true
	});
}
function isPluginFolderIntact(pluginFolder) {
	return fs.existsSync(path.join(pluginFolder, manifestFileName)) && isDirectory(path.join(pluginFolder, "server")) && isDirectory(path.join(pluginFolder, "client"));
}
function purgeIncompletePluginFolders() {
	let entries;
	try {
		entries = fs.readdirSync(pluginsFolder);
	} catch {
		return;
	}
	entries.forEach((entry) => {
		const entryPath = path.join(pluginsFolder, entry);
		if (!isDirectory(entryPath)) return;
		if (entry.startsWith(".")) {
			fs.rmSync(entryPath, {
				recursive: true,
				force: true
			});
			return;
		}
		if (!isPluginFolderIntact(entryPath)) {
			fs.rmSync(entryPath, {
				recursive: true,
				force: true
			});
			plugins.update((p) => {
				delete p[entry];
				return p;
			});
		}
	});
}
async function verifyPlugins(siteInfo) {
	const pluginsInfo = siteInfo.plugins;
	purgeIncompletePluginFolders();
	const pluginsInFolder = readPluginsFromFolder();
	const pluginIdInFolderList = Object.keys(pluginsInFolder);
	pluginIdInFolderList.forEach((pluginId) => {
		if (!pluginsInfo[pluginId]) {
			fs.rmSync(path.join(pluginsFolder, pluginId), {
				recursive: true,
				force: true
			});
			plugins.update((p) => {
				delete p[pluginId];
				return p;
			});
			return;
		}
		plugins.update((p) => {
			p[pluginId] = siteInfo.developmentMode ? {
				...pluginsInFolder[pluginId],
				uiHash: `dev-stale-${Date.now()}`
			} : pluginsInFolder[pluginId];
			return p;
		});
	});
	Object.keys(get(plugins)).filter((pluginId) => !pluginIdInFolderList.includes(pluginId)).forEach((pluginId) => {
		plugins.update((p) => {
			delete p[pluginId];
			return p;
		});
	});
	const notInstalledPlugins = Object.keys(pluginsInfo).filter((pluginId) => !get(plugins)[pluginId]);
	await Promise.all(notInstalledPlugins.map((pluginId) => downloadAndInstallPlugin(pluginId, pluginsInfo[pluginId], "install")));
	await Promise.all(Object.keys(get(plugins)).map(async (pluginId) => {
		const pluginInfoManifest = pluginsInfo[pluginId];
		if (!pluginInfoManifest) return;
		const pluginManifest = get(plugins)[pluginId];
		if (pluginManifest.version === pluginInfoManifest.version && pluginManifest.uiHash === pluginInfoManifest.uiHash) return;
		await downloadAndInstallPlugin(pluginId, pluginInfoManifest, "update");
	}));
}
/**
* Download the plugin-ui.zip for a plugin and atomically replace its folder with the new
* content. Used for both first-time installs and updates — the two used to have separate
* code paths and the update path's per-subdir swap could leave the folder as a manifest-
* only shell when the downloaded zip was malformed (no server/ or no client/ inside).
* One code path means one set of invariants to enforce.
*
* Invariant after a successful return: pluginFolder contains manifest.json + server/ +
* client/, and the `plugins` store entry matches what's on disk.
*
* On any failure (download error, malformed zip, missing server/ or client/, fs error)
* we leave the previous on-disk state untouched (so an old working build keeps serving)
* and drop the plugin from the store so the rest of the SSR pass and the browser-side
* loader skip it cleanly instead of trying to import files that don't exist. The
* `bun dev` workflow is unaffected: BE bumps the uiHash on rebuild, this function runs,
* and the new build replaces the old one wholesale.
*/
async function downloadAndInstallPlugin(pluginId, pluginManifest, mode) {
	const pluginFolder = path.join(pluginsFolder, pluginId);
	const tmpDir = path.join(pluginsFolder, `.${pluginId}.${mode}.${process.pid}.${Date.now()}`);
	try {
		await downloadAndExtractZip(await downloadPluginUiZip(pluginId), tmpDir);
		if (!isDirectory(path.join(tmpDir, "server")) || !isDirectory(path.join(tmpDir, "client"))) {
			fs.rmSync(tmpDir, {
				recursive: true,
				force: true
			});
			`${pluginId}`;
			plugins.update((p) => {
				delete p[pluginId];
				return p;
			});
			return;
		}
		fs.writeFileSync(path.join(tmpDir, manifestFileName), JSON.stringify(pluginManifest, null, 2));
		fs.rmSync(pluginFolder, {
			recursive: true,
			force: true
		});
		fs.renameSync(tmpDir, pluginFolder);
		plugins.update((p) => {
			p[pluginId] = structuredClone(pluginManifest);
			return p;
		});
		`${pluginId}`;
	} catch (e) {
		fs.rmSync(tmpDir, {
			recursive: true,
			force: true
		});
		`${mode}${pluginId}${e?.message ?? e}`;
		plugins.update((p) => {
			delete p[pluginId];
			return p;
		});
	}
}
async function preparePlugins(siteInfo) {
	if (!siteInfo || typeof siteInfo !== "object" || !siteInfo.plugins) throw error(503, "Pano backend is not reachable yet");
	const currentBackendHash = JSON.stringify(siteInfo.plugins);
	while (true) {
		if (preparePluginsInflight) {
			try {
				await preparePluginsInflight;
			} catch {}
			continue;
		}
		if (!siteInfo.developmentMode && serverSidePrepared && lastProcessedBackendHash === currentBackendHash) break;
		preparePluginsInflight = (async () => {
			createPluginsFolder();
			await verifyPlugins(siteInfo);
			serverSidePrepared = true;
			lastProcessedBackendHash = currentBackendHash;
		})();
		try {
			await preparePluginsInflight;
		} finally {
			preparePluginsInflight = null;
		}
		break;
	}
	const newSiteInfoPlugins = {};
	const loadedPlugins = get(plugins);
	Object.keys(loadedPlugins).forEach((pluginId) => {
		const plugin = loadedPlugins[pluginId];
		const vObj = plugin.version;
		const { version, uiHash } = vObj && typeof vObj === "object" ? vObj : plugin;
		const deps = plugin.dependencies;
		newSiteInfoPlugins[pluginId] = {
			version,
			uiHash,
			...deps ? { dependencies: deps } : {}
		};
	});
	siteInfo.plugins = newSiteInfoPlugins;
}
function generateStablePluginHash(siteInfoPlugins) {
	const stableData = {};
	for (const id of Object.keys(siteInfoPlugins || {}).sort()) {
		const plugin = siteInfoPlugins[id];
		const vObj = plugin.version;
		const { version, uiHash } = vObj && typeof vObj === "object" ? vObj : plugin;
		stableData[id] = {
			version,
			uiHash,
			dependencies: Array.isArray(plugin.dependencies) ? [...plugin.dependencies].sort() : []
		};
	}
	return JSON.stringify(stableData);
}
function isInitializeCacheHit(siteInfo, currentFrontendHash) {
	if (!siteInfo.developmentMode && serverSideInitialized && lastProcessedFrontendHash === currentFrontendHash) return true;
	return false;
}
async function doInitializePlugins(siteInfo, currentFrontendHash) {
	const previousRegisteredPages = registeredPages;
	registeredPages = {};
	try {
		await init();
		await loadPlugins(siteInfo);
	} catch (e) {
		registeredPages = previousRegisteredPages;
		throw e;
	}
	serverSideInitialized = true;
	lastProcessedFrontendHash = currentFrontendHash;
}
async function initializePlugins(siteInfo) {
	const currentFrontendHash = generateStablePluginHash(siteInfo.plugins);
	while (true) {
		if (isInitializeCacheHit(siteInfo, currentFrontendHash)) return;
		if (initializePluginsInflight) {
			const sameHash = initializePluginsInflightHash === currentFrontendHash;
			try {
				await initializePluginsInflight;
			} catch {}
			if (sameHash && isInitializeCacheHit(siteInfo, currentFrontendHash)) return;
			continue;
		}
		initializePluginsInflightHash = currentFrontendHash;
		initializePluginsInflight = doInitializePlugins(siteInfo, currentFrontendHash);
		try {
			await initializePluginsInflight;
		} finally {
			initializePluginsInflight = null;
			initializePluginsInflightHash = null;
		}
		return;
	}
}
var moduleCache = /* @__PURE__ */ new Map();
function buildPluginDependencyGraph(loadedPlugins) {
	const pluginIds = new Set(Object.keys(loadedPlugins));
	const graph = {};
	for (const pluginId of pluginIds) graph[pluginId] = (loadedPlugins[pluginId].dependencies || []).filter((dep) => pluginIds.has(dep));
	return graph;
}
function topologicalSortPlugins(graph) {
	const inDegree = {};
	const adj = {};
	for (const node of Object.keys(graph)) {
		if (!(node in inDegree)) inDegree[node] = 0;
		if (!(node in adj)) adj[node] = [];
	}
	for (const [node, deps] of Object.entries(graph)) for (const dep of deps) {
		if (!(dep in adj)) adj[dep] = [];
		if (!(dep in inDegree)) inDegree[dep] = 0;
		adj[dep].push(node);
		inDegree[node] = (inDegree[node] || 0) + 1;
	}
	const levels = [];
	let queue = Object.keys(inDegree).filter((n) => inDegree[n] === 0);
	while (queue.length > 0) {
		levels.push([...queue]);
		const nextQueue = [];
		for (const node of queue) for (const neighbor of adj[node] || []) {
			inDegree[neighbor]--;
			if (inDegree[neighbor] === 0) nextQueue.push(neighbor);
		}
		queue = nextQueue;
	}
	const resolved = new Set(levels.flat());
	const unresolved = Object.keys(graph).filter((n) => !resolved.has(n));
	if (unresolved.length > 0) levels.push(unresolved);
	return levels;
}
async function loadPlugins(siteInfo) {
	const pluginIds = Object.keys(get(plugins));
	await Promise.all(pluginIds.map(async (pluginId) => {
		const plugin = get(plugins)[pluginId];
		if (!plugin) return;
		{
			const pluginFolder = path.join(pluginsFolder, pluginId);
			const pluginHash = plugin.uiHash || "no-hash";
			const cacheKey = `${pluginId}-${pluginHash}`;
			if (moduleCache.has(cacheKey) && !siteInfo.developmentMode) {
				plugin.module = moduleCache.get(cacheKey);
				return;
			}
			const importSuffix = siteInfo.developmentMode ? `?${Date.now()}` : pluginHash !== "no-hash" ? `?v=${pluginHash}` : "";
			const mainPath = path.join(pluginFolder, "server", "server.mjs") + importSuffix;
			const __filename = url.fileURLToPath(import.meta.url);
			const currentDir = path.dirname(__filename);
			const targetFile = path.resolve(currentDir, process.cwd());
			const levels = path.relative(currentDir, targetFile).split(path.sep).length;
			const upDirs = `..${path.sep}`.repeat(levels);
			let module;
			try {
				module = await import(
					/* @vite-ignore */
					upDirs + mainPath
);
			} catch {
				try {
					module = await import(
						/* @vite-ignore */
						"file://" + path.join(path.resolve(upDirs + mainPath, process.cwd(), mainPath))
);
				} catch (e) {
					plugins.update((p) => {
						delete p[pluginId];
						return p;
					});
					return;
				}
			}
			plugin.module = module;
			if (!siteInfo.developmentMode) {
				const prefix = `${pluginId}-`;
				for (const key of moduleCache.keys()) if (key !== cacheKey && key.startsWith(prefix)) moduleCache.delete(key);
				moduleCache.set(cacheKey, module);
			}
		}
	}));
	const loadLevels = topologicalSortPlugins(buildPluginDependencyGraph(get(plugins)));
	for (const level of loadLevels) await Promise.all(level.map(async (pluginId) => {
		const plugin = get(plugins)[pluginId];
		if (!plugin?.module?.default) return;
		const PluginClass = plugin.module.default;
		if (!(typeof PluginClass === "function" && (PluginClass === PanoPlugin || PluginClass.prototype instanceof PanoPlugin || PluginClass.isPanoPlugin === true))) {
			plugins.update((p) => {
				delete p[pluginId];
				return p;
			});
			return;
		}
		const instance = new PluginClass({ pluginId });
		instance.pano = panoApiServer;
		try {
			await instance.onLoad();
		} catch (e) {}
	}));
}

export { preparePlugins as a, executeViewLoad as b, executeHookLoad as c, panoApi as d, executeLifecycle as e, findMatch as f, executeSidebarLoad as g, panoApiServer as h, initializePlugins as i, orderLinksBySavedOrder as o, panoApiClient as p, registeredPages as r, setPanoContext as s };
//# sourceMappingURL=PluginManager.js-B5x3OKEW.js.map
