import { e as error } from './exports2.js-DxZfja4I.js';
import { g as getContext, W as bind_props } from './server.js-D28cBEJ-.js';
import 'node:module';
import { e as executeLifecycle, c as executeHookLoad } from './PluginManager.js-B5x3OKEW.js';
import { r as resolveView } from './registry2.js-BubD3cPq.js';
import { c as avatarVersion } from './Store.js-C2vdyE6V.js';
import { a as getPostDetail } from './posts.js-DGnD0CAT.js';

//#region node_modules/@panomc/theme-core/src/lib/ui-logics/page-logics/PostDetailPageLogics.js
/**
* @type {import("@sveltejs/kit").Load}
*/
async function processLoad(event) {
	const { parent } = event;
	const { hookProps: parentHookProps } = await parent();
	let data = {
		post: {
			id: -1,
			title: "",
			category: "-",
			writer: { username: "" },
			text: "",
			date: 0,
			status: 1,
			image: "",
			views: 0,
			url: ""
		},
		previousPost: "-",
		nextPost: "-"
	};
	await getPostDetail({
		url: event.params.url,
		request: event
	}).then((body) => {
		if (body.error) {
			if (body.error === "POST_NOT_FOUND") throw error(404, body.error);
			throw error(500, body.error);
		}
		data = body;
	});
	data.hookProps = { ...parentHookProps };
	await executeLifecycle("theme:post-detail:load", data, event);
	data.hookProps["theme:post-detail:bottom"] = {
		...data.hookProps["theme:post-detail:bottom"],
		...await executeHookLoad("theme:post-detail:bottom", event)
	};
	data.pageTitle = data.post.title;
	return { ...data };
}
//#endregion
//#region node_modules/@panomc/theme-core/src/lib/pages/PostDetailPage.svelte
async function load(event) {
	const viewPromise = resolveView("PostDetailView", () => import('./PostDetailView.js-CjCvRPpK.js'));
	return {
		...await processLoad(event),
		View: await viewPromise
	};
}
function PostDetailPage($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		let data = $$props["data"];
		const themeSettings = getContext("themeSettings");
		getContext("session");
		if (data.View) {
			$$renderer.push("<!--[-->");
			data.View($$renderer, {
				data,
				themeSettings,
				avatarVersion
			});
			$$renderer.push("<!--]-->");
		} else {
			$$renderer.push("<!--[!-->");
			$$renderer.push("<!--]-->");
		}
		bind_props($$props, { data });
	});
}

export { PostDetailPage as P, load as l };
//# sourceMappingURL=PostDetailPage.js-GjsUvK1W.js.map
