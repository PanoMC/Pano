import { Z as attr_class, Y as stringify, X as attr, a5 as escape_html, a0 as store_get, a3 as html, a2 as unsubscribe_stores, W as bind_props } from './server.js-D28cBEJ-.js';
import { $ as $format } from './runtime.js-CJgfVvxa.js';
import './tooltip.util.js-Bd9x5X7L.js';
import { D as Date_1 } from './Date.js-ZK3lGml2.js';
import { H as Hook } from './Hook.js-DEYNBNbZ.js';
import './uneval.js-BL1Qg77w.js';
import './rolldown-runtime.js-B5FuG9Gw.js';
import 'node:module';
import './stores.js-QbD2A2ib.js';
import './client.js-CPEkJ2-P.js';
import './shared.js-3i5_hmQ1.js';
import './exports.js-CKkpMUqI.js';
import './internal2.js-KmQU-gaY.js';
import './index-server2.js-DlblWyyK.js';
import './language.util.js-C2xYQq5-.js';
import './internal.js-BlXt2rfE.js';
import './Store.js-C2vdyE6V.js';
import './exports2.js-DxZfja4I.js';
import './ToastContainer.js-CtmBBvhr.js';
import './locale.js-DnnPB87K.js';
import './format.js-CzDFIcjs.js';
import './PluginManager.js-B5x3OKEW.js';
import 'fs';
import './auth.util.js-BGCV_dhB.js';

//#region node_modules/@panomc/theme-core/src/lib/views/PostDetailView.svelte
function PostDetailView($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let data = $$props["data"];
		let themeSettings = $$props["themeSettings"];
		let avatarVersion = $$props["avatarVersion"];
		$$renderer.push(`<div class="vstack gap-3">`);
		if (data.post.category.title !== "-") {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<div class="text-center"><a${attr_class(`badge ${stringify(data.post.category.title !== "-" ? "text-bg-secondary" : "text-bg-primary")} text-decoration-none rounded-pill focus-ring`)}${attr("href", `/?category=${stringify(data.post.category.url)}`)}>${escape_html(data.post.category.title)}</a></div>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--> `);
		if ((typeof themeSettings.postCoverImageEnabled === "undefined" ? true : themeSettings.postCoverImageEnabled) && data.post.thumbnailUrl) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<div class="post-detail-cover rounded shadow-sm svelte-ee274o"><div class="ratio ratio-16x9 svelte-ee274o"><img id="thumbnail"${attr("src", data.post.thumbnailUrl)} class="d-block svelte-ee274o"${attr("alt", data.post.title)}${attr("title", data.post.title)}/></div> <div class="post-detail-cover__overlay rounded svelte-ee274o"><div class="d-flex flex-lg-row align-items-end justify-content-between"><div class="col-lg-3 d-flex align-items-end justify-content-start h-100">`);
			if (typeof themeSettings.postViewCountEnabled === "undefined" ? true : themeSettings.postViewCountEnabled) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<div class="opacity-75"><i class="fas fa-eye me-2"></i> ${escape_html(data.post.views)}</div>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--></div> <div class="col-lg-6 text-center opacity-75">`);
			Date_1($$renderer, { time: data.post.date });
			$$renderer.push(`<!----></div> <div class="col-lg-3 d-flex align-items-end justify-content-end opacity-75"><a${attr("href", `/player/${stringify(data.post.writer.username)}`)} class="d-inline-block focus-ring rounded-circle ms-2"${attr("hidden", typeof themeSettings.postAuthorImageEnabled === "undefined" ? false : !themeSettings.postAuthorImageEnabled)}><img${attr("src", `/api/profile/picture/${stringify(data.post.writer.username)}?${stringify(store_get($$store_subs ??= {}, "$avatarVersion", avatarVersion))}`)}${attr("alt", data.post.writer.username)} width="24" height="24" class="rounded-circle" onload="this.__e=event" onerror="this.__e=event"/></a></div></div></div></div>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--> <div class="card"><div class="card-body"><div class="card-text text-break word-break">${html(data.post.text)}</div></div> `);
		if (!(data.post.thumbnailUrl && (typeof themeSettings.postCoverImageEnabled === "undefined" ? true : themeSettings.postCoverImageEnabled))) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<div class="card-footer"><div class="d-flex align-items-center justify-content-between small">`);
			if (typeof themeSettings.postViewCountEnabled === "undefined" ? true : themeSettings.postViewCountEnabled) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<div><i class="fas fa-eye me-2"></i> ${escape_html(data.post.views)}</div>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--> <div class="d-flex align-items-center">`);
			Date_1($$renderer, { time: data.post.date });
			$$renderer.push(`<!----> <a${attr("href", `/player/${stringify(data.post.writer.username)}`)} class="d-inline-block rounded focus-ring rounded-circle ms-2"${attr("hidden", typeof themeSettings.postAuthorImageEnabled === "undefined" ? false : !themeSettings.postAuthorImageEnabled)}><img${attr("src", `/api/profile/picture/${stringify(data.post.writer.username)}?${stringify(store_get($$store_subs ??= {}, "$avatarVersion", avatarVersion))}`)}${attr("alt", data.post.writer.username)} width="28" height="28" class="rounded-circle" onload="this.__e=event" onerror="this.__e=event"/></a></div></div></div>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--></div> <div class="row justify-content-between"><div class="col-auto"><a${attr("href", `/post/${stringify(data.previousPost === "-" ? "" : data.previousPost.url)}`)}${attr_class("btn btn-link ps-0", void 0, { "disabled": data.previousPost === "-" })}${attr("hidden", typeof themeSettings.postPreviousPageEnabled === "undefined" ? false : !themeSettings.postPreviousPageEnabled)}><i class="fas fa-caret-left me-1"></i> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.post-detail.previous-post"))}</a></div> <div class="col-auto"><a${attr("href", `/post/${stringify(data.nextPost === "-" ? "" : data.nextPost.url)}`)}${attr_class("btn btn-link pe-0", void 0, { "disabled": data.nextPost === "-" })}${attr("hidden", typeof themeSettings.postNextPageEnabled === "undefined" ? false : !themeSettings.postNextPageEnabled)}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.post-detail.next-post"))} <i class="fas fa-caret-right ms-1"></i></a></div></div> `);
		Hook($$renderer, {
			name: "theme:post-detail:bottom",
			post: data.post
		});
		$$renderer.push(`<!----></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
		bind_props($$props, {
			data,
			themeSettings,
			avatarVersion
		});
	});
}

export { PostDetailView as default };
//# sourceMappingURL=PostDetailView.js-CjCvRPpK.js.map
