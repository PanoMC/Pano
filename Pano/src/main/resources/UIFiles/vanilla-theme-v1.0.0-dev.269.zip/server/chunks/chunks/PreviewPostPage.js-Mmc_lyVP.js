import { g as getContext, W as bind_props } from './server.js-D28cBEJ-.js';
import 'node:module';
import { r as resolveView } from './registry2.js-BubD3cPq.js';
import { c as avatarVersion } from './Store.js-C2vdyE6V.js';
import { b as getPostPreview } from './posts.js-DGnD0CAT.js';

//#region node_modules/@panomc/theme-core/src/lib/ui-logics/page-logics/PreviewPostPageLogics.js
/**
* @type {import("@sveltejs/kit").Load}
*/
async function processLoad(event) {
	const { parent } = event;
	const { session } = await parent();
	const { user } = session;
	if (!user && !user.panelAccess) return {
		status: 302,
		redirect: "/"
	};
	let data = {
		post: {
			id: -1,
			title: "",
			category: "-",
			writer: { username: "" },
			text: "",
			date: 0,
			status: 1,
			image: "",
			views: 0
		},
		previousPost: "-",
		nextPost: "-"
	};
	await getPostPreview({
		id: event.params.id,
		request: event
	}).then((body) => {
		if (body.error) {
			data = {};
			return;
		}
		data.post = body;
	});
	return data;
}
//#endregion
//#region node_modules/@panomc/theme-core/src/lib/pages/PreviewPostPage.svelte
async function load(event) {
	const viewPromise = resolveView("PreviewPostView", () => import('./PreviewPostView.js-Db0AEuCv.js'));
	return {
		...await processLoad(event),
		View: await viewPromise
	};
}
function PreviewPostPage($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		let data = $$props["data"];
		let post = $$props["post"];
		const themeSettings = getContext("themeSettings");
		if (data.View) {
			$$renderer.push("<!--[-->");
			data.View($$renderer, {
				data,
				post,
				themeSettings,
				avatarVersion
			});
			$$renderer.push("<!--]-->");
		} else {
			$$renderer.push("<!--[!-->");
			$$renderer.push("<!--]-->");
		}
		bind_props($$props, {
			data,
			post
		});
	});
}

export { PreviewPostPage as P, load as l };
//# sourceMappingURL=PreviewPostPage.js-Mmc_lyVP.js.map
