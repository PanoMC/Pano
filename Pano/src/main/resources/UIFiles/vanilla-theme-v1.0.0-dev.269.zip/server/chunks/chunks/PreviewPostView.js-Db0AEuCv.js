import { a5 as escape_html, a0 as store_get, Z as attr_class, Y as stringify, X as attr, a3 as html, a2 as unsubscribe_stores, W as bind_props } from './server.js-D28cBEJ-.js';
import { $ as $format } from './runtime.js-CJgfVvxa.js';
import './tooltip.util.js-Bd9x5X7L.js';
import { D as Date_1 } from './Date.js-ZK3lGml2.js';
import './uneval.js-BL1Qg77w.js';
import './rolldown-runtime.js-B5FuG9Gw.js';
import 'node:module';
import './stores.js-QbD2A2ib.js';
import './client.js-CPEkJ2-P.js';
import './shared.js-3i5_hmQ1.js';
import './exports.js-CKkpMUqI.js';
import './internal2.js-KmQU-gaY.js';
import './index-server2.js-DlblWyyK.js';
import './language.util.js-C2xYQq5-.js';
import './internal.js-BlXt2rfE.js';
import './Store.js-C2vdyE6V.js';
import './exports2.js-DxZfja4I.js';
import './ToastContainer.js-CtmBBvhr.js';
import './locale.js-DnnPB87K.js';
import './format.js-CzDFIcjs.js';

//#region node_modules/@panomc/theme-core/src/lib/views/PreviewPostView.svelte
function PreviewPostView($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let data = $$props["data"];
		let post = $$props["post"];
		let themeSettings = $$props["themeSettings"];
		let avatarVersion = $$props["avatarVersion"];
		$$renderer.push(`<div class="vstack gap-3"><h5 class="card-title mb-0">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.preview-post.title", { values: { postTitle: post.title } }))}</h5> `);
		if (post.category.title !== "-") {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<div class="text-center"><span${attr_class(`badge ${stringify(post.category.title !== "-" ? "text-bg-secondary" : "text-bg-primary")} text-decoration-none rounded-pill focus-ring`)}>${escape_html(post.category.title)}</span></div>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--> `);
		if ((typeof themeSettings.postCoverImageEnabled === "undefined" ? true : themeSettings.postCoverImageEnabled) && post.thumbnailUrl) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<div class="post-detail-cover rounded shadow-sm svelte-6aqg8j"><div class="ratio ratio-16x9 svelte-6aqg8j"><img id="thumbnail"${attr("src", post.thumbnailUrl)} class="d-block svelte-6aqg8j"${attr("alt", post.title)}${attr("title", post.title)}/></div> <div class="post-detail-cover__overlay rounded svelte-6aqg8j"><div class="d-flex flex-lg-row align-items-end justify-content-between"><div class="col-lg-3 d-flex align-items-end justify-content-start h-100">`);
			if (typeof themeSettings.postViewCountEnabled === "undefined" ? true : themeSettings.postViewCountEnabled) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<div class="opacity-75"><i class="fas fa-eye me-2"></i> ${escape_html(post.views)}</div>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--></div> <div class="col-lg-6 text-center opacity-75">`);
			Date_1($$renderer, { time: post.date });
			$$renderer.push(`<!----></div> <div class="col-lg-3 d-flex align-items-end justify-content-end opacity-75"><span class="d-inline-block focus-ring rounded-circle ms-2"><img${attr("src", `/api/profile/picture/${stringify(post.writer.username)}?${stringify(store_get($$store_subs ??= {}, "$avatarVersion", avatarVersion))}`)}${attr("alt", post.writer.username)} width="24" height="24" class="rounded-circle" onload="this.__e=event" onerror="this.__e=event"/></span></div></div></div></div>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--> <div class="card"><div class="card-body"><div class="card-text text-break word-break">${html(post.text)}</div></div> `);
		if (!(post.thumbnailUrl && (typeof themeSettings.postCoverImageEnabled === "undefined" ? true : themeSettings.postCoverImageEnabled))) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<div class="card-footer"><div class="d-flex align-items-center justify-content-between small">`);
			if (typeof themeSettings.postViewCountEnabled === "undefined" ? true : themeSettings.postViewCountEnabled) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<div><i class="fas fa-eye me-2"></i> ${escape_html(post.views)}</div>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--> <div class="d-flex align-items-center">`);
			Date_1($$renderer, { time: post.date });
			$$renderer.push(`<!----> <span class="d-inline-block rounded focus-ring rounded-circle ms-2"><img${attr("src", `/api/profile/picture/${stringify(post.writer.username)}?${stringify(store_get($$store_subs ??= {}, "$avatarVersion", avatarVersion))}`)}${attr("alt", post.writer.username)} width="28" height="28" class="rounded-circle" onload="this.__e=event" onerror="this.__e=event"/></span></div></div></div>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--></div></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
		bind_props($$props, {
			data,
			post,
			themeSettings,
			avatarVersion
		});
	});
}

export { PreviewPostView as default };
//# sourceMappingURL=PreviewPostView.js-Db0AEuCv.js.map
