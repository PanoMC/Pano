import { _ as __exportAll } from './rolldown-runtime.js-B5FuG9Gw.js';
import { V as fallback, a0 as store_get, _ as slot, a2 as unsubscribe_stores, W as bind_props } from './server.js-D28cBEJ-.js';
import { p as page } from './stores.js-QbD2A2ib.js';
import { r as resolveView } from './registry2.js-BubD3cPq.js';
import { m as requireLogin } from './Store.js-C2vdyE6V.js';

//#region node_modules/@panomc/theme-core/src/lib/ui-logics/layout-logics/ProfileLayoutLogics.js
async function processLoad({ parent }) {
	const parentData = await parent();
	const { session } = parentData;
	requireLogin(session);
	return parentData;
}
//#endregion
//#region node_modules/@panomc/theme-core/src/lib/layouts/ProfileLayout.svelte
var ProfileLayout_exports = /* @__PURE__ */ __exportAll({
	default: () => ProfileLayout,
	load: () => load
});
async function load(event) {
	const viewPromise = resolveView("ProfileLayoutView", () => import('./ProfileLayoutView.js-B3WW6UaH.js'));
	return {
		...await processLoad(event),
		profileLayoutView: await viewPromise
	};
}
function ProfileLayout($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let viewData, layoutView;
		let data = fallback($$props["data"], void 0);
		viewData = data ?? store_get($$store_subs ??= {}, "$page", page).data;
		layoutView = viewData?.profileLayoutView ?? store_get($$store_subs ??= {}, "$page", page).data.profileLayoutView;
		if (layoutView) {
			$$renderer.push("<!--[-->");
			layoutView($$renderer, {
				data: viewData,
				children: ($$renderer) => {
					$$renderer.push(`<!--[-->`);
					slot($$renderer, $$props, "default", {}, null);
					$$renderer.push(`<!--]-->`);
				},
				$$slots: { default: true }
			});
			$$renderer.push("<!--]-->");
		} else {
			$$renderer.push("<!--[!-->");
			$$renderer.push("<!--]-->");
		}
		if ($$store_subs) unsubscribe_stores($$store_subs);
		bind_props($$props, { data });
	});
}

export { ProfileLayout_exports as P, ProfileLayout as a, load as l };
//# sourceMappingURL=ProfileLayout.js-B2Aj3-w1.js.map
