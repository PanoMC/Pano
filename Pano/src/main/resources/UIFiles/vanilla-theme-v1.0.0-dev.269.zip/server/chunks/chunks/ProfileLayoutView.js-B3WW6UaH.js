import { _ as slot, W as bind_props } from './server.js-D28cBEJ-.js';
import './uneval.js-BL1Qg77w.js';

//#region node_modules/@panomc/theme-core/src/lib/views/ProfileLayoutView.svelte
function ProfileLayoutView($$renderer, $$props) {
	let data = $$props["data"];
	$$renderer.push(`<!--[-->`);
	slot($$renderer, $$props, "default", {}, null);
	$$renderer.push(`<!--]-->`);
	bind_props($$props, { data });
}

export { ProfileLayoutView as default };
//# sourceMappingURL=ProfileLayoutView.js-B3WW6UaH.js.map
