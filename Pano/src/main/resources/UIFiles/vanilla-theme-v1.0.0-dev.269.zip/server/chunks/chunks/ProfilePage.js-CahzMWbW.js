import { W as bind_props } from './server.js-D28cBEJ-.js';
import { p as panoApiClient, h as panoApiServer, e as executeLifecycle, b as executeViewLoad } from './PluginManager.js-B5x3OKEW.js';
import { r as resolveView } from './registry2.js-BubD3cPq.js';
import { l as load$1, P as ProfileSidebar } from './ProfileSidebar.js-BIu8zSKN.js';
import { a as getProfile } from './profile.js-C7iU3TQf.js';

//#region node_modules/@panomc/theme-core/src/lib/ui-logics/page-logics/ProfilePageLogics.js
/**
* @type {import("@sveltejs/kit").Load}
*/
async function processLoad(event) {
	const { parent } = event;
	await parent();
	let data = {
		registerDate: 0,
		lastLoginDate: 0
	};
	panoApiServer.ui.profile.content.edit((items) => {
		items.push({
			id: "profile-card",
			priority: 100,
			hidden: false
		});
	});
	panoApiServer.ui.profile.cardRows.edit((items) => {
		items.push({
			id: "register-date",
			priority: 100,
			hidden: false
		}, {
			id: "last-login",
			priority: 90,
			hidden: false
		});
	});
	await executeLifecycle("theme:profile:load", {}, event);
	const [, , , profileBody] = await Promise.all([
		executeViewLoad("profile-content", event),
		executeViewLoad("profile-card-rows", event),
		load$1(event),
		getProfile({ request: event })
	]);
	data = profileBody;
	return {
		...data,
		sidebar: ProfileSidebar,
		pageTitle: "pages.profile.title"
	};
}
//#endregion
//#region node_modules/@panomc/theme-core/src/lib/pages/profile/ProfilePage.svelte
async function load(event) {
	const viewPromise = resolveView("ProfileView", () => import('./ProfileView.js-BXVlxp2Y.js'));
	return {
		...await processLoad(event),
		View: await viewPromise
	};
}
function ProfilePage($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		let data = $$props["data"];
		const contentItems = panoApiClient.ui.profile.content.get();
		const cardRowItems = panoApiClient.ui.profile.cardRows.get();
		if (data.View) {
			$$renderer.push("<!--[-->");
			data.View($$renderer, {
				data,
				contentItems,
				cardRowItems
			});
			$$renderer.push("<!--]-->");
		} else {
			$$renderer.push("<!--[!-->");
			$$renderer.push("<!--]-->");
		}
		bind_props($$props, { data });
	});
}

export { ProfilePage as P, load as l };
//# sourceMappingURL=ProfilePage.js-CahzMWbW.js.map
