import { V as fallback, g as getContext, a0 as store_get, a2 as unsubscribe_stores, W as bind_props, T as writable, a5 as escape_html, Z as attr_class, $ as ensure_array_like, a1 as spread_props } from './server.js-D28cBEJ-.js';
import { o as onDestroy } from './index-server2.js-DlblWyyK.js';
import { $ as $format } from './runtime.js-CJgfVvxa.js';
import { d as panoApi, g as executeSidebarLoad } from './PluginManager.js-B5x3OKEW.js';
import { d as ApiUtil } from './Store.js-C2vdyE6V.js';
import './tooltip.util.js-Bd9x5X7L.js';
import { P as PageTitle } from './PageTitle.js-D99NSXzQ.js';
import { P as PlayerHead } from './PlayerHead.js-Bggv1de7.js';
import { S as Sidebar } from './Sidebar.js-BwVxP8m2.js';
import { V as ViewComponent } from './ViewComponent.js-C6amYVVM.js';
import { P as PlayerStatusBadge, a as PlayerPermissionBadge } from './PlayerStatusBadge.js-DO05KLuW.js';

//#region node_modules/@panomc/theme-core/src/lib/components/sidebars/ProfileSidebar.svelte
var data = writable({
	lastActivityTime: 0,
	inGame: false,
	permissionGroupName: "",
	isBanned: false
});
var load = async (event) => {
	panoApi.ui.sidebar.register({
		sidebarId: "profile",
		id: "profile-info",
		component: "local:profile-info",
		priority: 100
	});
	await executeSidebarLoad("profile", event);
	data.set(await ApiUtil.get({
		path: "/api/sidebars/profile",
		request: event
	}));
};
String.prototype.capitalize = function() {
	return this.charAt(0).toUpperCase() + this.slice(1);
};
function ProfileSidebar($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let user;
		let side = $$props["side"];
		let showDeleteAll = fallback($$props["showDeleteAll"], false);
		const session = getContext("session");
		let checkTime = 0;
		let interval;
		onDestroy(() => {
			clearInterval(interval);
		});
		const items = panoApi.ui.sidebar.get("profile");
		user = store_get($$store_subs ??= {}, "$session", session).user ? store_get($$store_subs ??= {}, "$session", session).user : {};
		Sidebar($$renderer, {
			side,
			children: ($$renderer) => {
				$$renderer.push(`<div class="d-flex flex-column gap-3">`);
				if (showDeleteAll) {
					$$renderer.push("<!--[0-->");
					$$renderer.push(`<div class="order-last order-lg-first w-100"><button class="btn btn-danger w-100" type="button"><i class="fas fa-trash-alt me-2"></i> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.delete-all"))}</button></div>`);
				} else $$renderer.push("<!--[-1-->");
				$$renderer.push(`<!--]--> <div${attr_class("vstack gap-3", void 0, {
					"order-first": showDeleteAll,
					"order-lg-last": showDeleteAll
				})}><!--[-->`);
				const each_array = ensure_array_like(store_get($$store_subs ??= {}, "$items", items));
				for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
					let item = each_array[$$index];
					if (item.id === "profile-info") {
						$$renderer.push("<!--[0-->");
						$$renderer.push(`<div class="card square-card-desktop svelte-cz9zqn"><div class="card-body vstack gap-3"><div class="d-block">`);
						PlayerHead($$renderer, {
							width: "64",
							height: "64",
							username: user.username,
							inGame: store_get($$store_subs ??= {}, "$data", data).inGame,
							lastActivityTime: store_get($$store_subs ??= {}, "$data", data).lastActivityTime,
							checkTime
						});
						$$renderer.push(`<!----></div> `);
						PageTitle($$renderer, {
							title: user.username,
							breadcrumb: false
						});
						$$renderer.push(`<!----> <div class="text-center">`);
						PlayerStatusBadge($$renderer, {
							banned: store_get($$store_subs ??= {}, "$data", data).isBanned,
							lastActivityTime: store_get($$store_subs ??= {}, "$data", data).lastActivityTime,
							inGame: store_get($$store_subs ??= {}, "$data", data).inGame,
							checkTime
						});
						$$renderer.push(`<!----></div> <div class="text-center">`);
						PlayerPermissionBadge($$renderer, { permissionGroupName: store_get($$store_subs ??= {}, "$data", data).permissionGroupName });
						$$renderer.push(`<!----></div></div></div>`);
					} else {
						$$renderer.push("<!--[-1-->");
						ViewComponent($$renderer, spread_props([{
							component: item.component,
							data: store_get($$store_subs ??= {}, "$data", data),
							user,
							checkTime
						}, item.props]));
					}
					$$renderer.push(`<!--]-->`);
				}
				$$renderer.push(`<!--]--></div></div>`);
			},
			$$slots: { default: true }
		});
		if ($$store_subs) unsubscribe_stores($$store_subs);
		bind_props($$props, {
			side,
			showDeleteAll
		});
	});
}

export { ProfileSidebar as P, load as l };
//# sourceMappingURL=ProfileSidebar.js-BIu8zSKN.js.map
