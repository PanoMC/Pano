import { $ as ensure_array_like, a0 as store_get, a5 as escape_html, a2 as unsubscribe_stores, W as bind_props } from './server.js-D28cBEJ-.js';
import { $ as $format } from './runtime.js-CJgfVvxa.js';
import { D as Date_1 } from './Date.js-ZK3lGml2.js';
import { C as CardHeader } from './CardHeader.js-DpkWpoy6.js';
import { V as ViewComponent } from './ViewComponent.js-C6amYVVM.js';
import './uneval.js-BL1Qg77w.js';
import './rolldown-runtime.js-B5FuG9Gw.js';
import 'node:module';
import './language.util.js-C2xYQq5-.js';
import './internal.js-BlXt2rfE.js';
import './client.js-CPEkJ2-P.js';
import './shared.js-3i5_hmQ1.js';
import './exports.js-CKkpMUqI.js';
import './internal2.js-KmQU-gaY.js';
import './index-server2.js-DlblWyyK.js';
import './Store.js-C2vdyE6V.js';
import './exports2.js-DxZfja4I.js';
import './ToastContainer.js-CtmBBvhr.js';
import './tooltip.util.js-Bd9x5X7L.js';
import './stores.js-QbD2A2ib.js';
import './locale.js-DnnPB87K.js';
import './format.js-CzDFIcjs.js';

//#region node_modules/@panomc/theme-core/src/lib/views/ProfileView.svelte
function ProfileView($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let data = $$props["data"];
		let contentItems = $$props["contentItems"];
		let cardRowItems = $$props["cardRowItems"];
		$$renderer.push(`<div class="vstack gap-3"><!--[-->`);
		const each_array = ensure_array_like(store_get($$store_subs ??= {}, "$contentItems", contentItems));
		for (let $$index_1 = 0, $$length = each_array.length; $$index_1 < $$length; $$index_1++) {
			let item = each_array[$$index_1];
			if (item.id === "profile-card") {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<div class="card">`);
				CardHeader($$renderer, { $$slots: { left: ($$renderer) => {
					$$renderer.push(`<div slot="left">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.profile.title"))}</div>`);
				} } });
				$$renderer.push(`<!----> <table class="table"><tbody><!--[-->`);
				const each_array_1 = ensure_array_like(store_get($$store_subs ??= {}, "$cardRowItems", cardRowItems));
				for (let $$index = 0, $$length = each_array_1.length; $$index < $$length; $$index++) {
					let row = each_array_1[$$index];
					if (row.id === "register-date") {
						$$renderer.push("<!--[0-->");
						$$renderer.push(`<tr><td>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.profile.register-date"))}</td><td>`);
						Date_1($$renderer, { time: data.registerDate });
						$$renderer.push(`<!----></td></tr>`);
					} else if (row.id === "last-login") {
						$$renderer.push("<!--[1-->");
						$$renderer.push(`<tr><td>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.profile.last-login"))}</td><td>`);
						Date_1($$renderer, {
							time: data.lastLoginDate,
							relativeFormat: "true"
						});
						$$renderer.push(`<!----></td></tr>`);
					} else if (row.props && row.props.label) {
						$$renderer.push("<!--[2-->");
						$$renderer.push(`<tr><td>${escape_html(row.props.label && row.props.label.includes(".") ? store_get($$store_subs ??= {}, "$_", $format)(row.props.label) : row.props.label)}</td><td>`);
						if (row.component) {
							$$renderer.push("<!--[0-->");
							ViewComponent($$renderer, {
								component: row.component,
								data: row.props.data
							});
						} else {
							$$renderer.push("<!--[-1-->");
							$$renderer.push(`${escape_html(row.props.value || "")}`);
						}
						$$renderer.push(`<!--]--></td></tr>`);
					} else $$renderer.push("<!--[-1-->");
					$$renderer.push(`<!--]-->`);
				}
				$$renderer.push(`<!--]--></tbody></table></div>`);
			} else if (item.component) {
				$$renderer.push("<!--[1-->");
				ViewComponent($$renderer, {
					component: item.component,
					data
				});
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]-->`);
		}
		$$renderer.push(`<!--]--></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
		bind_props($$props, {
			data,
			contentItems,
			cardRowItems
		});
	});
}

export { ProfileView as default };
//# sourceMappingURL=ProfileView.js-BXVlxp2Y.js.map
