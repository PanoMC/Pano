import { V as fallback, g as getContext, X as attr, a5 as escape_html, a0 as store_get, a3 as html, _ as slot, Z as attr_class, a2 as unsubscribe_stores, W as bind_props } from './server.js-D28cBEJ-.js';
import 'node:module';
import { $ as $format } from './runtime.js-CJgfVvxa.js';

//#region node_modules/@panomc/theme-core/src/lib/components/RegisterForm.svelte
function RegisterForm($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let username = fallback($$props["username"], "");
		let email = fallback($$props["email"], "");
		let password = fallback($$props["password"], "");
		let passwordRepeat = fallback($$props["passwordRepeat"], "");
		let agreement = fallback($$props["agreement"], false);
		let loading = fallback($$props["loading"], false);
		let usernameDisabled = fallback($$props["usernameDisabled"], false);
		const session = getContext("session");
		$$renderer.push(`<div class="form-group"><div class="form-floating"><input${attr("value", username)} class="form-control rounded-bottom-0 svelte-ez026b"${attr("disabled", loading || usernameDisabled, true)} id="registerUserName" type="text"/> <label for="registerUserName">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.register.inputs.username"))}</label></div> <div class="form-floating"><input${attr("value", email)} class="form-control rounded-top-0 svelte-ez026b"${attr("disabled", loading, true)} id="registerEmail" type="email"/> <label for="registerEmail">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.register.inputs.email"))}</label></div></div> <div class="form-group"><div class="form-floating"><input${attr("value", password)} class="form-control rounded-bottom-0 svelte-ez026b"${attr("disabled", loading, true)} id="registerPassword" type="password"/> <label for="registerPassword">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.register.inputs.password"))}</label></div> <div class="form-floating"><input${attr("value", passwordRepeat)} class="form-control rounded-top-0 svelte-ez026b"${attr("disabled", loading, true)} id="registerPasswordRepeat" type="password"/> <label for="registerPasswordRepeat">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.register.inputs.password-repeat"))}</label></div></div> `);
		if (store_get($$store_subs ??= {}, "$session", session).siteInfo.hasRegisterAgreement) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<div class="form-check"><input${attr("checked", agreement, true)} class="form-check-input"${attr("disabled", loading, true)} id="registerAcceptTerms" type="checkbox"/> <label class="form-check-label" for="registerAcceptTerms">${html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.register.inputs.agreement-text", { values: { link: `<a class="rounded focus-ring" href="/rules">${store_get($$store_subs ??= {}, "$_", $format)("components.modals.register.inputs.server-rules")}</a>` } }))}</label></div>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--> <!--[-->`);
		slot($$renderer, $$props, "beforeSubmit", {}, null);
		$$renderer.push(`<!--]--> <div class="vstack gap-2"><button${attr_class("btn btn-lg btn-secondary", void 0, { "disabled": loading })}${attr("disabled", loading, true)} type="submit">`);
		if (loading) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<span class="spinner-border spinner-border-sm me-2" role="status" aria-label="Loading"></span> <span>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.register"))}...</span>`);
		} else {
			$$renderer.push("<!--[-1-->");
			$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.register"))}`);
		}
		$$renderer.push(`<!--]--></button> <!--[-->`);
		slot($$renderer, $$props, "footer", {}, null);
		$$renderer.push(`<!--]--></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
		bind_props($$props, {
			username,
			email,
			password,
			passwordRepeat,
			agreement,
			loading,
			usernameDisabled
		});
	});
}

export { RegisterForm as R };
//# sourceMappingURL=RegisterForm.js-DuIBDPut.js.map
