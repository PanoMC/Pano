import { g as getContext, T as writable, a0 as store_get, a2 as unsubscribe_stores, W as bind_props } from './server.js-D28cBEJ-.js';
import 'node:module';
import { g as goto } from './client.js-CPEkJ2-P.js';
import { h as panoApiServer, e as executeLifecycle, b as executeViewLoad, p as panoApiClient } from './PluginManager.js-B5x3OKEW.js';
import { r as resolveView } from './registry2.js-BubD3cPq.js';
import { o as sendRegister, p as getCredentials, N as NETWORK_ERROR } from './Store.js-C2vdyE6V.js';
import { s as showSuccess } from './ToastContainer.js-CtmBBvhr.js';

//#region node_modules/@panomc/theme-core/src/lib/pages/RegisterPage.svelte
async function load(event) {
	const viewPromise = resolveView("RegisterView", () => import('./RegisterView.js-C1-FytWK.js'));
	const { parent } = event;
	await parent();
	panoApiServer.ui.auth.register.content.edit((items) => {
		items.push({
			id: "register-form",
			priority: 100,
			hidden: false
		});
	});
	const lifecycleData = {
		error: null,
		username: null,
		event
	};
	await executeLifecycle("theme:register:load", lifecycleData, event);
	await executeViewLoad("register-content", event);
	await executeViewLoad("register-alt-methods", event);
	return {
		initialError: lifecycleData.error || null,
		initialUsername: lifecycleData.username || null,
		pageTitle: "components.modals.register.title",
		View: await viewPromise
	};
}
function RegisterPage($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let data = $$props["data"];
		const session = getContext("session");
		const loading = writable();
		const error = writable();
		const successMessage = writable();
		const username = writable("");
		const email = writable("");
		const password = writable("");
		const passwordRepeat = writable("");
		if (data?.initialError) error.set(data.initialError);
		if (data?.initialUsername) username.set(data.initialUsername);
		const agreement = writable(!store_get($$store_subs ??= {}, "$session", session).siteInfo.hasRegisterAgreement ? true : false);
		async function onSubmit() {
			error.set(null);
			successMessage.set(null);
			loading.set(true);
			await sendRegister({
				username: store_get($$store_subs ??= {}, "$username", username),
				email: store_get($$store_subs ??= {}, "$email", email),
				password: store_get($$store_subs ??= {}, "$password", password),
				passwordRepeat: store_get($$store_subs ??= {}, "$passwordRepeat", passwordRepeat),
				agreement: store_get($$store_subs ??= {}, "$agreement", agreement),
				recaptcha: ""
			}).then(async (body) => {
				if (body.result === "ok") {
					if (body.login) {
						const csrfToken = body.csrfToken;
						const credsBody = await getCredentials(csrfToken);
						session.update((data) => {
							data.user = { ...Object.keys(credsBody).filter((key) => !["result"].includes(key)).reduce((object, key) => {
								object[key] = credsBody[key];
								return object;
							}, {}) };
							data.csrfToken = csrfToken;
							return data;
						});
						await showSuccess("successes.LOGIN_SUCCESSFUL");
						await goto();
						loading.set(false);
						return;
					}
					successMessage.set("REGISTER_SUCCESSFUL");
					loading.set(false);
				} else {
					if (body.error === "PLUGIN_DENIED_LOGIN" && body.reason) error.set(body.reason);
					else error.set(body.result === "error" ? body.error : NETWORK_ERROR);
					loading.set(false);
				}
			}).catch(() => {
				loading.set(false);
				error.set(NETWORK_ERROR);
			});
		}
		const contentItems = panoApiClient.ui.auth.register.content.get();
		const altMethods = panoApiClient.ui.auth.register.alternativeMethods.get();
		if (data.View) {
			$$renderer.push("<!--[-->");
			data.View($$renderer, {
				data,
				contentItems,
				altMethods,
				onSubmit,
				loading,
				error,
				successMessage,
				username,
				email,
				password,
				passwordRepeat,
				agreement
			});
			$$renderer.push("<!--]-->");
		} else {
			$$renderer.push("<!--[!-->");
			$$renderer.push("<!--]-->");
		}
		if ($$store_subs) unsubscribe_stores($$store_subs);
		bind_props($$props, { data });
	});
}

export { RegisterPage as R, load as l };
//# sourceMappingURL=RegisterPage.js-BcNWSfKE.js.map
