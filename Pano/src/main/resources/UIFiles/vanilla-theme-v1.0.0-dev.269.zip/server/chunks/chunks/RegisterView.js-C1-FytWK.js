import { W as bind_props, $ as ensure_array_like, a0 as store_get, Z as attr_class, Y as stringify, X as attr, a5 as escape_html, a9 as store_set, a2 as unsubscribe_stores } from './server.js-D28cBEJ-.js';
import { $ as $format } from './runtime.js-CJgfVvxa.js';
import { V as ViewComponent } from './ViewComponent.js-C6amYVVM.js';
import { E as ErrorAlert } from './ErrorAlert.js-DbwaZ_OB.js';
import { R as RegisterForm } from './RegisterForm.js-DuIBDPut.js';
import { S as SuccessAlert } from './SuccessAlert.js-D6Etg0s_.js';
import './uneval.js-BL1Qg77w.js';
import './rolldown-runtime.js-B5FuG9Gw.js';
import 'node:module';

//#region node_modules/@panomc/theme-core/src/lib/views/RegisterView.svelte
function RegisterView($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let data = $$props["data"];
		let contentItems = $$props["contentItems"];
		let altMethods = $$props["altMethods"];
		let onSubmit = $$props["onSubmit"];
		let loading = $$props["loading"];
		let error = $$props["error"];
		let successMessage = $$props["successMessage"];
		let username = $$props["username"];
		let email = $$props["email"];
		let password = $$props["password"];
		let passwordRepeat = $$props["passwordRepeat"];
		let agreement = $$props["agreement"];
		let $$settled = true;
		let $$inner_renderer;
		function $$render_inner($$renderer) {
			$$renderer.push(`<div class="container mx-auto"><div class="vstack gap-3"><!--[-->`);
			const each_array = ensure_array_like(store_get($$store_subs ??= {}, "$contentItems", contentItems));
			for (let $$index_1 = 0, $$length = each_array.length; $$index_1 < $$length; $$index_1++) {
				let item = each_array[$$index_1];
				if (item.id === "register-form") {
					$$renderer.push("<!--[0-->");
					$$renderer.push(`<form><div class="vstack gap-3">`);
					SuccessAlert($$renderer, { message: store_get($$store_subs ??= {}, "$successMessage", successMessage) });
					$$renderer.push(`<!----> `);
					ErrorAlert($$renderer, { error: store_get($$store_subs ??= {}, "$error", error) });
					$$renderer.push(`<!----> `);
					RegisterForm($$renderer, {
						loading: store_get($$store_subs ??= {}, "$loading", loading),
						get username() {
							return store_get($$store_subs ??= {}, "$username", username);
						},
						set username($$value) {
							store_set(username, $$value);
							$$settled = false;
						},
						get email() {
							return store_get($$store_subs ??= {}, "$email", email);
						},
						set email($$value) {
							store_set(email, $$value);
							$$settled = false;
						},
						get password() {
							return store_get($$store_subs ??= {}, "$password", password);
						},
						set password($$value) {
							store_set(password, $$value);
							$$settled = false;
						},
						get passwordRepeat() {
							return store_get($$store_subs ??= {}, "$passwordRepeat", passwordRepeat);
						},
						set passwordRepeat($$value) {
							store_set(passwordRepeat, $$value);
							$$settled = false;
						},
						get agreement() {
							return store_get($$store_subs ??= {}, "$agreement", agreement);
						},
						set agreement($$value) {
							store_set(agreement, $$value);
							$$settled = false;
						},
						$$slots: {
							beforeSubmit: ($$renderer) => {
								$$renderer.push(`<div slot="beforeSubmit"><!--[-->`);
								const each_array_1 = ensure_array_like(store_get($$store_subs ??= {}, "$contentItems", contentItems));
								for (let $$index = 0, $$length = each_array_1.length; $$index < $$length; $$index++) {
									let inlineItem = each_array_1[$$index];
									if (inlineItem.id !== "register-form" && inlineItem.component && (inlineItem.priority || 0) < 100) {
										$$renderer.push("<!--[0-->");
										ViewComponent($$renderer, {
											component: inlineItem.component,
											data: { pageType: "register" }
										});
									} else $$renderer.push("<!--[-1-->");
									$$renderer.push(`<!--]-->`);
								}
								$$renderer.push(`<!--]--></div>`);
							},
							footer: ($$renderer) => {
								$$renderer.push(`<div slot="footer" class="text-center"><a${attr_class(`btn btn-link ${stringify(store_get($$store_subs ??= {}, "$loading", loading) ? "disabled pe-none" : "")}`)}${attr("aria-disabled", store_get($$store_subs ??= {}, "$loading", loading))}${attr("tabindex", store_get($$store_subs ??= {}, "$loading", loading) ? -1 : void 0)} href="/login">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.already-registered"))}</a></div>`);
							}
						}
					});
					$$renderer.push(`<!----></div></form>`);
				} else if (item.component && (item.priority || 0) >= 100) {
					$$renderer.push("<!--[1-->");
					ViewComponent($$renderer, {
						component: item.component,
						data: { pageType: "register" }
					});
				} else $$renderer.push("<!--[-1-->");
				$$renderer.push(`<!--]-->`);
			}
			$$renderer.push(`<!--]--> `);
			if (store_get($$store_subs ??= {}, "$altMethods", altMethods) && store_get($$store_subs ??= {}, "$altMethods", altMethods).length > 0) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<div class="alt-methods-divider svelte-1tu2vj2"><span>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.login.or"))}</span></div> <div class="vstack gap-2"><!--[-->`);
				const each_array_2 = ensure_array_like(store_get($$store_subs ??= {}, "$altMethods", altMethods));
				for (let $$index_2 = 0, $$length = each_array_2.length; $$index_2 < $$length; $$index_2++) {
					let method = each_array_2[$$index_2];
					ViewComponent($$renderer, {
						component: method.component,
						data: { pageType: "register" }
					});
				}
				$$renderer.push(`<!--]--></div>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--></div></div>`);
		}
		do {
			$$settled = true;
			$$inner_renderer = $$renderer.copy();
			$$render_inner($$inner_renderer);
		} while (!$$settled);
		$$renderer.subsume($$inner_renderer);
		if ($$store_subs) unsubscribe_stores($$store_subs);
		bind_props($$props, {
			data,
			contentItems,
			altMethods,
			onSubmit,
			loading,
			error,
			successMessage,
			username,
			email,
			password,
			passwordRepeat,
			agreement
		});
	});
}

export { RegisterView as default };
//# sourceMappingURL=RegisterView.js-C1-FytWK.js.map
