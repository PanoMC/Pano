import { W as bind_props, a4 as get, T as writable } from './server.js-D28cBEJ-.js';
import { p as panoApiClient, e as executeLifecycle, b as executeViewLoad } from './PluginManager.js-B5x3OKEW.js';
import { r as resolveView } from './registry2.js-BubD3cPq.js';
import { w as sendRenewPassword, N as NETWORK_ERROR } from './Store.js-C2vdyE6V.js';

//#region node_modules/@panomc/theme-core/src/lib/ui-logics/page-logics/RenewPasswordPageLogics.js
async function processLoad(event) {
	const { parent, url: { searchParams } } = event;
	await parent();
	const token = searchParams.get("token") || "";
	await executeLifecycle("theme:renew-password:load", { token }, event);
	await executeViewLoad("renew-password-content", event);
	return {
		token,
		pageTitle: "pages.renew-password.title"
	};
}
async function onSubmit(error, message, loading, newPassword, newPasswordRepeat, data) {
	error.set(null);
	message.set(null);
	loading.set(true);
	await sendRenewPassword(get(newPassword), get(newPasswordRepeat), data.token).then((body) => {
		loading.set(false);
		if (body.result === "ok") {
			message.set("RENEW_PASSWORD_SUCCESSFUL");
			return;
		}
		if (body.error === "PLUGIN_DENIED_LOGIN" && body.reason) error.set(body.reason);
		else error.set(body.error);
	}).catch(() => {
		error.set(NETWORK_ERROR);
		loading.set(false);
	});
}
//#endregion
//#region node_modules/@panomc/theme-core/src/lib/pages/RenewPasswordPage.svelte
async function load(event) {
	const viewPromise = resolveView("RenewPasswordView", () => import('./RenewPasswordView.js-B1i8f_R2.js'));
	return {
		...await processLoad(event),
		View: await viewPromise
	};
}
function RenewPasswordPage($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		let data = $$props["data"];
		const renewPasswordContentItems = panoApiClient.ui.auth.renewPassword.content.get();
		let error = writable();
		let message = writable();
		let loading = writable();
		let newPassword = writable("");
		let newPasswordRepeat = writable("");
		if (data.View) {
			$$renderer.push("<!--[-->");
			data.View($$renderer, {
				data,
				error,
				message,
				loading,
				newPassword,
				newPasswordRepeat,
				renewPasswordContentItems,
				onSubmit
			});
			$$renderer.push("<!--]-->");
		} else {
			$$renderer.push("<!--[!-->");
			$$renderer.push("<!--]-->");
		}
		bind_props($$props, { data });
	});
}

export { RenewPasswordPage as R, load as l };
//# sourceMappingURL=RenewPasswordPage.js-DmLYgKHg.js.map
