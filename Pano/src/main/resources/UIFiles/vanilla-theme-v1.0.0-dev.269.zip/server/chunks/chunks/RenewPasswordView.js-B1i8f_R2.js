import { a5 as escape_html, a0 as store_get, X as attr, $ as ensure_array_like, Z as attr_class, a2 as unsubscribe_stores, W as bind_props } from './server.js-D28cBEJ-.js';
import { $ as $format } from './runtime.js-CJgfVvxa.js';
import { V as ViewComponent } from './ViewComponent.js-C6amYVVM.js';
import { E as ErrorAlert } from './ErrorAlert.js-DbwaZ_OB.js';
import { S as SuccessAlert } from './SuccessAlert.js-D6Etg0s_.js';
import './uneval.js-BL1Qg77w.js';
import './rolldown-runtime.js-B5FuG9Gw.js';
import 'node:module';

//#region node_modules/@panomc/theme-core/src/lib/views/RenewPasswordView.svelte
function RenewPasswordView($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let data = $$props["data"];
		let error = $$props["error"];
		let message = $$props["message"];
		let loading = $$props["loading"];
		let newPassword = $$props["newPassword"];
		let newPasswordRepeat = $$props["newPasswordRepeat"];
		let renewPasswordContentItems = $$props["renewPasswordContentItems"];
		let onSubmit = $$props["onSubmit"];
		$$renderer.push(`<div class="col-lg-4 col-md-6 m-auto"><div class="card"><div class="card-body"><h5 class="card-title">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.renew-password.title"))}</h5> `);
		ErrorAlert($$renderer, { error: store_get($$store_subs ??= {}, "$error", error) });
		$$renderer.push(`<!----> `);
		SuccessAlert($$renderer, { message: store_get($$store_subs ??= {}, "$message", message) });
		$$renderer.push(`<!----> <form><div class="vstack gap-3"><div class="input-group"><div class="form-floating"><input type="password" id="newPassword" class="form-control"${attr("disabled", store_get($$store_subs ??= {}, "$loading", loading), true)}${attr("value", store_get($$store_subs ??= {}, "$newPassword", newPassword))}/> <label for="newPassword">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.renew-password.inputs.new-password"))}</label></div> <div class="form-floating"><input type="password" id="newPasswordRepeat" class="form-control"${attr("disabled", store_get($$store_subs ??= {}, "$loading", loading), true)}${attr("value", store_get($$store_subs ??= {}, "$newPasswordRepeat", newPasswordRepeat))}/> <label for="newPasswordRepeat">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.renew-password.inputs.new-password-repeat"))}</label></div></div> <!--[-->`);
		const each_array = ensure_array_like(store_get($$store_subs ??= {}, "$renewPasswordContentItems", renewPasswordContentItems));
		for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
			let item = each_array[$$index];
			if (item.component) {
				$$renderer.push("<!--[0-->");
				ViewComponent($$renderer, {
					component: item.component,
					data: { pageType: "renew-password" }
				});
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]-->`);
		}
		$$renderer.push(`<!--]--> <button type="submit"${attr_class("btn btn-lg btn-secondary w-100", void 0, { "disabled": store_get($$store_subs ??= {}, "$loading", loading) })}${attr("disabled", store_get($$store_subs ??= {}, "$loading", loading), true)}>`);
		if (store_get($$store_subs ??= {}, "$loading", loading)) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<span class="spinner-border spinner-border-sm me-2" role="status" aria-label="Loading"></span> <span>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.change-password"))}...</span>`);
		} else {
			$$renderer.push("<!--[-1-->");
			$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.change-password"))}`);
		}
		$$renderer.push(`<!--]--></button></div></form></div></div></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
		bind_props($$props, {
			data,
			error,
			message,
			loading,
			newPassword,
			newPasswordRepeat,
			renewPasswordContentItems,
			onSubmit
		});
	});
}

export { RenewPasswordView as default };
//# sourceMappingURL=RenewPasswordView.js-B1i8f_R2.js.map
