import { a0 as store_get, a2 as unsubscribe_stores, a4 as get, T as writable } from './server.js-D28cBEJ-.js';
import 'node:module';
import { p as page } from './stores.js-QbD2A2ib.js';
import { p as panoApiClient, e as executeLifecycle, b as executeViewLoad } from './PluginManager.js-B5x3OKEW.js';
import { r as resolveView } from './registry2.js-BubD3cPq.js';
import { r as requireNotLogin, x as sendResetPassword, N as NETWORK_ERROR } from './Store.js-C2vdyE6V.js';
import { s as stripIdentifierWhitespace } from './loginInput.util.js-BxkO11lZ.js';

//#region node_modules/@panomc/theme-core/src/lib/ui-logics/page-logics/ResetPasswordPageLogics.js
async function processLoad(event) {
	const { parent } = event;
	const { session } = await parent();
	requireNotLogin(session);
	await executeLifecycle("theme:reset-password:load", {}, event);
	await executeViewLoad("reset-password-content", event);
	return { pageTitle: "pages.reset-password.title" };
}
async function onSubmit(error, message, loading, usernameOrEmail) {
	error.set(null);
	message.set(null);
	loading.set(true);
	await sendResetPassword(get(usernameOrEmail)).then((body) => {
		loading.set(false);
		if (body.result === "ok") {
			message.set("RESET_PASSWORD_SUCCESSFUL");
			return;
		}
		if (body.error === "NOT_EXISTS") {
			message.set("RESET_PASSWORD_SUCCESSFUL");
			return;
		}
		if (body.error === "PLUGIN_DENIED_LOGIN" && body.reason) error.set(body.reason);
		else error.set(body.error);
	}).catch(() => {
		error.set(NETWORK_ERROR);
		loading.set(false);
	});
}
//#endregion
//#region node_modules/@panomc/theme-core/src/lib/pages/ResetPasswordPage.svelte
async function load(event) {
	const viewPromise = resolveView("ResetPasswordView", () => import('./ResetPasswordView.js-D__8D8MM.js'));
	return {
		...await processLoad(event),
		View: await viewPromise
	};
}
function ResetPasswordPage($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let data;
		const resetPasswordContentItems = panoApiClient.ui.auth.resetPassword.content.get();
		const error = writable();
		const message = writable();
		const loading = writable();
		const usernameOrEmail = writable("");
		data = store_get($$store_subs ??= {}, "$page", page).data;
		if (data.View) {
			$$renderer.push("<!--[-->");
			data.View($$renderer, {
				data,
				error,
				message,
				loading,
				usernameOrEmail,
				resetPasswordContentItems,
				onSubmit,
				stripIdentifierWhitespace
			});
			$$renderer.push("<!--]-->");
		} else {
			$$renderer.push("<!--[!-->");
			$$renderer.push("<!--]-->");
		}
		if ($$store_subs) unsubscribe_stores($$store_subs);
	});
}

export { ResetPasswordPage as R, load as l };
//# sourceMappingURL=ResetPasswordPage.js-Bb3jgt9S.js.map
