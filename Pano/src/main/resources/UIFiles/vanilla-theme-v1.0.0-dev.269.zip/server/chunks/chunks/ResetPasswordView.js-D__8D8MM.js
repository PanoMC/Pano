import { a0 as store_get, X as attr, a5 as escape_html, $ as ensure_array_like, Z as attr_class, a2 as unsubscribe_stores, W as bind_props } from './server.js-D28cBEJ-.js';
import { $ as $format } from './runtime.js-CJgfVvxa.js';
import { V as ViewComponent } from './ViewComponent.js-C6amYVVM.js';
import { E as ErrorAlert } from './ErrorAlert.js-DbwaZ_OB.js';
import { S as SuccessAlert } from './SuccessAlert.js-D6Etg0s_.js';
import './uneval.js-BL1Qg77w.js';
import './rolldown-runtime.js-B5FuG9Gw.js';
import 'node:module';

//#region node_modules/@panomc/theme-core/src/lib/views/ResetPasswordView.svelte
function ResetPasswordView($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let data = $$props["data"];
		let error = $$props["error"];
		let message = $$props["message"];
		let loading = $$props["loading"];
		let usernameOrEmail = $$props["usernameOrEmail"];
		let resetPasswordContentItems = $$props["resetPasswordContentItems"];
		let onSubmit = $$props["onSubmit"];
		let stripIdentifierWhitespace = $$props["stripIdentifierWhitespace"];
		$$renderer.push(`<div class="vstack gap-3">`);
		ErrorAlert($$renderer, { error: store_get($$store_subs ??= {}, "$error", error) });
		$$renderer.push(`<!----> `);
		SuccessAlert($$renderer, { message: store_get($$store_subs ??= {}, "$message", message) });
		$$renderer.push(`<!----> <form><div class="vstack gap-3"><div class="form-floating"><input type="text"${attr("disabled", store_get($$store_subs ??= {}, "$loading", loading), true)}${attr("placeholder", store_get($$store_subs ??= {}, "$_", $format)("pages.reset-password.inputs.email-username.placeholder"))} id="email" class="form-control"${attr("value", store_get($$store_subs ??= {}, "$usernameOrEmail", usernameOrEmail))}/> <label for="email">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.reset-password.inputs.email-username.placeholder"))}</label></div> <!--[-->`);
		const each_array = ensure_array_like(store_get($$store_subs ??= {}, "$resetPasswordContentItems", resetPasswordContentItems));
		for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
			let item = each_array[$$index];
			if (item.component) {
				$$renderer.push("<!--[0-->");
				ViewComponent($$renderer, {
					component: item.component,
					data: { pageType: "reset-password" }
				});
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]-->`);
		}
		$$renderer.push(`<!--]--> <button type="submit"${attr_class("btn btn-lg btn-secondary w-100", void 0, { "disabled": store_get($$store_subs ??= {}, "$loading", loading) || !store_get($$store_subs ??= {}, "$usernameOrEmail", usernameOrEmail) })}${attr("disabled", store_get($$store_subs ??= {}, "$loading", loading) || !store_get($$store_subs ??= {}, "$usernameOrEmail", usernameOrEmail), true)}>`);
		if (store_get($$store_subs ??= {}, "$loading", loading)) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<span class="spinner-border spinner-border-sm me-2" role="status" aria-label="Loading"></span> <span>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.reset-password"))}...</span>`);
		} else {
			$$renderer.push("<!--[-1-->");
			$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.reset-password"))}`);
		}
		$$renderer.push(`<!--]--></button></div></form></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
		bind_props($$props, {
			data,
			error,
			message,
			loading,
			usernameOrEmail,
			resetPasswordContentItems,
			onSubmit,
			stripIdentifierWhitespace
		});
	});
}

export { ResetPasswordView as default };
//# sourceMappingURL=ResetPasswordView.js-D__8D8MM.js.map
