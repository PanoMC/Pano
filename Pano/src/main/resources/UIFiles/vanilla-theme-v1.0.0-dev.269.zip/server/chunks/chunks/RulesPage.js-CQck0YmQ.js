import { e as error } from './exports2.js-DxZfja4I.js';
import { W as bind_props } from './server.js-D28cBEJ-.js';
import { r as resolveView } from './registry2.js-BubD3cPq.js';
import { d as ApiUtil } from './Store.js-C2vdyE6V.js';

//#region node_modules/@panomc/theme-core/src/lib/pages/RulesPage.svelte
async function load(event) {
	const viewPromise = resolveView("RulesView", () => import('./RulesView.js-C5t0jcNv.js'));
	const parentData = await event.parent();
	const session = parentData.session;
	if (!session.siteInfo.hasRegisterAgreement) throw error(404);
	const csrfToken = session.csrfToken;
	let registerAgreement;
	try {
		registerAgreement = (await ApiUtil.get({
			path: "/api/registerAgreement",
			request: event,
			csrfToken
		})).registerAgreement;
	} catch (_e) {
		throw error(404);
	}
	return {
		...parentData,
		pageTitle: "pages.rules.title",
		registerAgreement,
		View: await viewPromise
	};
}
function RulesPage($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		let data = $$props["data"];
		if (data.View) {
			$$renderer.push("<!--[-->");
			data.View($$renderer, { data });
			$$renderer.push("<!--]-->");
		} else {
			$$renderer.push("<!--[!-->");
			$$renderer.push("<!--]-->");
		}
		bind_props($$props, { data });
	});
}

export { RulesPage as R, load as l };
//# sourceMappingURL=RulesPage.js-CQck0YmQ.js.map
