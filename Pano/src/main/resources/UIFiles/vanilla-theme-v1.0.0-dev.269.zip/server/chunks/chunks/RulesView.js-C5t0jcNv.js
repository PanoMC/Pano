import { a5 as escape_html, a0 as store_get, a3 as html, a2 as unsubscribe_stores, W as bind_props } from './server.js-D28cBEJ-.js';
import { $ as $format } from './runtime.js-CJgfVvxa.js';
import './uneval.js-BL1Qg77w.js';
import './rolldown-runtime.js-B5FuG9Gw.js';
import 'node:module';

//#region node_modules/@panomc/theme-core/src/lib/views/RulesView.svelte
function RulesView($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let data = $$props["data"];
		$$renderer.push(`<div class="vstack gap-3"><div class="alert alert-secondary mb-0" role="alert"><i class="fas fa-gavel me-2"></i> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.rules.warning"))}</div> <div class="card"><div class="card-body">${html(data.registerAgreement)}</div></div></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
		bind_props($$props, { data });
	});
}

export { RulesView as default };
//# sourceMappingURL=RulesView.js-C5t0jcNv.js.map
