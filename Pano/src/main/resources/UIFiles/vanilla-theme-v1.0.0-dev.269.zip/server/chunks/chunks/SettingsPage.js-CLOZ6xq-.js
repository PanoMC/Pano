import { g as getContext, a0 as store_get, U as derived$1, a2 as unsubscribe_stores, W as bind_props, T as writable, a4 as get } from './server.js-D28cBEJ-.js';
import 'node:module';
import { i as invalidateAll } from './client.js-CPEkJ2-P.js';
import { p as panoApiClient, h as panoApiServer, e as executeLifecycle, b as executeViewLoad } from './PluginManager.js-B5x3OKEW.js';
import { r as resolveView } from './registry2.js-BubD3cPq.js';
import { t as logout, d as ApiUtil, N as NETWORK_ERROR } from './Store.js-C2vdyE6V.js';
import { a as show } from './ToastContainer.js-CtmBBvhr.js';
import { c as currentLanguage, L as Languages, a as changeLanguage, g as getLanguageByLocale } from './language.util.js-C2xYQq5-.js';
import { s as stripIdentifierWhitespace } from './loginInput.util.js-BxkO11lZ.js';
import { l as load$1, P as ProfileSidebar } from './ProfileSidebar.js-BIu8zSKN.js';
import { s as sendChangeEmail, b as sendResetPassword, c as sendUpdateProfile } from './profile.js-C7iU3TQf.js';
import { p as parseUserAgent } from './string.util.js-dF34MZ_o.js';

//#region node_modules/@panomc/theme-core/src/lib/ui-logics/page-logics/SettingsPageLogics.js
/**
* @type {import("@sveltejs/kit").Load}
*/
async function processLoad(event) {
	const { parent } = event;
	await parent();
	panoApiServer.ui.settings.content.edit((items) => {
		items.push({
			id: "settings-cards",
			priority: 300,
			hidden: false
		}, {
			id: "sessions-card",
			priority: 100,
			hidden: false
		});
	});
	panoApiServer.ui.settings.cardRows.edit((items) => {
		items.push({
			id: "change-password",
			priority: 100,
			hidden: false
		}, {
			id: "change-email",
			priority: 90,
			hidden: false
		}, {
			id: "display-language",
			priority: 80,
			hidden: false
		});
	});
	await executeLifecycle("theme:settings:load", {}, event);
	const [, , , sessionsBody] = await Promise.all([
		executeViewLoad("settings-content", event),
		executeViewLoad("settings-card-rows", event),
		load$1(event),
		ApiUtil.get({
			path: "/api/profile/sessions",
			request: event
		})
	]);
	return {
		sidebar: ProfileSidebar,
		sessions: !sessionsBody.error ? sessionsBody.sessions : [],
		pageTitle: "pages.settings.title"
	};
}
async function sendResetPasswordLink(resetPasswordError, resetPasswordLoading, resetPasswordSuccess) {
	resetPasswordError.set(null);
	resetPasswordLoading.set(true);
	resetPasswordSuccess.set(false);
	await sendResetPassword().then((body) => {
		resetPasswordLoading.set(false);
		if (body.result === "ok") {
			resetPasswordSuccess.set(true);
			return;
		}
		resetPasswordError.set(body.error || "NETWORK_ERROR");
	}).catch(() => {
		resetPasswordLoading.set(false);
		resetPasswordError.set(NETWORK_ERROR);
	});
}
async function sendChangeEmailLink(changingEmailError, changingEmailLoading, changingEmailSuccess, currentPassword, newEmail, changingEmail, changingEmail2ndStep) {
	const next = get(newEmail);
	if (next == null || String(next).trim() === "") return;
	changingEmailError.set(null);
	changingEmailLoading.set(true);
	changingEmailSuccess.set(false);
	await sendChangeEmail(get(currentPassword), get(newEmail)).then((body) => {
		changingEmailLoading.set(false);
		if (body.result === "ok") {
			changingEmail.set(false);
			changingEmail2ndStep.set(false);
			changingEmailSuccess.set(true);
			return;
		}
		const err = body.error || "NETWORK_ERROR";
		if (err === "CURRENT_PASSWORD_NOT_CORRECT") changingEmail2ndStep.set(false);
		changingEmailError.set(err);
	}).catch(() => {
		changingEmailLoading.set(false);
		changingEmailError.set(NETWORK_ERROR);
	});
}
function startChangingEmail(changingEmail, changingEmailError) {
	changingEmailError.set(null);
	changingEmail.set(true);
}
function startChangingEmail2ndStep(changingEmail2ndStep, currentPassword, changingEmailError) {
	const pwd = get(currentPassword);
	if (pwd == null || String(pwd).trim() === "") return;
	changingEmailError.set(null);
	changingEmail2ndStep.set(true);
}
function stopChangingEmail(currentPassword, newEmail, changingEmail, changingEmail2ndStep, changingEmailError) {
	currentPassword.set("");
	newEmail.set("");
	changingEmailError.set(null);
	changingEmail2ndStep.set(false);
	changingEmail.set(false);
}
function stopChangingEmail2ndStep(changingEmail2ndStep, changingEmailError) {
	changingEmail2ndStep.set(false);
	changingEmailError.set(null);
}
async function saveSettings(userLocale, saveButtonLoading) {
	saveButtonLoading.set(true);
	await sendUpdateProfile({ localeCode: get(userLocale) }).then((body) => {
		if (body.error) {
			location.reload();
			return;
		}
		changeLanguage(getLanguageByLocale(get(userLocale)));
		saveButtonLoading.set(false);
	}).catch(() => {
		location.reload();
	});
}
async function onLogoutSession(sessionId, loadingSessionId, showToast, invalidateAll) {
	loadingSessionId.set(sessionId);
	ApiUtil.delete({
		path: `/api/profile/sessions/${sessionId}`,
		handler: async (body) => {
			loadingSessionId.set(null);
			if (body.error) {
				await showToast("errors." + body.error, {}, void 0, { variant: "danger" });
				return;
			}
			await showToast("toasts.session-logged-out-successful", {}, void 0, { variant: "success" });
			invalidateAll();
		}
	});
}
function init(session) {
	return {
		resetPasswordError: writable(),
		resetPasswordLoading: writable(),
		resetPasswordSuccess: writable(),
		currentPassword: writable(),
		newEmail: writable(),
		changingEmail: writable(),
		changingEmail2ndStep: writable(),
		changingEmailError: writable(),
		changingEmailLoading: writable(),
		changingEmailSuccess: writable(),
		userLocale: writable(session.siteInfo.locale),
		saveButtonLoading: writable(),
		loadingSessionId: writable(null)
	};
}
//#endregion
//#region node_modules/@panomc/theme-core/src/lib/pages/profile/SettingsPage.svelte
async function load(event) {
	const viewPromise = resolveView("SettingsView", () => import('./SettingsView.js-BGHdZPgj.js'));
	return {
		...await processLoad(event),
		View: await viewPromise
	};
}
function SettingsPage($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let data = $$props["data"];
		const session = getContext("session");
		const contentItems = panoApiClient.ui.settings.content.get();
		const cardRowItems = panoApiClient.ui.settings.cardRows.get();
		const { resetPasswordError, resetPasswordLoading, resetPasswordSuccess, currentPassword, newEmail, changingEmail, changingEmail2ndStep, changingEmailError, changingEmailLoading, changingEmailSuccess, userLocale, saveButtonLoading, loadingSessionId } = init(store_get($$store_subs ??= {}, "$session", session));
		let pluginStates = {};
		const totalDirtyPlugins = writable(0);
		const totalSaveablePlugins = writable(0);
		function registerPlugin(id, state) {
			if (!state) delete pluginStates[id];
			else pluginStates[id] = state;
			updateTotals();
		}
		function updateTotals() {
			totalDirtyPlugins.set(Object.values(pluginStates).filter((s) => s.isDirty).length);
			totalSaveablePlugins.set(Object.keys(pluginStates).length);
		}
		async function handleSave() {
			if (store_get($$store_subs ??= {}, "$saveButtonDisabled", saveButtonDisabled)) return;
			if (store_get($$store_subs ??= {}, "$userLocale", userLocale) !== store_get($$store_subs ??= {}, "$currentLanguage", currentLanguage).code) await saveSettings(userLocale, saveButtonLoading);
			const savePromises = Object.values(pluginStates).filter((state) => state.isDirty && state.save).map((state) => state.save());
			if (savePromises.length > 0) {
				saveButtonLoading.set(true);
				try {
					await Promise.all(savePromises);
				} catch (e) {
					console.error("Failed to save some plugins", e);
				} finally {
					saveButtonLoading.set(false);
					updateTotals();
				}
			}
		}
		const saveButtonVisible = derived$1([session, totalSaveablePlugins], ([currentSession, saveablePlugins]) => currentSession.siteInfo.allowUserLocaleSelection || saveablePlugins > 0);
		const saveButtonDisabled = derived$1([
			userLocale,
			currentLanguage,
			totalDirtyPlugins,
			saveButtonLoading
		], ([locale, language, dirtyPlugins, saving]) => locale === language.code && dirtyPlugins === 0 || saving);
		if (data.View) {
			$$renderer.push("<!--[-->");
			data.View($$renderer, {
				data,
				session,
				contentItems,
				cardRowItems,
				Languages,
				resetPasswordError,
				resetPasswordLoading,
				resetPasswordSuccess,
				currentPassword,
				newEmail,
				changingEmail,
				changingEmail2ndStep,
				changingEmailError,
				changingEmailLoading,
				changingEmailSuccess,
				userLocale,
				loadingSessionId,
				saveButtonVisible,
				saveButtonDisabled,
				sendResetPasswordLink,
				sendChangeEmailLink,
				startChangingEmail,
				startChangingEmail2ndStep,
				stopChangingEmail,
				stopChangingEmail2ndStep,
				onLogoutSession,
				registerPlugin,
				handleSave,
				logout,
				showToast: show,
				invalidateAll,
				parseUserAgent,
				stripIdentifierWhitespace
			});
			$$renderer.push("<!--]-->");
		} else {
			$$renderer.push("<!--[!-->");
			$$renderer.push("<!--]-->");
		}
		if ($$store_subs) unsubscribe_stores($$store_subs);
		bind_props($$props, { data });
	});
}

export { SettingsPage as S, load as l };
//# sourceMappingURL=SettingsPage.js-CLOZ6xq-.js.map
