import { $ as ensure_array_like, a0 as store_get, a5 as escape_html, Z as attr_class, X as attr, a1 as spread_props, a2 as unsubscribe_stores, W as bind_props } from './server.js-D28cBEJ-.js';
import { $ as $format } from './runtime.js-CJgfVvxa.js';
import './tooltip.util.js-Bd9x5X7L.js';
import { D as Date_1 } from './Date.js-ZK3lGml2.js';
import { N as NoContent } from './NoContent.js-BBe0Mapz.js';
import { C as CardHeader } from './CardHeader.js-DpkWpoy6.js';
import { V as ViewComponent } from './ViewComponent.js-C6amYVVM.js';
import './uneval.js-BL1Qg77w.js';
import './rolldown-runtime.js-B5FuG9Gw.js';
import 'node:module';
import './stores.js-QbD2A2ib.js';
import './client.js-CPEkJ2-P.js';
import './shared.js-3i5_hmQ1.js';
import './exports.js-CKkpMUqI.js';
import './internal2.js-KmQU-gaY.js';
import './index-server2.js-DlblWyyK.js';
import './language.util.js-C2xYQq5-.js';
import './internal.js-BlXt2rfE.js';
import './Store.js-C2vdyE6V.js';
import './exports2.js-DxZfja4I.js';
import './ToastContainer.js-CtmBBvhr.js';
import './locale.js-DnnPB87K.js';
import './format.js-CzDFIcjs.js';

//#region node_modules/@panomc/theme-core/src/lib/components/modals/LogoutSessionConfirmModal.svelte
var dialogID = "logoutSessionConfirmModal";
function LogoutSessionConfirmModal($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		$$renderer.push(`<div aria-hidden="true" class="modal fade"${attr("id", dialogID)} role="dialog" tabindex="-1"><div class="modal-dialog modal-dialog-centered" role="dialog"><div class="modal-content"><div class="modal-body text-center"><div class="pb-3"><i class="fas fa-question-circle fa-3x d-block m-auto text-gray"></i></div> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.logout-session-confirm.title"))}</div> <div class="modal-footer flex-nowrap"><button class="btn btn-link col-6 m-0" type="button">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.cancel"))}</button> <button class="btn btn-danger col-6 m-0" type="button">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.yes"))}</button></div></div></div></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
	});
}
//#endregion
//#region node_modules/@panomc/theme-core/src/lib/views/SettingsView.svelte
function SettingsView($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let data = $$props["data"];
		let session = $$props["session"];
		let contentItems = $$props["contentItems"];
		let cardRowItems = $$props["cardRowItems"];
		let Languages = $$props["Languages"];
		let resetPasswordError = $$props["resetPasswordError"];
		let resetPasswordLoading = $$props["resetPasswordLoading"];
		let resetPasswordSuccess = $$props["resetPasswordSuccess"];
		let currentPassword = $$props["currentPassword"];
		let newEmail = $$props["newEmail"];
		let changingEmail = $$props["changingEmail"];
		let changingEmail2ndStep = $$props["changingEmail2ndStep"];
		let changingEmailError = $$props["changingEmailError"];
		let changingEmailLoading = $$props["changingEmailLoading"];
		let changingEmailSuccess = $$props["changingEmailSuccess"];
		let userLocale = $$props["userLocale"];
		let loadingSessionId = $$props["loadingSessionId"];
		let saveButtonVisible = $$props["saveButtonVisible"];
		let saveButtonDisabled = $$props["saveButtonDisabled"];
		let sendResetPasswordLink = $$props["sendResetPasswordLink"];
		let sendChangeEmailLink = $$props["sendChangeEmailLink"];
		let startChangingEmail = $$props["startChangingEmail"];
		let startChangingEmail2ndStep = $$props["startChangingEmail2ndStep"];
		let stopChangingEmail = $$props["stopChangingEmail"];
		let stopChangingEmail2ndStep = $$props["stopChangingEmail2ndStep"];
		let onLogoutSession = $$props["onLogoutSession"];
		let registerPlugin = $$props["registerPlugin"];
		let handleSave = $$props["handleSave"];
		let logout = $$props["logout"];
		let showToast = $$props["showToast"];
		let invalidateAll = $$props["invalidateAll"];
		let parseUserAgent = $$props["parseUserAgent"];
		let stripIdentifierWhitespace = $$props["stripIdentifierWhitespace"];
		let sessions = [];
		sessions = data.sessions;
		$$renderer.push(`<div class="vstack gap-3"><!--[-->`);
		const each_array = ensure_array_like(store_get($$store_subs ??= {}, "$contentItems", contentItems));
		for (let $$index_3 = 0, $$length = each_array.length; $$index_3 < $$length; $$index_3++) {
			let item = each_array[$$index_3];
			if (item.id === "settings-cards") {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<div class="card mt-3 mt-lg-0">`);
				CardHeader($$renderer, { $$slots: { left: ($$renderer) => {
					$$renderer.push(`<div slot="left">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.title"))}</div>`);
				} } });
				$$renderer.push(`<!----> <div class="card-body"><!--[-->`);
				const each_array_1 = ensure_array_like(store_get($$store_subs ??= {}, "$cardRowItems", cardRowItems));
				for (let $$index_1 = 0, $$length = each_array_1.length; $$index_1 < $$length; $$index_1++) {
					let row = each_array_1[$$index_1];
					if (row.id === "change-password") {
						$$renderer.push("<!--[0-->");
						$$renderer.push(`<div class="row"><label class="col-md-4 col-form-label" for="resetPassword">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.inputs.change-password.title"))}</label> <div class="col col-form-label"><button${attr_class("btn btn-link", void 0, { "is-invalid": store_get($$store_subs ??= {}, "$resetPasswordError", resetPasswordError) })} aria-describedby="resetPassword validationResetPassword"${attr("disabled", store_get($$store_subs ??= {}, "$resetPasswordLoading", resetPasswordLoading) || !store_get($$store_subs ??= {}, "$session", session).siteInfo.emailEnabled, true)} type="button">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.inputs.change-password.description"))}</button> <div id="validationResetPassword" class="invalid-feedback">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("errors." + store_get($$store_subs ??= {}, "$resetPasswordError", resetPasswordError)))}</div> `);
						if (store_get($$store_subs ??= {}, "$resetPasswordSuccess", resetPasswordSuccess)) {
							$$renderer.push("<!--[0-->");
							$$renderer.push(`<p class="mb-0">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.inputs.change-password.success-message"))}</p>`);
						} else $$renderer.push("<!--[-1-->");
						$$renderer.push(`<!--]--></div></div>`);
					} else if (row.id === "change-email") {
						$$renderer.push("<!--[1-->");
						$$renderer.push(`<div class="row"><label class="col-md-4 col-form-label" for="userEmail">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.inputs.change-email.title"))}</label> <div class="col col-form-label"><form><div class="row g-2 align-items-start">`);
						if (!store_get($$store_subs ??= {}, "$changingEmail", changingEmail)) {
							$$renderer.push("<!--[0-->");
							$$renderer.push(`<div class="col-12">`);
							if (store_get($$store_subs ??= {}, "$changingEmailSuccess", changingEmailSuccess)) {
								$$renderer.push("<!--[0-->");
								$$renderer.push(`<p class="text-dark mb-0">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.inputs.change-email.success-message", { values: { newEmail: store_get($$store_subs ??= {}, "$newEmail", newEmail) } }))}</p>`);
							} else {
								$$renderer.push("<!--[-1-->");
								$$renderer.push(`<button type="button" class="btn btn-link" aria-describedby="userEmail"${attr("disabled", !store_get($$store_subs ??= {}, "$session", session).siteInfo.emailEnabled, true)}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.inputs.change-email.description"))}</button>`);
							}
							$$renderer.push(`<!--]--></div>`);
						} else if (store_get($$store_subs ??= {}, "$changingEmail2ndStep", changingEmail2ndStep)) {
							$$renderer.push("<!--[1-->");
							$$renderer.push(`<div class="col-12 col-md min-w-0"><input type="email" id="newEmail"${attr("placeholder", store_get($$store_subs ??= {}, "$_", $format)("pages.settings.inputs.change-password.new-email-placeholder"))}${attr_class("form-control", void 0, { "is-invalid": store_get($$store_subs ??= {}, "$changingEmail2ndStep", changingEmail2ndStep) && store_get($$store_subs ??= {}, "$changingEmailError", changingEmailError) && store_get($$store_subs ??= {}, "$changingEmailError", changingEmailError) !== "CURRENT_PASSWORD_NOT_CORRECT" })} aria-describedby="validationChangingEmail"${attr("value", store_get($$store_subs ??= {}, "$newEmail", newEmail))} autofocus=""/> <div id="validationChangingEmail" class="invalid-feedback">`);
							if (store_get($$store_subs ??= {}, "$changingEmail2ndStep", changingEmail2ndStep) && store_get($$store_subs ??= {}, "$changingEmailError", changingEmailError) && store_get($$store_subs ??= {}, "$changingEmailError", changingEmailError) !== "CURRENT_PASSWORD_NOT_CORRECT") {
								$$renderer.push("<!--[0-->");
								$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("errors." + store_get($$store_subs ??= {}, "$changingEmailError", changingEmailError)))}`);
							} else $$renderer.push("<!--[-1-->");
							$$renderer.push(`<!--]--></div></div> <div class="col-12 col-md-auto d-flex flex-wrap gap-2 align-items-center justify-content-md-end"><button type="reset" class="btn btn-link link-primary">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.inputs.change-email.back"))}</button> <button type="submit"${attr_class("btn btn-link link-secondary", void 0, { "disabled": store_get($$store_subs ??= {}, "$changingEmailLoading", changingEmailLoading) || !String(store_get($$store_subs ??= {}, "$newEmail", newEmail) ?? "").trim() })}${attr("disabled", store_get($$store_subs ??= {}, "$changingEmailLoading", changingEmailLoading) || !String(store_get($$store_subs ??= {}, "$newEmail", newEmail) ?? "").trim(), true)}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.inputs.change-email.confirm"))}</button></div>`);
						} else {
							$$renderer.push("<!--[-1-->");
							$$renderer.push(`<div class="col-12 col-md min-w-0"><input type="password" id="currentPassword"${attr("placeholder", store_get($$store_subs ??= {}, "$_", $format)("pages.settings.inputs.change-email.current-password-placeholder"))}${attr_class("form-control", void 0, { "is-invalid": store_get($$store_subs ??= {}, "$changingEmailError", changingEmailError) === "CURRENT_PASSWORD_NOT_CORRECT" })}${attr("aria-describedby", store_get($$store_subs ??= {}, "$changingEmailError", changingEmailError) === "CURRENT_PASSWORD_NOT_CORRECT" ? "validationCurrentPassword" : void 0)}${attr("value", store_get($$store_subs ??= {}, "$currentPassword", currentPassword))} autofocus=""/> `);
							if (store_get($$store_subs ??= {}, "$changingEmailError", changingEmailError) === "CURRENT_PASSWORD_NOT_CORRECT") {
								$$renderer.push("<!--[0-->");
								$$renderer.push(`<div id="validationCurrentPassword" class="invalid-feedback d-block">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("errors." + store_get($$store_subs ??= {}, "$changingEmailError", changingEmailError)))}</div>`);
							} else $$renderer.push("<!--[-1-->");
							$$renderer.push(`<!--]--></div> <div class="col-12 col-md-auto d-flex flex-wrap gap-2 align-items-center justify-content-md-end"><button type="reset" class="btn btn-link link-danger">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.inputs.change-email.cancel"))}</button> <button type="submit"${attr_class("btn btn-link", void 0, { "disabled": !String(store_get($$store_subs ??= {}, "$currentPassword", currentPassword) ?? "").trim() })}${attr("disabled", !String(store_get($$store_subs ??= {}, "$currentPassword", currentPassword) ?? "").trim(), true)}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.inputs.change-email.continue"))}</button></div>`);
						}
						$$renderer.push(`<!--]--></div></form></div></div>`);
					} else if (row.id === "display-language") {
						$$renderer.push("<!--[2-->");
						if (store_get($$store_subs ??= {}, "$session", session).siteInfo.allowUserLocaleSelection) {
							$$renderer.push("<!--[0-->");
							$$renderer.push(`<div class="row"><label class="col-md-4 col-form-label" for="userLocaleCode">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.inputs.display-language.title"))}</label> <div class="col col-form-label">`);
							$$renderer.select({
								class: "form-control",
								id: "userLocaleCode",
								value: store_get($$store_subs ??= {}, "$userLocale", userLocale)
							}, ($$renderer) => {
								$$renderer.push(`<!--[-->`);
								const each_array_2 = ensure_array_like(Object.keys(store_get($$store_subs ??= {}, "$Languages", Languages)));
								for (let index = 0, $$length = each_array_2.length; index < $$length; index++) {
									let language = each_array_2[index];
									$$renderer.option({ value: store_get($$store_subs ??= {}, "$Languages", Languages)[language].code }, ($$renderer) => {
										$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$Languages", Languages)[language].name)}`);
									});
								}
								$$renderer.push(`<!--]-->`);
							});
							$$renderer.push(`</div></div>`);
						} else $$renderer.push("<!--[-1-->");
						$$renderer.push(`<!--]-->`);
					} else if (row.props && row.props.label) {
						$$renderer.push("<!--[3-->");
						$$renderer.push(`<div class="row"><label class="col-md-4 col-form-label"${attr("for", row.id)}>${escape_html(row.props.label && row.props.label.includes(".") ? store_get($$store_subs ??= {}, "$_", $format)(row.props.label) : row.props.label)}</label> <div class="col col-form-label">`);
						if (row.component) {
							$$renderer.push("<!--[0-->");
							ViewComponent($$renderer, {
								component: row.component,
								data: row.props.data,
								onRegister: (state) => registerPlugin(row.id, state)
							});
						} else {
							$$renderer.push("<!--[-1-->");
							$$renderer.push(`${escape_html(row.props.value || "")}`);
						}
						$$renderer.push(`<!--]--></div></div>`);
					} else if (row.component) {
						$$renderer.push("<!--[4-->");
						$$renderer.push(`<div class="row"><div class="col-12">`);
						ViewComponent($$renderer, {
							component: row.component,
							data: row.props?.data || data,
							onRegister: (state) => registerPlugin(row.id, state)
						});
						$$renderer.push(`<!----></div></div>`);
					} else $$renderer.push("<!--[-1-->");
					$$renderer.push(`<!--]-->`);
				}
				$$renderer.push(`<!--]--> `);
				if (store_get($$store_subs ??= {}, "$saveButtonVisible", saveButtonVisible)) {
					$$renderer.push("<!--[0-->");
					$$renderer.push(`<button${attr_class("btn btn-secondary", void 0, { "disabled": store_get($$store_subs ??= {}, "$saveButtonDisabled", saveButtonDisabled) })}${attr("aria-disabled", store_get($$store_subs ??= {}, "$saveButtonDisabled", saveButtonDisabled))}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.save"))}</button>`);
				} else $$renderer.push("<!--[-1-->");
				$$renderer.push(`<!--]--></div></div>`);
			} else if (item.id === "sessions-card") {
				$$renderer.push("<!--[1-->");
				$$renderer.push(`<div class="card">`);
				CardHeader($$renderer, {
					truncateLeft: false,
					$$slots: { left: ($$renderer) => {
						$$renderer.push(`<div slot="left">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.inputs.sessions.title"))} <small class="d-block text-muted">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.inputs.sessions.max-sessions-warning"))}</small></div>`);
					} }
				});
				$$renderer.push(`<!----> `);
				if (!sessions) {
					$$renderer.push("<!--[0-->");
					$$renderer.push(`<div class="text-center p-3"><div class="spinner-border text-primary" role="status"><span class="visually-hidden">Loading...</span></div></div>`);
				} else if (sessions.length === 0) {
					$$renderer.push("<!--[1-->");
					$$renderer.push(`<div class="card-body">`);
					NoContent($$renderer, {});
					$$renderer.push(`<!----></div>`);
				} else {
					$$renderer.push("<!--[-1-->");
					$$renderer.push(`<div class="table-responsive"><table class="table table-hover"><thead><tr><th class="align-middle">ID</th><th class="align-middle"></th><th class="align-middle"><i class="fas fa-window-maximize"></i></th><th class="align-middle">IP</th><th class="align-middle"><i class="fas fa-history"></i></th><th class="align-middle"><i class="fas fa-hourglass-end"></i></th><th class="align-middle"></th></tr></thead><tbody><!--[-->`);
					const each_array_3 = ensure_array_like(sessions);
					for (let $$index_2 = 0, $$length = each_array_3.length; $$index_2 < $$length; $$index_2++) {
						let s = each_array_3[$$index_2];
						$$renderer.push(`<tr${attr_class("", void 0, { "table-active": s.isCurrent })}><td class="align-middle"><code>#${escape_html(s.id)}</code></td><td class="align-middle">`);
						if (s.isCurrent) {
							$$renderer.push("<!--[0-->");
							$$renderer.push(`<span class="badge text-bg-primary">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.inputs.sessions.current-session"))}</span>`);
						} else $$renderer.push("<!--[-1-->");
						$$renderer.push(`<!--]--></td><td class="align-middle"><span${attr("title", s.userAgent)}>${escape_html(parseUserAgent(s.userAgent))}</span></td><td class="align-middle"><code>${escape_html(s.ip)}</code></td><td class="align-middle">`);
						Date_1($$renderer, { time: s.lastActivityTime });
						$$renderer.push(`<!----></td><td class="align-middle">`);
						Date_1($$renderer, { time: s.expireDate });
						$$renderer.push(`<!----></td><td class="align-middle text-end"><button class="btn btn-link text-danger"${attr("title", store_get($$store_subs ??= {}, "$_", $format)("buttons.logout"))}${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("buttons.logout"))}${attr("disabled", store_get($$store_subs ??= {}, "$loadingSessionId", loadingSessionId) === s.id, true)}>`);
						if (store_get($$store_subs ??= {}, "$loadingSessionId", loadingSessionId) === s.id) {
							$$renderer.push("<!--[0-->");
							$$renderer.push(`<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>`);
						} else {
							$$renderer.push("<!--[-1-->");
							$$renderer.push(`<i class="fas fa-sign-out-alt"></i>`);
						}
						$$renderer.push(`<!--]--></button></td></tr>`);
					}
					$$renderer.push(`<!--]--></tbody></table></div>`);
				}
				$$renderer.push(`<!--]--></div>`);
			} else if (item.component) {
				$$renderer.push("<!--[2-->");
				ViewComponent($$renderer, spread_props([{
					component: item.component,
					data
				}, item.props]));
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]-->`);
		}
		$$renderer.push(`<!--]--></div> `);
		LogoutSessionConfirmModal($$renderer);
		$$renderer.push(`<!---->`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
		bind_props($$props, {
			data,
			session,
			contentItems,
			cardRowItems,
			Languages,
			resetPasswordError,
			resetPasswordLoading,
			resetPasswordSuccess,
			currentPassword,
			newEmail,
			changingEmail,
			changingEmail2ndStep,
			changingEmailError,
			changingEmailLoading,
			changingEmailSuccess,
			userLocale,
			loadingSessionId,
			saveButtonVisible,
			saveButtonDisabled,
			sendResetPasswordLink,
			sendChangeEmailLink,
			startChangingEmail,
			startChangingEmail2ndStep,
			stopChangingEmail,
			stopChangingEmail2ndStep,
			onLogoutSession,
			registerPlugin,
			handleSave,
			logout,
			showToast,
			invalidateAll,
			parseUserAgent,
			stripIdentifierWhitespace
		});
	});
}

export { SettingsView as default };
//# sourceMappingURL=SettingsView.js-BGHdZPgj.js.map
