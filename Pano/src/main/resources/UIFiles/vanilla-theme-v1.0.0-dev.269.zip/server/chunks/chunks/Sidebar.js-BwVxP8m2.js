import { V as fallback, Z as attr_class, _ as slot, W as bind_props } from './server.js-D28cBEJ-.js';

//#region node_modules/@panomc/theme-core/src/lib/components/Sidebar.svelte
function Sidebar($$renderer, $$props) {
	let side = fallback($$props["side"], "right");
	$$renderer.push(`<aside${attr_class("col-lg-4 order-first", void 0, {
		"order-lg-last": side === "right",
		"order-lg-first": side === "left"
	})}><!--[-->`);
	slot($$renderer, $$props, "default", {}, null);
	$$renderer.push(`<!--]--></aside>`);
	bind_props($$props, { side });
}

export { Sidebar as S };
//# sourceMappingURL=Sidebar.js-BwVxP8m2.js.map
