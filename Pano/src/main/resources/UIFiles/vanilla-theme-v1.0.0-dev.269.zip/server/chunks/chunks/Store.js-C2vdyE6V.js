import { _ as __exportAll } from './rolldown-runtime.js-B5FuG9Gw.js';
import { r as redirect } from './exports2.js-DxZfja4I.js';
import { a4 as get, T as writable } from './server.js-D28cBEJ-.js';
import { g as goto } from './client.js-CPEkJ2-P.js';
import { s as showSuccess } from './ToastContainer.js-CtmBBvhr.js';

//#region node_modules/@panomc/sdk/core/js/variables.js
var API_URL = "http://localhost:8088/api";
var PANEL_URL = "/panel";
var PANO_WEBSITE_URL = "https://dev.panomc.com";
var PANO_WEBSITE_API_URL = void 0;
var COOKIE_PREFIX = "pano_";
var CSRF_TOKEN_COOKIE_NAME = "csrf_token";
var JWT_COOKIE_NAME = "auth_token";
var CSRF_HEADER = "X-CSRF-Token";
function checkDomainRedirection() {
	if (typeof window === "undefined" || !API_URL || API_URL.startsWith("/")) return;
}
function updateApiUrl(apiUrl) {
	API_URL = apiUrl;
}
function updatePanoWebsiteUrl(panoWebsiteUrl) {
	PANO_WEBSITE_URL = panoWebsiteUrl;
}
function updatePanoWebsiteApiUrl(panoWebsiteApiUrl) {
	PANO_WEBSITE_API_URL = panoWebsiteApiUrl;
}
//#endregion
//#region node_modules/@panomc/sdk/core/js/api.util.js
var NETWORK_ERROR = "NETWORK_ERROR";
var networkErrorBody = {
	result: "error",
	error: NETWORK_ERROR
};
function buildQueryParams(params) {
	const queryString = Object.keys(params).filter((key) => params[key]).map((key) => `${encodeURIComponent(key)}=${encodeURIComponent(params[key])}`).join("&");
	return queryString === "" ? "" : "?" + queryString;
}
var ApiUtil = {
	interceptors: {},
	async get({ path, request, csrfToken, token, blob, handler }) {
		return this.customRequest({
			path,
			request,
			csrfToken,
			token,
			blob,
			handler
		});
	},
	async post({ path, request, body, headers, csrfToken, token, blob, handler, onUploadProgress }) {
		return this.customRequest({
			path,
			data: {
				method: "POST",
				credentials: "include",
				body,
				headers
			},
			request,
			csrfToken,
			token,
			blob,
			handler,
			onUploadProgress
		});
	},
	async put({ path, request, body, headers, csrfToken, token, blob, handler, onUploadProgress }) {
		return this.customRequest({
			path,
			data: {
				method: "PUT",
				credentials: "include",
				body,
				headers
			},
			request,
			csrfToken,
			token,
			blob,
			handler,
			onUploadProgress
		});
	},
	async delete({ path, request, headers, csrfToken, token, blob, handler }) {
		return this.customRequest({
			path,
			data: {
				method: "DELETE",
				headers
			},
			request,
			csrfToken,
			token,
			blob,
			handler
		});
	},
	async customRequest({ path, data = {}, request, csrfToken, token, blob, handler, onUploadProgress }) {
		if (!csrfToken) {
			let session;
			if (request && typeof request.parent === "function") session = (await request.parent()).session;
			csrfToken = session && session.csrfToken;
		}
		const CSRFHeader = csrfToken ? { [CSRF_HEADER]: csrfToken } : {};
		if (!(data.body instanceof FormData)) {
			data.body = JSON.stringify(data.body);
			data.headers = {
				"Content-Type": "application/json",
				...data.headers
			};
		}
		const options = {
			...data,
			headers: {
				...data.headers,
				...CSRFHeader
			}
		};
		if (token) options.headers["Authorization"] = `Bearer ${token}`;
		else if ("credentials" in Request.prototype) options["credentials"] = "include";
		const hasEventFetch = request && request.fetch;
		const isReverseProxied = !API_URL.includes(".panomc.com");
		if (hasEventFetch && isReverseProxied) {
			if (!path.startsWith("/api/")) path = `/api/${path.replace("/api/", "")}`;
		} else if (request && !get(initialized) || true) {
			let apiUrl = API_URL;
			if (!API_URL.includes(".panomc.com") && false);
			path = `${apiUrl}/${path.replace("/api/", "")}`;
		}
		const bodyHandler = (response) => blob ? response.blob() : response.text();
		const jsonParseHandler = (json) => {
			try {
				return JSON.parse(json);
			} catch (err) {
				return json;
			}
		};
		const requestCall = (rejectHandler) => {
			const reject = async (err) => {
				console.log(err);
				if (rejectHandler) throw new Error(err);
				if (!this.interceptors.errorHandler || !handler) return;
				this.interceptors.errorHandler(requestCall);
			};
			return (request && request.fetch ? request.fetch(path, options) : fetch(path, options)).then(bodyHandler).then(jsonParseHandler).then(async (parsedJson) => {
				if (parsedJson?.error === "DISABLED_FOR_DEMO") return;
				return handler ? await handler(parsedJson, reject) : parsedJson;
			}).catch(reject);
		};
		return requestCall();
	}
};
//#endregion
//#region node_modules/@panomc/theme-core/src/lib/api.util.js
var api_util_exports = /* @__PURE__ */ __exportAll({
	NETWORK_ERROR: () => NETWORK_ERROR,
	buildQueryParams: () => buildQueryParams,
	default: () => ApiUtil,
	networkErrorBody: () => networkErrorBody
});
//#endregion
//#region node_modules/@panomc/theme-core/src/lib/services/auth.js
var sendLogout = async () => {
	return ApiUtil.post({ path: "/api/auth/logout" });
};
var sendLogin = async (body) => {
	return ApiUtil.post({
		path: "/api/auth/login",
		body
	});
};
var getCredentials = async (csrfToken) => {
	return ApiUtil.get({
		path: "/api/auth/credentials",
		csrfToken
	});
};
var getCredentialsServerSide = async (token) => {
	return ApiUtil.get({
		path: "/api/auth/credentials",
		token
	}).then((response) => {
		if (response.result !== "ok") return null;
		return Object.keys(response).filter((key) => !["result"].includes(key)).reduce((object, key) => {
			object[key] = response[key];
			return object;
		}, {});
	});
};
var sendRegister = async (body) => {
	return ApiUtil.post({
		path: "/api/auth/register",
		body
	});
};
var sendVerifyEmail = async (token) => {
	return ApiUtil.post({
		path: "/api/auth/verifyEmail",
		body: { token }
	});
};
var sendVerifyNewEmail = async (token) => {
	return ApiUtil.post({
		path: "/api/auth/verifyNewEmail",
		body: { token }
	});
};
var sendResetPassword = async (usernameOrEmail) => {
	return ApiUtil.post({
		path: "/api/auth/resetPassword",
		body: { usernameOrEmail }
	});
};
var sendRenewPassword = async (newPassword, newPasswordRepeat, token) => {
	return ApiUtil.post({
		path: "/api/auth/renewPassword",
		body: {
			newPassword,
			newPasswordRepeat,
			token
		}
	});
};
var verifyLinkCode = async (username, code) => {
	return ApiUtil.post({
		path: "/api/auth/verifyLinkCode",
		body: {
			username,
			code
		}
	});
};
//#endregion
//#region node_modules/@panomc/theme-core/src/lib/Store.js
var notificationsCount = writable(0);
var initialized = writable(false);
var avatarVersion = writable("");
async function logout(session) {
	sendLogout().then(async () => {
		if (typeof localStorage !== "undefined") localStorage.removeItem("pano_demo_bubble_shown");
		if (session) session.update((data) => {
			data.user = null;
			data.csrfToken = null;
			return data;
		});
		await showSuccess("toasts.session-logged-out-successful");
		await goto();
	});
}
function requireLogin(session, goto = "/login") {
	if (!session.user) throw redirect(302, goto);
}
function requireNotLogin(session) {
	if (session.user) throw redirect(302, "/");
}

export { API_URL as A, COOKIE_PREFIX as C, JWT_COOKIE_NAME as J, NETWORK_ERROR as N, PANO_WEBSITE_URL as P, CSRF_TOKEN_COOKIE_NAME as a, updatePanoWebsiteUrl as b, avatarVersion as c, ApiUtil as d, buildQueryParams as e, api_util_exports as f, getCredentialsServerSide as g, updatePanoWebsiteApiUrl as h, checkDomainRedirection as i, PANO_WEBSITE_API_URL as j, PANEL_URL as k, CSRF_HEADER as l, requireLogin as m, sendVerifyNewEmail as n, sendRegister as o, getCredentials as p, sendLogin as q, requireNotLogin as r, sendVerifyEmail as s, logout as t, updateApiUrl as u, verifyLinkCode as v, sendRenewPassword as w, sendResetPassword as x, notificationsCount as y };
//# sourceMappingURL=Store.js-C2vdyE6V.js.map
