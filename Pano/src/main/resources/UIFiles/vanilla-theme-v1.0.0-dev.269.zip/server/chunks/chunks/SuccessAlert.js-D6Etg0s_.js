import { a5 as escape_html, a0 as store_get, a2 as unsubscribe_stores, W as bind_props } from './server.js-D28cBEJ-.js';
import { $ as $format } from './runtime.js-CJgfVvxa.js';

//#region node_modules/@panomc/theme-core/src/lib/components/SuccessAlert.svelte
function SuccessAlert($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let message = $$props["message"];
		if (message || false) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<div class="alert alert-primary mb-0">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("successes." + (message.key || message), { values: message.props }))}</div>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]-->`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
		bind_props($$props, { message });
	});
}

export { SuccessAlert as S };
//# sourceMappingURL=SuccessAlert.js-D6Etg0s_.js.map
