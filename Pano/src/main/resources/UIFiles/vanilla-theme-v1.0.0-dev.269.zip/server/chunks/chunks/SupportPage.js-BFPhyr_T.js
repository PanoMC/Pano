import { g as getContext, W as bind_props, T as writable, $ as ensure_array_like, a0 as store_get, a1 as spread_props, a2 as unsubscribe_stores } from './server.js-D28cBEJ-.js';
import 'node:module';
import { d as panoApi, e as executeLifecycle, b as executeViewLoad, c as executeHookLoad, g as executeSidebarLoad } from './PluginManager.js-B5x3OKEW.js';
import { r as resolveView } from './registry2.js-BubD3cPq.js';
import { d as ApiUtil } from './Store.js-C2vdyE6V.js';
import { S as Sidebar } from './Sidebar.js-BwVxP8m2.js';
import { V as ViewComponent } from './ViewComponent.js-C6amYVVM.js';
import { O as OnlineAdmins } from './OnlineAdmins.js-FcRIIIBU.js';

//#region node_modules/@panomc/theme-core/src/lib/components/sidebars/SupportSidebar.svelte
var data = writable({ onlineAdmins: [] });
var load$1 = async (event) => {
	panoApi.ui.sidebar.register({
		sidebarId: "support",
		id: "online-admins",
		component: "local:online-admins",
		priority: 100
	});
	await executeSidebarLoad("support", event);
	data.set(await ApiUtil.get({
		path: "/api/sidebars/support",
		request: event
	}));
};
function SupportSidebar($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let side = $$props["side"];
		const items = panoApi.ui.sidebar.get("support");
		Sidebar($$renderer, {
			side,
			children: ($$renderer) => {
				$$renderer.push(`<div class="vstack gap-3"><!--[-->`);
				const each_array = ensure_array_like(store_get($$store_subs ??= {}, "$items", items));
				for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
					let item = each_array[$$index];
					if (item.id === "online-admins") {
						$$renderer.push("<!--[0-->");
						OnlineAdmins($$renderer, { onlineAdmins: store_get($$store_subs ??= {}, "$data", data).onlineAdmins });
					} else {
						$$renderer.push("<!--[-1-->");
						ViewComponent($$renderer, spread_props([{
							component: item.component,
							data: store_get($$store_subs ??= {}, "$data", data)
						}, item.props]));
					}
					$$renderer.push(`<!--]-->`);
				}
				$$renderer.push(`<!--]--></div>`);
			},
			$$slots: { default: true }
		});
		if ($$store_subs) unsubscribe_stores($$store_subs);
		bind_props($$props, { side });
	});
}
//#endregion
//#region node_modules/@panomc/theme-core/src/lib/ui-logics/page-logics/SupportPageLogics.js
async function processLoad(event) {
	const { parent } = event;
	const { session, hookProps: parentHookProps } = await parent();
	const themeSettings = session.siteInfo.themeSettings;
	const onlineAdminsEnabled = typeof themeSettings.sidebarCarts?.onlineAdmins === "undefined" ? true : themeSettings.sidebarCarts.onlineAdmins;
	if (onlineAdminsEnabled) await load$1(event);
	const data = { hookProps: { ...parentHookProps } };
	panoApi.ui.view.register({
		viewId: "support-content",
		id: "support-options",
		priority: 100
	});
	panoApi.ui.view.register({
		viewId: "support-options",
		id: "create-ticket",
		component: "local:create-ticket",
		priority: 100
	});
	panoApi.ui.view.register({
		viewId: "support-options",
		id: "send-email",
		component: "local:send-email",
		priority: 90
	});
	await executeLifecycle("theme:support:load", data, event);
	const [, , supportHookProps] = await Promise.all([
		executeViewLoad("support-content", event),
		executeViewLoad("support-options", event),
		executeHookLoad("theme:support:content", event)
	]);
	data.hookProps["theme:support:content"] = {
		...data.hookProps["theme:support:content"],
		...supportHookProps
	};
	return {
		...data,
		sidebar: onlineAdminsEnabled ? SupportSidebar : null,
		pageTitle: "pages.support.title"
	};
}
//#endregion
//#region node_modules/@panomc/theme-core/src/lib/pages/SupportPage.svelte
async function load(event) {
	const viewPromise = resolveView("SupportView", () => import('./SupportView.js-DMhjE6iW.js'));
	return {
		...await processLoad(event),
		View: await viewPromise
	};
}
function SupportPage($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		let data = $$props["data"];
		const session = getContext("session");
		const items = panoApi.ui.view.get("support-content");
		const optionItems = panoApi.ui.view.get("support-options");
		if (data.View) {
			$$renderer.push("<!--[-->");
			data.View($$renderer, {
				data,
				session,
				items,
				optionItems
			});
			$$renderer.push("<!--]-->");
		} else {
			$$renderer.push("<!--[!-->");
			$$renderer.push("<!--]-->");
		}
		bind_props($$props, { data });
	});
}

export { SupportPage as S, load as l };
//# sourceMappingURL=SupportPage.js-BFPhyr_T.js.map
