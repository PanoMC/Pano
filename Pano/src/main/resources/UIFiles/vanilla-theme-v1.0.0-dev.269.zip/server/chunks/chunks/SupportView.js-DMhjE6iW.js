import { $ as ensure_array_like, a0 as store_get, a5 as escape_html, X as attr, Y as stringify, a1 as spread_props, a2 as unsubscribe_stores, W as bind_props } from './server.js-D28cBEJ-.js';
import { $ as $format } from './runtime.js-CJgfVvxa.js';
import { V as ViewComponent } from './ViewComponent.js-C6amYVVM.js';
import { H as Hook } from './Hook.js-DEYNBNbZ.js';
import './uneval.js-BL1Qg77w.js';
import './rolldown-runtime.js-B5FuG9Gw.js';
import 'node:module';
import './stores.js-QbD2A2ib.js';
import './client.js-CPEkJ2-P.js';
import './shared.js-3i5_hmQ1.js';
import './exports.js-CKkpMUqI.js';
import './internal2.js-KmQU-gaY.js';
import './index-server2.js-DlblWyyK.js';
import './PluginManager.js-B5x3OKEW.js';
import './exports2.js-DxZfja4I.js';
import './internal.js-BlXt2rfE.js';
import './Store.js-C2vdyE6V.js';
import './ToastContainer.js-CtmBBvhr.js';
import 'fs';
import './auth.util.js-BGCV_dhB.js';

//#region node_modules/@panomc/theme-core/src/lib/views/SupportView.svelte
function SupportView($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let data = $$props["data"];
		let session = $$props["session"];
		let items = $$props["items"];
		let optionItems = $$props["optionItems"];
		$$renderer.push(`<div class="vstack gap-3"><!--[-->`);
		const each_array = ensure_array_like(store_get($$store_subs ??= {}, "$items", items));
		for (let $$index_1 = 0, $$length = each_array.length; $$index_1 < $$length; $$index_1++) {
			let item = each_array[$$index_1];
			if (item.id === "support-options") {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<ul class="list-group text-center support-list justify-content-center svelte-jn3gd4"><!--[-->`);
				const each_array_1 = ensure_array_like(store_get($$store_subs ??= {}, "$optionItems", optionItems));
				for (let $$index = 0, $$length = each_array_1.length; $$index < $$length; $$index++) {
					let opt = each_array_1[$$index];
					if (opt.id === "create-ticket") {
						$$renderer.push("<!--[0-->");
						$$renderer.push(`<a href="/ticket/create" class="list-group-item list-group-item-action focus-ring svelte-jn3gd4"><div class="vstack gap-2 justify-content-center"><i class="fas fa-ticket fa-2x"></i> <h5>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.support.options.create-ticket.title"))}</h5> <small class="opacity-75">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.support.options.create-ticket.description"))}</small></div></a>`);
					} else if (opt.id === "send-email") {
						$$renderer.push("<!--[1-->");
						$$renderer.push(`<a${attr("href", `mailto:${stringify(store_get($$store_subs ??= {}, "$session", session).siteInfo.supportEmail)}`)} class="list-group-item list-group-item-action focus-ring svelte-jn3gd4"><div class="vstack gap-2 justify-content-center"><i class="fas fa-envelope fa-2x"></i> <h5>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.support.options.send-email.title"))}<i class="fas fa-external-link-alt ms-2 small"></i></h5> <small class="opacity-75">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.support.options.send-email.description", { values: { websiteName: store_get($$store_subs ??= {}, "$session", session).siteInfo.websiteName } }))}</small></div></a>`);
					} else {
						$$renderer.push("<!--[-1-->");
						$$renderer.push(`<div class="list-group-item list-group-item-action p-0 overflow-hidden svelte-jn3gd4">`);
						ViewComponent($$renderer, spread_props([{
							component: opt.component,
							data
						}, opt.props]));
						$$renderer.push(`<!----></div>`);
					}
					$$renderer.push(`<!--]-->`);
				}
				$$renderer.push(`<!--]--></ul>`);
			} else {
				$$renderer.push("<!--[-1-->");
				ViewComponent($$renderer, spread_props([{
					component: item.component,
					data
				}, item.props]));
			}
			$$renderer.push(`<!--]-->`);
		}
		$$renderer.push(`<!--]--> `);
		Hook($$renderer, { name: "theme:support:content" });
		$$renderer.push(`<!----></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
		bind_props($$props, {
			data,
			session,
			items,
			optionItems
		});
	});
}

export { SupportView as default };
//# sourceMappingURL=SupportView.js-DMhjE6iW.js.map
