import { _ as __exportAll } from './rolldown-runtime.js-B5FuG9Gw.js';
import { V as fallback, a0 as store_get, _ as slot, a2 as unsubscribe_stores, W as bind_props } from './server.js-D28cBEJ-.js';
import { p as page } from './stores.js-QbD2A2ib.js';
import { r as resolveView } from './registry2.js-BubD3cPq.js';
import { p as processLoadServer, a as processLoad, i as init } from './ThemeSettingsLayoutLogics.js-BeKxPzDr.js';

//#region node_modules/@panomc/theme-core/src/lib/layouts/ThemeSettingsLayout.svelte
var ThemeSettingsLayout_exports = /* @__PURE__ */ __exportAll({
	default: () => ThemeSettingsLayout,
	load: () => load,
	loadServer: () => loadServer
});
async function loadServer(event) {
	return await processLoadServer(event);
}
async function load(event) {
	const viewPromise = resolveView("ThemeSettingsLayoutView", () => import('./ThemeSettingsLayoutView.js-CjCkbd0m.js'));
	return {
		...await processLoad(event),
		themeSettingsLayoutView: await viewPromise
	};
}
function ThemeSettingsLayout($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let viewData, layoutView;
		let data = fallback($$props["data"], void 0);
		const hidden = init();
		viewData = data ?? store_get($$store_subs ??= {}, "$page", page).data;
		layoutView = viewData?.themeSettingsLayoutView ?? store_get($$store_subs ??= {}, "$page", page).data.themeSettingsLayoutView;
		if (layoutView) {
			$$renderer.push("<!--[-->");
			layoutView($$renderer, {
				data: viewData,
				hidden,
				children: ($$renderer) => {
					$$renderer.push(`<!--[-->`);
					slot($$renderer, $$props, "default", {}, null);
					$$renderer.push(`<!--]-->`);
				},
				$$slots: { default: true }
			});
			$$renderer.push("<!--]-->");
		} else {
			$$renderer.push("<!--[!-->");
			$$renderer.push("<!--]-->");
		}
		if ($$store_subs) unsubscribe_stores($$store_subs);
		bind_props($$props, { data });
	});
}

export { ThemeSettingsLayout_exports as T, loadServer as a, ThemeSettingsLayout as b, load as l };
//# sourceMappingURL=ThemeSettingsLayout.js-C5M-p3G5.js.map
