import { r as redirect } from './exports2.js-DxZfja4I.js';
import { T as writable } from './server.js-D28cBEJ-.js';
import 'node:module';
import { h as hasPermission, P as Permissions } from './auth.util.js-BGCV_dhB.js';

function showToast(text, params = {}, toastComponent, variant = null) {
	window.parent.postMessage({
		type: "show-toast",
		text,
		params,
		toastComponent,
		variant
	}, "*");
}
function showSuccessToast(text, params = {}) {
	showToast(text, params, void 0, "success");
}
function showErrorToast(text, params = {}) {
	showToast(text, params, void 0, "danger");
}
var confirmCallbacks = /* @__PURE__ */ new Map();
var confirmIdCounter = 0;
function showConfirm(title, onConfirm) {
	const id = ++confirmIdCounter;
	confirmCallbacks.set(id, onConfirm);
	window.parent.postMessage({
		type: "show-confirm",
		title,
		id
	}, "*");
}
async function processLoadServer(event) {
	const { parent } = event;
	const { user, siteInfo: { themeSettings } } = await parent();
	if (!hasPermission(Permissions.MANAGE_VIEW, user || {})) throw redirect(302, "/");
	return { themeSettings };
}
async function processLoad(event) {
	const { data } = event;
	return data;
}
function init() {
	return writable(true);
}

export { processLoad as a, showSuccessToast as b, showErrorToast as c, init as i, processLoadServer as p, showConfirm as s };
//# sourceMappingURL=ThemeSettingsLayoutLogics.js-BeKxPzDr.js.map
