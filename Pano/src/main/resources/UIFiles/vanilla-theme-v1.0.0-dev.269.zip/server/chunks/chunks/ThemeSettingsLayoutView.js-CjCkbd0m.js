import { X as attr, a0 as store_get, _ as slot, a2 as unsubscribe_stores, W as bind_props } from './server.js-D28cBEJ-.js';
import './uneval.js-BL1Qg77w.js';

//#region node_modules/@panomc/theme-core/src/lib/views/ThemeSettingsLayoutView.svelte
function ThemeSettingsLayoutView($$renderer, $$props) {
	var $$store_subs;
	let data = $$props["data"];
	let hidden = $$props["hidden"];
	$$renderer.push(`<div${attr("hidden", store_get($$store_subs ??= {}, "$hidden", hidden))}><!--[-->`);
	slot($$renderer, $$props, "default", {}, null);
	$$renderer.push(`<!--]--></div>`);
	if ($$store_subs) unsubscribe_stores($$store_subs);
	bind_props($$props, {
		data,
		hidden
	});
}

export { ThemeSettingsLayoutView as default };
//# sourceMappingURL=ThemeSettingsLayoutView.js-CjCkbd0m.js.map
