import { T as writable, g as getContext, a9 as store_set, a0 as store_get, a2 as unsubscribe_stores, W as bind_props, aa as store_mutate } from './server.js-D28cBEJ-.js';
import 'node:module';
import { $ as $format } from './runtime.js-CJgfVvxa.js';
import { p as panoApiClient, o as orderLinksBySavedOrder } from './PluginManager.js-B5x3OKEW.js';
import { r as resolveView, g as getSettingsSchemaExtension } from './registry2.js-BubD3cPq.js';
import { d as ApiUtil } from './Store.js-C2vdyE6V.js';
import { s as showConfirm, b as showSuccessToast, c as showErrorToast } from './ThemeSettingsLayoutLogics.js-BeKxPzDr.js';

//#region node_modules/@panomc/theme-core/src/lib/services/theme-setting.js
var saveThemeSettings = async (settings) => {
	const body = new FormData();
	if (settings.uploads) {
		Object.keys(settings.uploads).forEach((key) => {
			body.append(key, settings.uploads[key]);
		});
		delete settings["uploads"];
	}
	body.append("settings", JSON.stringify(settings));
	return ApiUtil.put({
		path: `/api/panel/theme/settings`,
		body,
		blob: true
	});
};
//#endregion
//#region node_modules/@panomc/theme-core/src/lib/pages/ThemeSettingsPage.svelte
async function load(event) {
	const viewPromise = resolveView("ThemeSettingsView", () => import('./ThemeSettingsView.js-Di4tKAlL.js'));
	const { parent } = event;
	const { themeSettings } = await parent();
	return {
		themeSettings,
		View: await viewPromise
	};
}
function ThemeSettingsPage($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let tabHasSavedData, anyUnsavedChanges, anySettingsExist;
		let data = $$props["data"];
		const themeSettings = writable(data.themeSettings);
		const originalThemeSettings = writable(JSON.parse(JSON.stringify(data.themeSettings)));
		const session = getContext("session");
		const settingsSchemaExtension = getSettingsSchemaExtension();
		const saving = writable(false);
		const resetting = writable(false);
		const resettingAll = writable(false);
		const activeTab = writable(settingsSchemaExtension?.defaultTab ?? "general");
		const backgroundImageFiles = writable(null);
		const headerBackgroundImageFiles = writable(null);
		const playCardBackgroundImageFiles = writable(null);
		const themeDefaults = {
			dark: {
				navbar: "#044389",
				header: "#ffffff"
			},
			light: {
				navbar: "#ffffff",
				header: "#ffffff"
			},
			copper: {
				navbar: "#9c622b",
				header: "#b87333"
			},
			emerald: {
				navbar: "#0d8a61",
				header: "#10b981"
			},
			midnight: {
				navbar: "#6d44c5",
				header: "#8b5cf6"
			},
			crimson: {
				navbar: "#bf3636",
				header: "#ef4444"
			}
		};
		const currentThemeDefault = writable(themeDefaults.dark);
		function onThemeColorChange(e) {
			const value = e.target.value;
			store_mutate($$store_subs ??= {}, "$themeSettings", themeSettings, store_get($$store_subs ??= {}, "$themeSettings", themeSettings).themeColor = value);
			if (value === "copper") {
				store_mutate($$store_subs ??= {}, "$themeSettings", themeSettings, store_get($$store_subs ??= {}, "$themeSettings", themeSettings).navbarBgColor = "#9c622b");
				store_mutate($$store_subs ??= {}, "$themeSettings", themeSettings, store_get($$store_subs ??= {}, "$themeSettings", themeSettings).headerBgColor = "#b87333");
			} else if (value === "emerald") {
				store_mutate($$store_subs ??= {}, "$themeSettings", themeSettings, store_get($$store_subs ??= {}, "$themeSettings", themeSettings).navbarBgColor = "#0d8a61");
				store_mutate($$store_subs ??= {}, "$themeSettings", themeSettings, store_get($$store_subs ??= {}, "$themeSettings", themeSettings).headerBgColor = "#10b981");
			} else if (value === "midnight") {
				store_mutate($$store_subs ??= {}, "$themeSettings", themeSettings, store_get($$store_subs ??= {}, "$themeSettings", themeSettings).navbarBgColor = "#6d44c5");
				store_mutate($$store_subs ??= {}, "$themeSettings", themeSettings, store_get($$store_subs ??= {}, "$themeSettings", themeSettings).headerBgColor = "#8b5cf6");
			} else if (value === "crimson") {
				store_mutate($$store_subs ??= {}, "$themeSettings", themeSettings, store_get($$store_subs ??= {}, "$themeSettings", themeSettings).navbarBgColor = "#bf3636");
				store_mutate($$store_subs ??= {}, "$themeSettings", themeSettings, store_get($$store_subs ??= {}, "$themeSettings", themeSettings).headerBgColor = "#ef4444");
			} else if (value === "dark") {
				store_mutate($$store_subs ??= {}, "$themeSettings", themeSettings, store_get($$store_subs ??= {}, "$themeSettings", themeSettings).navbarBgColor = "#044389");
				store_mutate($$store_subs ??= {}, "$themeSettings", themeSettings, store_get($$store_subs ??= {}, "$themeSettings", themeSettings).headerBgColor = "#ffffff");
			} else if (value === "light") {
				store_mutate($$store_subs ??= {}, "$themeSettings", themeSettings, store_get($$store_subs ??= {}, "$themeSettings", themeSettings).navbarBgColor = "#ffffff");
				store_mutate($$store_subs ??= {}, "$themeSettings", themeSettings, store_get($$store_subs ??= {}, "$themeSettings", themeSettings).headerBgColor = "#ffffff");
			}
		}
		const navPluginLinks = panoApiClient.ui.nav.site.getNavLinks();
		const orderedNavLinks = writable([]);
		const orderedFooterLinks = writable([]);
		const nativeLinks = [
			{
				id: "home",
				text: "pages.theme-settings.navbar.home",
				href: "/"
			},
			{
				id: "support",
				text: "pages.theme-settings.navbar.support",
				href: "/support"
			},
			{
				id: "rules",
				text: "pages.theme-settings.navbar.rules",
				href: "/rules"
			}
		];
		const draggingItemIndex = writable(null);
		const dragOverItemIndex = writable(null);
		function onDragStart(event, index) {
			store_set(draggingItemIndex, index);
			event.dataTransfer.effectAllowed = "move";
			event.dataTransfer.setData("text/plain", index);
		}
		function onDragOver(event, index) {
			event.preventDefault();
			event.dataTransfer.dropEffect = "move";
			store_set(dragOverItemIndex, index);
		}
		function onDragEnd() {
			store_set(draggingItemIndex, null);
			store_set(dragOverItemIndex, null);
		}
		function onDrop(event, index, target = "nav") {
			event.preventDefault();
			const fromIndex = store_get($$store_subs ??= {}, "$draggingItemIndex", draggingItemIndex);
			const toIndex = index;
			store_set(draggingItemIndex, null);
			store_set(dragOverItemIndex, null);
			if (fromIndex === null || fromIndex === toIndex) return;
			if (target === "nav") {
				const newOrder = [...store_get($$store_subs ??= {}, "$orderedNavLinks", orderedNavLinks)];
				const [movedItem] = newOrder.splice(fromIndex, 1);
				newOrder.splice(toIndex, 0, movedItem);
				store_set(orderedNavLinks, newOrder);
				store_mutate($$store_subs ??= {}, "$themeSettings", themeSettings, store_get($$store_subs ??= {}, "$themeSettings", themeSettings).navLinksOrder = newOrder.map((l) => l.id));
			} else if (target === "footer") {
				const newOrder = [...store_get($$store_subs ??= {}, "$orderedFooterLinks", orderedFooterLinks)];
				const [movedItem] = newOrder.splice(fromIndex, 1);
				newOrder.splice(toIndex, 0, movedItem);
				store_set(orderedFooterLinks, newOrder);
				store_mutate($$store_subs ??= {}, "$themeSettings", themeSettings, store_get($$store_subs ??= {}, "$themeSettings", themeSettings).footerLinksOrder = newOrder.map((l) => l.id));
			}
		}
		function toggleLink(id, checked) {
			if (!store_get($$store_subs ??= {}, "$themeSettings", themeSettings).navLinksEnableStatus) store_mutate($$store_subs ??= {}, "$themeSettings", themeSettings, store_get($$store_subs ??= {}, "$themeSettings", themeSettings).navLinksEnableStatus = {});
			store_mutate($$store_subs ??= {}, "$themeSettings", themeSettings, store_get($$store_subs ??= {}, "$themeSettings", themeSettings).navLinksEnableStatus[id] = checked);
			store_set(themeSettings, store_get($$store_subs ??= {}, "$themeSettings", themeSettings));
		}
		function toggleFooterLink(id, checked) {
			if (!store_get($$store_subs ??= {}, "$themeSettings", themeSettings).footerLinksEnableStatus) store_mutate($$store_subs ??= {}, "$themeSettings", themeSettings, store_get($$store_subs ??= {}, "$themeSettings", themeSettings).footerLinksEnableStatus = {});
			store_mutate($$store_subs ??= {}, "$themeSettings", themeSettings, store_get($$store_subs ??= {}, "$themeSettings", themeSettings).footerLinksEnableStatus[id] = checked);
			store_set(themeSettings, store_get($$store_subs ??= {}, "$themeSettings", themeSettings));
		}
		const baseTabKeys = {
			general: [
				"themeColor",
				"backgroundColor",
				"bgImagePosition",
				"bgImageRepeat",
				"bgImageSize",
				"backgroundImage"
			],
			logo: [
				"logoVisibility",
				"logoPosition",
				"logoHeight",
				"logoWidth",
				"logoAnimation"
			],
			header: [
				"defaultHeaderBg",
				"headerBgColor",
				"headerHeight",
				"headerWidthOption",
				"headerNavBarGap",
				"headerBgImagePosition",
				"headerBgImageRepeat",
				"headerBgImageSize",
				"headerBackgroundImage"
			],
			navbar: [
				"navbarWidthOption",
				"navbarBgColor",
				"navRoundLevel",
				"navLinksEnabled",
				"navLinksEnableStatus",
				"navLinksOrder"
			],
			sidebar: [
				"sidebarEnabled",
				"sidebarPosition",
				"sidebarCarts"
			],
			"play-card": [
				"playCardStyle",
				"defaultPlayCardBg",
				"playCardBgOpacity",
				"playCardBgEffect",
				"playCardBackgroundImage",
				"playCardIpText",
				"playCardStatusBadge",
				"playCardPlayerCount",
				"playCardVersionInfo",
				"playCardIpColor",
				"playCardBorderColor"
			],
			"post-card": [
				"postsEnabled",
				"postCoverImageEnabled",
				"postReadMoreButtonEnabled",
				"postAuthorImageEnabled",
				"postViewCountEnabled",
				"postPreviousPageEnabled",
				"postNextPageEnabled"
			],
			footer: [
				"footerEnabled",
				"footerLogoEnabled",
				"footerTitleEnabled",
				"footerTitle",
				"footerContentEnabled",
				"footerContent",
				"footerLinksEnabled",
				"footerPluginLinksEnabled",
				"footerLinksEnableStatus",
				"footerLinksOrder"
			],
			advanced: ["customCss"]
		};
		const tabKeys = (() => {
			const merged = {};
			for (const tab in baseTabKeys) merged[tab] = [...baseTabKeys[tab]];
			const extTabs = settingsSchemaExtension?.tabs;
			if (extTabs) for (const tab in extTabs) {
				if (!merged[tab]) merged[tab] = [];
				for (const key of extTabs[tab]) if (!merged[tab].includes(key)) merged[tab].push(key);
			}
			return merged;
		})();
		const checkTabChanged = (tab, current, original) => {
			return tabKeys[tab]?.some((key) => {
				if (key === "backgroundImage" || key === "headerBackgroundImage" || key === "playCardBackgroundImage") {
					const uploadExists = !!current.uploads?.[key];
					const fileDeleted = original.files?.[key] && !current.files?.[key];
					return uploadExists || fileDeleted;
				}
				return JSON.stringify(current[key]) !== JSON.stringify(original[key]);
			});
		};
		const checkTabHasData = (tab, original) => {
			return tabKeys[tab]?.some((key) => {
				if (key === "backgroundImage" || key === "headerBackgroundImage" || key === "playCardBackgroundImage") return !!original.files?.[key];
				return typeof original[key] !== "undefined" && original[key] !== null;
			});
		};
		const tabChanged = writable(false);
		const tabResetVisible = writable(false);
		const allResetVisible = writable(false);
		const defaultHeaderBg = writable(true);
		function onBackgroundImageChange(event) {
			const image = event.target.files[0];
			store_mutate($$store_subs ??= {}, "$themeSettings", themeSettings, store_get($$store_subs ??= {}, "$themeSettings", themeSettings).uploads = {
				...store_get($$store_subs ??= {}, "$themeSettings", themeSettings).uploads || {},
				backgroundImage: image
			});
		}
		function onRemoveBackgroundImageClick() {
			delete store_get($$store_subs ??= {}, "$themeSettings", themeSettings).files.backgroundImage;
			store_set(themeSettings, store_get($$store_subs ??= {}, "$themeSettings", themeSettings));
		}
		function onRemoveHeaderBackgroundImageClick() {
			delete store_get($$store_subs ??= {}, "$themeSettings", themeSettings).files.headerBackgroundImage;
			store_set(themeSettings, store_get($$store_subs ??= {}, "$themeSettings", themeSettings));
		}
		function onHeaderBackgroundImageChange(event) {
			const image = event.target.files[0];
			store_mutate($$store_subs ??= {}, "$themeSettings", themeSettings, store_get($$store_subs ??= {}, "$themeSettings", themeSettings).uploads = {
				...store_get($$store_subs ??= {}, "$themeSettings", themeSettings).uploads || {},
				headerBackgroundImage: image
			});
		}
		function onPlayCardBackgroundImageChange(event) {
			const image = event.target.files[0];
			store_mutate($$store_subs ??= {}, "$themeSettings", themeSettings, store_get($$store_subs ??= {}, "$themeSettings", themeSettings).uploads = {
				...store_get($$store_subs ??= {}, "$themeSettings", themeSettings).uploads || {},
				playCardBackgroundImage: image
			});
		}
		function onRemovePlayCardBackgroundImageClick() {
			if (!store_get($$store_subs ??= {}, "$themeSettings", themeSettings).files) store_mutate($$store_subs ??= {}, "$themeSettings", themeSettings, store_get($$store_subs ??= {}, "$themeSettings", themeSettings).files = {});
			delete store_get($$store_subs ??= {}, "$themeSettings", themeSettings).files.playCardBackgroundImage;
			store_set(themeSettings, store_get($$store_subs ??= {}, "$themeSettings", themeSettings));
		}
		async function save() {
			store_set(saving, true);
			const settingsToSave = structuredClone(store_get($$store_subs ??= {}, "$originalThemeSettings", originalThemeSettings));
			if (!settingsToSave.files) settingsToSave.files = {};
			settingsToSave.uploads = { ...store_get($$store_subs ??= {}, "$themeSettings", themeSettings).uploads || {} };
			tabKeys[store_get($$store_subs ??= {}, "$activeTab", activeTab)].forEach((key) => {
				if (key === "backgroundImage" || key === "headerBackgroundImage" || key === "playCardBackgroundImage") {
					if (!store_get($$store_subs ??= {}, "$themeSettings", themeSettings).files?.[key]) settingsToSave.files[key] = [];
				} else settingsToSave[key] = store_get($$store_subs ??= {}, "$themeSettings", themeSettings)[key];
			});
			if (settingsToSave.uploads) Object.keys(settingsToSave.uploads).forEach((key) => {
				if (!tabKeys[store_get($$store_subs ??= {}, "$activeTab", activeTab)].includes(key)) delete settingsToSave.uploads[key];
			});
			const response = await saveThemeSettings(settingsToSave);
			const newSettings = JSON.parse(await response.text());
			delete newSettings["result"];
			store_set(backgroundImageFiles, null);
			store_set(headerBackgroundImageFiles, null);
			store_set(themeSettings, newSettings);
			originalThemeSettings.set(structuredClone(store_get($$store_subs ??= {}, "$themeSettings", themeSettings)));
			showSuccessToast(store_get($$store_subs ??= {}, "$_", $format)("messages.settings-save-success") || "Ayarlar başarıyla kaydedildi!");
			store_set(saving, false);
		}
		async function resetTab() {
			showConfirm("components.modals.confirm-reset-tab.title", async () => {
				store_set(resetting, true);
				const settingsToSave = structuredClone(store_get($$store_subs ??= {}, "$originalThemeSettings", originalThemeSettings));
				if (!settingsToSave.files) settingsToSave.files = {};
				tabKeys[store_get($$store_subs ??= {}, "$activeTab", activeTab)].forEach((key) => {
					if (key === "backgroundImage" || key === "headerBackgroundImage" || key === "playCardBackgroundImage") {
						settingsToSave.files[key] = [];
						if (store_get($$store_subs ??= {}, "$themeSettings", themeSettings).uploads) delete store_get($$store_subs ??= {}, "$themeSettings", themeSettings).uploads[key];
					} else delete settingsToSave[key];
				});
				const response = await saveThemeSettings(settingsToSave);
				const newSettings = JSON.parse(await response.text());
				delete newSettings["result"];
				store_set(backgroundImageFiles, null);
				store_set(headerBackgroundImageFiles, null);
				store_set(playCardBackgroundImageFiles, null);
				store_set(themeSettings, newSettings);
				originalThemeSettings.set(structuredClone(store_get($$store_subs ??= {}, "$themeSettings", themeSettings)));
				showSuccessToast(store_get($$store_subs ??= {}, "$_", $format)("messages.settings-reset-tab-success") || "Sekme ayarları sıfırlandı!");
				store_set(resetting, false);
			});
		}
		async function resetAll() {
			showConfirm("components.modals.confirm-reset-all.title", async () => {
				store_set(resettingAll, true);
				try {
					const response = await saveThemeSettings({});
					const newSettings = JSON.parse(await response.text());
					delete newSettings["result"];
					store_set(backgroundImageFiles, null);
					store_set(headerBackgroundImageFiles, null);
					store_set(themeSettings, newSettings);
					originalThemeSettings.set(structuredClone(store_get($$store_subs ??= {}, "$themeSettings", themeSettings)));
					showSuccessToast(store_get($$store_subs ??= {}, "$_", $format)("messages.settings-reset-all-success"));
				} catch (error) {
					console.error("Failed to reset all settings:", error);
					showErrorToast(store_get($$store_subs ??= {}, "$_", $format)("messages.settings-reset-all-error"));
				} finally {
					store_set(resettingAll, false);
				}
			});
		}
		store_set(currentThemeDefault, themeDefaults[store_get($$store_subs ??= {}, "$themeSettings", themeSettings).themeColor || "dark"] || themeDefaults.dark);
		{
			const pluginLinks = store_get($$store_subs ??= {}, "$navPluginLinks", navPluginLinks).map((l) => ({
				...l,
				id: l.href,
				isPlugin: true
			}));
			const allLinksSource = [...nativeLinks, ...pluginLinks];
			store_set(orderedNavLinks, orderLinksBySavedOrder(allLinksSource, store_get($$store_subs ??= {}, "$themeSettings", themeSettings).navLinksOrder));
			store_set(orderedFooterLinks, orderLinksBySavedOrder(allLinksSource, store_get($$store_subs ??= {}, "$themeSettings", themeSettings).footerLinksOrder));
		}
		store_set(tabChanged, checkTabChanged(store_get($$store_subs ??= {}, "$activeTab", activeTab), store_get($$store_subs ??= {}, "$themeSettings", themeSettings), store_get($$store_subs ??= {}, "$originalThemeSettings", originalThemeSettings)));
		tabHasSavedData = checkTabHasData(store_get($$store_subs ??= {}, "$activeTab", activeTab), store_get($$store_subs ??= {}, "$originalThemeSettings", originalThemeSettings));
		anyUnsavedChanges = Object.keys(tabKeys).some((tab) => checkTabChanged(tab, store_get($$store_subs ??= {}, "$themeSettings", themeSettings), store_get($$store_subs ??= {}, "$originalThemeSettings", originalThemeSettings)));
		anySettingsExist = Object.keys(tabKeys).some((tab) => checkTabHasData(tab, store_get($$store_subs ??= {}, "$originalThemeSettings", originalThemeSettings)));
		store_set(tabResetVisible, store_get($$store_subs ??= {}, "$tabChanged", tabChanged) || tabHasSavedData);
		store_set(allResetVisible, anyUnsavedChanges || anySettingsExist);
		store_set(defaultHeaderBg, typeof store_get($$store_subs ??= {}, "$themeSettings", themeSettings).defaultHeaderBg === "undefined" ? true : store_get($$store_subs ??= {}, "$themeSettings", themeSettings).defaultHeaderBg);
		if (data.View) {
			$$renderer.push("<!--[-->");
			data.View($$renderer, {
				data,
				themeSettings,
				session,
				activeTab,
				saving,
				resetting,
				resettingAll,
				backgroundImageFiles,
				headerBackgroundImageFiles,
				playCardBackgroundImageFiles,
				currentThemeDefault,
				defaultHeaderBg,
				orderedNavLinks,
				orderedFooterLinks,
				draggingItemIndex,
				dragOverItemIndex,
				tabChanged,
				tabResetVisible,
				allResetVisible,
				onThemeColorChange,
				onBackgroundImageChange,
				onRemoveBackgroundImageClick,
				onHeaderBackgroundImageChange,
				onRemoveHeaderBackgroundImageClick,
				onPlayCardBackgroundImageChange,
				onRemovePlayCardBackgroundImageClick,
				onDragStart,
				onDragOver,
				onDragEnd,
				onDrop,
				toggleLink,
				toggleFooterLink,
				save,
				resetTab,
				resetAll
			});
			$$renderer.push("<!--]-->");
		} else {
			$$renderer.push("<!--[!-->");
			$$renderer.push("<!--]-->");
		}
		if ($$store_subs) unsubscribe_stores($$store_subs);
		bind_props($$props, { data });
	});
}

export { ThemeSettingsPage as T, load as l };
//# sourceMappingURL=ThemeSettingsPage.js-LrDRTJ0l.js.map
