import { Z as attr_class, a0 as store_get, a5 as escape_html, X as attr, $ as ensure_array_like, a2 as unsubscribe_stores, W as bind_props } from './server.js-D28cBEJ-.js';
import { $ as $format } from './runtime.js-CJgfVvxa.js';
import './uneval.js-BL1Qg77w.js';
import './rolldown-runtime.js-B5FuG9Gw.js';
import 'node:module';

//#region node_modules/@panomc/theme-core/src/lib/views/ThemeSettingsView.svelte
function ThemeSettingsView($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let data = $$props["data"];
		let themeSettings = $$props["themeSettings"];
		let session = $$props["session"];
		let activeTab = $$props["activeTab"];
		let saving = $$props["saving"];
		let resetting = $$props["resetting"];
		let resettingAll = $$props["resettingAll"];
		let backgroundImageFiles = $$props["backgroundImageFiles"];
		let headerBackgroundImageFiles = $$props["headerBackgroundImageFiles"];
		let playCardBackgroundImageFiles = $$props["playCardBackgroundImageFiles"];
		let currentThemeDefault = $$props["currentThemeDefault"];
		let defaultHeaderBg = $$props["defaultHeaderBg"];
		let orderedNavLinks = $$props["orderedNavLinks"];
		let orderedFooterLinks = $$props["orderedFooterLinks"];
		let draggingItemIndex = $$props["draggingItemIndex"];
		let dragOverItemIndex = $$props["dragOverItemIndex"];
		let tabChanged = $$props["tabChanged"];
		let tabResetVisible = $$props["tabResetVisible"];
		let allResetVisible = $$props["allResetVisible"];
		let onThemeColorChange = $$props["onThemeColorChange"];
		let onBackgroundImageChange = $$props["onBackgroundImageChange"];
		let onRemoveBackgroundImageClick = $$props["onRemoveBackgroundImageClick"];
		let onHeaderBackgroundImageChange = $$props["onHeaderBackgroundImageChange"];
		let onRemoveHeaderBackgroundImageClick = $$props["onRemoveHeaderBackgroundImageClick"];
		let onPlayCardBackgroundImageChange = $$props["onPlayCardBackgroundImageChange"];
		let onRemovePlayCardBackgroundImageClick = $$props["onRemovePlayCardBackgroundImageClick"];
		let onDragStart = $$props["onDragStart"];
		let onDragOver = $$props["onDragOver"];
		let onDragEnd = $$props["onDragEnd"];
		let onDrop = $$props["onDrop"];
		let toggleLink = $$props["toggleLink"];
		let toggleFooterLink = $$props["toggleFooterLink"];
		let save = $$props["save"];
		let resetTab = $$props["resetTab"];
		let resetAll = $$props["resetAll"];
		$$renderer.push(`<div class="card"><div class="card-header"><ul class="nav nav-tabs card-header-tabs" id="themeSettingsTabs" role="tablist"><li class="nav-item" role="presentation"><button${attr_class("nav-link", void 0, { "active": store_get($$store_subs ??= {}, "$activeTab", activeTab) === "general" })} data-bs-target="#general" data-bs-toggle="tab" id="general-tab" role="tab" type="button">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.tabs.general"))}</button></li> <li class="nav-item" role="presentation"><button${attr_class("nav-link", void 0, { "active": store_get($$store_subs ??= {}, "$activeTab", activeTab) === "logo" })} data-bs-target="#logo" data-bs-toggle="tab" id="logo-tab" role="tab" type="button">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.tabs.logo"))}</button></li> <li class="nav-item" role="presentation"><button${attr_class("nav-link", void 0, { "active": store_get($$store_subs ??= {}, "$activeTab", activeTab) === "header" })} data-bs-target="#header" data-bs-toggle="tab" id="header-tab" role="tab" type="button">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.tabs.cover"))}</button></li> <li class="nav-item" role="presentation"><button${attr_class("nav-link", void 0, { "active": store_get($$store_subs ??= {}, "$activeTab", activeTab) === "navbar" })} data-bs-target="#navbar" data-bs-toggle="tab" id="navbar-tab" role="tab" type="button">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.tabs.navbar"))}</button></li> <li class="nav-item" role="presentation"><button${attr_class("nav-link", void 0, { "active": store_get($$store_subs ??= {}, "$activeTab", activeTab) === "sidebar" })} data-bs-target="#sidebar" data-bs-toggle="tab" id="sidebar-tab" role="tab" type="button">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.tabs.sidebar"))}</button></li> <li class="nav-item" role="presentation"><button${attr_class("nav-link", void 0, { "active": store_get($$store_subs ??= {}, "$activeTab", activeTab) === "post-card" })} data-bs-target="#post-card" data-bs-toggle="tab" id="post-card-tab" role="tab" type="button">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.tabs.post-card"))}</button></li> <li class="nav-item" role="presentation"><button${attr_class("nav-link", void 0, { "active": store_get($$store_subs ??= {}, "$activeTab", activeTab) === "play-card" })} data-bs-target="#play-card" data-bs-toggle="tab" id="play-card-tab" role="tab" type="button">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.tabs.play-card"))}</button></li> <li class="nav-item" role="presentation"><button${attr_class("nav-link", void 0, { "active": store_get($$store_subs ??= {}, "$activeTab", activeTab) === "footer" })} data-bs-target="#footer" data-bs-toggle="tab" id="footer-tab" role="tab" type="button">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.tabs.footer"))}</button></li> <li class="nav-item" role="presentation"><button${attr_class("nav-link", void 0, { "active": store_get($$store_subs ??= {}, "$activeTab", activeTab) === "advanced" })} data-bs-target="#advanced" data-bs-toggle="tab" id="advanced-tab" role="tab" type="button">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.tabs.advanced"))}</button></li></ul></div> <div class="card-body"><div class="tab-content"><div${attr_class("tab-pane fade", void 0, {
			"show": store_get($$store_subs ??= {}, "$activeTab", activeTab) === "general",
			"active": store_get($$store_subs ??= {}, "$activeTab", activeTab) === "general"
		})} id="general" role="tabpanel"><div class="row mb-3"><label class="col-md-6 col-form-label" for="theme-color">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.general.theme-color"))}</label> <div class="col-md-6">`);
		$$renderer.select({
			class: "form-select",
			id: "theme-color",
			value: store_get($$store_subs ??= {}, "$themeSettings", themeSettings).themeColor || "dark"
		}, ($$renderer) => {
			$$renderer.option({ value: "dark" }, ($$renderer) => {
				$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.general.colors.dark"))}`);
			});
			$$renderer.option({ value: "light" }, ($$renderer) => {
				$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.general.colors.light"))}`);
			});
			$$renderer.option({ value: "copper" }, ($$renderer) => {
				$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.general.colors.copper"))}`);
			});
			$$renderer.option({ value: "emerald" }, ($$renderer) => {
				$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.general.colors.emerald"))}`);
			});
			$$renderer.option({ value: "midnight" }, ($$renderer) => {
				$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.general.colors.midnight"))}`);
			});
			$$renderer.option({ value: "crimson" }, ($$renderer) => {
				$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.general.colors.crimson"))}`);
			});
		});
		$$renderer.push(`</div></div> <div class="row mb-3"><label class="col-md-6 col-form-label" for="bgColor">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.general.bg-color"))}</label> <div class="col-md-6"><input id="bgColor" class="form-control form-control-color" type="color"${attr("value", store_get($$store_subs ??= {}, "$themeSettings", themeSettings).backgroundColor || "#f5f7fa")}/></div></div> <div class="row mb-3"><label class="col-md-6 col-form-label" for="breadcrumb-enabled">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.general.breadcrumb"))}</label> <div class="col-md-6 d-flex align-items-center"><div class="form-check form-switch"><input${attr("checked", store_get($$store_subs ??= {}, "$themeSettings", themeSettings).breadcrumbEnabled, true)} class="form-check-input" id="breadcrumb-enabled" type="checkbox"/></div></div></div> <div class="row mb-3"><label class="col-md-6 col-form-label" for="background-image-upload">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.general.bg-image"))}</label> <div class="col-md-6">`);
		if (store_get($$store_subs ??= {}, "$themeSettings", themeSettings).files?.backgroundImage) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<div class="input-group"><img${attr("alt", store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.general.bg-image"))} class="border rounded-start" style="object-fit: contain;" width="71" height="40"${attr("src", "/api/theme/file/" + store_get($$store_subs ??= {}, "$themeSettings", themeSettings).files.backgroundImage)}/> <input id="background-image-upload" class="form-control" type="file" accept="image/*"/> <button class="btn btn-outline-danger shadow-none rounded-end">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.remove"))}</button></div>`);
		} else {
			$$renderer.push("<!--[-1-->");
			$$renderer.push(`<input id="background-image-upload" class="form-control" type="file" accept="image/*"/>`);
		}
		$$renderer.push(`<!--]--></div></div> <div class="row mb-3"><label class="col-md-6 col-form-label" for="bg-image-position">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.general.bg-image-placement"))}</label> <div class="col-md-6">`);
		$$renderer.select({
			class: "form-select",
			id: "bg-image-position",
			value: store_get($$store_subs ??= {}, "$themeSettings", themeSettings).bgImagePosition || "center center"
		}, ($$renderer) => {
			$$renderer.option({ value: "left top" }, ($$renderer) => {
				$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.general.placements.left-top"))}`);
			});
			$$renderer.option({ value: "center center" }, ($$renderer) => {
				$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.general.placements.center"))}`);
			});
			$$renderer.option({ value: "right bottom" }, ($$renderer) => {
				$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.general.placements.right-bottom"))}`);
			});
		});
		$$renderer.push(`</div></div> <div class="row mb-3"><label class="col-md-6 col-form-label" for="bg-image-repeat">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.general.bg-image-repeat"))}</label> <div class="col-md-6">`);
		$$renderer.select({
			class: "form-select",
			id: "bg-image-repeat",
			value: store_get($$store_subs ??= {}, "$themeSettings", themeSettings).bgImageRepeat || "no-repeat"
		}, ($$renderer) => {
			$$renderer.option({ value: "repeat" }, ($$renderer) => {
				$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.general.repeats.repeat"))}`);
			});
			$$renderer.option({ value: "no-repeat" }, ($$renderer) => {
				$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.general.repeats.no-repeat"))}`);
			});
			$$renderer.option({ value: "repeat-x" }, ($$renderer) => {
				$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.general.repeats.repeat-x"))}`);
			});
			$$renderer.option({ value: "repeat-y" }, ($$renderer) => {
				$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.general.repeats.repeat-y"))}`);
			});
		});
		$$renderer.push(`</div></div> <div class="row mb-3"><label class="col-md-6 col-form-label" for="background-image-position">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.general.bg-image-size"))}</label> <div class="col-md-6">`);
		$$renderer.select({
			class: "form-select",
			id: "background-image-position",
			value: store_get($$store_subs ??= {}, "$themeSettings", themeSettings).bgImageSize || "auto"
		}, ($$renderer) => {
			$$renderer.option({ value: "auto" }, ($$renderer) => {
				$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.general.sizes.auto"))}`);
			});
			$$renderer.option({ value: "cover" }, ($$renderer) => {
				$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.general.sizes.cover"))}`);
			});
			$$renderer.option({ value: "contain" }, ($$renderer) => {
				$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.general.sizes.contain"))}`);
			});
			$$renderer.option({ value: "100% 100%" }, ($$renderer) => {
				$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.general.sizes.stretch"))}`);
			});
		});
		$$renderer.push(`</div></div></div> <div class="tab-pane fade" id="logo" role="tabpanel"><div class="row mb-3"><label class="col-md-6" for="logo-visibility">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.logo.visibility"))}</label> <div class="col-md-6"><div class="form-check form-switch"><input${attr("checked", typeof store_get($$store_subs ??= {}, "$themeSettings", themeSettings).logoVisibility === "undefined" ? true : store_get($$store_subs ??= {}, "$themeSettings", themeSettings).logoVisibility, true)} class="form-check-input" id="logo-visibility" type="checkbox"/></div></div></div> <div class="row mb-3"><label class="col-md-6 col-form-label" for="logoPosition">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.logo.position"))}</label> <div class="col-md-6">`);
		$$renderer.select({
			class: "form-select",
			id: "logoPosition",
			value: store_get($$store_subs ??= {}, "$themeSettings", themeSettings).logoPosition || "CENTER"
		}, ($$renderer) => {
			$$renderer.option({ value: "TOP_START" }, ($$renderer) => {
				$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.logo.positions.top-start"))}`);
			});
			$$renderer.option({ value: "TOP" }, ($$renderer) => {
				$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.logo.positions.top"))}`);
			});
			$$renderer.option({ value: "TOP_END" }, ($$renderer) => {
				$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.logo.positions.top-end"))}`);
			});
			$$renderer.option({ value: "CENTER_START" }, ($$renderer) => {
				$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.logo.positions.center-start"))}`);
			});
			$$renderer.option({ value: "CENTER" }, ($$renderer) => {
				$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.logo.positions.center"))}`);
			});
			$$renderer.option({ value: "CENTER_END" }, ($$renderer) => {
				$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.logo.positions.center-end"))}`);
			});
			$$renderer.option({ value: "BOTTOM_START" }, ($$renderer) => {
				$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.logo.positions.bottom-start"))}`);
			});
			$$renderer.option({ value: "BOTTOM" }, ($$renderer) => {
				$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.logo.positions.bottom"))}`);
			});
			$$renderer.option({ value: "BOTTOM_END" }, ($$renderer) => {
				$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.logo.positions.bottom-end"))}`);
			});
		});
		$$renderer.push(`</div></div> <div class="row mb-3"><label class="col-md-6 col-form-label" for="logo-height">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.logo.height"))}</label> <div class="col-md-6"><input id="logo-height" class="form-control" type="number" placeholder="auto"${attr("value", store_get($$store_subs ??= {}, "$themeSettings", themeSettings).logoHeight)}/></div></div> <div class="row mb-3"><label class="col-md-6 col-form-label" for="logo-width">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.logo.width"))}</label> <div class="col-md-6"><input id="logo-width" class="form-control" type="number" placeholder="256"${attr("value", store_get($$store_subs ??= {}, "$themeSettings", themeSettings).logoWidth)}/></div></div> <div class="row mb-3"><label class="col-md-6 col-form-label" for="logoAnimation">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.logo.animation"))}</label> <div class="col-md-6">`);
		$$renderer.select({
			class: "form-select",
			id: "logoAnimation",
			value: store_get($$store_subs ??= {}, "$themeSettings", themeSettings).logoAnimation || "off"
		}, ($$renderer) => {
			$$renderer.option({ value: "off" }, ($$renderer) => {
				$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.logo.animations.off"))}`);
			});
			$$renderer.option({ value: "zoom" }, ($$renderer) => {
				$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.logo.animations.zoom"))}`);
			});
			$$renderer.option({ value: "floating" }, ($$renderer) => {
				$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.logo.animations.floating"))}`);
			});
		});
		$$renderer.push(`</div></div></div> <div class="tab-pane fade" id="header" role="tabpanel"><div class="row mb-3"><label class="col-md-6" for="logo-visibility">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.cover.default-bg"))}</label> <div class="col-md-6"><div class="form-check form-switch"><input${attr("checked", store_get($$store_subs ??= {}, "$defaultHeaderBg", defaultHeaderBg), true)} class="form-check-input" id="logo-visibility" type="checkbox"/></div></div></div> <div class="row mb-3"><label class="col-md-6 col-form-label" for="headerBackgroundImage">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.cover.bg-image"))}</label> <div class="col-md-6">`);
		if (store_get($$store_subs ??= {}, "$themeSettings", themeSettings).files?.headerBackgroundImage || store_get($$store_subs ??= {}, "$defaultHeaderBg", defaultHeaderBg)) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<div class="input-group"><div style="height: 40px; width: 150px;"><img${attr("alt", store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.cover.bg-image"))} class="border rounded-start" style="height: 100%; width: 100%; object-fit: cover;"${attr("src", store_get($$store_subs ??= {}, "$defaultHeaderBg", defaultHeaderBg) ? "/assets/img/default-header-bg.png" : "/api/theme/file/" + store_get($$store_subs ??= {}, "$themeSettings", themeSettings).files.headerBackgroundImage)}/></div> <input id="headerBackgroundImage" class="form-control" type="file" accept="image/*"${attr("disabled", store_get($$store_subs ??= {}, "$defaultHeaderBg", defaultHeaderBg), true)}/> <button${attr_class("btn btn-outline-danger shadow-none rounded-end", void 0, { "disabled": store_get($$store_subs ??= {}, "$defaultHeaderBg", defaultHeaderBg) })}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.remove"))}</button></div>`);
		} else {
			$$renderer.push("<!--[-1-->");
			$$renderer.push(`<input id="headerBackgroundImage" class="form-control" type="file" accept="image/*"/>`);
		}
		$$renderer.push(`<!--]--></div></div> <div class="row mb-3"><label class="col-md-6 col-form-label" for="headerBgImagePosition">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.general.bg-image-placement"))}</label> <div class="col-md-6">`);
		$$renderer.select({
			class: "form-select",
			id: "headerBgImagePosition",
			value: store_get($$store_subs ??= {}, "$themeSettings", themeSettings).headerBgImagePosition || "center center"
		}, ($$renderer) => {
			$$renderer.option({ value: "left top" }, ($$renderer) => {
				$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.general.placements.left-top"))}`);
			});
			$$renderer.option({ value: "center center" }, ($$renderer) => {
				$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.general.placements.center"))}`);
			});
			$$renderer.option({ value: "right bottom" }, ($$renderer) => {
				$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.general.placements.right-bottom"))}`);
			});
		});
		$$renderer.push(`</div></div> <div class="row mb-3"><label class="col-md-6 col-form-label" for="headerBgImageRepeat">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.general.bg-image-repeat"))}</label> <div class="col-md-6">`);
		$$renderer.select({
			class: "form-select",
			id: "headerBgImageRepeat",
			value: store_get($$store_subs ??= {}, "$themeSettings", themeSettings).headerBgImageRepeat || "no-repeat"
		}, ($$renderer) => {
			$$renderer.option({ value: "repeat" }, ($$renderer) => {
				$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.general.repeats.repeat"))}`);
			});
			$$renderer.option({ value: "no-repeat" }, ($$renderer) => {
				$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.general.repeats.no-repeat"))}`);
			});
			$$renderer.option({ value: "repeat-x" }, ($$renderer) => {
				$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.general.repeats.repeat-x"))}`);
			});
			$$renderer.option({ value: "repeat-y" }, ($$renderer) => {
				$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.general.repeats.repeat-y"))}`);
			});
		});
		$$renderer.push(`</div></div> <div class="row mb-3"><label class="col-md-6 col-form-label" for="headerBgImageSize">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.general.bg-image-size"))}</label> <div class="col-md-6">`);
		$$renderer.select({
			class: "form-select",
			id: "headerBgImageSize",
			value: store_get($$store_subs ??= {}, "$themeSettings", themeSettings).headerBgImageSize || "cover"
		}, ($$renderer) => {
			$$renderer.option({ value: "auto" }, ($$renderer) => {
				$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.general.sizes.auto"))}`);
			});
			$$renderer.option({ value: "cover" }, ($$renderer) => {
				$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.general.sizes.cover"))}`);
			});
			$$renderer.option({ value: "contain" }, ($$renderer) => {
				$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.general.sizes.contain"))}`);
			});
			$$renderer.option({ value: "100% 100%" }, ($$renderer) => {
				$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.general.sizes.stretch"))}`);
			});
		});
		$$renderer.push(`</div></div> <div class="row mb-3"><label class="col-md-6 col-form-label" for="headerBgColor">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.cover.bg-color"))}</label> <div class="col-md-6"><input id="headerBgColor" class="form-control form-control-color" type="color"${attr("value", store_get($$store_subs ??= {}, "$themeSettings", themeSettings).headerBgColor || store_get($$store_subs ??= {}, "$currentThemeDefault", currentThemeDefault).header)}/></div></div> <div class="row mb-3"><label class="col-md-6 col-form-label" for="headerHeight">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.cover.height"))}</label> <div class="col-md-6"><input class="form-control" id="headerHeight" placeholder="auto" type="number"${attr("value", store_get($$store_subs ??= {}, "$themeSettings", themeSettings).headerHeight)}/></div></div> <div class="row mb-3"><label class="col-md-6 col-form-label" for="headerWidthOption">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.cover.width"))}</label> <div class="col-md-6">`);
		$$renderer.select({
			class: "form-select",
			id: "headerWidthOption",
			value: store_get($$store_subs ??= {}, "$themeSettings", themeSettings).headerWidthOption || "FULL_SIZE"
		}, ($$renderer) => {
			$$renderer.option({ value: "BY_CONTENT" }, ($$renderer) => {
				$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.cover.width-options.by-content"))}`);
			});
			$$renderer.option({ value: "FULL_SIZE" }, ($$renderer) => {
				$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.cover.width-options.full-size"))}`);
			});
		});
		$$renderer.push(`</div></div> <div class="row mb-3"><label class="col-md-6 col-form-label" for="headerNavBarGap">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.cover.nav-gap"))}</label> <div class="col-md-6"><input class="form-range" id="headerNavBarGap" max="5" min="0" type="range"${attr("value", store_get($$store_subs ??= {}, "$themeSettings", themeSettings).headerNavBarGap || "3")}/> <output aria-hidden="true" for="headerNavBarGap">${escape_html(store_get($$store_subs ??= {}, "$themeSettings", themeSettings).headerNavBarGap || "3")}</output></div></div></div> <div class="tab-pane fade" id="navbar" role="tabpanel"><div class="row mb-3"><label class="col-md-6 col-form-label" for="navbarWidthOption">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.navbar.width"))}</label> <div class="col-md-6">`);
		$$renderer.select({
			class: "form-select",
			id: "navbarWidthOption",
			value: store_get($$store_subs ??= {}, "$themeSettings", themeSettings).navbarWidthOption || "BY_CONTENT"
		}, ($$renderer) => {
			$$renderer.option({ value: "BY_CONTENT" }, ($$renderer) => {
				$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.cover.width-options.by-content"))}`);
			});
			$$renderer.option({ value: "FULL_SIZE" }, ($$renderer) => {
				$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.cover.width-options.full-size"))}`);
			});
		});
		$$renderer.push(`</div></div> <div class="row mb-3"><label class="col-md-6 col-form-label" for="navbarBgColor">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.navbar.bg-color"))}</label> <div class="col-md-6"><input id="navbarBgColor" class="form-control form-control-color" type="color"${attr("value", store_get($$store_subs ??= {}, "$themeSettings", themeSettings).navbarBgColor || store_get($$store_subs ??= {}, "$currentThemeDefault", currentThemeDefault).navbar)}/></div></div> <div class="row mb-3"><label class="col-md-6 col-form-label" for="navRoundEnabled">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.navbar.border-radius"))}</label> <div class="col-md-6"><input class="form-range" id="headerNavBarGap" max="5" min="0" type="range"${attr("value", store_get($$store_subs ??= {}, "$themeSettings", themeSettings).navRoundLevel || 5)}/> <output aria-hidden="true" for="headerNavBarGap">${escape_html(store_get($$store_subs ??= {}, "$themeSettings", themeSettings).navRoundLevel || "5")}</output></div></div> <div class="row mb-3"><label class="col-md-6" for="logo-visibility">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.navbar.links-visibility"))}</label> <div class="col-md-6"><div class="form-check form-switch"><input${attr("checked", typeof store_get($$store_subs ??= {}, "$themeSettings", themeSettings).navLinksEnabled === "undefined" ? true : store_get($$store_subs ??= {}, "$themeSettings", themeSettings).navLinksEnabled, true)} class="form-check-input" id="logo-visibility" type="checkbox"/></div></div></div> <div class="row mb-3"><label class="col-md-6 col-form-label" for="navbarLinks">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.navbar.links"))}</label> <div class="col-md-6" id="navbarLinks"><ul class="list-group"><!--[-->`);
		const each_array = ensure_array_like(store_get($$store_subs ??= {}, "$orderedNavLinks", orderedNavLinks));
		for (let index = 0, $$length = each_array.length; index < $$length; index++) {
			let link = each_array[index];
			$$renderer.push(`<li${attr_class("list-group-item d-flex justify-content-between align-items-center drag-item svelte-1qe7qxt", void 0, {
				"dragging": store_get($$store_subs ??= {}, "$draggingItemIndex", draggingItemIndex) === index,
				"drag-over": store_get($$store_subs ??= {}, "$dragOverItemIndex", dragOverItemIndex) === index && store_get($$store_subs ??= {}, "$draggingItemIndex", draggingItemIndex) !== index
			})} draggable="true" style="cursor: move;"><div class="d-flex align-items-center gap-2"><i class="fa fa-bars text-muted"></i> <span>`);
			if (link.isPlugin) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`${escape_html(link.text && link.text.includes(".") ? store_get($$store_subs ??= {}, "$_", $format)(link.text) : link.text)} <span class="badge text-bg-secondary opacity-50 ms-1" style="font-size: 0.6rem;"><i class="fa-solid fa-plug me-1"></i>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("labels.plugin"))}</span>`);
			} else {
				$$renderer.push("<!--[-1-->");
				$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)(link.text))}`);
			}
			$$renderer.push(`<!--]--></span></div> <div class="form-check form-switch m-0"><input class="form-check-input" type="checkbox"${attr("checked", store_get($$store_subs ??= {}, "$themeSettings", themeSettings).navLinksEnableStatus?.[link.id] ?? true, true)}/></div></li>`);
		}
		$$renderer.push(`<!--]--></ul> <div class="form-text mt-2">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.navbar.drag-drop-hint") || "Linkleri sürükleyip bırakarak sıralayabilirsiniz.")}</div></div></div></div> <div class="tab-pane fade" id="sidebar" role="tabpanel"><div class="row mb-3"><label class="col-md-6" for="sidebarVisibility">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.sidebar.visibility"))}</label> <div class="col-md-6"><div class="form-check form-switch"><input${attr("checked", typeof store_get($$store_subs ??= {}, "$themeSettings", themeSettings).sidebarEnabled === "undefined" ? true : store_get($$store_subs ??= {}, "$themeSettings", themeSettings).sidebarEnabled, true)} class="form-check-input" id="sidebarVisibility" type="checkbox"/></div></div></div> <div class="row mb-3"><label class="col-md-6" for="sidebarPosition">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.sidebar.position"))}</label> <div class="col-md-6">`);
		$$renderer.select({
			class: "form-select",
			id: "sidebarPosition",
			value: store_get($$store_subs ??= {}, "$themeSettings", themeSettings).sidebarPosition || "RIGHT"
		}, ($$renderer) => {
			$$renderer.option({ value: "LEFT" }, ($$renderer) => {
				$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.sidebar.positions.left"))}`);
			});
			$$renderer.option({ value: "RIGHT" }, ($$renderer) => {
				$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.sidebar.positions.right"))}`);
			});
		});
		$$renderer.push(`</div></div> <div class="row mb-3"><label class="col-md-6" for="lastRegistrantsCartVisibility">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.sidebar.last-registrants"))}</label> <div class="col-md-6"><div class="form-check form-switch"><input${attr("checked", typeof store_get($$store_subs ??= {}, "$themeSettings", themeSettings).sidebarCarts?.lastRegistrants === "undefined" ? true : store_get($$store_subs ??= {}, "$themeSettings", themeSettings).sidebarCarts?.lastRegistrants, true)} class="form-check-input" id="lastRegistrantsCartVisibility" type="checkbox"/></div></div></div> <div class="row mb-3"><label class="col-md-6" for="onlineAdminsCartVisibility">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.sidebar.online-admins"))}</label> <div class="col-md-6"><div class="form-check form-switch"><input${attr("checked", typeof store_get($$store_subs ??= {}, "$themeSettings", themeSettings).sidebarCarts?.onlineAdmins === "undefined" ? true : store_get($$store_subs ??= {}, "$themeSettings", themeSettings).sidebarCarts?.onlineAdmins, true)} class="form-check-input" id="onlineAdminsCartVisibility" type="checkbox"/></div></div></div></div> <div${attr_class("tab-pane fade", void 0, {
			"active": store_get($$store_subs ??= {}, "$activeTab", activeTab) === "play-card",
			"show": store_get($$store_subs ??= {}, "$activeTab", activeTab) === "play-card"
		})} id="play-card" role="tabpanel"><div class="row mb-3"><label class="col-md-6 col-form-label" for="playCardStyle">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.sidebar.play-card-style"))}</label> <div class="col-md-6">`);
		$$renderer.select({
			class: "form-select",
			id: "playCardStyle",
			value: store_get($$store_subs ??= {}, "$themeSettings", themeSettings).playCardStyle || "style-2"
		}, ($$renderer) => {
			$$renderer.option({ value: "style-2" }, ($$renderer) => {
				$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.sidebar.play-card-styles.style-2"))}`);
			});
			$$renderer.option({ value: "style-1" }, ($$renderer) => {
				$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.sidebar.play-card-styles.style-1"))}`);
			});
		});
		$$renderer.push(`</div></div> <div class="row mb-3"><label class="col-md-6 col-form-label" for="defaultPlayCardBg">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.sidebar.play-card-default-bg"))}</label> <div class="col-md-6 d-flex align-items-center"><div class="form-check form-switch"><input${attr("checked", typeof store_get($$store_subs ??= {}, "$themeSettings", themeSettings).defaultPlayCardBg === "undefined" ? true : store_get($$store_subs ??= {}, "$themeSettings", themeSettings).defaultPlayCardBg, true)} class="form-check-input" id="defaultPlayCardBg" type="checkbox"/></div></div></div> <div class="row mb-3"><label class="col-md-6 col-form-label" for="playCardBgImage">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.sidebar.play-card-bg-image"))}</label> <div class="col-md-6">`);
		if (store_get($$store_subs ??= {}, "$themeSettings", themeSettings).files?.playCardBackgroundImage || (typeof store_get($$store_subs ??= {}, "$themeSettings", themeSettings).defaultPlayCardBg === "undefined" ? true : store_get($$store_subs ??= {}, "$themeSettings", themeSettings).defaultPlayCardBg)) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<div class="input-group"><div style="height: 40px; width: 150px;"><img${attr("alt", store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.sidebar.play-card-bg-image"))} class="border rounded-start" style="height: 100%; width: 100%; object-fit: cover;"${attr("src", store_get($$store_subs ??= {}, "$themeSettings", themeSettings).files?.playCardBackgroundImage ? "/api/theme/file/" + store_get($$store_subs ??= {}, "$themeSettings", themeSettings).files.playCardBackgroundImage : (typeof store_get($$store_subs ??= {}, "$themeSettings", themeSettings).defaultHeaderBg === "undefined" ? true : store_get($$store_subs ??= {}, "$themeSettings", themeSettings).defaultHeaderBg) || !store_get($$store_subs ??= {}, "$themeSettings", themeSettings).files?.headerBackgroundImage ? "/assets/img/default-header-bg.png" : "/api/theme/file/" + store_get($$store_subs ??= {}, "$themeSettings", themeSettings).files.headerBackgroundImage)}/></div> <input id="playCardBgImage" class="form-control"${attr("disabled", typeof store_get($$store_subs ??= {}, "$themeSettings", themeSettings).defaultPlayCardBg === "undefined" ? true : store_get($$store_subs ??= {}, "$themeSettings", themeSettings).defaultPlayCardBg, true)} type="file"/> <button${attr_class("btn btn-outline-danger", void 0, { "disabled": typeof store_get($$store_subs ??= {}, "$themeSettings", themeSettings).defaultPlayCardBg === "undefined" ? true : store_get($$store_subs ??= {}, "$themeSettings", themeSettings).defaultPlayCardBg })} type="button">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.remove"))}</button></div>`);
		} else {
			$$renderer.push("<!--[-1-->");
			$$renderer.push(`<input class="form-control" id="playCardBgImage" type="file"/>`);
		}
		$$renderer.push(`<!--]--></div></div> <div class="row mb-3"><label class="col-md-6 col-form-label" for="playCardBgOpacity">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.sidebar.play-card-bg-opacity"))}</label> <div class="col-md-6"><input class="form-range" id="playCardBgOpacity" max="1" min="0" step="0.05" type="range"${attr("value", store_get($$store_subs ??= {}, "$themeSettings", themeSettings).playCardBgOpacity ?? .5)}/> <div class="text-end small">${escape_html(Math.round((store_get($$store_subs ??= {}, "$themeSettings", themeSettings).playCardBgOpacity ?? .5) * 100))}%</div></div></div> <div class="row mb-3"><label class="col-md-6 col-form-label" for="playCardBgEffect">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.sidebar.play-card-bg-effect"))}</label> <div class="col-md-6">`);
		$$renderer.select({
			class: "form-select",
			id: "playCardBgEffect",
			value: store_get($$store_subs ??= {}, "$themeSettings", themeSettings).playCardBgEffect || "solid"
		}, ($$renderer) => {
			$$renderer.option({ value: "solid" }, ($$renderer) => {
				$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.sidebar.play-card-bg-effects.solid"))}`);
			});
			$$renderer.option({ value: "gradient" }, ($$renderer) => {
				$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.sidebar.play-card-bg-effects.gradient"))}`);
			});
		});
		$$renderer.push(`</div></div> <div class="row mb-3"><label class="col-md-6 col-form-label" for="playCardIpText">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.sidebar.play-card-ip-text"))}</label> <div class="col-md-6"><input class="form-control" id="playCardIpText"${attr("placeholder", store_get($$store_subs ??= {}, "$session", session).siteInfo.serverIp)} type="text"${attr("value", store_get($$store_subs ??= {}, "$themeSettings", themeSettings).playCardIpText || store_get($$store_subs ??= {}, "$session", session).siteInfo.serverIp)}/> <div class="small opacity-75 mt-1">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.sidebar.play-card-ip-text-hint"))}</div></div></div> <div class="row mb-3"><label class="col-md-6 col-form-label" for="playCardStatusBadge">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.sidebar.play-card-status-badge"))}</label> <div class="col-md-6 d-flex align-items-center"><div class="form-check form-switch"><input${attr("checked", store_get($$store_subs ??= {}, "$themeSettings", themeSettings).playCardStatusBadge ?? true, true)} class="form-check-input" id="playCardStatusBadge" type="checkbox"/></div></div></div> <div class="row mb-3"><label class="col-md-6 col-form-label" for="playCardPlayerCount">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.sidebar.play-card-player-count"))}</label> <div class="col-md-6 d-flex align-items-center"><div class="form-check form-switch"><input${attr("checked", store_get($$store_subs ??= {}, "$themeSettings", themeSettings).playCardPlayerCount ?? true, true)} class="form-check-input" id="playCardPlayerCount" type="checkbox"/></div></div></div> <div class="row mb-3"><label class="col-md-6 col-form-label" for="playCardVersionInfo">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.sidebar.play-card-version-info"))}</label> <div class="col-md-6 d-flex align-items-center"><div class="form-check form-switch"><input${attr("checked", store_get($$store_subs ??= {}, "$themeSettings", themeSettings).playCardVersionInfo ?? true, true)} class="form-check-input" id="playCardVersionInfo" type="checkbox"/></div></div></div> <div class="row mb-3"><label class="col-md-6 col-form-label" for="playCardIpColor">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.sidebar.play-card-ip-color"))}</label> <div class="col-md-6">`);
		$$renderer.select({
			class: "form-select",
			id: "playCardIpColor",
			value: store_get($$store_subs ??= {}, "$themeSettings", themeSettings).playCardIpColor || "default"
		}, ($$renderer) => {
			$$renderer.option({ value: "default" }, ($$renderer) => {
				$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.sidebar.default"))}`);
			});
			$$renderer.option({ value: "primary" }, ($$renderer) => {
				$$renderer.push(`Primary`);
			});
			$$renderer.option({ value: "secondary" }, ($$renderer) => {
				$$renderer.push(`Secondary`);
			});
			$$renderer.option({ value: "success" }, ($$renderer) => {
				$$renderer.push(`Success`);
			});
			$$renderer.option({ value: "danger" }, ($$renderer) => {
				$$renderer.push(`Danger`);
			});
			$$renderer.option({ value: "warning" }, ($$renderer) => {
				$$renderer.push(`Warning`);
			});
			$$renderer.option({ value: "info" }, ($$renderer) => {
				$$renderer.push(`Info`);
			});
			$$renderer.option({ value: "light" }, ($$renderer) => {
				$$renderer.push(`Light`);
			});
			$$renderer.option({ value: "dark" }, ($$renderer) => {
				$$renderer.push(`Dark`);
			});
		});
		$$renderer.push(`</div></div> <div class="row mb-3"><label class="col-md-6 col-form-label" for="playCardBorderColor">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.sidebar.play-card-border-color"))}</label> <div class="col-md-6">`);
		$$renderer.select({
			class: "form-select",
			id: "playCardBorderColor",
			value: store_get($$store_subs ??= {}, "$themeSettings", themeSettings).playCardBorderColor || "default"
		}, ($$renderer) => {
			$$renderer.option({ value: "default" }, ($$renderer) => {
				$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.sidebar.default"))}`);
			});
			$$renderer.option({ value: "border-primary" }, ($$renderer) => {
				$$renderer.push(`Primary`);
			});
			$$renderer.option({ value: "border-secondary" }, ($$renderer) => {
				$$renderer.push(`Secondary`);
			});
			$$renderer.option({ value: "border-success" }, ($$renderer) => {
				$$renderer.push(`Success`);
			});
			$$renderer.option({ value: "border-danger" }, ($$renderer) => {
				$$renderer.push(`Danger`);
			});
			$$renderer.option({ value: "border-warning" }, ($$renderer) => {
				$$renderer.push(`Warning`);
			});
			$$renderer.option({ value: "border-info" }, ($$renderer) => {
				$$renderer.push(`Info`);
			});
			$$renderer.option({ value: "border-light" }, ($$renderer) => {
				$$renderer.push(`Light`);
			});
			$$renderer.option({ value: "border-dark" }, ($$renderer) => {
				$$renderer.push(`Dark`);
			});
		});
		$$renderer.push(`</div></div></div> <div class="tab-pane fade" id="post-card" role="tabpanel"><div class="row mb-3"><label class="col-md-6" for="postsEnabled">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.post-card.visibility"))}</label> <div class="col-md-6"><div class="form-check form-switch"><input${attr("checked", typeof store_get($$store_subs ??= {}, "$themeSettings", themeSettings).postsEnabled === "undefined" ? true : store_get($$store_subs ??= {}, "$themeSettings", themeSettings).postsEnabled, true)} class="form-check-input" id="postsEnabled" type="checkbox"/></div></div></div> <div class="row mb-3"><label class="col-md-6" for="postCoverImageEnabled">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.post-card.cover-image"))}</label> <div class="col-md-6"><div class="form-check form-switch"><input${attr("checked", typeof store_get($$store_subs ??= {}, "$themeSettings", themeSettings).postCoverImageEnabled === "undefined" ? true : store_get($$store_subs ??= {}, "$themeSettings", themeSettings).postCoverImageEnabled, true)} class="form-check-input" id="postCoverImageEnabled" type="checkbox"/></div></div></div> <div class="row mb-3"><label class="col-md-6" for="postReadMoreButtonEnabled">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.post-card.read-more"))}</label> <div class="col-md-6"><div class="form-check form-switch"><input${attr("checked", typeof store_get($$store_subs ??= {}, "$themeSettings", themeSettings).postReadMoreButtonEnabled === "undefined" ? true : store_get($$store_subs ??= {}, "$themeSettings", themeSettings).postReadMoreButtonEnabled, true)} class="form-check-input" id="postReadMoreButtonEnabled" type="checkbox"/></div></div></div> <div class="row mb-3"><label class="col-md-6" for="postAuthorImageEnabled">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.post-card.author-image"))}</label> <div class="col-md-6"><div class="form-check form-switch"><input${attr("checked", typeof store_get($$store_subs ??= {}, "$themeSettings", themeSettings).postAuthorImageEnabled === "undefined" ? true : store_get($$store_subs ??= {}, "$themeSettings", themeSettings).postAuthorImageEnabled, true)} class="form-check-input" id="postAuthorImageEnabled" type="checkbox"/></div></div></div> <div class="row mb-3"><label class="col-md-6" for="postViewCountEnabled">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.post-card.views"))}</label> <div class="col-md-6"><div class="form-check form-switch"><input${attr("checked", typeof store_get($$store_subs ??= {}, "$themeSettings", themeSettings).postViewCountEnabled === "undefined" ? true : store_get($$store_subs ??= {}, "$themeSettings", themeSettings).postViewCountEnabled, true)} class="form-check-input" id="postViewCountEnabled" type="checkbox"/></div></div></div> <div class="row mb-3"><label class="col-md-6" for="postPreviousPageEnabled">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.post-card.previous-post"))}</label> <div class="col-md-6"><div class="form-check form-switch"><input${attr("checked", typeof store_get($$store_subs ??= {}, "$themeSettings", themeSettings).postPreviousPageEnabled === "undefined" ? true : store_get($$store_subs ??= {}, "$themeSettings", themeSettings).postPreviousPageEnabled, true)} class="form-check-input" id="postPreviousPageEnabled" type="checkbox"/></div></div></div> <div class="row mb-3"><label class="col-md-6" for="postNextPageEnabled">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.post-card.next-post"))}</label> <div class="col-md-6"><div class="form-check form-switch"><input${attr("checked", typeof store_get($$store_subs ??= {}, "$themeSettings", themeSettings).postNextPageEnabled === "undefined" ? true : store_get($$store_subs ??= {}, "$themeSettings", themeSettings).postNextPageEnabled, true)} class="form-check-input" id="postNextPageEnabled" type="checkbox"/></div></div></div></div> <div class="tab-pane fade" id="footer" role="tabpanel"><div class="row mb-3"><label class="col-md-6" for="footerEnabled">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.footer.visibility"))}</label> <div class="col-md-6"><div class="form-check form-switch"><input${attr("checked", typeof store_get($$store_subs ??= {}, "$themeSettings", themeSettings).footerEnabled === "undefined" ? true : store_get($$store_subs ??= {}, "$themeSettings", themeSettings).footerEnabled, true)} class="form-check-input" id="footerEnabled" type="checkbox"/></div></div></div> <div class="row mb-3"><label class="col-md-6" for="footerLogoEnabled">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.footer.logo-visibility"))}</label> <div class="col-md-6"><div class="form-check form-switch"><input${attr("checked", store_get($$store_subs ??= {}, "$themeSettings", themeSettings).footerLogoEnabled ?? true, true)} class="form-check-input" id="footerLogoEnabled" type="checkbox"/></div></div></div> <div class="row mb-3"><label class="col-md-6" for="footerTitleEnabled">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.footer.title-visibility"))}</label> <div class="col-md-6"><div class="form-check form-switch"><input${attr("checked", store_get($$store_subs ??= {}, "$themeSettings", themeSettings).footerTitleEnabled ?? true, true)} class="form-check-input" id="footerTitleEnabled" type="checkbox"/></div></div></div> <div class="row mb-3"><label class="col-md-6 col-form-label" for="footerTitle">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.footer.title"))}</label> <div class="col-md-6"><input class="form-control" id="footerTitle" type="text"${attr("value", store_get($$store_subs ??= {}, "$themeSettings", themeSettings).footerTitle ?? store_get($$store_subs ??= {}, "$session", session).siteInfo.websiteName)}/></div></div> <div class="row mb-3"><label class="col-md-6" for="footerContentEnabled">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.footer.content-visibility"))}</label> <div class="col-md-6"><div class="form-check form-switch"><input${attr("checked", store_get($$store_subs ??= {}, "$themeSettings", themeSettings).footerContentEnabled ?? true, true)} class="form-check-input" id="footerContentEnabled" type="checkbox"/></div></div></div> <div class="row mb-3"><label class="col-md-6 col-form-label" for="footerContent">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.footer.content"))}</label> <div class="col-md-6"><textarea class="form-control" id="footerContent" style="height: 200px;">`);
		const $$body = escape_html(store_get($$store_subs ??= {}, "$themeSettings", themeSettings).footerContent ?? store_get($$store_subs ??= {}, "$session", session).siteInfo.websiteDescription);
		if ($$body) $$renderer.push(`${$$body}`);
		$$renderer.push(`</textarea></div></div> <div class="row mb-3"><label class="col-md-6" for="footer-links-visibility">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.footer.links-visibility"))}</label> <div class="col-md-6"><div class="form-check form-switch"><input${attr("checked", store_get($$store_subs ??= {}, "$themeSettings", themeSettings).footerLinksEnabled ?? true, true)} class="form-check-input" id="footer-links-visibility" type="checkbox"/></div></div></div> <div class="row mb-3"><label class="col-md-6" for="footer-plugin-links-visibility">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.footer.plugin-links-visibility"))}</label> <div class="col-md-6"><div class="form-check form-switch"><input${attr("checked", store_get($$store_subs ??= {}, "$themeSettings", themeSettings).footerPluginLinksEnabled ?? true, true)} class="form-check-input" id="footer-plugin-links-visibility" type="checkbox"/></div></div></div> <div class="row mb-3"><label class="col-md-6 col-form-label" for="footerLinks">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.footer.links"))}</label> <div class="col-md-6" id="footerLinks"><ul class="list-group"><!--[-->`);
		const each_array_1 = ensure_array_like(store_get($$store_subs ??= {}, "$orderedFooterLinks", orderedFooterLinks));
		for (let index = 0, $$length = each_array_1.length; index < $$length; index++) {
			let link = each_array_1[index];
			if (!link.isPlugin || (store_get($$store_subs ??= {}, "$themeSettings", themeSettings).footerPluginLinksEnabled ?? true)) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<li${attr_class("list-group-item d-flex justify-content-between align-items-center drag-item svelte-1qe7qxt", void 0, {
					"dragging": store_get($$store_subs ??= {}, "$draggingItemIndex", draggingItemIndex) === index,
					"drag-over": store_get($$store_subs ??= {}, "$dragOverItemIndex", dragOverItemIndex) === index && store_get($$store_subs ??= {}, "$draggingItemIndex", draggingItemIndex) !== index
				})} draggable="true" style="cursor: move;"><div class="d-flex align-items-center gap-2"><i class="fa fa-bars text-muted"></i> <span>`);
				if (link.isPlugin) {
					$$renderer.push("<!--[0-->");
					$$renderer.push(`${escape_html(link.text && link.text.includes(".") ? store_get($$store_subs ??= {}, "$_", $format)(link.text) : link.text)} <span class="badge text-bg-secondary opacity-50 ms-1" style="font-size: 0.6rem;"><i class="fa-solid fa-plug me-1"></i>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("labels.plugin"))}</span>`);
				} else {
					$$renderer.push("<!--[-1-->");
					$$renderer.push(`${escape_html(store_get($$store_subs ??= {}, "$_", $format)(link.text))}`);
				}
				$$renderer.push(`<!--]--></span></div> <div class="form-check form-switch m-0"><input class="form-check-input" type="checkbox"${attr("checked", store_get($$store_subs ??= {}, "$themeSettings", themeSettings).footerLinksEnableStatus?.[link.id] ?? true, true)}/></div></li>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]-->`);
		}
		$$renderer.push(`<!--]--></ul> <div class="form-text mt-2">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.navbar.drag-drop-hint") || "Linkleri sürükleyip bırakarak sıralayabilirsiniz.")}</div></div></div></div> <div class="tab-pane fade" id="advanced" role="tabpanel"><div class="row"><label class="col col-form-label" for="customCss">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.theme-settings.advanced.custom-css"))}</label> <div class="col-6"><textarea class="form-control" id="customCss" style="height: 200px;">`);
		const $$body_1 = escape_html(store_get($$store_subs ??= {}, "$themeSettings", themeSettings).customCss);
		if ($$body_1) $$renderer.push(`${$$body_1}`);
		$$renderer.push(`</textarea></div></div></div></div> <div class="mt-4 d-flex align-items-center gap-2 border-top pt-3"><button${attr_class("btn btn-secondary", void 0, { "disabled": store_get($$store_subs ??= {}, "$saving", saving) || !store_get($$store_subs ??= {}, "$tabChanged", tabChanged) })}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.save"))}</button> <button${attr_class("btn btn-link", void 0, { "disabled": store_get($$store_subs ??= {}, "$resetting", resetting) || store_get($$store_subs ??= {}, "$saving", saving) })}${attr("hidden", !store_get($$store_subs ??= {}, "$tabResetVisible", tabResetVisible))}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.reset-tab"))}</button> <div class="ms-auto"><button${attr_class("btn btn-link link-danger", void 0, { "disabled": store_get($$store_subs ??= {}, "$resettingAll", resettingAll) || store_get($$store_subs ??= {}, "$saving", saving) })}${attr("hidden", !store_get($$store_subs ??= {}, "$allResetVisible", allResetVisible))}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.reset-all"))}</button></div></div></div></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
		bind_props($$props, {
			data,
			themeSettings,
			session,
			activeTab,
			saving,
			resetting,
			resettingAll,
			backgroundImageFiles,
			headerBackgroundImageFiles,
			playCardBackgroundImageFiles,
			currentThemeDefault,
			defaultHeaderBg,
			orderedNavLinks,
			orderedFooterLinks,
			draggingItemIndex,
			dragOverItemIndex,
			tabChanged,
			tabResetVisible,
			allResetVisible,
			onThemeColorChange,
			onBackgroundImageChange,
			onRemoveBackgroundImageClick,
			onHeaderBackgroundImageChange,
			onRemoveHeaderBackgroundImageClick,
			onPlayCardBackgroundImageChange,
			onRemovePlayCardBackgroundImageClick,
			onDragStart,
			onDragOver,
			onDragEnd,
			onDrop,
			toggleLink,
			toggleFooterLink,
			save,
			resetTab,
			resetAll
		});
	});
}

export { ThemeSettingsView as default };
//# sourceMappingURL=ThemeSettingsView.js-Di4tKAlL.js.map
