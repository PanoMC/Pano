import { W as bind_props, T as writable, $ as ensure_array_like, a0 as store_get, a5 as escape_html, a1 as spread_props, a2 as unsubscribe_stores } from './server.js-D28cBEJ-.js';
import { $ as $format } from './runtime.js-CJgfVvxa.js';
import { d as panoApi, g as executeSidebarLoad } from './PluginManager.js-B5x3OKEW.js';
import { d as ApiUtil } from './Store.js-C2vdyE6V.js';
import { S as Sidebar } from './Sidebar.js-BwVxP8m2.js';
import { V as ViewComponent } from './ViewComponent.js-C6amYVVM.js';
import { O as OnlineAdmins } from './OnlineAdmins.js-FcRIIIBU.js';
import { T as TicketStatuses } from './TicketStatus.js-GhIwl1A5.js';

//#region node_modules/@panomc/theme-core/src/lib/components/sidebars/TicketCreateAndDetailSidebar.svelte
var data = writable({ onlineAdmins: [] });
var ticketData = writable(null);
var load = async (event, ticket) => {
	panoApi.ui.sidebar.register({
		sidebarId: "ticket",
		id: "online-admins",
		component: "local:online-admins",
		priority: 100
	});
	panoApi.ui.sidebar.register({
		sidebarId: "ticket",
		id: "close-ticket-button",
		component: "local:close-ticket-button",
		priority: 110
	});
	await executeSidebarLoad("ticket", event);
	data.set(await ApiUtil.get({
		path: "/api/sidebars/support",
		request: event
	}));
	if (ticket) ticketData.set(ticket);
};
function TicketCreateAndDetailSidebar($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let side = $$props["side"];
		const items = panoApi.ui.sidebar.get("ticket");
		Sidebar($$renderer, {
			side,
			children: ($$renderer) => {
				$$renderer.push(`<div class="vstack gap-3"><!--[-->`);
				const each_array = ensure_array_like(store_get($$store_subs ??= {}, "$items", items));
				for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
					let item = each_array[$$index];
					if (item.id === "online-admins") {
						$$renderer.push("<!--[0-->");
						OnlineAdmins($$renderer, { onlineAdmins: store_get($$store_subs ??= {}, "$data", data).onlineAdmins });
					} else if (item.id === "close-ticket-button") {
						$$renderer.push("<!--[1-->");
						if (store_get($$store_subs ??= {}, "$ticketData", ticketData) && store_get($$store_subs ??= {}, "$ticketData", ticketData).status !== TicketStatuses.CLOSED) {
							$$renderer.push("<!--[0-->");
							$$renderer.push(`<button class="btn btn-danger w-100" type="button"><i class="fas fa-times me-2"></i> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.close-ticket"))}</button>`);
						} else $$renderer.push("<!--[-1-->");
						$$renderer.push(`<!--]-->`);
					} else {
						$$renderer.push("<!--[-1-->");
						ViewComponent($$renderer, spread_props([{
							component: item.component,
							data: store_get($$store_subs ??= {}, "$data", data),
							ticketData: store_get($$store_subs ??= {}, "$ticketData", ticketData)
						}, item.props]));
					}
					$$renderer.push(`<!--]-->`);
				}
				$$renderer.push(`<!--]--></div>`);
			},
			$$slots: { default: true }
		});
		if ($$store_subs) unsubscribe_stores($$store_subs);
		bind_props($$props, { side });
	});
}

export { TicketCreateAndDetailSidebar as T, load as l };
//# sourceMappingURL=TicketCreateAndDetailSidebar.js-BcHSjF3Z.js.map
