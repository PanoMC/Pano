import { e as error } from './exports2.js-DxZfja4I.js';
import { W as bind_props, T as writable, a4 as get } from './server.js-D28cBEJ-.js';
import 'node:module';
import { r as resolveView } from './registry2.js-BubD3cPq.js';
import { c as avatarVersion } from './Store.js-C2vdyE6V.js';
import { g as getTicketDetail, s as sendTicketMessage, l as loadMoreTicketMessages } from './CloseTicketConfirmModal.js-ex0CkG3p.js';
import './runtime.js-CJgfVvxa.js';
import { l as load$1, T as TicketCreateAndDetailSidebar } from './TicketCreateAndDetailSidebar.js-BcHSjF3Z.js';

//#region node_modules/@panomc/theme-core/src/lib/ui-logics/page-logics/TicketDetailPageLogics.js
/**
* @type {import("@sveltejs/kit").Load}
*/
async function processLoad(event) {
	const { parent } = event;
	await parent();
	let data = { ticket: {
		id: -1,
		username: "",
		title: "",
		category: "-",
		messages: [],
		status: 1,
		date: 0,
		messageCount: 0
	} };
	await getTicketDetail({
		id: event.params.id,
		request: event
	}).then((body) => {
		if (body.error) {
			if (body.error === "NOT_EXISTS" || body.error === "BAD_REQUEST") throw error(404, body.error);
			throw error(500, body.error);
		}
		data = body;
	});
	await load$1(event, data.ticket);
	data.pageTitle = {
		title: "pages.ticket-detail.tab-title",
		titleValues: {
			ticketId: `#${data.ticket.id}`,
			title: data.ticket.title
		}
	};
	return {
		...data,
		sidebar: TicketCreateAndDetailSidebar
	};
}
async function loadMore(loadMoreLoading, messages, data) {
	loadMoreLoading.set(true);
	await loadMoreTicketMessages({
		id: data.ticket.id,
		lastMessageId: get(messages)[0].id
	}).then((body) => {
		if (body.error) return;
		body.messages.reverse().forEach((message) => {
			messages.update((messages) => {
				messages.unshift(message);
				return messages;
			});
		});
		loadMoreLoading.set(false);
	});
}
async function sendMessage(messageSendLoading, sentMessageCount, shouldScroll, messages, message, data) {
	messageSendLoading.set(true);
	await sendTicketMessage({
		ticketId: data.ticket.id,
		message: get(message)
	}).then((body) => {
		if (body.error) return;
		shouldScroll.set(true);
		messages.update((messages) => {
			messages.push(body.message);
			return messages;
		});
		sentMessageCount.update((sentMessageCount) => {
			sentMessageCount++;
			return sentMessageCount;
		});
		message.set("");
		messageSendLoading.set(false);
	});
}
function init(data) {
	const shouldScroll = writable(true);
	const message = writable("");
	const messages = writable(data.ticket.messages);
	return {
		shouldScroll,
		message,
		messagesSectionDiv: writable(),
		loadMoreLoading: writable(false),
		messageSendLoading: writable(false),
		sentMessageCount: writable(0),
		messages,
		ticket: writable(data.ticket)
	};
}
//#endregion
//#region node_modules/@panomc/theme-core/src/lib/pages/ticket/TicketDetailPage.svelte
async function load(event) {
	const viewPromise = resolveView("TicketDetailView", () => import('./TicketDetailView.js-LrN9aHf0.js'));
	return {
		...await processLoad(event),
		View: await viewPromise
	};
}
function TicketDetailPage($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		let data = $$props["data"];
		const { message, messageSendLoading, messagesSectionDiv, loadMoreLoading, shouldScroll, sentMessageCount, messages, ticket } = init(data);
		if (data.View) {
			$$renderer.push("<!--[-->");
			data.View($$renderer, {
				data,
				ticket,
				messages,
				message,
				messageSendLoading,
				messagesSectionDiv,
				loadMoreLoading,
				shouldScroll,
				sentMessageCount,
				avatarVersion,
				loadMore,
				sendMessage
			});
			$$renderer.push("<!--]-->");
		} else {
			$$renderer.push("<!--[!-->");
			$$renderer.push("<!--]-->");
		}
		bind_props($$props, { data });
	});
}

export { TicketDetailPage as T, load as l };
//# sourceMappingURL=TicketDetailPage.js-ygeLO6tv.js.map
