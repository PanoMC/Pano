import { a0 as store_get, Z as attr_class, a5 as escape_html, $ as ensure_array_like, X as attr, Y as stringify, a3 as html, a2 as unsubscribe_stores, W as bind_props } from './server.js-D28cBEJ-.js';
import { $ as $format } from './runtime.js-CJgfVvxa.js';
import './tooltip.util.js-Bd9x5X7L.js';
import { D as Date_1 } from './Date.js-ZK3lGml2.js';
import { P as PageTitle } from './PageTitle.js-D99NSXzQ.js';
import { C as CardHeader } from './CardHeader.js-DpkWpoy6.js';
import { T as TicketStatuses, a as TicketStatus } from './TicketStatus.js-GhIwl1A5.js';
import './uneval.js-BL1Qg77w.js';
import './rolldown-runtime.js-B5FuG9Gw.js';
import 'node:module';
import './stores.js-QbD2A2ib.js';
import './client.js-CPEkJ2-P.js';
import './shared.js-3i5_hmQ1.js';
import './exports.js-CKkpMUqI.js';
import './internal2.js-KmQU-gaY.js';
import './index-server2.js-DlblWyyK.js';
import './language.util.js-C2xYQq5-.js';
import './internal.js-BlXt2rfE.js';
import './Store.js-C2vdyE6V.js';
import './exports2.js-DxZfja4I.js';
import './ToastContainer.js-CtmBBvhr.js';
import './locale.js-DnnPB87K.js';
import './format.js-CzDFIcjs.js';

//#region node_modules/@panomc/theme-core/src/lib/views/TicketDetailView.svelte
function TicketDetailView($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let isSendButtonDisabled;
		let data = $$props["data"];
		let ticket = $$props["ticket"];
		let messages = $$props["messages"];
		let message = $$props["message"];
		let messageSendLoading = $$props["messageSendLoading"];
		let messagesSectionDiv = $$props["messagesSectionDiv"];
		let loadMoreLoading = $$props["loadMoreLoading"];
		let shouldScroll = $$props["shouldScroll"];
		let sentMessageCount = $$props["sentMessageCount"];
		let avatarVersion = $$props["avatarVersion"];
		let loadMore = $$props["loadMore"];
		let sendMessage = $$props["sendMessage"];
		isSendButtonDisabled = store_get($$store_subs ??= {}, "$message", message) === "";
		$$renderer.push(`<div class="vstack gap-3">`);
		PageTitle($$renderer, {
			title: `#${store_get($$store_subs ??= {}, "$ticket", ticket).id} ${store_get($$store_subs ??= {}, "$ticket", ticket).title}`,
			subtitle: store_get($$store_subs ??= {}, "$_", $format)("pages.ticket-detail.detail.opened-in-category", { values: { category: `<a
  href="/tickets?category=${store_get($$store_subs ??= {}, "$ticket", ticket).category.url}"
  title="${store_get($$store_subs ??= {}, "$_", $format)("pages.ticket-detail.filter")}"
  >${store_get($$store_subs ??= {}, "$ticket", ticket).category === "-" ? store_get($$store_subs ??= {}, "$_", $format)("pages.ticket-detail.no-category") : store_get($$store_subs ??= {}, "$ticket", ticket).category.title}
</a>` } }),
			subtitleHtml: true
		});
		$$renderer.push(`<!----> <div class="card mt-lg-0">`);
		CardHeader($$renderer, { $$slots: {
			left: ($$renderer) => {
				$$renderer.push(`<small slot="left" class="text-body-secondary">`);
				Date_1($$renderer, {
					time: store_get($$store_subs ??= {}, "$ticket", ticket).date,
					relativeFormat: true
				});
				$$renderer.push(`<!----></small>`);
			},
			right: ($$renderer) => {
				$$renderer.push(`<div slot="right">`);
				TicketStatus($$renderer, { status: store_get($$store_subs ??= {}, "$ticket", ticket).status });
				$$renderer.push(`<!----></div>`);
			}
		} });
		$$renderer.push(`<!----> <div class="card-body" id="messageSection">`);
		if (store_get($$store_subs ??= {}, "$messages", messages).length < store_get($$store_subs ??= {}, "$ticket", ticket).messageCount && store_get($$store_subs ??= {}, "$ticket", ticket).messageCount > 5) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<div class="d-flex justify-content-center mb-3"><button${attr_class("btn btn-sm btn-secondary", void 0, { "disabled": store_get($$store_subs ??= {}, "$loadMoreLoading", loadMoreLoading) })}><i class="fas fa-arrow-up me-1"></i> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.ticket-detail.previous-messages", { values: { count: store_get($$store_subs ??= {}, "$ticket", ticket).messageCount - (store_get($$store_subs ??= {}, "$messages", messages).length - store_get($$store_subs ??= {}, "$sentMessageCount", sentMessageCount)) } }))}</button></div>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--> <div class="vstack gap-2"><!--[-->`);
		const each_array = ensure_array_like(store_get($$store_subs ??= {}, "$messages", messages));
		for (let index = 0, $$length = each_array.length; index < $$length; index++) {
			let message = each_array[index];
			if (message.panel) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<div class="row g-2 flex-nowrap"><div class="col-auto"><a${attr("href", `/player/${stringify(message.username)}`)}><img${attr("src", `/api/profile/picture/${stringify(message.username)}?${stringify(store_get($$store_subs ??= {}, "$avatarVersion", avatarVersion))}`)}${attr("alt", message.username)} class="rounded-circle animate__animated animate__zoomIn" width="48" height="48" onload="this.__e=event" onerror="this.__e=event"/></a></div> <div class="col vstack align-items-start"><div class="card rounded-5 text-bg-primary border-0 shadow-sm"><div class="card-body answer px-3 py-2">${html(message.message)}</div></div> <small class="text-body-secondary mt-1">`);
				Date_1($$renderer, {
					time: message.date,
					relativeFormat: true
				});
				$$renderer.push(`<!----></small></div></div>`);
			} else {
				$$renderer.push("<!--[-1-->");
				$$renderer.push(`<div class="row g-2 flex-nowrap"><div class="col vstack align-items-end"><div class="card rounded-5 bg-transparent border shadow-sm"><div class="card-body px-3 py-2">${escape_html(message.message)}</div></div> <small class="text-body-secondary mt-1">`);
				Date_1($$renderer, {
					time: message.date,
					relativeFormat: true
				});
				$$renderer.push(`<!----></small></div> <div class="col-auto"><a${attr("href", `/player/${stringify(message.username)}`)}><img${attr("src", `/api/profile/picture/${stringify(message.username)}?${stringify(store_get($$store_subs ??= {}, "$avatarVersion", avatarVersion))}`)}${attr("alt", message.username)} class="rounded-circle animate__animated animate__zoomIn" width="48" height="48" onload="this.__e=event" onerror="this.__e=event"/></a></div></div>`);
			}
			$$renderer.push(`<!--]-->`);
		}
		$$renderer.push(`<!--]--></div></div> <div${attr_class("card-footer", void 0, { "d-none": store_get($$store_subs ??= {}, "$ticket", ticket).status === TicketStatuses.CLOSED })}><div class="input-group"><textarea${attr("placeholder", store_get($$store_subs ??= {}, "$_", $format)("pages.ticket-detail.inputs.message.placeholder"))} class="form-control">`);
		const $$body = escape_html(store_get($$store_subs ??= {}, "$message", message));
		if ($$body) $$renderer.push(`${$$body}`);
		$$renderer.push(`</textarea> <button${attr_class("btn btn-secondary border-left-0", void 0, { "disabled": store_get($$store_subs ??= {}, "$messageSendLoading", messageSendLoading) || isSendButtonDisabled })}${attr("disabled", store_get($$store_subs ??= {}, "$messageSendLoading", messageSendLoading) || isSendButtonDisabled, true)}${attr("title", store_get($$store_subs ??= {}, "$_", $format)("buttons.send"))}${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("buttons.send"))}><i class="fas fa-paper-plane"></i></button></div></div></div></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
		bind_props($$props, {
			data,
			ticket,
			messages,
			message,
			messageSendLoading,
			messagesSectionDiv,
			loadMoreLoading,
			shouldScroll,
			sentMessageCount,
			avatarVersion,
			loadMore,
			sendMessage
		});
	});
}

export { TicketDetailView as default };
//# sourceMappingURL=TicketDetailView.js-LrN9aHf0.js.map
