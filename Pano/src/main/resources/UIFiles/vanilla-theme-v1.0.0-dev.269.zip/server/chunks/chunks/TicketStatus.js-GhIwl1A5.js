import { V as fallback, a5 as escape_html, a0 as store_get, a2 as unsubscribe_stores, W as bind_props } from './server.js-D28cBEJ-.js';
import { $ as $format } from './runtime.js-CJgfVvxa.js';

//#region node_modules/@panomc/theme-core/src/lib/components/TicketStatus.svelte
var TicketStatuses = Object.freeze({
	NEW: "NEW",
	REPLIED: "REPLIED",
	CLOSED: "CLOSED"
});
function TicketStatus($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let status = fallback($$props["status"], () => TicketStatuses.NEW, true);
		if (status === TicketStatuses.NEW) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<span class="badge text-bg-success rounded-pill">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("ticket-statuses.new"))}</span>`);
		} else if (status === TicketStatuses.REPLIED) {
			$$renderer.push("<!--[1-->");
			$$renderer.push(`<span class="badge text-bg-warning rounded-pill">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("ticket-statuses.replied"))}</span>`);
		} else if (status === TicketStatuses.CLOSED) {
			$$renderer.push("<!--[2-->");
			$$renderer.push(`<span class="badge text-bg-danger rounded-pill">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("ticket-statuses.closed"))}</span>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]-->`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
		bind_props($$props, { status });
	});
}

export { TicketStatuses as T, TicketStatus as a };
//# sourceMappingURL=TicketStatus.js-GhIwl1A5.js.map
