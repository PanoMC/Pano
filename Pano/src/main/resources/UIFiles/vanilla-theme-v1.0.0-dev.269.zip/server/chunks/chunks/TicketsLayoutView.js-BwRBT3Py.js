import { _ as slot, W as bind_props } from './server.js-D28cBEJ-.js';
import { C as CloseTicketConfirmModal } from './CloseTicketConfirmModal.js-ex0CkG3p.js';
import './uneval.js-BL1Qg77w.js';
import './runtime.js-CJgfVvxa.js';
import './rolldown-runtime.js-B5FuG9Gw.js';
import 'node:module';
import './Store.js-C2vdyE6V.js';
import './exports2.js-DxZfja4I.js';
import './shared.js-3i5_hmQ1.js';
import './client.js-CPEkJ2-P.js';
import './exports.js-CKkpMUqI.js';
import './internal2.js-KmQU-gaY.js';
import './index-server2.js-DlblWyyK.js';
import './ToastContainer.js-CtmBBvhr.js';
import './ErrorAlert.js-DbwaZ_OB.js';

//#region node_modules/@panomc/theme-core/src/lib/views/TicketsLayoutView.svelte
function TicketsLayoutView($$renderer, $$props) {
	let data = $$props["data"];
	$$renderer.push(`<!--[-->`);
	slot($$renderer, $$props, "default", {}, null);
	$$renderer.push(`<!--]--> `);
	CloseTicketConfirmModal($$renderer);
	$$renderer.push(`<!---->`);
	bind_props($$props, { data });
}

export { TicketsLayoutView as default };
//# sourceMappingURL=TicketsLayoutView.js-BwRBT3Py.js.map
