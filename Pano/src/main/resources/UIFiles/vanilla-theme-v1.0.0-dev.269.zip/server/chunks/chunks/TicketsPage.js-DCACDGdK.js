import { e as error } from './exports2.js-DxZfja4I.js';
import { W as bind_props, T as writable } from './server.js-D28cBEJ-.js';
import 'node:module';
import { g as goto } from './client.js-CPEkJ2-P.js';
import { p as panoApiClient, h as panoApiServer, e as executeLifecycle, b as executeViewLoad } from './PluginManager.js-B5x3OKEW.js';
import { r as resolveView } from './registry2.js-BubD3cPq.js';
import { e as buildQueryParams } from './Store.js-C2vdyE6V.js';
import { l as load$1, P as ProfileSidebar } from './ProfileSidebar.js-BIu8zSKN.js';
import { b as getTickets, d as show } from './CloseTicketConfirmModal.js-ex0CkG3p.js';
import './runtime.js-CJgfVvxa.js';

//#region node_modules/@panomc/theme-core/src/lib/ui-logics/page-logics/TicketsPageLogics.js
var PageTypes = Object.freeze({
	ALL: "ALL",
	CLOSED: "CLOSED"
});
var DefaultPageType = PageTypes.ALL;
/**
* @type {import("@sveltejs/kit").Load}
*/
async function processLoad(event) {
	const { parent, url: { searchParams } } = event;
	await parent();
	const page = parseInt(searchParams.get("page")) || 1;
	const pageType = searchParams.get("pageType") || DefaultPageType;
	const categoryUrl = searchParams.get("category");
	const data = await getTickets({
		page,
		pageType,
		categoryUrl,
		request: event
	});
	if (data.error) {
		if (data.error === "PAGE_NOT_FOUND" || data.error === "NOT_EXISTS" || data.error === "BAD_REQUEST") throw error(404, data.error);
		throw error(500, data.error);
	}
	data.pageType = pageType;
	data.categoryUrl = categoryUrl;
	panoApiServer.ui.tickets.content.edit((items) => {
		items.push({
			id: "tickets-card",
			priority: 100,
			hidden: false
		});
	});
	await executeLifecycle("theme:tickets:load", {}, event);
	await executeViewLoad("tickets-content", event);
	await load$1(event);
	data.pageTitle = {
		title: categoryUrl ? "pages.category-tickets.title" : "pages.tickets.title",
		titleValues: categoryUrl ? { categoryName: `"${data.category.title}"` } : null
	};
	return {
		...data,
		sidebar: ProfileSidebar
	};
}
async function refreshData(data) {
	await goto(buildQueryParams({
		page: data.page,
		pageType: data.pageType,
		category: data.categoryUrl
	}), { });
}
async function onPageClick(data, page) {
	data.page = page;
	await refreshData(data);
}
var onCloseTicketClick = (tickets, updatedTicket) => {
	tickets.update((tickets) => {
		tickets.forEach((ticket) => {
			if (ticket.id === updatedTicket.id) ticket.selected = true;
		});
		return tickets;
	});
	show();
};
function init(data) {
	const tickets = writable(data.tickets);
	return { tickets };
}
//#endregion
//#region node_modules/@panomc/theme-core/src/lib/pages/profile/TicketsPage.svelte
async function load(event) {
	const viewPromise = resolveView("TicketsView", () => import('./TicketsView.js-DGVHofeM.js'));
	return {
		...await processLoad(event),
		View: await viewPromise
	};
}
function TicketsPage($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		let data = $$props["data"];
		let tickets;
		const contentItems = panoApiClient.ui.tickets.content.get();
		tickets = init(data).tickets;
		if (data.View) {
			$$renderer.push("<!--[-->");
			data.View($$renderer, {
				data,
				contentItems,
				tickets,
				PageTypes,
				onCloseTicketClick,
				onPageClick
			});
			$$renderer.push("<!--]-->");
		} else {
			$$renderer.push("<!--[!-->");
			$$renderer.push("<!--]-->");
		}
		bind_props($$props, { data });
	});
}

export { TicketsPage as T, load as l };
//# sourceMappingURL=TicketsPage.js-DCACDGdK.js.map
