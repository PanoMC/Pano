import { $ as ensure_array_like, a0 as store_get, a2 as unsubscribe_stores, W as bind_props, a5 as escape_html, Z as attr_class, X as attr, Y as stringify, a3 as html } from './server.js-D28cBEJ-.js';
import 'node:module';
import { $ as $format } from './runtime.js-CJgfVvxa.js';
import './tooltip.util.js-Bd9x5X7L.js';
import { D as Date_1 } from './Date.js-ZK3lGml2.js';
import { P as Pagination } from './Pagination.js-CeyG1SGU.js';
import { N as NoContent } from './NoContent.js-BBe0Mapz.js';
import { C as CardHeader } from './CardHeader.js-DpkWpoy6.js';
import { V as ViewComponent } from './ViewComponent.js-C6amYVVM.js';
import { T as TicketStatuses, a as TicketStatus } from './TicketStatus.js-GhIwl1A5.js';
import './uneval.js-BL1Qg77w.js';
import './rolldown-runtime.js-B5FuG9Gw.js';
import './stores.js-QbD2A2ib.js';
import './client.js-CPEkJ2-P.js';
import './shared.js-3i5_hmQ1.js';
import './exports.js-CKkpMUqI.js';
import './internal2.js-KmQU-gaY.js';
import './index-server2.js-DlblWyyK.js';
import './language.util.js-C2xYQq5-.js';
import './internal.js-BlXt2rfE.js';
import './Store.js-C2vdyE6V.js';
import './exports2.js-DxZfja4I.js';
import './ToastContainer.js-CtmBBvhr.js';
import './locale.js-DnnPB87K.js';
import './format.js-CzDFIcjs.js';

//#region node_modules/@panomc/theme-core/src/lib/components/TicketRow.svelte
function TicketRow($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let ticket = $$props["ticket"];
		$$renderer.push(`<tr${attr_class("", void 0, { "table-active": ticket.selected })}><th scope="row" class="text-center align-middle">`);
		if (ticket.status !== TicketStatuses.CLOSED) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<button type="button"${attr("title", store_get($$store_subs ??= {}, "$_", $format)("buttons.close-ticket"))}${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("buttons.close-ticket"))} class="btn btn-link"><i class="fas fa-check"></i></button>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--></th><td class="align-middle" style="max-width: 300px;"><div class="text-truncate"><a class="rounded focus-ring text-decoration-none d-block text-truncate"${attr("href", `/ticket/${stringify(ticket.id)}`)}${attr("title", `#${stringify(ticket.id)} ${stringify(ticket.title)}`)}>#${escape_html(ticket.id)} ${escape_html(ticket.title)}</a></div></td><td class="align-middle">`);
		TicketStatus($$renderer, { status: ticket.status });
		$$renderer.push(`<!----></td><td class="align-middle text-nowrap"><a${attr_class(`badge rounded-pill ${stringify(ticket.category.title === "-" ? "text-bg-primary" : "text-bg-secondary")} text-decoration-none focus-ring`)}${attr("href", `/tickets?category=${stringify(ticket.category.url)}`)}>${escape_html(ticket.category.title === "-" ? store_get($$store_subs ??= {}, "$_", $format)("components.ticket-row.no-category") : ticket.category.title)}</a></td><td class="align-middle text-nowrap"><span>`);
		Date_1($$renderer, { time: ticket.lastUpdate });
		$$renderer.push(`<!----></span></td></tr>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
		bind_props($$props, { ticket });
	});
}
//#endregion
//#region node_modules/@panomc/theme-core/src/lib/components/Tickets.svelte
function Tickets($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let tickets = $$props["tickets"];
		if (tickets.length > 0) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<div class="table-responsive"><table class="table table-hover"><thead><tr><th class="align-middle" scope="col"></th><th class="align-middle" scope="col">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.tickets.table.title"))}</th><th class="align-middle" scope="col">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.tickets.table.status"))}</th><th class="align-middle" scope="col">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.tickets.table.category"))}</th><th class="align-middle" scope="col">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.tickets.table.last-reply"))}</th></tr></thead><tbody><!--[-->`);
			const each_array = ensure_array_like(tickets);
			for (let index = 0, $$length = each_array.length; index < $$length; index++) {
				let ticket = each_array[index];
				TicketRow($$renderer, { ticket });
			}
			$$renderer.push(`<!--]--></tbody></table></div>`);
		} else {
			$$renderer.push("<!--[-1-->");
			NoContent($$renderer, {});
		}
		$$renderer.push(`<!--]-->`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
		bind_props($$props, { tickets });
	});
}
//#endregion
//#region node_modules/@panomc/theme-core/src/lib/views/TicketsView.svelte
function TicketsView($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let data = $$props["data"];
		let contentItems = $$props["contentItems"];
		let tickets = $$props["tickets"];
		let PageTypes = $$props["PageTypes"];
		let onCloseTicketClick = $$props["onCloseTicketClick"];
		let onPageClick = $$props["onPageClick"];
		$$renderer.push(`<div class="vstack gap-3"><!--[-->`);
		const each_array = ensure_array_like(store_get($$store_subs ??= {}, "$contentItems", contentItems));
		for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
			let item = each_array[$$index];
			if (item.id === "tickets-card") {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<div class="card mt-3 mt-lg-0">`);
				CardHeader($$renderer, { $$slots: {
					left: ($$renderer) => {
						$$renderer.push(`<div slot="left">${html(data.categoryUrl ? store_get($$store_subs ??= {}, "$_", $format)("pages.category-tickets.title", { values: { categoryName: `<strong>"${data.category.title === "-" ? store_get($$store_subs ??= {}, "$_", $format)("pages.category-tickets.no-category") : data.category.title}"</strong>` } }) : store_get($$store_subs ??= {}, "$_", $format)("pages.tickets.title"))}</div>`);
					},
					right: ($$renderer) => {
						$$renderer.push(`<div slot="right" class="btn-group"><a${attr_class("btn btn-outline-primary btn-sm", void 0, { "active": data.pageType === PageTypes.ALL })} role="button" href="/tickets">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.tickets.all"))}</a> <a${attr_class("btn btn-outline-primary btn-sm", void 0, { "active": data.pageType === PageTypes.CLOSED })} role="button" href="/tickets?pageType=CLOSED">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.tickets.closed"))}</a></div>`);
					}
				} });
				$$renderer.push(`<!----> `);
				Tickets($$renderer, { tickets: store_get($$store_subs ??= {}, "$tickets", tickets) });
				$$renderer.push(`<!----> `);
				if (data.ticketCount > 0) {
					$$renderer.push("<!--[0-->");
					$$renderer.push(`<div class="card-footer">`);
					Pagination($$renderer, {
						page: data.page,
						totalPage: data.totalPage});
					$$renderer.push(`<!----></div>`);
				} else $$renderer.push("<!--[-1-->");
				$$renderer.push(`<!--]--></div>`);
			} else if (item.component) {
				$$renderer.push("<!--[1-->");
				ViewComponent($$renderer, {
					component: item.component,
					data
				});
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]-->`);
		}
		$$renderer.push(`<!--]--></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
		bind_props($$props, {
			data,
			contentItems,
			tickets,
			PageTypes,
			onCloseTicketClick,
			onPageClick
		});
	});
}

export { TicketsView as default };
//# sourceMappingURL=TicketsView.js-DGVHofeM.js.map
