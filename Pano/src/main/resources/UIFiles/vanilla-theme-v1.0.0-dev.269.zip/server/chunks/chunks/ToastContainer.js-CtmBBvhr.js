import { _ as __exportAll } from './rolldown-runtime.js-B5FuG9Gw.js';
import { V as fallback, W as bind_props, T as writable, X as attr, Y as stringify, Z as attr_class, _ as slot, $ as ensure_array_like, a0 as store_get, a1 as spread_props, a2 as unsubscribe_stores, a3 as html } from './server.js-D28cBEJ-.js';
import { t as tick } from './index-server2.js-DlblWyyK.js';
import { $ as $format } from './runtime.js-CJgfVvxa.js';

//#region node_modules/@panomc/theme-core/src/lib/components/Toast.svelte
function Toast($$renderer, $$props) {
	let variantClass;
	let id = $$props["id"];
	let variant = fallback($$props["variant"], null);
	const VARIANT_CLASSES = {
		success: "text-success",
		danger: "text-danger"
	};
	variantClass = VARIANT_CLASSES[variant] ?? "";
	$$renderer.push(`<div${attr("id", `appToast${stringify(id)}`)}${attr_class(`animate__animated animate__bounceInUp toast align-items-center shadow-lg text-bg-tertiary opacity-100 ${stringify(variantClass)}`)} role="alert" aria-live="assertive" aria-atomic="true" data-bs-dismiss="toast"><div class="toast-body"><!--[-->`);
	slot($$renderer, $$props, "default", {}, null);
	$$renderer.push(`<!--]--></div></div>`);
	bind_props($$props, {
		id,
		variant
	});
}
//#endregion
//#region node_modules/@panomc/theme-core/src/lib/components/DefaultToast.svelte
function DefaultToast($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let id = $$props["id"];
		let text = $$props["text"];
		let values = $$props["values"];
		let variant = fallback($$props["variant"], null);
		Toast($$renderer, {
			id,
			variant,
			children: ($$renderer) => {
				$$renderer.push(`${html(store_get($$store_subs ??= {}, "$_", $format)(text, { values }))}`);
			},
			$$slots: { default: true }
		});
		if ($$store_subs) unsubscribe_stores($$store_subs);
		bind_props($$props, {
			id,
			text,
			values,
			variant
		});
	});
}
//#endregion
//#region node_modules/@panomc/theme-core/src/lib/components/ToastContainer.svelte
var ToastContainer_exports = /* @__PURE__ */ __exportAll({
	default: () => ToastContainer,
	limitTitle: () => limitTitle,
	show: () => show,
	showError: () => showError,
	showSuccess: () => showSuccess
});
var toasts = writable([]);
var id = 0;
Array.prototype.insert = function(index, item) {
	this.splice(index, 0, item);
	return this;
};
Array.prototype.remove = function(index) {
	this.splice(index, 1);
	return this;
};
async function show(text, params = {}, toastComponent = DefaultToast, options = {}) {
	if (text) params.text = text;
	if (toastComponent === DefaultToast) params = {
		text,
		values: params,
		variant: options.variant ?? null
	};
	const toast = {
		component: toastComponent,
		params
	};
	id = id + 1;
	toast.id = id;
	toasts.update((toasts) => {
		toasts.push(toast);
		return toasts;
	});
	await tick();
	const toastElement = document.getElementById("appToast" + id);
	if (toastElement) {
		new window.bootstrap.Toast(toastElement).show();
		toastElement.addEventListener("hidden.bs.toast", () => {
			toasts.update((toasts) => {
				const foundToast = toasts.find((toast) => toast.id === id);
				toasts.remove(toasts.indexOf(foundToast));
				return toasts;
			});
		});
	}
}
function showSuccess(text, params = {}) {
	return show(text, params, DefaultToast, { variant: "success" });
}
function showError(text, params = {}) {
	return show(text, params, DefaultToast, { variant: "danger" });
}
function limitTitle(text) {
	const limit = 32;
	if (text.length > limit) text = text.substring(0, limit) + "...";
	return text;
}
function ToastContainer($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		$$renderer.push(`<div class="toast-container position-fixed bottom-0 start-50 translate-middle-x mb-3"><!--[-->`);
		const each_array = ensure_array_like(store_get($$store_subs ??= {}, "$toasts", toasts));
		for (let index = 0, $$length = each_array.length; index < $$length; index++) {
			let toast = each_array[index];
			if (toast.component) {
				$$renderer.push("<!--[-->");
				toast.component($$renderer, spread_props([{ id: toast.id }, toast.params]));
				$$renderer.push("<!--]-->");
			} else {
				$$renderer.push("<!--[!-->");
				$$renderer.push("<!--]-->");
			}
		}
		$$renderer.push(`<!--]--></div>`);
		if ($$store_subs) unsubscribe_stores($$store_subs);
	});
}

export { ToastContainer_exports as T, show as a, ToastContainer as b, showSuccess as s };
//# sourceMappingURL=ToastContainer.js-CtmBBvhr.js.map
