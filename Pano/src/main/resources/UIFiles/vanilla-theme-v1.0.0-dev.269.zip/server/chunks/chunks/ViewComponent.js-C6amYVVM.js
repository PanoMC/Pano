import { a1 as spread_props } from './server.js-D28cBEJ-.js';

//#region node_modules/@panomc/theme-core/src/lib/components/ViewComponent.svelte
function ViewComponent($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		let { component, $$slots, $$events, ...rest } = $$props;
		if (component && typeof component !== "function") {
			$$renderer.push("<!--[0-->");
			const Component = component.default || component;
			if (Component) {
				$$renderer.push("<!--[-->");
				Component($$renderer, spread_props([rest]));
				$$renderer.push("<!--]-->");
			} else {
				$$renderer.push("<!--[!-->");
				$$renderer.push("<!--]-->");
			}
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]-->`);
	});
}

export { ViewComponent as V };
//# sourceMappingURL=ViewComponent.js-C6amYVVM.js.map
