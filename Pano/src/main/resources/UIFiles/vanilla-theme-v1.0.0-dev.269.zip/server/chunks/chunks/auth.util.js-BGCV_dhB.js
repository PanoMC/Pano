import { a4 as get } from './server.js-D28cBEJ-.js';
import { p as page } from './stores.js-QbD2A2ib.js';

//#region node_modules/@panomc/theme-core/src/lib/auth.util.js
var Permissions = Object.freeze({
	ACCESS_PANEL: "ACCESS_PANEL",
	MANAGE_SERVERS: "MANAGE_SERVERS",
	MANAGE_POSTS: "MANAGE_POSTS",
	MANAGE_TICKETS: "MANAGE_TICKETS",
	MANAGE_PLAYERS: "MANAGE_PLAYERS",
	MANAGE_VIEW: "MANAGE_VIEW",
	MANAGE_ADDONS: "MANAGE_ADDONS",
	MANAGE_PLATFORM_SETTINGS: "MANAGE_PLATFORM_SETTINGS",
	MANAGE_PERMISSION_GROUPS: "MANAGE_PERMISSION_GROUPS",
	ACCESS_ACTIVITY_LOGS: "ACCESS_ACTIVITY_LOGS",
	MANAGE_TRANSLATIONS: "MANAGE_TRANSLATIONS"
});
function hasPermission(permission, user) {
	if (!permission) return true;
	if (!user) {
		let pageUser;
		pageUser = get(page).data?.user;
		if (!pageUser) pageUser = get(page).data?.session?.user;
		user = pageUser;
	}
	const userObject = user;
	if (!userObject) return false;
	if (userObject.admin) return true;
	if (!userObject.permissions) return false;
	const toPermNode = (p) => {
		const raw = String(p || "").trim();
		if (!raw) return "";
		return raw.toLowerCase().replaceAll("_", ".");
	};
	const wantedNode = toPermNode(permission);
	const wantedKey = String(permission || "").trim().toUpperCase();
	const perms = Array.isArray(userObject.permissions) ? userObject.permissions : [];
	const permsLower = perms.map((x) => String(x || "").toLowerCase());
	return wantedNode && permsLower.includes(wantedNode) || wantedKey && perms.includes(wantedKey);
}

export { Permissions as P, hasPermission as h };
//# sourceMappingURL=auth.util.js-BGCV_dhB.js.map
