import { _ as __exportAll } from './rolldown-runtime.js-B5FuG9Gw.js';
import { b as base } from './internal.js-BlXt2rfE.js';
import { T as writable, a4 as get } from './server.js-D28cBEJ-.js';
import './client.js-CPEkJ2-P.js';
import { r as registerLocaleLoader, w as waitLocale, i as init$1, a as $locale } from './runtime.js-CJgfVvxa.js';
import { d as ApiUtil } from './Store.js-C2vdyE6V.js';

//#region node_modules/@panomc/theme-core/src/lib/language.util.js
var language_util_exports = /* @__PURE__ */ __exportAll({
	Languages: () => Languages,
	changeLanguage: () => changeLanguage,
	currentLanguage: () => currentLanguage,
	getAcceptedLanguage: () => getAcceptedLanguage,
	getLanguageByLocale: () => getLanguageByLocale,
	init: () => init,
	languageLoading: () => languageLoading,
	loadLanguage: () => loadLanguage
});
var languageLoading = writable(false);
var currentLanguage = writable(null);
var Languages = writable({});
async function fetchLanguages(event) {
	const locales = (await ApiUtil.get({
		path: `/api/locales`,
		request: event
	})).data;
	Languages.set(Object.fromEntries(locales.map((item) => [item.code, item])));
}
async function init(initialLocale, event) {
	await fetchLanguages(event);
	const languageToLoad = getLanguageByLocale(initialLocale) || get(Languages)["en-US"];
	const enUS = get(Languages)["en-US"];
	if (languageToLoad.code === enUS.code) await loadLanguage(enUS, event);
	else await Promise.all([loadLanguage(enUS, event), loadLanguage(languageToLoad, event)]);
	currentLanguage.set(languageToLoad);
	await waitLocale();
	init$1({
		fallbackLocale: "en-US",
		initialLocale: languageToLoad.code
	});
}
function getAcceptedLanguage(headers) {
	if (typeof headers.get("accept-language") === "undefined" || headers.get("accept-language") == null) return "";
	return headers.get("accept-language").split(",")[0];
}
async function loadLanguage(language, event) {
	const useFetch = event ? event.fetch : fetch;
	const [localTranslationsResponse, translationsResponse] = await Promise.all([useFetch(base + `/theme-api/languages/${language.code}.json`), ApiUtil.get({
		path: `/api/locales/${language.code}/translations/types/THEME`,
		request: event
	})]);
	const languageFile = await localTranslationsResponse.json();
	const customTranslations = translationsResponse.result !== "ok" ? {} : translationsResponse.data;
	const translations = unflattenObject({
		...flattenObject(languageFile),
		...flattenObject(customTranslations)
	});
	registerLocaleLoader(language.code, async () => translations);
	await waitLocale(language.code);
	if (language.derivatives) for (const derivative of language.derivatives) {
		registerLocaleLoader(derivative, async () => translations);
		await waitLocale(language.code);
	}
}
async function changeLanguage(language) {
	if (get(currentLanguage) === language) return;
	languageLoading.set(true);
	await loadLanguage(language);
	$locale.set(language.code);
	currentLanguage.set(language);
	languageLoading.set(false);
}
function getLanguageByLocale(locale) {
	let foundLanguage = null;
	const languages = get(Languages);
	Object.keys(languages).forEach((key) => {
		const language = languages[key];
		if (language.code === locale) foundLanguage = language;
	});
	return foundLanguage;
}
function flattenObject(obj, prefix = "", result = {}) {
	for (const key in obj) {
		const value = obj[key];
		const newKey = prefix ? `${prefix}.${key}` : key;
		if (typeof value === "object" && value !== null && !Array.isArray(value)) flattenObject(value, newKey, result);
		else result[newKey] = value;
	}
	return result;
}
function unflattenObject(flatObj) {
	const result = {};
	for (const flatKey in flatObj) {
		const keys = flatKey.split(".");
		keys.reduce((acc, key, idx) => {
			if (idx === keys.length - 1) acc[key] = flatObj[flatKey];
			else acc[key] = acc[key] || {};
			return acc[key];
		}, result);
	}
	return result;
}

export { Languages as L, changeLanguage as a, currentLanguage as c, getLanguageByLocale as g, init as i, language_util_exports as l };
//# sourceMappingURL=language.util.js-C2xYQq5-.js.map
