//#region node_modules/@panomc/theme-core/src/lib/loginInput.util.js
/** Strips all Unicode whitespace from login/registration identifier fields. */
function stripIdentifierWhitespace(value) {
	return typeof value === "string" ? value.replace(/\s/g, "") : "";
}

export { stripIdentifierWhitespace as s };
//# sourceMappingURL=loginInput.util.js-BxkO11lZ.js.map
