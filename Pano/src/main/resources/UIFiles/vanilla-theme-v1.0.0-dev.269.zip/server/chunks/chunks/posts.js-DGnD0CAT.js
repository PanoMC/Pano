import { e as buildQueryParams, d as ApiUtil } from './Store.js-C2vdyE6V.js';

var getPosts = async ({ page, categoryUrl, request, csrfToken }) => {
	const queryParams = buildQueryParams({
		page,
		categoryUrl
	});
	return ApiUtil.get({
		path: `/api/posts${queryParams}`,
		request,
		csrfToken
	}).then((body) => {
		body.page = parseInt(page);
		return body;
	});
};
var getPostDetail = async ({ url, request, csrfToken }) => {
	return ApiUtil.get({
		path: `/api/posts/${url}`,
		request,
		csrfToken
	}).then((body) => {
		body.url = url;
		return body;
	});
};
var getPostPreview = async ({ id, request, csrfToken }) => {
	return ApiUtil.get({
		path: `/api/panel/posts/${id}/preview`,
		request,
		csrfToken
	}).then((body) => {
		body.id = parseInt(id);
		return body;
	});
};

export { getPostDetail as a, getPostPreview as b, getPosts as g };
//# sourceMappingURL=posts.js-DGnD0CAT.js.map
