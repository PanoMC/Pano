import { d as ApiUtil } from './Store.js-C2vdyE6V.js';

//#region node_modules/@panomc/theme-core/src/lib/services/profile.js
var getProfile = async ({ request }) => {
	return ApiUtil.get({
		path: `/api/profile`,
		request
	});
};
var getPlayerProfile = async ({ request, username }) => {
	return ApiUtil.get({
		path: `/api/profiles/${username}`,
		request
	});
};
var sendResetPassword = async () => {
	return ApiUtil.post({ path: "/api/profile/resetPassword" });
};
var sendChangeEmail = async (currentPassword, newEmail) => {
	return ApiUtil.post({
		path: "/api/profile/changeEmail",
		body: {
			currentPassword,
			newEmail
		}
	});
};
var sendUpdateProfile = async (body) => {
	return ApiUtil.put({
		path: "/api/profile",
		body
	});
};

export { getProfile as a, sendResetPassword as b, sendUpdateProfile as c, getPlayerProfile as g, sendChangeEmail as s };
//# sourceMappingURL=profile.js-C7iU3TQf.js.map
