//#region node_modules/@panomc/theme-core/src/lib/string.util.js
function truncate(str, n) {
	return str.length > n ? str.substr(0, n - 1) : str;
}
function parseUserAgent(userAgent) {
	if (!userAgent || userAgent === "-") return "Unknown";
	const ua = userAgent.toLowerCase();
	let browser = "Unknown Browser";
	if (ua.includes("firefox")) browser = "Firefox";
	else if (ua.includes("edg")) browser = "Edge";
	else if (ua.includes("chrome")) browser = "Chrome";
	else if (ua.includes("safari")) browser = "Safari";
	else if (ua.includes("opera") || ua.includes("opr")) browser = "Opera";
	let os = "Unknown OS";
	if (ua.includes("win")) os = "Windows";
	else if (ua.includes("mac")) os = "macOS";
	else if (ua.includes("linux")) os = "Linux";
	else if (ua.includes("android")) os = "Android";
	else if (ua.includes("iphone") || ua.includes("ipad")) os = "iOS";
	return `${browser} (${os})`;
}

export { parseUserAgent as p, truncate as t };
//# sourceMappingURL=string.util.js-dF34MZ_o.js.map
