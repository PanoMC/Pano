import path from 'path';
import fs from 'fs';

//#region node_modules/@panomc/theme-core/src/routes/theme-api-languages.js
/** @type {import("@sveltejs/kit").RequestHandler} */
async function GET({ params }) {
	const { language } = params;
	const fileName = `${path.basename(String(language ?? ""))}.json`;
	const candidates = [path.resolve("lang"), path.resolve(path.dirname(process.argv[1]) + "/lang")].map((dir) => ({
		dir,
		filePath: path.resolve(dir, fileName)
	}));
	for (const { dir, filePath } of candidates) if (!filePath.startsWith(dir + path.sep)) return new Response(JSON.stringify({ error: "Forbidden" }), {
		status: 403,
		headers: { "Content-Type": "application/json" }
	});
	let filePath = candidates[0].filePath;
	if (!fs.existsSync(filePath)) filePath = candidates[1].filePath;
	if (fs.existsSync(filePath)) {
		const fileContent = fs.readFileSync(filePath, "utf-8");
		return new Response(fileContent, { headers: { "Content-Type": "application/json" } });
	} else return new Response(JSON.stringify({ error: "Language file not found" }), {
		status: 404,
		headers: { "Content-Type": "application/json" }
	});
}

export { GET };
//# sourceMappingURL=_server.js-2pX_gEv9.js.map
