import path from 'path';
import fs from 'fs';

//#region node_modules/@panomc/theme-core/src/routes/theme-api-licenses.js
/** @type {import("@sveltejs/kit").RequestHandler} */
async function GET() {
	let filePath = path.resolve(`licenses.json`);
	if (!fs.existsSync(filePath)) filePath = path.resolve(path.dirname(process.argv[1]) + `/licenses.json`);
	if (fs.existsSync(filePath)) {
		const fileContent = fs.readFileSync(filePath, "utf-8");
		return new Response(fileContent, { headers: { "Content-Type": "application/json" } });
	} else return new Response(JSON.stringify({}), { headers: { "Content-Type": "application/json" } });
}

export { GET };
//# sourceMappingURL=_server.js-DqVBnEmT.js.map
