import { l as load$1 } from '../../../../chunks/Layout.js-BQtxiVwm.js';

//#region node_modules/@panomc/theme-core/src/routes/plugin-ui/layout.js
/**
* @type {import('@sveltejs/kit').PageLoad}
*/
async function load(event) {
	return load$1(event);
}

var _layout = /*#__PURE__*/Object.freeze({
	__proto__: null,
	load: load
});

export { _layout as _ };
//# sourceMappingURL=_layout.js-Cvl7CaX4.js.map
