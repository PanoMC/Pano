import { W as bind_props, _ as slot } from '../../../../chunks/server.js-D28cBEJ-.js';
import { L as Layout } from '../../../../chunks/Layout.js-BQtxiVwm.js';
import '../../../../chunks/uneval.js-BL1Qg77w.js';
import '../../../../chunks/exports2.js-DxZfja4I.js';
import '../../../../chunks/shared.js-3i5_hmQ1.js';
import '../../../../chunks/internal.js-BlXt2rfE.js';
import 'node:module';
import '../../../../chunks/client.js-CPEkJ2-P.js';
import '../../../../chunks/exports.js-CKkpMUqI.js';
import '../../../../chunks/internal2.js-KmQU-gaY.js';
import '../../../../chunks/index-server2.js-DlblWyyK.js';
import '../../../../chunks/rolldown-runtime.js-B5FuG9Gw.js';
import '../../../../chunks/PluginManager.js-B5x3OKEW.js';
import '../../../../chunks/Store.js-C2vdyE6V.js';
import '../../../../chunks/ToastContainer.js-CtmBBvhr.js';
import '../../../../chunks/runtime.js-CJgfVvxa.js';
import 'fs';
import '../../../../chunks/AppLayout.js-DAJIOVN_.js';
import '../../../../chunks/stores.js-QbD2A2ib.js';
import '../../../../chunks/registry2.js-BubD3cPq.js';
import '../../../../chunks/copy-to-clipboard.js-CF5RgzCy.js';
import '../../../../chunks/language.util.js-C2xYQq5-.js';
import '../../../../chunks/tooltip.util.js-Bd9x5X7L.js';
import '../../../../chunks/auth.util.js-BGCV_dhB.js';
import '../../../../chunks/Date.js-ZK3lGml2.js';
import '../../../../chunks/locale.js-DnnPB87K.js';
import '../../../../chunks/format.js-CzDFIcjs.js';
import '../../../../chunks/Pagination.js-CeyG1SGU.js';
import '../../../../chunks/NoContent.js-BBe0Mapz.js';
import '../../../../chunks/PageActions.js-CkhIQPLY.js';
import '../../../../chunks/PageTitle.js-D99NSXzQ.js';
import '../../../../chunks/PlayerHead.js-Bggv1de7.js';
import '../../../../chunks/MainLayout.js-D6bbLTwz.js';
import '../../../../chunks/AuthLayout.js-CZsvwKoS.js';
import '../../../../chunks/ProfileLayout.js-B2Aj3-w1.js';
import '../../../../chunks/ThemeSettingsLayout.js-C5M-p3G5.js';
import '../../../../chunks/ThemeSettingsLayoutLogics.js-BeKxPzDr.js';
import '../../../../chunks/TicketsLayout.js-OiCrCQml.js';

//#region src/routes/(plugin-ui)/[...path]/+layout.svelte
function _layout($$renderer, $$props) {
	let data = $$props["data"];
	Layout($$renderer, {
		data,
		children: ($$renderer) => {
			$$renderer.push(`<!--[-->`);
			slot($$renderer, $$props, "default", {}, null);
			$$renderer.push(`<!--]-->`);
		},
		$$slots: { default: true }
	});
	bind_props($$props, { data });
}

export { _layout as default };
//# sourceMappingURL=_layout.svelte.js-DUDm2JTg.js.map
