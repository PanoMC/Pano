import { l as load$1 } from '../../../../chunks/Page.js-CHxlFwZT.js';

//#region node_modules/@panomc/theme-core/src/routes/plugin-ui/page.js
/**
* @type {import('@sveltejs/kit').PageLoad}
*/
async function load(event) {
	return load$1(event);
}

var _page = /*#__PURE__*/Object.freeze({
	__proto__: null,
	load: load
});

export { _page as _ };
//# sourceMappingURL=_page.js-6WRYh3vQ.js.map
