import { W as bind_props } from '../../../../chunks/server.js-D28cBEJ-.js';
import { P as Page } from '../../../../chunks/Page.js-CHxlFwZT.js';
import '../../../../chunks/uneval.js-BL1Qg77w.js';
import 'node:module';

//#region src/routes/(plugin-ui)/[...path]/+page.svelte
function _page($$renderer, $$props) {
	let data = $$props["data"];
	Page($$renderer, { data });
	bind_props($$props, { data });
}

export { _page as default };
//# sourceMappingURL=_page.svelte.js-DOWbyG_p.js.map
