var _layout = /*#__PURE__*/Object.freeze({
	__proto__: null
});

export { _layout as _ };
//# sourceMappingURL=_layout.js-CrKBASyK.js.map
