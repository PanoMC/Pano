import { _ as slot } from '../../../chunks/server.js-D28cBEJ-.js';
import '../../../chunks/uneval.js-BL1Qg77w.js';

//#region src/routes/(theme)/+layout.svelte
function _layout($$renderer, $$props) {
	$$renderer.push(`<!--[-->`);
	slot($$renderer, $$props, "default", {}, null);
	$$renderer.push(`<!--]-->`);
}

export { _layout as default };
//# sourceMappingURL=_layout.svelte.js-C21mq6sJ.js.map
