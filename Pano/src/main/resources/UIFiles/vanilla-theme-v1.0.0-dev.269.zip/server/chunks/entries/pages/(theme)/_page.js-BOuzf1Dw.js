import { l as load } from '../../../chunks/HomePage.js-Ci1nMBCG.js';

var _page = /*#__PURE__*/Object.freeze({
	__proto__: null,
	load: load
});

export { _page as _ };
//# sourceMappingURL=_page.js-BOuzf1Dw.js.map
