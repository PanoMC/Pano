import { l as load } from '../../../../chunks/ConfirmNewEmailPage.js-D4tM_mhp.js';

var _page = /*#__PURE__*/Object.freeze({
	__proto__: null,
	load: load
});

export { _page as _ };
//# sourceMappingURL=_page.js-Cdi0TYkN.js.map
