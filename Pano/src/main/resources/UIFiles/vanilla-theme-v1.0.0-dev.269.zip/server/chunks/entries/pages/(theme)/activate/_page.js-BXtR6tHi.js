import { l as load } from '../../../../chunks/ActivateEmailPage.js-D18yq8-i.js';

var _page = /*#__PURE__*/Object.freeze({
	__proto__: null,
	load: load
});

export { _page as _ };
//# sourceMappingURL=_page.js-BXtR6tHi.js.map
