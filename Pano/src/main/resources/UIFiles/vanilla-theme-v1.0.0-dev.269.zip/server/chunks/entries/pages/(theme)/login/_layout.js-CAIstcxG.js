import { l as load } from '../../../../chunks/AuthLayout.js-CZsvwKoS.js';

var _layout = /*#__PURE__*/Object.freeze({
	__proto__: null,
	load: load
});

export { _layout as _ };
//# sourceMappingURL=_layout.js-CAIstcxG.js.map
