import { W as bind_props } from '../../../../chunks/server.js-D28cBEJ-.js';
import { L as LoginPage } from '../../../../chunks/LoginPage.js-DKd722RN.js';
import '../../../../chunks/uneval.js-BL1Qg77w.js';
import 'node:module';
import '../../../../chunks/client.js-CPEkJ2-P.js';
import '../../../../chunks/shared.js-3i5_hmQ1.js';
import '../../../../chunks/exports.js-CKkpMUqI.js';
import '../../../../chunks/internal2.js-KmQU-gaY.js';
import '../../../../chunks/index-server2.js-DlblWyyK.js';
import '../../../../chunks/rolldown-runtime.js-B5FuG9Gw.js';
import '../../../../chunks/PluginManager.js-B5x3OKEW.js';
import '../../../../chunks/exports2.js-DxZfja4I.js';
import '../../../../chunks/internal.js-BlXt2rfE.js';
import '../../../../chunks/Store.js-C2vdyE6V.js';
import '../../../../chunks/ToastContainer.js-CtmBBvhr.js';
import '../../../../chunks/runtime.js-CJgfVvxa.js';
import 'fs';
import '../../../../chunks/registry2.js-BubD3cPq.js';
import '../../../../chunks/language.util.js-C2xYQq5-.js';
import '../../../../chunks/locale.js-DnnPB87K.js';
import '../../../../chunks/format.js-CzDFIcjs.js';
import '../../../../chunks/loginInput.util.js-BxkO11lZ.js';

//#region src/routes/(theme)/login/+page.svelte
function _page($$renderer, $$props) {
	let data = $$props["data"];
	LoginPage($$renderer, { data });
	bind_props($$props, { data });
}

export { _page as default };
//# sourceMappingURL=_page.svelte.js-BC0qwZ45.js.map
