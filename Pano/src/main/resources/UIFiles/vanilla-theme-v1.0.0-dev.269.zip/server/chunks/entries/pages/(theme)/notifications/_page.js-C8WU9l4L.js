import { l as load } from '../../../../chunks/NotificationsPage.js-BxLUec4T.js';

var _page = /*#__PURE__*/Object.freeze({
	__proto__: null,
	load: load
});

export { _page as _ };
//# sourceMappingURL=_page.js-C8WU9l4L.js.map
