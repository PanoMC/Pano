import { W as bind_props } from '../../../../chunks/server.js-D28cBEJ-.js';
import { N as NotificationsPage } from '../../../../chunks/NotificationsPage.js-BxLUec4T.js';
import '../../../../chunks/uneval.js-BL1Qg77w.js';
import '../../../../chunks/index-server2.js-DlblWyyK.js';
import '../../../../chunks/rolldown-runtime.js-B5FuG9Gw.js';
import 'node:module';
import '../../../../chunks/registry2.js-BubD3cPq.js';
import '../../../../chunks/Store.js-C2vdyE6V.js';
import '../../../../chunks/exports2.js-DxZfja4I.js';
import '../../../../chunks/shared.js-3i5_hmQ1.js';
import '../../../../chunks/client.js-CPEkJ2-P.js';
import '../../../../chunks/exports.js-CKkpMUqI.js';
import '../../../../chunks/internal2.js-KmQU-gaY.js';
import '../../../../chunks/ToastContainer.js-CtmBBvhr.js';
import '../../../../chunks/runtime.js-CJgfVvxa.js';
import '../../../../chunks/language.util.js-C2xYQq5-.js';
import '../../../../chunks/internal.js-BlXt2rfE.js';
import '../../../../chunks/NotificationManager.js-5CX8pNRh.js';
import '../../../../chunks/locale.js-DnnPB87K.js';
import '../../../../chunks/siteRealtime.js-DF-ZW4fv.js';
import '../../../../chunks/ProfileSidebar.js-BIu8zSKN.js';
import '../../../../chunks/PluginManager.js-B5x3OKEW.js';
import 'fs';
import '../../../../chunks/tooltip.util.js-Bd9x5X7L.js';
import '../../../../chunks/stores.js-QbD2A2ib.js';
import '../../../../chunks/PageTitle.js-D99NSXzQ.js';
import '../../../../chunks/PlayerHead.js-Bggv1de7.js';
import '../../../../chunks/Sidebar.js-BwVxP8m2.js';
import '../../../../chunks/ViewComponent.js-C6amYVVM.js';
import '../../../../chunks/PlayerStatusBadge.js-DO05KLuW.js';

//#region src/routes/(theme)/notifications/+page.svelte
function _page($$renderer, $$props) {
	let data = $$props["data"];
	NotificationsPage($$renderer, { data });
	bind_props($$props, { data });
}

export { _page as default };
//# sourceMappingURL=_page.svelte.js-R3Btpxj4.js.map
