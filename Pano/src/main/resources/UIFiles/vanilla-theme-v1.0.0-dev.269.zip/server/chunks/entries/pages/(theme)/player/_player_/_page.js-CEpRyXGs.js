import { l as load } from '../../../../../chunks/PlayerDetailPage.js-rBYWXnsV.js';

var _page = /*#__PURE__*/Object.freeze({
	__proto__: null,
	load: load
});

export { _page as _ };
//# sourceMappingURL=_page.js-CEpRyXGs.js.map
