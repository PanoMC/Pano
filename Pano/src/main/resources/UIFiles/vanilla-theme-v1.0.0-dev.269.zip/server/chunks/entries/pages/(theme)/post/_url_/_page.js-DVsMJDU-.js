import { l as load } from '../../../../../chunks/PostDetailPage.js-GjsUvK1W.js';

var _page = /*#__PURE__*/Object.freeze({
	__proto__: null,
	load: load
});

export { _page as _ };
//# sourceMappingURL=_page.js-DVsMJDU-.js.map
