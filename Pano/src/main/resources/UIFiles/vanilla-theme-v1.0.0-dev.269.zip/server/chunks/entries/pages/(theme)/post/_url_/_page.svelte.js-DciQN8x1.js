import { W as bind_props } from '../../../../../chunks/server.js-D28cBEJ-.js';
import { P as PostDetailPage } from '../../../../../chunks/PostDetailPage.js-GjsUvK1W.js';
import '../../../../../chunks/uneval.js-BL1Qg77w.js';
import '../../../../../chunks/exports2.js-DxZfja4I.js';
import '../../../../../chunks/shared.js-3i5_hmQ1.js';
import 'node:module';
import '../../../../../chunks/PluginManager.js-B5x3OKEW.js';
import '../../../../../chunks/rolldown-runtime.js-B5FuG9Gw.js';
import '../../../../../chunks/internal.js-BlXt2rfE.js';
import '../../../../../chunks/client.js-CPEkJ2-P.js';
import '../../../../../chunks/exports.js-CKkpMUqI.js';
import '../../../../../chunks/internal2.js-KmQU-gaY.js';
import '../../../../../chunks/index-server2.js-DlblWyyK.js';
import '../../../../../chunks/Store.js-C2vdyE6V.js';
import '../../../../../chunks/ToastContainer.js-CtmBBvhr.js';
import '../../../../../chunks/runtime.js-CJgfVvxa.js';
import 'fs';
import '../../../../../chunks/registry2.js-BubD3cPq.js';
import '../../../../../chunks/posts.js-DGnD0CAT.js';

//#region src/routes/(theme)/post/[url]/+page.svelte
function _page($$renderer, $$props) {
	let data = $$props["data"];
	PostDetailPage($$renderer, { data });
	bind_props($$props, { data });
}

export { _page as default };
//# sourceMappingURL=_page.svelte.js-DciQN8x1.js.map
