import { l as load } from '../../../../../../chunks/PreviewPostPage.js-Mmc_lyVP.js';

var _page = /*#__PURE__*/Object.freeze({
	__proto__: null,
	load: load
});

export { _page as _ };
//# sourceMappingURL=_page.js-BuD5dW_5.js.map
