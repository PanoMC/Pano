import { W as bind_props } from '../../../../../../chunks/server.js-D28cBEJ-.js';
import { P as PreviewPostPage } from '../../../../../../chunks/PreviewPostPage.js-Mmc_lyVP.js';
import '../../../../../../chunks/uneval.js-BL1Qg77w.js';
import 'node:module';
import '../../../../../../chunks/registry2.js-BubD3cPq.js';
import '../../../../../../chunks/Store.js-C2vdyE6V.js';
import '../../../../../../chunks/rolldown-runtime.js-B5FuG9Gw.js';
import '../../../../../../chunks/exports2.js-DxZfja4I.js';
import '../../../../../../chunks/shared.js-3i5_hmQ1.js';
import '../../../../../../chunks/client.js-CPEkJ2-P.js';
import '../../../../../../chunks/exports.js-CKkpMUqI.js';
import '../../../../../../chunks/internal2.js-KmQU-gaY.js';
import '../../../../../../chunks/index-server2.js-DlblWyyK.js';
import '../../../../../../chunks/ToastContainer.js-CtmBBvhr.js';
import '../../../../../../chunks/runtime.js-CJgfVvxa.js';
import '../../../../../../chunks/posts.js-DGnD0CAT.js';

//#region src/routes/(theme)/preview/post/[id]/+page.svelte
function _page($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		let data = $$props["data"];
		PreviewPostPage($$renderer, { post: data.post });
		bind_props($$props, { data });
	});
}

export { _page as default };
//# sourceMappingURL=_page.svelte.js-BxVaFZ4_.js.map
