import { l as load } from '../../../../chunks/ProfileLayout.js-B2Aj3-w1.js';

var _layout = /*#__PURE__*/Object.freeze({
	__proto__: null,
	load: load
});

export { _layout as _ };
//# sourceMappingURL=_layout.js-UbnSjAZn.js.map
