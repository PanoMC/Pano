import { l as load } from '../../../../chunks/ProfilePage.js-CahzMWbW.js';

var _page = /*#__PURE__*/Object.freeze({
	__proto__: null,
	load: load
});

export { _page as _ };
//# sourceMappingURL=_page.js-Dp-7sWLV.js.map
