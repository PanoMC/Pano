import { l as load } from '../../../../../chunks/SettingsPage.js-CLOZ6xq-.js';

var _page = /*#__PURE__*/Object.freeze({
	__proto__: null,
	load: load
});

export { _page as _ };
//# sourceMappingURL=_page.js-CimIXlz2.js.map
