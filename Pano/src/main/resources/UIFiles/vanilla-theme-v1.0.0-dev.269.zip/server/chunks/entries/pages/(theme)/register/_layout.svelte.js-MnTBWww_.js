import { _ as slot } from '../../../../chunks/server.js-D28cBEJ-.js';
import { a as AuthLayout } from '../../../../chunks/AuthLayout.js-CZsvwKoS.js';
import '../../../../chunks/uneval.js-BL1Qg77w.js';
import '../../../../chunks/rolldown-runtime.js-B5FuG9Gw.js';
import 'node:module';
import '../../../../chunks/stores.js-QbD2A2ib.js';
import '../../../../chunks/client.js-CPEkJ2-P.js';
import '../../../../chunks/shared.js-3i5_hmQ1.js';
import '../../../../chunks/exports.js-CKkpMUqI.js';
import '../../../../chunks/internal2.js-KmQU-gaY.js';
import '../../../../chunks/index-server2.js-DlblWyyK.js';
import '../../../../chunks/registry2.js-BubD3cPq.js';
import '../../../../chunks/Store.js-C2vdyE6V.js';
import '../../../../chunks/exports2.js-DxZfja4I.js';
import '../../../../chunks/ToastContainer.js-CtmBBvhr.js';
import '../../../../chunks/runtime.js-CJgfVvxa.js';

//#region src/routes/(theme)/register/+layout.svelte
function _layout($$renderer, $$props) {
	AuthLayout($$renderer, {
		children: ($$renderer) => {
			$$renderer.push(`<!--[-->`);
			slot($$renderer, $$props, "default", {}, null);
			$$renderer.push(`<!--]-->`);
		},
		$$slots: { default: true }
	});
}

export { _layout as default };
//# sourceMappingURL=_layout.svelte.js-MnTBWww_.js.map
