import { l as load } from '../../../../chunks/RegisterPage.js-BcNWSfKE.js';

var _page = /*#__PURE__*/Object.freeze({
	__proto__: null,
	load: load
});

export { _page as _ };
//# sourceMappingURL=_page.js-OY4UpFS-.js.map
