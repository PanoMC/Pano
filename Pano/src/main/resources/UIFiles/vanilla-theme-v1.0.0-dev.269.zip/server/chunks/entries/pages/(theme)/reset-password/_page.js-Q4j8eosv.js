import { l as load } from '../../../../chunks/ResetPasswordPage.js-Bb3jgt9S.js';

var _page = /*#__PURE__*/Object.freeze({
	__proto__: null,
	load: load
});

export { _page as _ };
//# sourceMappingURL=_page.js-Q4j8eosv.js.map
