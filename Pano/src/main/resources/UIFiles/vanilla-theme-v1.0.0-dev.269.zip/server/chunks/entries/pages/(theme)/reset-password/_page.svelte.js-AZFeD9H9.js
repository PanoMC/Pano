import { W as bind_props } from '../../../../chunks/server.js-D28cBEJ-.js';
import { R as ResetPasswordPage } from '../../../../chunks/ResetPasswordPage.js-Bb3jgt9S.js';
import '../../../../chunks/uneval.js-BL1Qg77w.js';
import 'node:module';
import '../../../../chunks/stores.js-QbD2A2ib.js';
import '../../../../chunks/client.js-CPEkJ2-P.js';
import '../../../../chunks/shared.js-3i5_hmQ1.js';
import '../../../../chunks/exports.js-CKkpMUqI.js';
import '../../../../chunks/internal2.js-KmQU-gaY.js';
import '../../../../chunks/index-server2.js-DlblWyyK.js';
import '../../../../chunks/rolldown-runtime.js-B5FuG9Gw.js';
import '../../../../chunks/PluginManager.js-B5x3OKEW.js';
import '../../../../chunks/exports2.js-DxZfja4I.js';
import '../../../../chunks/internal.js-BlXt2rfE.js';
import '../../../../chunks/Store.js-C2vdyE6V.js';
import '../../../../chunks/ToastContainer.js-CtmBBvhr.js';
import '../../../../chunks/runtime.js-CJgfVvxa.js';
import 'fs';
import '../../../../chunks/registry2.js-BubD3cPq.js';
import '../../../../chunks/loginInput.util.js-BxkO11lZ.js';

//#region src/routes/(theme)/reset-password/+page.svelte
function _page($$renderer, $$props) {
	let data = $$props["data"];
	ResetPasswordPage($$renderer);
	bind_props($$props, { data });
}

export { _page as default };
//# sourceMappingURL=_page.svelte.js-AZFeD9H9.js.map
