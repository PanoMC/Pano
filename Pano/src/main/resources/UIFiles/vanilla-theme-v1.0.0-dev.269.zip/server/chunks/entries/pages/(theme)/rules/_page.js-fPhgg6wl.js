import { l as load } from '../../../../chunks/RulesPage.js-CQck0YmQ.js';

var _page = /*#__PURE__*/Object.freeze({
	__proto__: null,
	load: load
});

export { _page as _ };
//# sourceMappingURL=_page.js-fPhgg6wl.js.map
