import { W as bind_props } from '../../../../chunks/server.js-D28cBEJ-.js';
import { R as RulesPage } from '../../../../chunks/RulesPage.js-CQck0YmQ.js';
import '../../../../chunks/uneval.js-BL1Qg77w.js';
import '../../../../chunks/exports2.js-DxZfja4I.js';
import '../../../../chunks/shared.js-3i5_hmQ1.js';
import '../../../../chunks/registry2.js-BubD3cPq.js';
import '../../../../chunks/Store.js-C2vdyE6V.js';
import '../../../../chunks/rolldown-runtime.js-B5FuG9Gw.js';
import 'node:module';
import '../../../../chunks/client.js-CPEkJ2-P.js';
import '../../../../chunks/exports.js-CKkpMUqI.js';
import '../../../../chunks/internal2.js-KmQU-gaY.js';
import '../../../../chunks/index-server2.js-DlblWyyK.js';
import '../../../../chunks/ToastContainer.js-CtmBBvhr.js';
import '../../../../chunks/runtime.js-CJgfVvxa.js';

//#region src/routes/(theme)/rules/+page.svelte
function _page($$renderer, $$props) {
	let data = $$props["data"];
	RulesPage($$renderer, { data });
	bind_props($$props, { data });
}

export { _page as default };
//# sourceMappingURL=_page.svelte.js-CPNmvhmq.js.map
