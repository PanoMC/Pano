import { l as load } from '../../../../chunks/SupportPage.js-BFPhyr_T.js';

var _page = /*#__PURE__*/Object.freeze({
	__proto__: null,
	load: load
});

export { _page as _ };
//# sourceMappingURL=_page.js-BTdU5_xp.js.map
