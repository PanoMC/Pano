import { l as load } from '../../../../../chunks/TicketDetailPage.js-ygeLO6tv.js';

var _page = /*#__PURE__*/Object.freeze({
	__proto__: null,
	load: load
});

export { _page as _ };
//# sourceMappingURL=_page.js-CqlDecyv.js.map
