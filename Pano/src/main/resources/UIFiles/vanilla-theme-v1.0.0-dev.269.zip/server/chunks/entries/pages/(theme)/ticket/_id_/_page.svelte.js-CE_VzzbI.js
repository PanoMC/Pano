import { W as bind_props } from '../../../../../chunks/server.js-D28cBEJ-.js';
import { T as TicketDetailPage } from '../../../../../chunks/TicketDetailPage.js-ygeLO6tv.js';
import '../../../../../chunks/uneval.js-BL1Qg77w.js';
import '../../../../../chunks/exports2.js-DxZfja4I.js';
import '../../../../../chunks/shared.js-3i5_hmQ1.js';
import 'node:module';
import '../../../../../chunks/registry2.js-BubD3cPq.js';
import '../../../../../chunks/Store.js-C2vdyE6V.js';
import '../../../../../chunks/rolldown-runtime.js-B5FuG9Gw.js';
import '../../../../../chunks/client.js-CPEkJ2-P.js';
import '../../../../../chunks/exports.js-CKkpMUqI.js';
import '../../../../../chunks/internal2.js-KmQU-gaY.js';
import '../../../../../chunks/index-server2.js-DlblWyyK.js';
import '../../../../../chunks/ToastContainer.js-CtmBBvhr.js';
import '../../../../../chunks/runtime.js-CJgfVvxa.js';
import '../../../../../chunks/CloseTicketConfirmModal.js-ex0CkG3p.js';
import '../../../../../chunks/ErrorAlert.js-DbwaZ_OB.js';
import '../../../../../chunks/TicketCreateAndDetailSidebar.js-BcHSjF3Z.js';
import '../../../../../chunks/PluginManager.js-B5x3OKEW.js';
import '../../../../../chunks/internal.js-BlXt2rfE.js';
import 'fs';
import '../../../../../chunks/Sidebar.js-BwVxP8m2.js';
import '../../../../../chunks/ViewComponent.js-C6amYVVM.js';
import '../../../../../chunks/OnlineAdmins.js-FcRIIIBU.js';
import '../../../../../chunks/tooltip.util.js-Bd9x5X7L.js';
import '../../../../../chunks/stores.js-QbD2A2ib.js';
import '../../../../../chunks/NoContent.js-BBe0Mapz.js';
import '../../../../../chunks/CardHeader.js-DpkWpoy6.js';
import '../../../../../chunks/TicketStatus.js-GhIwl1A5.js';

//#region src/routes/(theme)/ticket/[id]/+page.svelte
function _page($$renderer, $$props) {
	let data = $$props["data"];
	TicketDetailPage($$renderer, { data });
	bind_props($$props, { data });
}

export { _page as default };
//# sourceMappingURL=_page.svelte.js-CE_VzzbI.js.map
