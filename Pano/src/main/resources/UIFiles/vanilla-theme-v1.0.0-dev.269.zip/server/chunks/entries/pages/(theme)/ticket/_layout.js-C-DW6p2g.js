import { l as load } from '../../../../chunks/TicketsLayout.js-OiCrCQml.js';

var _layout = /*#__PURE__*/Object.freeze({
	__proto__: null,
	load: load
});

export { _layout as _ };
//# sourceMappingURL=_layout.js-C-DW6p2g.js.map
