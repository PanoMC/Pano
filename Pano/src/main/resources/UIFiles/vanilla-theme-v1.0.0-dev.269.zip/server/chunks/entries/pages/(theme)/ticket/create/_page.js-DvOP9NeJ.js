import { l as load } from '../../../../../chunks/CreateTicketPage.js-BDUrD2Ao.js';

var _page = /*#__PURE__*/Object.freeze({
	__proto__: null,
	load: load
});

export { _page as _ };
//# sourceMappingURL=_page.js-DvOP9NeJ.js.map
