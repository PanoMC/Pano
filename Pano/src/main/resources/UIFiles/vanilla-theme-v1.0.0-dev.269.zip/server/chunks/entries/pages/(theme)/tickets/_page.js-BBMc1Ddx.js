import { l as load } from '../../../../chunks/TicketsPage.js-DCACDGdK.js';

var _page = /*#__PURE__*/Object.freeze({
	__proto__: null,
	load: load
});

export { _page as _ };
//# sourceMappingURL=_page.js-BBMc1Ddx.js.map
