import { W as bind_props } from '../../../../chunks/server.js-D28cBEJ-.js';
import { T as TicketsPage } from '../../../../chunks/TicketsPage.js-DCACDGdK.js';
import '../../../../chunks/uneval.js-BL1Qg77w.js';
import '../../../../chunks/exports2.js-DxZfja4I.js';
import '../../../../chunks/shared.js-3i5_hmQ1.js';
import 'node:module';
import '../../../../chunks/client.js-CPEkJ2-P.js';
import '../../../../chunks/exports.js-CKkpMUqI.js';
import '../../../../chunks/internal2.js-KmQU-gaY.js';
import '../../../../chunks/index-server2.js-DlblWyyK.js';
import '../../../../chunks/rolldown-runtime.js-B5FuG9Gw.js';
import '../../../../chunks/PluginManager.js-B5x3OKEW.js';
import '../../../../chunks/internal.js-BlXt2rfE.js';
import '../../../../chunks/Store.js-C2vdyE6V.js';
import '../../../../chunks/ToastContainer.js-CtmBBvhr.js';
import '../../../../chunks/runtime.js-CJgfVvxa.js';
import 'fs';
import '../../../../chunks/registry2.js-BubD3cPq.js';
import '../../../../chunks/ProfileSidebar.js-BIu8zSKN.js';
import '../../../../chunks/tooltip.util.js-Bd9x5X7L.js';
import '../../../../chunks/stores.js-QbD2A2ib.js';
import '../../../../chunks/PageTitle.js-D99NSXzQ.js';
import '../../../../chunks/PlayerHead.js-Bggv1de7.js';
import '../../../../chunks/Sidebar.js-BwVxP8m2.js';
import '../../../../chunks/ViewComponent.js-C6amYVVM.js';
import '../../../../chunks/PlayerStatusBadge.js-DO05KLuW.js';
import '../../../../chunks/CloseTicketConfirmModal.js-ex0CkG3p.js';
import '../../../../chunks/ErrorAlert.js-DbwaZ_OB.js';

//#region src/routes/(theme)/tickets/+page.svelte
function _page($$renderer, $$props) {
	let data = $$props["data"];
	TicketsPage($$renderer, { data });
	bind_props($$props, { data });
}

export { _page as default };
//# sourceMappingURL=_page.svelte.js-9LmQpFxA.js.map
