import { l as load } from '../../../../chunks/ThemeSettingsLayout.js-C5M-p3G5.js';

var _layout = /*#__PURE__*/Object.freeze({
	__proto__: null,
	load: load
});

export { _layout as _ };
//# sourceMappingURL=_layout.js-DpLKsVuQ.js.map
