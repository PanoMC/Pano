import { a as loadServer } from '../../../../chunks/ThemeSettingsLayout.js-C5M-p3G5.js';

var _layout_server = /*#__PURE__*/Object.freeze({
	__proto__: null,
	load: loadServer
});

export { _layout_server as _ };
//# sourceMappingURL=_layout.server.js-CnU0rXN_.js.map
