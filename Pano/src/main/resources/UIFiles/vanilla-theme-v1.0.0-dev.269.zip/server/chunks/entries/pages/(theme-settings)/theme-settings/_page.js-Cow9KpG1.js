import { l as load } from '../../../../chunks/ThemeSettingsPage.js-LrDRTJ0l.js';

var _page = /*#__PURE__*/Object.freeze({
	__proto__: null,
	load: load
});

export { _page as _ };
//# sourceMappingURL=_page.js-Cow9KpG1.js.map
