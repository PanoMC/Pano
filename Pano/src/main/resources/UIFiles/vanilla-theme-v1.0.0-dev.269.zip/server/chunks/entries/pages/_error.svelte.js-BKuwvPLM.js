import { V as fallback, W as bind_props, g as getContext } from '../../chunks/server.js-D28cBEJ-.js';
import 'node:module';
import '../../chunks/client.js-CPEkJ2-P.js';
import { r as resolveView } from '../../chunks/registry2.js-BubD3cPq.js';
import '../../chunks/uneval.js-BL1Qg77w.js';
import '../../chunks/shared.js-3i5_hmQ1.js';
import '../../chunks/exports.js-CKkpMUqI.js';
import '../../chunks/internal2.js-KmQU-gaY.js';
import '../../chunks/index-server2.js-DlblWyyK.js';
import '../../chunks/rolldown-runtime.js-B5FuG9Gw.js';

//#endregion
//#region node_modules/@sveltejs/kit/src/runtime/app/state/server.js
function context() {
	return getContext("__request__");
}
//#endregion
//#region node_modules/@sveltejs/kit/src/runtime/app/state/index.js
/**
* A read-only reactive object with information about the current page, serving several use cases:
* - retrieving the combined `data` of all pages/layouts anywhere in your component tree (also see [loading data](https://svelte.dev/docs/kit/load))
* - retrieving the current value of the `form` prop anywhere in your component tree (also see [form actions](https://svelte.dev/docs/kit/form-actions))
* - retrieving the page state that was set through `goto`, `pushState` or `replaceState` (also see [goto](https://svelte.dev/docs/kit/$app-navigation#goto) and [shallow routing](https://svelte.dev/docs/kit/shallow-routing))
* - retrieving metadata such as the URL you're on, the current route and its parameters, and whether or not there was an error
*
* ```svelte
* <!--- file: +layout.svelte --->
* <script>
* 	import { page } from '$app/state';
* <\/script>
*
* <p>Currently at {page.url.pathname}</p>
*
* {#if page.error}
* 	<span class="red">Problem detected</span>
* {:else}
* 	<span class="small">All systems operational</span>
* {/if}
* ```
*
* Changes to `page` are available exclusively with runes. (The legacy reactivity syntax will not reflect any changes)
*
* ```svelte
* <!--- file: +page.svelte --->
* <script>
* 	import { page } from '$app/state';
* 	const id = $derived(page.params.id); // This will correctly update id for usage on this page
* 	$: badId = page.params.id; // Do not use; will never update after initial load
* <\/script>
* ```
*
* On the server, values can only be read during rendering (in other words _not_ in e.g. `load` functions). In the browser, the values can be read at any time.
*
* @type {import('@sveltejs/kit').Page}
*/
var page = {
	get data() {
		return context().page.data;
	},
	get error() {
		return context().page.error;
	},
	get form() {
		return context().page.form;
	},
	get params() {
		return context().page.params;
	},
	get route() {
		return context().page.route;
	},
	get state() {
		return context().page.state;
	},
	get status() {
		return context().page.status;
	},
	get url() {
		return context().page.url;
	}
};
//#endregion
//#region node_modules/@panomc/theme-core/src/lib/pages/ErrorPage.svelte
var viewPromise = resolveView("ErrorView", () => import('../../chunks/ErrorView.js-BTyrvSYN.js'));
var resolvedView;
viewPromise.then((view) => resolvedView = view);
function ErrorPage($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		let data = fallback($$props["data"], void 0);
		let View = resolvedView;
		if (!View) viewPromise.then((view) => View = view);
		if (data?.View ?? View) {
			$$renderer.push("<!--[-->");
			(data?.View ?? View)($$renderer, {
				data,
				page
			});
			$$renderer.push("<!--]-->");
		} else {
			$$renderer.push("<!--[!-->");
			$$renderer.push("<!--]-->");
		}
		bind_props($$props, { data });
	});
}
//#endregion
//#region src/routes/+error.svelte
function _error($$renderer) {
	ErrorPage($$renderer, {});
}

export { _error as default };
//# sourceMappingURL=_error.svelte.js-BKuwvPLM.js.map
