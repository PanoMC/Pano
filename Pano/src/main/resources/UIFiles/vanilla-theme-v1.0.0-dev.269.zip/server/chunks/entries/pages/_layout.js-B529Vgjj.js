import { s as setThemeConfig } from '../../chunks/registry2.js-BubD3cPq.js';
import { l as load$1 } from '../../chunks/AppLayout.js-DAJIOVN_.js';
import { l as load$2 } from '../../chunks/MainLayout.js-D6bbLTwz.js';

//#region theme.config.js
/**
* vanilla-theme is the reference thin theme: it overrides nothing, so every
* page renders @panomc/theme-core's default views. Use this file to:
*   - override views:      views: { LoginView: () => import("./src/views/LoginView.svelte") }
*   - extend the settings schema: settingsSchema: [...]
*/
var theme_config_default = { views: {} };
//#endregion
//#region node_modules/@panomc/theme-core/src/routes/root-layout-load.js
/**
* @type {import("@sveltejs/kit").LayoutLoad}
*/
async function load(event) {
	const appData = await load$1(event);
	const mainData = await load$2(event);
	return {
		...appData,
		...mainData
	};
}
//#endregion
//#region src/routes/+layout.js
setThemeConfig(theme_config_default);

var _layout = /*#__PURE__*/Object.freeze({
	__proto__: null,
	load: load
});

export { _layout as _ };
//# sourceMappingURL=_layout.js-B529Vgjj.js.map
