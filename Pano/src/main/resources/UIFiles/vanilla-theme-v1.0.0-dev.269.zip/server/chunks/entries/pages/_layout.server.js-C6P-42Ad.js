import { a as loadServer } from '../../chunks/AppLayout.js-DAJIOVN_.js';

var _layout_server = /*#__PURE__*/Object.freeze({
	__proto__: null,
	load: loadServer
});

export { _layout_server as _ };
//# sourceMappingURL=_layout.server.js-C6P-42Ad.js.map
