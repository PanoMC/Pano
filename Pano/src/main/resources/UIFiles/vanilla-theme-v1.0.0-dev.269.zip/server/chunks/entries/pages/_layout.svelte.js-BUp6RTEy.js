import { W as bind_props, a0 as store_get, a2 as unsubscribe_stores, _ as slot } from '../../chunks/server.js-D28cBEJ-.js';
import 'node:module';
import { p as page } from '../../chunks/stores.js-QbD2A2ib.js';
import '../../chunks/specifiers.js-DAH8di1Y.js';
import { b as AppLayout } from '../../chunks/AppLayout.js-DAJIOVN_.js';
import { a as MainLayout } from '../../chunks/MainLayout.js-D6bbLTwz.js';
import '../../chunks/uneval.js-BL1Qg77w.js';
import '../../chunks/client.js-CPEkJ2-P.js';
import '../../chunks/shared.js-3i5_hmQ1.js';
import '../../chunks/exports.js-CKkpMUqI.js';
import '../../chunks/internal2.js-KmQU-gaY.js';
import '../../chunks/index-server2.js-DlblWyyK.js';
import '../../chunks/rolldown-runtime.js-B5FuG9Gw.js';
import '../../chunks/exports2.js-DxZfja4I.js';
import '../../chunks/internal.js-BlXt2rfE.js';
import '../../chunks/runtime.js-CJgfVvxa.js';
import '../../chunks/PluginManager.js-B5x3OKEW.js';
import '../../chunks/Store.js-C2vdyE6V.js';
import '../../chunks/ToastContainer.js-CtmBBvhr.js';
import 'fs';
import '../../chunks/registry2.js-BubD3cPq.js';
import '../../chunks/copy-to-clipboard.js-CF5RgzCy.js';
import '../../chunks/language.util.js-C2xYQq5-.js';
import '../../chunks/tooltip.util.js-Bd9x5X7L.js';
import '../../chunks/auth.util.js-BGCV_dhB.js';
import '../../chunks/Date.js-ZK3lGml2.js';
import '../../chunks/locale.js-DnnPB87K.js';
import '../../chunks/format.js-CzDFIcjs.js';
import '../../chunks/Pagination.js-CeyG1SGU.js';
import '../../chunks/NoContent.js-BBe0Mapz.js';
import '../../chunks/PageActions.js-CkhIQPLY.js';
import '../../chunks/PageTitle.js-D99NSXzQ.js';
import '../../chunks/PlayerHead.js-Bggv1de7.js';

//#endregion
//#region node_modules/@panomc/theme-core/src/routes/RootLayout.svelte
function RootLayout($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		var $$store_subs;
		let isThemeSettings, isResetLayout, showMainLayout;
		let data = $$props["data"];
		isThemeSettings = store_get($$store_subs ??= {}, "$page", page).route.id?.includes("(theme-settings)");
		isResetLayout = store_get($$store_subs ??= {}, "$page", page).data.resetLayout;
		showMainLayout = !isThemeSettings && !isResetLayout;
		AppLayout($$renderer, {
			data,
			children: ($$renderer) => {
				if (showMainLayout) {
					$$renderer.push("<!--[0-->");
					MainLayout($$renderer, {
						children: ($$renderer) => {
							$$renderer.push(`<!--[-->`);
							slot($$renderer, $$props, "default", {}, null);
							$$renderer.push(`<!--]-->`);
						},
						$$slots: { default: true }
					});
				} else {
					$$renderer.push("<!--[-1-->");
					$$renderer.push(`<!--[-->`);
					slot($$renderer, $$props, "default", {}, null);
					$$renderer.push(`<!--]-->`);
				}
				$$renderer.push(`<!--]-->`);
			},
			$$slots: { default: true }
		});
		if ($$store_subs) unsubscribe_stores($$store_subs);
		bind_props($$props, { data });
	});
}
//#endregion
//#region src/routes/+layout.svelte
function _layout($$renderer, $$props) {
	let data = $$props["data"];
	RootLayout($$renderer, {
		data,
		children: ($$renderer) => {
			$$renderer.push(`<!--[-->`);
			slot($$renderer, $$props, "default", {}, null);
			$$renderer.push(`<!--]-->`);
		},
		$$slots: { default: true }
	});
	bind_props($$props, { data });
}

export { _layout as default };
//# sourceMappingURL=_layout.svelte.js-BUp6RTEy.js.map
