const manifest = (() => {
function __memo(fn) {
	let value;
	return () => value ??= (value = fn());
}

return {
	appDir: "_app",
	appPath: "_app",
	assets: new Set(["assets/.gitkeep","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-300.eot","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-300.svg","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-300.ttf","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-300.woff","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-300.woff2","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-500.eot","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-500.svg","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-500.ttf","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-500.woff","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-500.woff2","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-700.eot","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-700.svg","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-700.ttf","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-700.woff","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-700.woff2","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-regular.eot","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-regular.svg","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-regular.ttf","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-regular.woff","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-regular.woff2","assets/img/404.png","assets/img/default-header-bg.png","assets/img/green.svg","assets/img/logo.svg","assets/img/red.svg","assets/img/yellow.svg","assets/webfonts/fa-brands-400.ttf","assets/webfonts/fa-brands-400.woff2","assets/webfonts/fa-regular-400.ttf","assets/webfonts/fa-regular-400.woff2","assets/webfonts/fa-solid-900.ttf","assets/webfonts/fa-solid-900.woff2","assets/webfonts/fa-v4compatibility.ttf","assets/webfonts/fa-v4compatibility.woff2","lib/be8641ae3b66de78/bootstrap/bootstrap.bundle.min.js","robots.txt","runtime/sdk/components-panel.js","runtime/sdk/components-theme.js","runtime/sdk/index.js","runtime/sdk/internal.js","runtime/sdk/svelte.js","runtime/sdk/toasts.js","runtime/sdk/utils-api.js","runtime/sdk/utils-auth.js","runtime/sdk/utils-component.js","runtime/sdk/utils-language.js","runtime/sdk/utils-text.js","runtime/sdk/utils-tooltip.js","runtime/sdk/variables.js","runtime/svelte/animate.js","runtime/svelte/attachments.js","runtime/svelte/easing.js","runtime/svelte/events.js","runtime/svelte/i18n.js","runtime/svelte/index.js","runtime/svelte/internal-client.js","runtime/svelte/internal-disclose-version.js","runtime/svelte/internal-flags-async.js","runtime/svelte/internal-flags-legacy.js","runtime/svelte/internal-flags-tracing.js","runtime/svelte/internal.js","runtime/svelte/legacy.js","runtime/svelte/motion.js","runtime/svelte/reactivity-window.js","runtime/svelte/reactivity.js","runtime/svelte/store.js","runtime/svelte/transition.js"]),
	mimeTypes: {".svg":"image/svg+xml",".ttf":"font/ttf",".woff":"font/woff",".woff2":"font/woff2",".png":"image/png",".js":"text/javascript",".txt":"text/plain"},
	_: {
		client: {start:"_app/immutable/entry/start.BWRorWCf.js",app:"_app/immutable/entry/app.p8842KZj.js",imports:["_app/immutable/entry/start.BWRorWCf.js","_app/immutable/chunks/Blb7-VIZ.js","_app/immutable/chunks/Biz4eTeZ.js","_app/immutable/chunks/DUIz69l0.js","_app/immutable/chunks/W9ntaSi6.js","_app/immutable/chunks/DgaXQ5Dw.js","_app/immutable/chunks/QTnfLwEv.js","_app/immutable/chunks/CYMlyaez.js","_app/immutable/chunks/8sTG5F_A.js","_app/immutable/chunks/UUqK8TMg.js","_app/immutable/entry/app.p8842KZj.js","_app/immutable/chunks/Biz4eTeZ.js","_app/immutable/chunks/DUIz69l0.js","_app/immutable/chunks/W9ntaSi6.js","_app/immutable/chunks/DgaXQ5Dw.js","_app/immutable/chunks/QTnfLwEv.js","_app/immutable/chunks/CYMlyaez.js","_app/immutable/chunks/8sTG5F_A.js","_app/immutable/chunks/HclGiUj8.js","_app/immutable/chunks/mflOPTHH.js","_app/immutable/chunks/xihTtKlq.js"],stylesheets:[],fonts:[],uses_env_dynamic_public:false},
		nodes: [
			__memo(() => import('./nodes/0.js-Dlss9U8U.js')),
			__memo(() => import('./nodes/1.js-oTn8QmgZ.js')),
			__memo(() => import('./nodes/2.js-BuwwYI8r.js')),
			__memo(() => import('./nodes/3.js-D9PE3ay0.js')),
			__memo(() => import('./nodes/4.js-pGm8cOab.js')),
			__memo(() => import('./nodes/5.js-BO58vZ_u.js')),
			__memo(() => import('./nodes/6.js-DkkUh_G1.js')),
			__memo(() => import('./nodes/7.js-CK0jpEtQ.js')),
			__memo(() => import('./nodes/8.js-zvuAK6lt.js')),
			__memo(() => import('./nodes/9.js-8c4ezB8L.js')),
			__memo(() => import('./nodes/10.js-1A8FA2fW.js')),
			__memo(() => import('./nodes/11.js-DWv_xDtU.js')),
			__memo(() => import('./nodes/12.js-DAy-GVRr.js')),
			__memo(() => import('./nodes/13.js-ooQnrm7u.js')),
			__memo(() => import('./nodes/14.js-BgjhxZPZ.js')),
			__memo(() => import('./nodes/15.js-CVYG0Lsa.js')),
			__memo(() => import('./nodes/16.js-BwAxYPkU.js')),
			__memo(() => import('./nodes/17.js-CPnq0qOm.js')),
			__memo(() => import('./nodes/18.js-ClDAnlel.js')),
			__memo(() => import('./nodes/19.js-xf51L820.js')),
			__memo(() => import('./nodes/20.js-CxDJ0OfL.js')),
			__memo(() => import('./nodes/21.js-CnE8iJbB.js')),
			__memo(() => import('./nodes/22.js-DYIogoFm.js')),
			__memo(() => import('./nodes/23.js-jCDjNz1b.js')),
			__memo(() => import('./nodes/24.js-BzS6Jr89.js')),
			__memo(() => import('./nodes/25.js-BBRFc2jx.js')),
			__memo(() => import('./nodes/26.js-Ct6GO8Yl.js')),
			__memo(() => import('./nodes/27.js-CVO0qITb.js')),
			__memo(() => import('./nodes/28.js-DC5pQoGH.js')),
			__memo(() => import('./nodes/29.js-CrUES94z.js')),
			__memo(() => import('./nodes/30.js-TxW9l6Pf.js'))
		],
		remotes: {
			
		},
		routes: [
			{
				id: "/(theme)",
				pattern: /^\/$/,
				params: [],
				page: { layouts: [0,3,], errors: [1,,], leaf: 12 },
				endpoint: null
			},
			{
				id: "/(theme)/activate-new-email",
				pattern: /^\/activate-new-email\/?$/,
				params: [],
				page: { layouts: [0,3,], errors: [1,,], leaf: 14 },
				endpoint: null
			},
			{
				id: "/(theme)/activate",
				pattern: /^\/activate\/?$/,
				params: [],
				page: { layouts: [0,3,], errors: [1,,], leaf: 13 },
				endpoint: null
			},
			{
				id: "/(theme)/login",
				pattern: /^\/login\/?$/,
				params: [],
				page: { layouts: [0,3,4,], errors: [1,,,], leaf: 15 },
				endpoint: null
			},
			{
				id: "/(theme)/notifications",
				pattern: /^\/notifications\/?$/,
				params: [],
				page: { layouts: [0,3,], errors: [1,,], leaf: 16 },
				endpoint: null
			},
			{
				id: "/(theme)/player/[player]",
				pattern: /^\/player\/([^/]+?)\/?$/,
				params: [{"name":"player","optional":false,"rest":false,"chained":false}],
				page: { layouts: [0,3,], errors: [1,,], leaf: 17 },
				endpoint: null
			},
			{
				id: "/(theme)/plugins/[pluginId]/resources/plugin-ui/client/[fileName]",
				pattern: /^\/plugins\/([^/]+?)\/resources\/plugin-ui\/client\/([^/]+?)\/?$/,
				params: [{"name":"pluginId","optional":false,"rest":false,"chained":false},{"name":"fileName","optional":false,"rest":false,"chained":false}],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/(theme)/plugins/_pluginId_/resources/plugin-ui/client/_fileName_/_server.js-TTGOD1Fz.js'))
			},
			{
				id: "/(theme)/post/[url]",
				pattern: /^\/post\/([^/]+?)\/?$/,
				params: [{"name":"url","optional":false,"rest":false,"chained":false}],
				page: { layouts: [0,3,], errors: [1,,], leaf: 18 },
				endpoint: null
			},
			{
				id: "/(theme)/preview/post/[id]",
				pattern: /^\/preview\/post\/([^/]+?)\/?$/,
				params: [{"name":"id","optional":false,"rest":false,"chained":false}],
				page: { layouts: [0,3,], errors: [1,,], leaf: 19 },
				endpoint: null
			},
			{
				id: "/(theme)/profile",
				pattern: /^\/profile\/?$/,
				params: [],
				page: { layouts: [0,3,5,], errors: [1,,,], leaf: 20 },
				endpoint: null
			},
			{
				id: "/(theme)/profile/settings",
				pattern: /^\/profile\/settings\/?$/,
				params: [],
				page: { layouts: [0,3,5,], errors: [1,,,], leaf: 21 },
				endpoint: null
			},
			{
				id: "/(theme)/register",
				pattern: /^\/register\/?$/,
				params: [],
				page: { layouts: [0,3,6,], errors: [1,,,], leaf: 22 },
				endpoint: null
			},
			{
				id: "/(theme)/renew-password",
				pattern: /^\/renew-password\/?$/,
				params: [],
				page: { layouts: [0,3,], errors: [1,,], leaf: 23 },
				endpoint: null
			},
			{
				id: "/(theme)/reset-password",
				pattern: /^\/reset-password\/?$/,
				params: [],
				page: { layouts: [0,3,7,], errors: [1,,,], leaf: 24 },
				endpoint: null
			},
			{
				id: "/(theme)/rules",
				pattern: /^\/rules\/?$/,
				params: [],
				page: { layouts: [0,3,], errors: [1,,], leaf: 25 },
				endpoint: null
			},
			{
				id: "/(theme)/support",
				pattern: /^\/support\/?$/,
				params: [],
				page: { layouts: [0,3,], errors: [1,,], leaf: 26 },
				endpoint: null
			},
			{
				id: "/(theme)/theme-api/languages/[language].json",
				pattern: /^\/theme-api\/languages\/([^/]+?)\.json\/?$/,
				params: [{"name":"language","optional":false,"rest":false,"chained":false}],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/(theme)/theme-api/languages/_language_.json/_server.js-2pX_gEv9.js'))
			},
			{
				id: "/(theme)/theme-api/licenses.json",
				pattern: /^\/theme-api\/licenses\.json\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/(theme)/theme-api/licenses.json/_server.js-DqVBnEmT.js'))
			},
			{
				id: "/(theme-settings)/theme-settings",
				pattern: /^\/theme-settings\/?$/,
				params: [],
				page: { layouts: [0,10,], errors: [1,,], leaf: 30 },
				endpoint: null
			},
			{
				id: "/(theme)/tickets",
				pattern: /^\/tickets\/?$/,
				params: [],
				page: { layouts: [0,3,9,], errors: [1,,,], leaf: 29 },
				endpoint: null
			},
			{
				id: "/(theme)/ticket/create",
				pattern: /^\/ticket\/create\/?$/,
				params: [],
				page: { layouts: [0,3,8,], errors: [1,,,], leaf: 28 },
				endpoint: null
			},
			{
				id: "/(theme)/ticket/[id]",
				pattern: /^\/ticket\/([^/]+?)\/?$/,
				params: [{"name":"id","optional":false,"rest":false,"chained":false}],
				page: { layouts: [0,3,8,], errors: [1,,,], leaf: 27 },
				endpoint: null
			},
			{
				id: "/(plugin-ui)/[...path]",
				pattern: /^(?:\/([^]*))?\/?$/,
				params: [{"name":"path","optional":false,"rest":true,"chained":true}],
				page: { layouts: [0,2,], errors: [1,,], leaf: 11 },
				endpoint: null
			}
		],
		prerendered_routes: new Set([]),
		matchers: async () => {
			
			return {  };
		},
		server_assets: {}
	}
}
})();

export { manifest as m };
//# sourceMappingURL=manifest.js-BLzHi_1F.js.map
