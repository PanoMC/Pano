const index = 1;
let component_cache;
const component = async () => component_cache ??= (await import('../entries/pages/_error.svelte.js-BKuwvPLM.js')).default;
const imports = ["_app/immutable/nodes/1.DPTWGpfP.js","_app/immutable/chunks/Biz4eTeZ.js","_app/immutable/chunks/DUIz69l0.js","_app/immutable/chunks/W9ntaSi6.js","_app/immutable/chunks/DgaXQ5Dw.js","_app/immutable/chunks/QTnfLwEv.js","_app/immutable/chunks/CYMlyaez.js","_app/immutable/chunks/8sTG5F_A.js","_app/immutable/chunks/Blb7-VIZ.js","_app/immutable/chunks/UUqK8TMg.js","_app/immutable/chunks/HclGiUj8.js","_app/immutable/chunks/xihTtKlq.js","_app/immutable/chunks/Cvrue2JE.js","_app/immutable/chunks/DA94XoNu.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=1.js-oTn8QmgZ.js.map
