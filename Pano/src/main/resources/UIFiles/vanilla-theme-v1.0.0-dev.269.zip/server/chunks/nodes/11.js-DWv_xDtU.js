export { _ as universal } from '../entries/pages/(plugin-ui)/_...path_/_page.js-6WRYh3vQ.js';
import '../chunks/Page.js-CHxlFwZT.js';
import '../chunks/server.js-D28cBEJ-.js';
import '../chunks/uneval.js-BL1Qg77w.js';
import 'node:module';

const index = 11;
let component_cache;
const component = async () => component_cache ??= (await import('../entries/pages/(plugin-ui)/_...path_/_page.svelte.js-DOWbyG_p.js')).default;
const universal_id = "src/routes/(plugin-ui)/[...path]/+page.js";
const imports = ["_app/immutable/nodes/11.DuG1aehf.js","_app/immutable/chunks/QTnfLwEv.js","_app/immutable/chunks/Biz4eTeZ.js","_app/immutable/chunks/DUIz69l0.js","_app/immutable/chunks/W9ntaSi6.js","_app/immutable/chunks/DgaXQ5Dw.js","_app/immutable/chunks/CYMlyaez.js","_app/immutable/chunks/8sTG5F_A.js","_app/immutable/chunks/xihTtKlq.js","_app/immutable/chunks/DA94XoNu.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets, universal_id };
//# sourceMappingURL=11.js-DWv_xDtU.js.map
