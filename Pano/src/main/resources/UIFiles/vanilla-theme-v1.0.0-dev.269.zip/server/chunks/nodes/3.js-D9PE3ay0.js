export { _ as universal } from '../entries/pages/(theme)/_layout.js-CrKBASyK.js';

const index = 3;
let component_cache;
const component = async () => component_cache ??= (await import('../entries/pages/(theme)/_layout.svelte.js-C21mq6sJ.js')).default;
const universal_id = "src/routes/(theme)/+layout.js";
const imports = ["_app/immutable/nodes/3.DedKiZy9.js","_app/immutable/chunks/QTnfLwEv.js","_app/immutable/chunks/Biz4eTeZ.js","_app/immutable/chunks/DUIz69l0.js","_app/immutable/chunks/W9ntaSi6.js","_app/immutable/chunks/DgaXQ5Dw.js","_app/immutable/chunks/CYMlyaez.js","_app/immutable/chunks/8sTG5F_A.js","_app/immutable/chunks/xihTtKlq.js","_app/immutable/chunks/DA94XoNu.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets, universal_id };
//# sourceMappingURL=3.js-D9PE3ay0.js.map
