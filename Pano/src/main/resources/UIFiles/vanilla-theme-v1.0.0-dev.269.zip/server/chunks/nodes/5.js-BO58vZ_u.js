export { _ as universal } from '../entries/pages/(theme)/profile/_layout.js-UbnSjAZn.js';
import '../chunks/ProfileLayout.js-B2Aj3-w1.js';
import '../chunks/rolldown-runtime.js-B5FuG9Gw.js';
import 'node:module';
import '../chunks/server.js-D28cBEJ-.js';
import '../chunks/uneval.js-BL1Qg77w.js';
import '../chunks/stores.js-QbD2A2ib.js';
import '../chunks/client.js-CPEkJ2-P.js';
import '../chunks/shared.js-3i5_hmQ1.js';
import '../chunks/exports.js-CKkpMUqI.js';
import '../chunks/internal2.js-KmQU-gaY.js';
import '../chunks/index-server2.js-DlblWyyK.js';
import '../chunks/registry2.js-BubD3cPq.js';
import '../chunks/Store.js-C2vdyE6V.js';
import '../chunks/exports2.js-DxZfja4I.js';
import '../chunks/ToastContainer.js-CtmBBvhr.js';
import '../chunks/runtime.js-CJgfVvxa.js';

const index = 5;
let component_cache;
const component = async () => component_cache ??= (await import('../entries/pages/(theme)/profile/_layout.svelte.js-BbjWSnyz.js')).default;
const universal_id = "src/routes/(theme)/profile/+layout.js";
const imports = ["_app/immutable/nodes/5.Dd0Wd-yj.js","_app/immutable/chunks/QTnfLwEv.js","_app/immutable/chunks/Biz4eTeZ.js","_app/immutable/chunks/DUIz69l0.js","_app/immutable/chunks/W9ntaSi6.js","_app/immutable/chunks/DgaXQ5Dw.js","_app/immutable/chunks/CYMlyaez.js","_app/immutable/chunks/8sTG5F_A.js","_app/immutable/chunks/xihTtKlq.js","_app/immutable/chunks/DA94XoNu.js","_app/immutable/chunks/BTcjKX9J.js","_app/immutable/chunks/HclGiUj8.js","_app/immutable/chunks/Cvrue2JE.js","_app/immutable/chunks/BsJMi3BR2.js","_app/immutable/chunks/Blb7-VIZ.js","_app/immutable/chunks/UUqK8TMg.js","_app/immutable/chunks/LaARUoH62.js","_app/immutable/chunks/kMMNL7gb.js","_app/immutable/chunks/CBwcy369.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets, universal_id };
//# sourceMappingURL=5.js-BO58vZ_u.js.map
